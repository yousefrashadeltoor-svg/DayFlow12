# Dayflow AI assistant (agent)

- **Bring your own key.** 29 providers (renewing free tiers first: Groq, Google Gemini, OpenRouter, NVIDIA NIM, Cloudflare Workers AI, Hugging Face, SambaNova, Z.ai, SiliconFlow, Cohere, Vercel AI Gateway; then trial, paid and local: Ollama, LM Studio, any OpenAI-compatible URL).
- Free-tier facts were checked against several independent comparisons dated Aug–Nov 2026. They change often (GitHub Models was retired 2026-07-30, Cerebras became a card-required trial, Mistral free API access is disputed), so **model lists are loaded live from each provider's `/models` endpoint**, and OpenRouter free models are detected from the **real per-model price** the API returns.
- Logos: LobeHub Icons (MIT), bundled locally.
- **Agent tools** (`src/services/ai/tools.ts`): read your day, search, stats, prayer times, tasks, alarms; create/update/delete/start/complete activities, plan a whole day, apply plans; create/update/delete/skip alarms (real native alarms); tasks; notes; journal; occasions; water; prayers; habits; goals; focus timer; themes/decor/settings; open screens. Every change is undoable; deletes need approval by default (setting: auto / confirm deletes / confirm all).
- Models without native tool calling switch automatically to a text tool protocol (remembered per model).
- **Privacy:** the only feature that uses the network. Consent screen first; keys stored on-device in `state/aiKeys` and excluded from backups; optional daily summary can be turned off.
- **Android:** requests use Capacitor native HTTP (no CORS). Cleartext HTTP only for localhost / 10.0.2.2 (local models).
- Tests: `src/tests/agent.test.ts` (simulated provider): multi-action request, undo, approval flow, text-protocol fallback, honest errors, live model list + free detection.
