# What's new in v2 (review + feature pass)

## Android logic fixes found during review
| Problem | Fix |
|---|---|
| Snooze alarms had kind `block`, so the next web sync **cancelled them** | Snoozes are now kind `snooze` with `refKind` (block/task) – never touched by sync |
| Sync cancelled alarms whose notification was still on screen | Only pending alarms (`scheduled/escalating/snoozed`) are cancelled |
| Opening the app from a notification did not stop the escalation | `MainActivity` acknowledges the alarm (DISMISS) and routes to the right screen |
| Unrelated notification actions could silence a ringing alarm clock | `stopAudio` ignores other keys while a `ua:` alarm rings |
| Exact alarms off by default on Android 14 | `USE_EXACT_ALARM` declared (alarm/calendar app) + `setAlarmClock` for user alarms (no permission needed) |
| Widgets only refreshed on data change | Chronometer countdown (ticks by itself) + a wake-up alarm at the next block start/end, prayer, midnight |
| Widget refresh used a broadcast round-trip | Providers are updated directly |
| Drafts could be converted to "missed" | `sweepPast` skips drafts; stats exclude drafts |
| `init()` ran twice under StrictMode/remounts | Idempotent |

## Native additions (Kotlin)
`UserAlarms` (real alarm clocks, self-perpetuating, snooze limits, one-time auto-disable), `AlarmRingActivity` (full-screen over lock screen, pulse animation),
`PrayerEngine` (offline astronomy, 7-day alarms, pre-prayer alert, persistent notification with live countdown, "I prayed" logging), `Maintenance` (daily 00:05 renewal),
`SegmentPlayer` (trimmed + looping playback), prayer widget (progress ring bitmap, chronometer, tally, button), occasion/tasks lines in all widgets,
plugin: `pickRingtone` (system tone picker), `pickMusic` (media library picker → copied → trim), `configurePrayer`, `getAudioInfo`, full-screen-intent helpers.

## Web layer
Calendar (Gregorian + Hijri, occasions, official-holiday flag, red-flagged other-religion occasions, add occasion/task/activity per day), Plan grid with lane layout + drag/resize + long-press add + Apply-plan flow,
Journal, Alarms + sound picker + waveform trimmer, Egypt prayer screen (27 governorates + cities), 13 themes with live previews, seasonal/time-of-day decor (Fluent 3D + Pexels, bundled), organised settings with green "?" help sheets (Egyptian dialect), welcome tour.
