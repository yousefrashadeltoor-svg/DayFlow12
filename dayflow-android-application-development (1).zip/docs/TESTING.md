# DAYFLOW — Test plan

## Automated
- `npm test` — scheduling engine (fixed protection, overlaps, buffers, windows, dependencies, delayed blocks, insufficient time, multi-deadline placement, splitting, recurrence incl. DST, what-if immutability, determinism), SRS, CSV, rules, prayer.
- `npm run typecheck` — strict TypeScript.
- `cd android && ./gradlew testDebugUnitTest` — Kotlin wall-clock conversion tests.

## Manual Android checklist (run on ≥ 2 physical devices)
| # | Scenario | Expected |
|---|---|---|
| 1 | Grant notifications, create block 3 min ahead, lock screen | Notification on time with Done / Snooze / Skip |
| 2 | Tap **Done** from shade with app killed | Block becomes Completed when app reopens; widget updates |
| 3 | **Snooze 10** | New notification 10 min later; Reliability ▸ actions log shows SNOOZE_10 ok |
| 4 | Tap Done twice quickly / tap stale notification | Second tap logged `duplicate` / `stale`, no double update |
| 5 | Revoke exact-alarm access | Reminders listed as *Inexact*; Reliability Center shows warning |
| 6 | Reboot device | Reliability ▸ Reboot recovery shows restored count; alarms still fire |
| 7 | Change time zone | Alarms re-registered to local wall-clock time |
| 8 | Custom MP3 sound / delete file | Plays file; when missing falls back to TTS, then alarm tone |
| 9 | Battery saver + Doze (`adb shell dumpsys deviceidle force-idle`) | Exact alarms still delivered (allow-while-idle) |
| 10 | App update over existing install | Data and alarms preserved (MY_PACKAGE_REPLACED restore) |
| 11 | Backup → wipe → restore (merge & replace) | Records identical |
| 12 | Import invalid CSV | Rows flagged; nothing imported until confirmed |

## 7-day alarm log template
| Date | Device / Android | Permissions | Reminder | Expected | Actual | Locked? | Fg/Bg | Rebooted? | Action OK? |
|---|---|---|---|---|---|---|---|---|---|


## Added in v2 — manual checks (physical devices)
| # | Scenario | Expected |
|---|---|---|
| 13 | Create an alarm 2 min ahead with a song trimmed to 10 s, lock the phone | Full-screen ring over the lock screen, only the trimmed part loops, Snooze/Stop work |
| 14 | Reboot / change time zone with a repeating alarm | Alarm still rings at the right local time (Reliability ▸ reboot recovery) |
| 15 | Choose a ringtone via *Phone ringtone* | Android's own picker opens (not the file manager) |
| 16 | Enable prayer alerts, never open the app for 3 days | Prayer alerts keep arriving (daily maintenance alarm) |
| 17 | Tap *I prayed* in the notification and in the widget | Tally updates in app, widget and persistent notification |
| 18 | Add a block in Plan (draft) | No reminder / widget until *Apply plan*; History + Journal show the applied plan |
| 19 | Add an occasion for tomorrow | Morning notification + widget line the next day; Christian/Jewish occasions never appear there |
| 20 | Widgets: compact / medium / large / prayer | Countdown ticks, Done/Start/I-prayed buttons update records |
