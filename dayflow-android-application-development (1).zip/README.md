# DAYFLOW · مدير اليوم

نظام شخصي متكامل لتخطيط اليوم وتنفيذه وفهمه — يعمل دون اتصال، وبياناتك تبقى على جهازك.
A premium, offline-first personal life-management app. **React + Vite + TypeScript + Tailwind** UI running inside **Capacitor 7**, with a **custom Kotlin native layer** (AlarmManager, notification actions, boot recovery, TTS/audio service, SQLite, home-screen widgets).

---

## 1. البناء على أندرويد ستوديو / Build in Android Studio

Requirements: **Node 20+**, **JDK 21**, **Android Studio (Ladybug or newer)**, Android SDK 35.

```bash
npm ci                 # install exact locked dependencies
npm test               # 27 unit tests (scheduling engine, recurrence, SRS, CSV, rules, prayer)
npm run build          # build the web layer into dist/
npx cap sync android   # copy dist/ into android/app/src/main/assets/public
npx cap open android   # or open the android/ folder in Android Studio
```

Then in Android Studio: **Build ▸ Build App Bundle(s) / APK(s) ▸ Build APK(s)**, or run on a device.
CLI alternative: `cd android && ./gradlew assembleDebug` → `android/app/build/outputs/apk/debug/app-debug.apk`.

> After every change in `src/`, run `npm run build && npx cap sync android` again.

### Release signing
Never commit keys. Provide them as environment variables (or `~/.gradle/gradle.properties`):
`DAYFLOW_KEYSTORE_PATH`, `DAYFLOW_KEYSTORE_PASSWORD`, `DAYFLOW_KEY_ALIAS`, `DAYFLOW_KEY_PASSWORD`, then `./gradlew assembleRelease`.

### GitHub Actions
`.github/workflows/android.yml` installs from the lockfile, type-checks, runs tests, builds the web app, syncs Capacitor, runs Kotlin unit tests, builds the debug APK and uploads it as an artifact. A manual run with `release: true` builds a signed APK using the secrets `DAYFLOW_KEYSTORE_BASE64`, `DAYFLOW_KEYSTORE_PASSWORD`, `DAYFLOW_KEY_ALIAS`, `DAYFLOW_KEY_PASSWORD`. Failures fail the job — nothing is reported as successful unless Gradle succeeded.

---

## 2. Architecture

```
src/
  models/types.ts                 – complete relational domain model (45 collections)
  services/database/db.ts         – StorageAdapter: native SQLite (Android) / IndexedDB (web), atomic batches, migrations
  services/native/dayflowNative.ts– typed bridge to the Kotlin plugin (error codes, honest web fallbacks)
  services/scheduling/engine.ts   – deterministic scheduler: conflicts, repack, catch-up, what-if, split, multi-day placement, recurrence
  services/scheduling/rules.ts    – configurable rules engine with explanations and suggestions
  services/reminders/reminderSync – rolling-horizon alarm set → native AlarmManager (dedup by stable key)
  services/analytics/stats.ts     – statistics, habit streaks, insights (with confidence), burnout awareness, weekly report
  services/backup, services/import– versioned JSON backup (AES-GCM optional), CSV/XLSX import with mapping & validation
  services/prayer.ts, study/srs.ts– offline prayer-time astronomy, configurable spaced repetition
  stores/appStore.ts              – single source of truth, transactional commits with rollback, undo, materialisation
  features/*                      – Today, Plan, Focus, Progress, More + 17 module screens
android/app/src/main/java/com/dayflow/app/
  plugin/DayflowNativePlugin.kt   – Capacitor plugin (all bridge methods)
  data/DayflowDatabase.kt         – SQLiteOpenHelper, stepwise additive migrations, indexes, transactions
  alarm/AlarmScheduler.kt         – exact / inexact AlarmManager scheduling, sync, restore, status
  alarm/Receivers.kt              – AlarmReceiver, NotificationActionReceiver, BootReceiver, ActivityActions (idempotent)
  alarm/NotificationHelper.kt     – channels, grouped notifications, localized action buttons
  audio/AlarmAudioService.kt      – foreground media service: custom file → TTS → alarm tone → system sound
  widget/Widgets.kt               – compact / medium / large AppWidgets + quick-action receiver
```

## 2b. Version 2 highlights (see docs/NEW_IN_V2.md for the review findings)
- **Real alarm clocks** (`AlarmManager.setAlarmClock`): ringtone/alarm-tone picker from Android itself, music from the device's media picker with a **waveform trimmer**, label (+ TTS), repeat days, snooze length/limit, ring duration, gradual volume, vibration, skip-next, full-screen ring screen over the lock screen.
- **Prayer times for all 27 Egyptian governorates** (Egyptian General Authority of Survey method by default, manual ±minutes, Hanafi option): next prayer + live countdown + progress ring, per-prayer alerts, pre-prayer alert, persistent notification, "I prayed" button (notification/widget/app), statistics and streak. Computed offline on the device; renewed daily by a native maintenance alarm.
- **Calendar**: month grid with Hijri days and 3D occasion icons; official-holiday / not-official badge on every occasion; Christian & Jewish occasions are shown **only** in the calendar with a red "!" and the religion name and never reach notifications or widgets; green "?" opens a detail sheet with a real photo; add personal occasions (yearly, notify) and tasks for any day.
- **Plan**: lane layout keeps adjacent/overlapping blocks separate yet fully readable (exact time + note on every block), drag (also across days), resize, long-press to add, **Apply plan** (drafts → reminders/widgets/history/journal).
- **Journal**: mood, energy, gratitude, highlight, lesson, tags, auto day-summary, applied-plan snapshots, prompts, search, stats, writing reminder, export.
- **13 themes** (palette, typography, corner radii, card construction, navigation style, header, overview layout, timeline style) with a live Home preview each.
- **Seasonal decor** (autumn leaves, winter holidays incl. Santa/stockings/snow, spring, summer, Ramadan lanterns, Eid, Hajj, Sham El-Nessim, national days, Mother's Day, New Year) + time-of-day hero; every image is bundled — **the app never touches the network**.
- Settings split into six pages; every unclear item has a green "?" with an Egyptian-dialect explanation. UI text is Egyptian Arabic (English also available).

## 3. Genuinely working functionality
- Activities: create / edit / delete, fixed & flexible, windows, priority, energy, difficulty, prep/cleanup/buffer, dependencies, links, tags, notes.
- Recurrence (daily, selected weekdays, every N weeks, monthly, specific dates, until/count) with per-occurrence detachment and "this / future" edit scope.
- Today dashboard with correct denominators, live current-activity card, all block actions (start, pause, resume, complete, partial %, skip, snooze, cancel, reset, note), timeline with now-line, filters, density, collapse, week navigation.
- Plan: day / 3-day / week hour-grid with drag-and-drop (fixed blocks need confirmation), month, agenda, timeline; templates (9 defaults + unlimited custom), weekday assignment, special dates, day duplication, save-as-template, routines with step check-off.
- Smart engine: conflict detection, resolve proposals, catch-up, what-if (delay / extend / move to tomorrow / add appointment), splitting, before/after history with restore & undo. Nothing is changed without Accept.
- Rules engine (10 rule types) with live violations and one-tap corrections.
- Tasks (lists, checklist, subtasks, dependencies, recurrence, reminders, attachments) with automatic scheduling into free time; Projects with milestones & timeline.
- Study: subject → unit → lesson, dashboard & ETA from real pace, flashcards with configurable SRS, exams with revision blocks.
- Focus timer (6 modes, persistent across navigation/restarts), distraction log & stats, local ambience audio.
- Workouts: plans, execution with rest timer and voice cues, exercise library, history, missed-workout handling, optional metrics.
- Habits (check / numeric / timed / avoid, daily / weekly / custom days, breaks, streaks that never erase history, heatmap).
- Water, meals, sleep logging & reminders; goals linked to tasks/projects/habits/study; notes with rich text, checklists, links, search.
- Analytics (daily / weekly / monthly), insights with confidence & data range, burnout signals, weekly report, CSV/JSON export.
- Backup (JSON, optional AES-256-GCM), preview/diff/merge/replace restore; CSV & XLSX import (mapping, validation, duplicates, overlaps) and export.
- Arabic RTL / English LTR, light / dark / system themes, 6 accents, font scaling, reduced motion; global search & commands.

## 4. Needs Android permissions / system settings
| Capability | Requirement |
|---|---|
| Notifications & action buttons | `POST_NOTIFICATIONS` (Android 13+), requested in context |
| Exact reminders | "Alarms & reminders" special access (Android 12+). Without it reminders are scheduled inexactly and the app shows **Inexact**. |
| Reliable delivery on aggressive OEMs | User must exclude the app from battery optimization (Reliability Center opens the setting) |
| Alarm audio / TTS while ringing | Foreground service type `mediaPlayback`; falls back to channel sound if Android blocks the service start |
| Location for prayer times | Optional, one-shot via WebView geolocation; manual coordinates always available |

## 5. Not implemented / limitations (honest list)
- **App blocking**: not implemented; the Focus screen states this explicitly (no Accessibility misuse).
- **AI coach**: disabled and not connected to any service; no data leaves the device.
- **Calendar provider sync** (Google Calendar) is not implemented.
- Web preview: no native alarms, widgets or notification actions — it shows the computed plan and labels it as *not scheduled*.
- Android shows at most 3 notification buttons at once; the per-activity button order decides which appear.
- Widgets refresh on data changes, alarms, actions and every 30 minutes (Android minimum); "remaining minutes" is not ticking per second.
- Gradle build was **not executed in this environment** (no Android SDK / JDK): the Kotlin sources were reviewed statically but never compiled, so expect to fix small compile errors on the first Android Studio build. No APK is claimed.
- Widget text direction follows the *device* language (RemoteViews cannot be forced RTL per app language).
- Hijri dates use the Umm al-Qura calendar via the platform; Egypt's Dar al-Ifta may differ by one day — use *Hijri date adjustment*.
- Ringtone/music pickers are OEM-provided screens; their look differs per phone.
- `USE_EXACT_ALARM` is restricted by Google Play policy to alarm/calendar apps (this app qualifies); sideloaded builds are unaffected.
- Images/3D icons are inlined into `dist/index.html` (~5 MB) so the app is 100 % offline.
- The 7-day, two-device alarm acceptance test (spec §36) must be run on physical devices — see `docs/TESTING.md`.
