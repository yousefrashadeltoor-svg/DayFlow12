// @vitest-environment jsdom
process.env.TZ = 'Africa/Cairo';
import 'fake-indexeddb/auto';
import { describe, it, expect, beforeAll, vi } from 'vitest';
import { useApp } from '@/stores/appStore';
import { decide, newChat, send, setKey, undo } from '@/services/ai/agent';
import { listModels } from '@/services/ai/client';
import { PROVIDERS, providerById } from '@/services/ai/providers';
import { isFreeModel } from '@/features/assistant/Providers';
import { addDays, todayKey } from '@/utils/date';

type Reply = { content?: string; tool_calls?: { id: string; function: { name: string; arguments: string } }[] } | { status: number; error: string };
let script: Reply[] = [];
const requests: { url: string; body: any }[] = []; // eslint-disable-line @typescript-eslint/no-explicit-any
const call = (id: string, name: string, args: unknown) => ({ id, function: { name, arguments: JSON.stringify(args) } });

beforeAll(async () => {
  (window as any).matchMedia = (q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {} }); // eslint-disable-line @typescript-eslint/no-explicit-any
  vi.stubGlobal('fetch', async (url: string, init: RequestInit) => {
    const body = init.body ? JSON.parse(String(init.body)) : null;
    requests.push({ url, body });
    if (url.endsWith('/models')) return new Response(JSON.stringify({ data: [
      { id: 'meta-llama/llama-3.3-70b-instruct:free', pricing: { prompt: '0', completion: '0' }, supported_parameters: ['tools'], context_length: 131072 },
      { id: 'openai/gpt-4.1', pricing: { prompt: '0.000002', completion: '0.000008' }, supported_parameters: ['tools'] },
      { id: 'text-embedding-3-small' } ] }), { status: 200 });
    const r = script.shift() ?? { content: 'done' };
    if ('status' in r) return new Response(JSON.stringify({ error: { message: r.error } }), { status: r.status });
    return new Response(JSON.stringify({ choices: [{ message: { role: 'assistant', content: r.content ?? null, tool_calls: r.tool_calls } }], usage: { prompt_tokens: 10, completion_tokens: 5 } }), { status: 200 });
  });
  await useApp.getState().init();
  const s = useApp.getState().data.settings.app;
  await useApp.getState().updateSettings({ onboarded: true, ai: { ...s.ai, consent: true, providerId: 'groq', modelId: 'openai/gpt-oss-120b', execution: 'confirm_destructive' } });
  await setKey('groq', 'gsk_test');
});

const freshChat = async () => { const c = newChat(useApp.getState().data.settings.app); await useApp.getState().put('aiChats', c); return c.id; };
const last = (id: string) => useApp.getState().data.aiChats[id].messages;

describe('AI agent executes real app actions', () => {
  it('creates a repeating alarm, a planned+applied activity, a task and a journal entry from one request', async () => {
    const tomorrow = addDays(todayKey(), 1);
    script = [
      { content: '', tool_calls: [
        call('c1', 'create_alarm', { time: '06:30', label: 'صحيان الشغل', days: ['workdays'] }),
        call('c2', 'create_activity', { title: 'مذاكرة فيزياء', date: tomorrow, start: '09:00', duration_min: 120, category: 'study', notes: 'الفصل التالت' }),
        call('c3', 'create_task', { title: 'تسليم المشروع', due_date: tomorrow, priority: 5 }),
        call('c4', 'write_journal', { text: 'النهاردة كان يوم حلو', mood: 4 }),
      ] },
      { content: 'تمام! عملتلك المنبه والمذاكرة والمهمة وكتبت في يومياتك ✅' },
    ];
    const id = await freshChat();
    await send(id, 'اعملي منبه ٦:٣٠ أيام الشغل ومذاكرة بكرة ٩ الصبح ساعتين ومهمة تسليم المشروع واكتب في يومياتي');
    const d = useApp.getState().data;
    const alarm = Object.values(d.alarmClocks).find((a) => a.label === 'صحيان الشغل')!;
    expect(alarm.minute).toBe(390); expect(alarm.days).toEqual([0, 1, 2, 3, 4, 6]); expect(alarm.enabled).toBe(true);
    const act = Object.values(d.activities).find((b) => b.title === 'مذاكرة فيزياء')!;
    expect(act.date).toBe(tomorrow); expect(act.startMin).toBe(540); expect(act.durationMin).toBe(120); expect(act.applied).toBe(true); expect(act.notes).toBe('الفصل التالت');
    expect(Object.values(d.tasks).find((t) => t.title === 'تسليم المشروع')?.priority).toBe(5);
    expect(d.journal[todayKey()].body).toContain('يوم حلو'); expect(d.journal[todayKey()].mood).toBe(4);
    const msgs = last(id);
    expect(msgs.filter((m) => m.role === 'tool')).toHaveLength(4);
    const runs = msgs.find((m) => m.role === 'assistant' && m.runs?.length)!.runs!;
    expect(runs.every((r) => r.status === 'done')).toBe(true);
    expect(runs.find((r) => r.name === 'create_alarm')?.cards?.[0].type).toBe('alarm');
    expect(msgs.at(-1)!.content).toContain('تمام');
    // the second request carried the tool results back to the model
    const second = requests.filter((r) => r.url.endsWith('/chat/completions')).at(-1)!.body;
    expect(second.messages.filter((m: { role: string }) => m.role === 'tool')).toHaveLength(4);
    expect(second.tools.length).toBeGreaterThan(20);
    // undo really removes the alarm
    const aMsg = msgs.find((m) => m.runs?.length)!;
    expect(await undo(id, aMsg.id, 'c1')).toBe(true);
    expect(Object.values(useApp.getState().data.alarmClocks).some((a) => a.label === 'صحيان الشغل')).toBe(false);
  });

  it('asks for approval before deleting, then deletes only after approval', async () => {
    const t = Date.now();
    await useApp.getState().put('tasks', { id: 'tdel', title: 'مهمة للمسح', description: '', priority: 3, status: 'todo', estimateMin: 30, trackedMin: 0, tags: [], checklist: [], subtasks: [], notes: '', dependsOn: [], starred: false, someday: false, createdAt: t, updatedAt: t });
    script = [{ content: '', tool_calls: [call('d1', 'delete_task', { id: 'tdel' })] }, { content: 'اتمسحت.' }];
    const id = await freshChat();
    await send(id, 'امسح مهمة للمسح');
    const m = last(id).find((x) => x.runs?.length)!;
    expect(m.runs![0].status).toBe('needs_confirm');
    expect(useApp.getState().data.tasks.tdel).toBeTruthy();
    await decide(id, m.id, 'd1', true);
    expect(useApp.getState().data.tasks.tdel).toBeUndefined();
    expect(last(id).at(-1)!.content).toBe('اتمسحت.');
  });

  it('falls back to the text tool protocol when a model rejects native tools', async () => {
    script = [
      { status: 400, error: 'tools are not supported for this model' },
      { content: '```tool\n{"calls":[{"name":"log_water","arguments":{"ml":330}}]}\n```' },
      { content: 'سجّلت ٣٣٠ مل 💧' },
    ];
    const id = await freshChat();
    await send(id, 'سجّل كوباية مية ٣٣٠');
    expect(Object.values(useApp.getState().data.waterLogs).some((w) => w.ml === 330)).toBe(true);
    expect(useApp.getState().data.settings.app.ai.providers.groq?.toolMode?.['openai/gpt-oss-120b']).toBe('json');
    expect(last(id).at(-1)!.content).toContain('٣٣٠');
  });

  it('falls back to another free model on rate limit and marks 404 models as unavailable', async () => {
    // give groq a verified catalogue so an alternate exists
    const st0 = useApp.getState().data.settings.app;
    await useApp.getState().updateSettings({ ai: { ...st0.ai, providers: { ...st0.ai.providers, groq: { enabled: true, modelsFetchedAt: Date.now(), models: [{ id: 'openai/gpt-oss-120b', tools: true, free: true }, { id: 'openai/gpt-oss-20b', tools: true, free: true }] } } } });
    script = [{ status: 429, error: 'rate limit' }, { content: 'ردّيت من البديل ✅' }];
    const id = await freshChat();
    await send(id, 'قول حاجة');
    const m = last(id).at(-1)!;
    expect(m.role).toBe('assistant'); expect(m.modelId).toBe('openai/gpt-oss-20b'); expect(m.fallbackFrom).toBe('openai/gpt-oss-120b');
    script = [{ status: 404, error: 'model not found' }, { content: 'ok' }];
    const id2 = await freshChat();
    await send(id2, 'تاني');
    expect(useApp.getState().data.settings.app.ai.providers.groq?.badModels).toContain('openai/gpt-oss-120b');
    // restore clean state for other tests
    const st1 = useApp.getState().data.settings.app;
    await useApp.getState().updateSettings({ ai: { ...st1.ai, providers: { ...st1.ai.providers, groq: { enabled: true, models: undefined, modelsFetchedAt: undefined, badModels: [] } } } });
  });

  it('reports provider errors honestly instead of pretending', async () => {
    script = [{ status: 401, error: 'invalid api key' }];
    const id = await freshChat();
    await send(id, 'إيه جدولي؟');
    const e = last(id).at(-1)!;
    expect(e.role).toBe('error'); expect(e.content.startsWith('auth|')).toBe(true);
  });

  it('loads real model lists and detects free models from real prices', async () => {
    const p = providerById('openrouter')!;
    const models = await listModels({ provider: p, apiKey: 'k', baseUrl: p.baseUrl });
    expect(models.map((m) => m.id)).toEqual(['meta-llama/llama-3.3-70b-instruct:free', 'openai/gpt-4.1']); // embeddings filtered out
    expect(isFreeModel(p, models[0])).toBe(true); expect(isFreeModel(p, models[1])).toBe(false);
    expect(models[0].tools).toBe(true); expect(models[0].context).toBe(131072);
  });

  it('catalogue: many providers, every one has a bundled logo, free ones first', async () => {
    expect(PROVIDERS.length).toBeGreaterThanOrEqual(25);
    expect(PROVIDERS.filter((p) => p.tier === 'free').length).toBeGreaterThanOrEqual(10);
    const fs = await import('fs');
    for (const p of PROVIDERS) expect(fs.existsSync(`src/assets/ai-logos/${p.logo}.svg`), p.logo).toBe(true);
    expect(isFreeModel(providerById('gemini')!, { id: 'gemini-2.5-flash' })).toBe(true);
    expect(isFreeModel(providerById('gemini')!, { id: 'gemini-2.5-pro' })).toBe(false);
  });
});
