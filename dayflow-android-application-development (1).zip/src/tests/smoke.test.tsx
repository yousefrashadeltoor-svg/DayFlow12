// @vitest-environment jsdom
process.env.TZ = 'Africa/Cairo';
import 'fake-indexeddb/auto';
import { describe, it, expect, beforeAll } from 'vitest';
import { createRoot } from 'react-dom/client';
import { act } from 'react';
import App from '@/App';
import { useApp } from '@/stores/appStore';
import { useUI, type Screen, type Tab } from '@/stores/uiStore';

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function until(fn: () => boolean, ms = 5000) { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (fn()) return; await act(async () => { await wait(80); }); } throw new Error('until() timeout'); }
const errors: string[] = [];

beforeAll(() => {
  (globalThis as unknown as { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
  window.matchMedia = window.matchMedia || ((q: string) => ({ matches: false, media: q, onchange: null, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {}, dispatchEvent: () => false }) as unknown as MediaQueryList);
  window.scrollTo = () => undefined;
  HTMLElement.prototype.scrollIntoView = () => undefined;
  // jsdom lacks Element.scrollTo
  (Element.prototype as unknown as { scrollTo?: unknown }).scrollTo = function (this: Element, opt?: ScrollToOptions | number) { if (typeof opt === 'object' && opt && 'top' in opt) this.scrollTop = Number(opt.top); };
  const origError = console.error;
  console.error = (...a: unknown[]) => { const s = a.map(String).join(' '); if (/Cannot read|is not a function|is not defined|undefined|Minified|Error:/.test(s) && !/act\(|not wrapped|ReactDOMTestUtils/.test(s)) errors.push(s.slice(0, 300)); origError(...a); };
});

describe('app smoke test (web build, IndexedDB)', () => {
  it('boots, seeds data and renders every tab and screen without throwing', async () => {
    const el = document.createElement('div'); document.body.appendChild(el);
    const root = createRoot(el);
    await act(async () => { root.render(<App />); });
    await act(async () => { await wait(400); });
    await until(() => useApp.getState().ready);
    await act(async () => { await wait(300); });
    expect(useApp.getState().fatal).toBeNull();
    // first run shows the welcome tour
    expect(el.textContent).toMatch(/Dayflow|مدير اليوم/);
    expect(el.textContent).toContain('By,Joseph');
    const { ASCII_ART } = await import('@/services/brand');
    expect(ASCII_ART).toBe('█▀▄ ▄▀█ █▄█   █▀▀ █░░ █▀█ █░█░█\n█▄▀ █▀█ ░█░   █▀░ █▄▄ █▄█ ▀▄▀▄▀');
    await act(async () => { await useApp.getState().updateSettings({ onboarded: true, userName: 'أحمد' }); await wait(100); });

    expect(el.querySelector('pre.ascii-mark')?.textContent).toBe('█▀▄ ▄▀█ █▄█   █▀▀ █░░ █▀█ █░█░█\n█▄▀ █▀█ ░█░   █▀░ █▄▄ █▄█ ▀▄▀▄▀');
    const tabs: Tab[] = ['today', 'plan', 'focus', 'assistant', 'progress', 'more'];
    for (const t of tabs) { await act(async () => { useUI.getState().setTab(t); await wait(250); }); expect(el.innerHTML.length).toBeGreaterThan(300); }

    const screens: Screen[] = ['tasks', 'projects', 'study', 'workouts', 'habits', 'wellness', 'goals', 'notes', 'notifications', 'reliability', 'backup', 'settings', 'set_look', 'set_plan', 'set_alerts', 'set_sound', 'set_study', 'set_data', 'rules', 'templates', 'history', 'about', 'prayer', 'alarms', 'calendar', 'journal', 'themes', 'decor', 'ai_providers'];
    for (const sc of screens) {
      await act(async () => { useUI.setState({ tab: 'more', stack: [sc] }); await wait(120); });
      await until(() => el.innerHTML.length > 300 && !el.querySelector('.skeleton'), 6000);
    }
    expect(errors).toEqual([]);
  }, 60000);

  it('apply-plan flow: drafts create no reminders until applied, then log history + journal', async () => {
    const st = useApp.getState();
    await st.updateSettings({ autoApplyPlan: false });
    const { coreFrom } = await import('@/services/defaults');
    const { todayKey } = await import('@/utils/date');
    const { buildDesiredAlarms } = await import('@/services/reminders/reminderSync');
    const tomorrow = new Date(Date.now() + 86400000); const key = `${tomorrow.getFullYear()}-${String(tomorrow.getMonth() + 1).padStart(2, '0')}-${String(tomorrow.getDate()).padStart(2, '0')}`;
    const b = await st.createActivity(coreFrom({ title: 'مذاكرة اختبار', categoryId: 'cat_study', startMin: 17 * 60, durationMin: 60, notes: 'ملاحظة مهمة' }), key);
    expect(b?.applied).toBe(false);
    expect(buildDesiredAlarms(useApp.getState()).some((a) => a.payload.title === 'مذاكرة اختبار')).toBe(false);
    const n = await useApp.getState().applyDayPlan(key);
    expect(n).toBe(1);
    const alarms = buildDesiredAlarms(useApp.getState()).filter((a) => a.payload.title === 'مذاكرة اختبار');
    expect(alarms.length).toBeGreaterThan(0);
    expect(alarms[0].payload.note).toBe('ملاحظة مهمة');
    expect(alarms[0].payload.body).toContain('ساعة'.slice(0, 0));
    const data = useApp.getState().data;
    expect(Object.values(data.scheduleChanges).some((c) => c.kind === 'apply' && c.date === key)).toBe(true);
    expect(data.journal[key]?.plans.length).toBe(1);
    void todayKey;
  }, 20000);

  it('occasions are materialised for native (no other-religion entries) and user occasions are included', async () => {
    const st = useApp.getState();
    const { todayKey } = await import('@/utils/date');
    await st.put('specialDates', { id: 'sd1', date: todayKey(), label: 'عيد ميلاد أحمد', kind: 'special', emoji: 'balloon', yearly: true, notify: true, notifyMin: 480, createdAt: Date.now(), updatedAt: Date.now() });
    await useApp.getState().syncOccasions();
    const occ = Object.values(useApp.getState().data.occasions);
    expect(occ.some((o) => o.title === 'عيد ميلاد أحمد')).toBe(true);
    expect(occ.some((o) => ['coptic_xmas', 'passover', 'hanukkah', 'western_xmas'].includes(o.key))).toBe(false);
  });
});

describe('interactive smoke', () => {
  it('switches through all themes (light/dark), decor levels and plays the welcome tour', async () => {
    const el = document.createElement('div'); document.body.appendChild(el);
    const root = createRoot(el);
    await act(async () => { root.render(<App />); await wait(500); });
    const { THEMES } = await import('@/services/themes');
    for (const th of THEMES) {
      for (const mode of ['light', 'dark'] as const) {
        await act(async () => { await useApp.getState().updateSettings({ themeId: th.id, theme: mode }); await wait(40); });
        expect(document.documentElement.dataset.theme).toBe(th.id);
        expect(document.documentElement.classList.contains('dark')).toBe(mode === 'dark' || !!th.forceDark);
      }
    }
    for (const decor of ['off', 'light', 'full'] as const) await act(async () => { await useApp.getState().updateSettings({ decor }); await wait(30); });
    await act(async () => { await useApp.getState().updateSettings({ language: 'en', themeId: 'gemini', theme: 'light' }); await wait(60); });
    await act(async () => { await useApp.getState().updateSettings({ language: 'ar' }); await wait(60); });
    expect(document.documentElement.dir).toBe('rtl');
    // welcome tour: step through every slide
    await act(async () => { useUI.getState().set({ tourOpen: true }); await wait(60); });
    for (let i = 0; i < 7; i++) {
      const next = [...el.querySelectorAll('button')].find((b) => /يلا نبدأ|التالي|Next|Let's start/.test(b.textContent ?? '') && b.className.includes('flex-1'));
      expect(next, `tour slide ${i}`).toBeTruthy();
      await act(async () => { next!.dispatchEvent(new MouseEvent('click', { bubbles: true })); await wait(40); });
    }
    await act(async () => { useUI.getState().set({ tourOpen: false }); await wait(30); });
    expect(errors).toEqual([]);
  }, 60000);

  it('opens the activity editor, block details, what-if and catch-up sheets with real data', async () => {
    const el = document.createElement('div'); document.body.appendChild(el);
    const root = createRoot(el);
    await act(async () => { root.render(<App />); await wait(400); });
    const st = useApp.getState();
    const { coreFrom } = await import('@/services/defaults');
    const { todayKey } = await import('@/utils/date');
    await st.updateSettings({ autoApplyPlan: true });
    const a = await useApp.getState().createActivity(coreFrom({ title: 'نشاط ١', categoryId: 'cat_work', startMin: 600, durationMin: 30, notes: 'ملاحظة' }), todayKey());
    const b = await useApp.getState().createActivity(coreFrom({ title: 'نشاط ٢', categoryId: 'cat_work', startMin: 610, durationMin: 10 }), todayKey());
    expect(a?.applied).toBe(true); expect(b).toBeTruthy();
    for (const tab of ['today', 'plan'] as const) await act(async () => { useUI.getState().setTab(tab); await wait(200); });
    await act(async () => { useUI.getState().openEditor({ date: todayKey(), startMin: 700 }); await wait(100); });
    await until(() => /نشاط جديد|New activity/.test(el.textContent ?? ''));
    await act(async () => { useUI.getState().closeEditor(); await wait(50); });
    await act(async () => { useUI.setState({ detailFor: a!.id }); await wait(120); });
    expect(el.textContent).toContain('نشاط ١');
    await act(async () => { useUI.setState({ detailFor: null, whatIfFor: a!.id }); await wait(120); });
    await act(async () => { useUI.setState({ whatIfFor: null, catchUpFor: a!.id }); await wait(120); });
    await act(async () => { useUI.setState({ catchUpFor: null, commandOpen: true }); await wait(120); });
    await act(async () => { useUI.setState({ commandOpen: false }); await wait(30); });
    // lane layout on the plan grid: the two close blocks must both be rendered with their times
    await act(async () => { useUI.getState().setTab('plan'); await wait(250); });
    expect(el.textContent).toContain('نشاط ٢');
    expect(errors).toEqual([]);
  }, 60000);
});
