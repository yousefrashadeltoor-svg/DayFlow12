import { describe, it, expect } from 'vitest';
import { nextReview } from '@/services/study/srs';
import { parseCSV, toCSV, autoMap } from '@/services/import/csv';
import { parseTime } from '@/utils/date';
import { evaluateRules, inQuiet } from '@/services/scheduling/rules';
import { computePrayerTimes } from '@/services/prayer';

describe('spaced repetition', () => {
  it('follows configured intervals', () => {
    let c = { step: -1, ease: 2.5, lapses: 0 };
    const due: number[] = [];
    for (let i = 0; i < 4; i++) { const r = nextReview(c, 2, '2030-01-01', [1, 3, 7, 21]); due.push(r.intervalDays); c = { step: r.step, ease: r.ease, lapses: r.lapses }; }
    expect(due).toEqual([1, 3, 7, 21]);
  });
  it('again resets and counts a lapse', () => {
    const r = nextReview({ step: 3, ease: 2.5, lapses: 0 }, 0, '2030-01-01', [2, 5]);
    expect(r).toMatchObject({ step: 0, intervalDays: 2, lapses: 1, nextDue: '2030-01-03' });
  });
});

describe('csv', () => {
  it('round-trips quotes, commas and arabic', () => {
    const rows = [['title', 'notes'], ['دراسة', 'a, "b"']];
    expect(parseCSV(toCSV(rows))).toEqual(rows);
  });
  it('detects semicolons and maps arabic headers', () => {
    const rows = parseCSV('العنوان;البدء;المدة\nقراءة;08:00;30');
    expect(autoMap(rows[0], 'activities')).toMatchObject({ title: 0, start: 1, duration: 2 });
  });
  it('validates time formats', () => {
    expect(parseTime('7:30 pm')).toBe(1170);
    expect(parseTime('٠٨:١٥')).toBe(495);
    expect(parseTime('25:00')).toBeNull();
    expect(parseTime('abc')).toBeNull();
  });
});

describe('rules', () => {
  it('quiet hours wrap midnight', () => {
    expect(inQuiet(23 * 60 + 30, 23 * 60, 6 * 60)).toBe(true);
    expect(inQuiet(12 * 60, 23 * 60, 6 * 60)).toBe(false);
  });
  it('flags recovery after intensive study', () => {
    const base = { description: '', icon: '', color: '', fixed: false, priority: 3, importance: 3, energy: 'medium' as const, difficulty: 3, reminder: { enabled: false, offsets: [], atEnd: false, soundMode: 'inherit' as const, repeatIntervalMin: 0, maxRepeats: 0, critical: false, actions: [] }, prepMin: 0, cleanupMin: 0, bufferMin: 0, dependsOn: [], notes: '', tags: [], splitAllowed: false, minSplitMin: 25, date: '2030-01-01', status: 'planned' as const, pausedTotalMs: 0, snoozeCount: 0, source: 'manual' as const, events: [], createdAt: 0, updatedAt: 0 };
    const v = evaluateRules([{ id: 'r', type: 'recovery_after_study', enabled: true, priority: 1, params: { minStudyMin: 90, recoveryMin: 15 }, override: false, createdAt: 0, updatedAt: 0 }], {
      date: '2030-01-01', blocks: [{ ...base, id: 's', title: 'S', categoryId: 'cat_study', startMin: 480, durationMin: 120 }, { ...base, id: 'w', title: 'W', categoryId: 'cat_work', startMin: 600, durationMin: 60 }],
      categories: { cat_study: { id: 'cat_study', key: 'study', nameAr: '', nameEn: '', icon: '', color: '', builtin: true, productive: true, createdAt: 0, updatedAt: 0 }, cat_work: { id: 'cat_work', key: 'work', nameAr: '', nameEn: '', icon: '', color: '', builtin: true, productive: true, createdAt: 0, updatedAt: 0 } },
      settings: { productiveStartMin: 540, productiveEndMin: 780, dayEndMin: 1380, quietHours: { enabled: false, startMin: 0, endMin: 0, days: [], allowCritical: true }, water: { workoutBonusMl: 500 } } as never,
      tasks: [], scheduledTaskIds: new Set(), fmtTime: String, fmtDate: String,
    });
    expect(v).toHaveLength(1);
    expect(v[0].suggestion?.type).toBe('insert_break');
  });
});

describe('prayer times', () => {
  it('computes plausible Makkah times', () => {
    const p = computePrayerTimes('2030-06-21', 21.4225, 39.8262, 'makkah', 'standard')!;
    expect(p).not.toBeNull();
    expect(p.fajr).toBeLessThan(p.sunrise);
    expect(p.sunrise).toBeLessThan(p.dhuhr);
    expect(p.dhuhr).toBeLessThan(p.asr);
    expect(p.asr).toBeLessThan(p.maghrib);
    expect(p.maghrib).toBeLessThan(p.isha);
  });
});
