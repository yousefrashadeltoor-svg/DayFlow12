process.env.TZ = 'Africa/Cairo'; // prayer maths use the device offset; Egypt = UTC+2 (+3 in summer)
import { describe, it, expect } from 'vitest';
import { layoutLanes } from '@/services/scheduling/engine';
import { nextRing } from '@/services/alarmClock';
import { occasionsOn, orthodoxEaster, hijriOf, materializeOccasions, CATALOGUE } from '@/services/occasions';
import { computePrayerTimes, EGYPT_PLACES, nextPrayer, prayerStats, qiblaBearing } from '@/services/prayer';
import { seasonFor, resolveSeasonIds, pickSeasonId, MAX_DECOR_PICKS } from '@/services/decor';
import { themeCss, THEMES } from '@/services/themes';

const opts = { hijriAdjust: 0, showOtherReligions: true, user: [] as never[] };

describe('lane layout (adjacent / overlapping blocks)', () => {
  it('puts overlapping blocks side by side and keeps adjacent tiny blocks apart', () => {
    const l = layoutLanes([{ id: 'a', start: 600, end: 660 }, { id: 'b', start: 630, end: 690 }, { id: 'c', start: 700, end: 760 }], 40);
    expect(l.a).toEqual({ col: 0, cols: 2 }); expect(l.b).toEqual({ col: 1, cols: 2 }); expect(l.c.cols).toBe(1);
  });
  it('separates touching 10-minute blocks because each needs a minimum visual height', () => {
    const l = layoutLanes([{ id: 'x', start: 600, end: 610 }, { id: 'y', start: 610, end: 620 }, { id: 'z', start: 620, end: 630 }], 40);
    expect(new Set([l.x.col, l.y.col, l.z.col]).size).toBe(3);
    expect(l.x.cols).toBe(3);
  });
  it('does not split blocks that are far apart', () => {
    const l = layoutLanes([{ id: 'a', start: 0, end: 60 }, { id: 'b', start: 300, end: 360 }], 40);
    expect(l.a.cols).toBe(1); expect(l.b.cols).toBe(1);
  });
  it('is deterministic', () => {
    const items = [{ id: 'q', start: 100, end: 160 }, { id: 'p', start: 100, end: 160 }];
    expect(layoutLanes(items, 30)).toEqual(layoutLanes([...items].reverse(), 30));
  });
});

describe('alarm clock next ring', () => {
  const at = (y: number, m: number, d: number, h: number, mi = 0) => new Date(y, m - 1, d, h, mi).getTime();
  it('one-time alarm rings today if still ahead, else tomorrow', () => {
    expect(nextRing({ minute: 8 * 60, days: [], enabled: true }, at(2030, 5, 1, 7))).toBe(at(2030, 5, 1, 8));
    expect(nextRing({ minute: 8 * 60, days: [], enabled: true }, at(2030, 5, 1, 9))).toBe(at(2030, 5, 2, 8));
  });
  it('repeats on selected weekdays and honours skipDate', () => {
    const wed = at(2030, 5, 1, 9); // Wednesday
    expect(new Date(nextRing({ minute: 420, days: [1, 3], enabled: true }, wed)!).getDay()).toBe(1);
    expect(nextRing({ minute: 420, days: [0, 1, 2, 3, 4, 5, 6], enabled: true, skipDate: '2030-05-02' }, wed)).toBe(at(2030, 5, 3, 7));
  });
  it('disabled alarms never ring', () => { expect(nextRing({ minute: 1, days: [], enabled: false }, 0)).toBeNull(); });
});

describe('occasions', () => {
  it('computes Orthodox Easter correctly (2024-05-05, 2025-04-20, 2026-04-12)', () => {
    expect(orthodoxEaster(2024)).toBe('2024-05-05'); expect(orthodoxEaster(2025)).toBe('2025-04-20'); expect(orthodoxEaster(2026)).toBe('2026-04-12');
  });
  it('Sham El-Nessim is the Monday after Orthodox Easter and is an official holiday', () => {
    const o = occasionsOn('2026-04-13', opts).find((x) => x.key === 'sham')!;
    expect(o.official).toBe(true); expect(o.flagged).toBe(false);
  });
  it('flags Christian / Jewish occasions and keeps them out of native records', () => {
    const xmas = occasionsOn('2026-01-07', opts).find((x) => x.key === 'coptic_xmas')!;
    expect(xmas.flagged).toBe(true); expect(xmas.religionLabelAr).toBe('مسيحي'); expect(xmas.official).toBe(true);
    const recs = materializeOccasions('2026-01-01', 30, opts);
    expect(recs.some((r) => r.key === 'coptic_xmas')).toBe(false);
    expect(recs.some((r) => r.key === 'jan25')).toBe(true);
    expect(occasionsOn('2026-01-07', { ...opts, showOtherReligions: false }).some((x) => x.key === 'coptic_xmas')).toBe(false);
  });
  it('Jan 1 and Dec 25 are not official public holidays', () => {
    expect(occasionsOn('2026-01-01', opts).find((x) => x.key === 'new_year')!.official).toBe(false);
    expect(occasionsOn('2026-12-25', opts).find((x) => x.key === 'western_xmas')!.official).toBe(false);
  });
  it('Hijri conversion is sane and Eid al-Fitr 2026 lands around March 20', () => {
    const h = hijriOf('2026-03-20', 0);
    expect(h.y).toBe(1447); expect(h.m).toBe(10);
    expect(occasionsOn('2026-03-20', opts).some((x) => x.key === 'eid_fitr')).toBe(true);
  });
  it('Hijri adjustment shifts occasions by a day', () => {
    expect(occasionsOn('2026-03-21', { ...opts, hijriAdjust: -1 }).some((x) => x.key === 'eid_fitr')).toBe(true);
  });
  it('every occasion has a bundled photo key and Arabic details', () => { for (const d of Object.values(CATALOGUE)) { expect(d.image.length).toBeGreaterThan(0); expect(d.detailsAr.length).toBeGreaterThan(10); } });
});

describe('prayer times (Egypt)', () => {
  it('orders prayers and gives plausible Cairo times', () => {
    const cairo = EGYPT_PLACES[0];
    const t = computePrayerTimes('2030-06-21', cairo.lat, cairo.lng, 'egypt', 'standard')!;
    expect(t.fajr).toBeLessThan(t.sunrise); expect(t.sunrise).toBeLessThan(t.dhuhr); expect(t.dhuhr).toBeLessThan(t.asr); expect(t.asr).toBeLessThan(t.maghrib); expect(t.maghrib).toBeLessThan(t.isha);
    expect(t.dhuhr).toBeGreaterThan(11 * 60); expect(t.dhuhr).toBeLessThan(14 * 60 + 30); // 12:00 or 13:00 with summer time
  });
  it('covers all 27 governorates with valid coordinates', () => {
    expect(EGYPT_PLACES.filter((p) => p.governorate)).toHaveLength(27);
    for (const p of EGYPT_PLACES) { expect(p.lat).toBeGreaterThan(21); expect(p.lat).toBeLessThan(32); expect(p.lng).toBeGreaterThan(24); expect(p.lng).toBeLessThan(37); expect(computePrayerTimes('2030-01-15', p.lat, p.lng, 'egypt', 'standard')).not.toBeNull(); }
  });
  it('next prayer progress is between 0 and 100 and stats count logs', () => {
    const cfg = { governorate: 'cairo', leadMin: 10, ongoing: true, sound: { kind: 'default' as const }, enabled: true, method: 'egypt' as const, asr: 'standard' as const, lat: 30.0444, lng: 31.2357, city: 'cairo', adjustments: {}, createBlocks: false, durationMin: 15, reminder: true };
    const n = nextPrayer(Date.now(), cfg)!;
    expect(n.progress).toBeGreaterThanOrEqual(0); expect(n.progress).toBeLessThanOrEqual(100); expect(n.at).toBeGreaterThan(Date.now());
    const today = new Date().toISOString().slice(0, 10);
    void today;
    expect(prayerStats([]).today).toBe(0);
  });
  it('Qibla from Cairo is south-east (~136°)', () => { const q = qiblaBearing(30.0444, 31.2357); expect(q).toBeGreaterThan(125); expect(q).toBeLessThan(145); });
});

describe('decor & themes', () => {
  it('chooses Ramadan, winter holidays and autumn by date', () => {
    expect(seasonFor(new Date(2026, 9, 15, 10), 0, '2026-10-15').id).toBe('autumn');
    expect(seasonFor(new Date(2026, 11, 10, 10), 0, '2026-12-10').id).toBe('winter_holidays');
    const r = seasonFor(new Date(2026, 1, 25, 10), 0, '2026-02-25'); // 8 Ramadan 1447 (Umm al-Qura)
    expect(['ramadan']).toContain(r.id);
    expect(seasonFor(new Date(2026, 6, 10, 23), 0, '2026-07-10').tod).toBe('night');
  });
  it('generates scoped CSS for every theme (light and dark)', () => {
    const css = themeCss();
    for (const t of THEMES) { expect(css).toContain(`[data-theme="${t.id}"]`); }
    expect(THEMES.length).toBeGreaterThanOrEqual(12);
    expect(new Set(THEMES.map((t) => t.font)).size).toBeGreaterThanOrEqual(6);
  });
});

describe('multi-decor resolver', () => {
  const now = new Date(2026, 9, 15, 10); // autumn
  it('automatic season is always first, manual picks blend, deduped, capped at 4', () => {
    expect(resolveSeasonIds(now, 0, '2026-10-15', {})).toEqual(['autumn']);
    expect(resolveSeasonIds(now, 0, '2026-10-15', { active: ['ramadan', 'winter', 'autumn'] })).toEqual(['autumn', 'ramadan', 'winter']);
    expect(resolveSeasonIds(now, 0, '2026-10-15', { active: ['ramadan', 'winter', 'summer', 'spring'] })).toHaveLength(4);
    expect(MAX_DECOR_PICKS).toBe(3);
  });
  it('solo preview shows exactly one; disabled seasons are skipped', () => {
    expect(resolveSeasonIds(now, 0, '2026-10-15', { solo: 'eid_fitr', active: ['ramadan'] })).toEqual(['eid_fitr']);
    expect(resolveSeasonIds(now, 0, '2026-10-15', { active: ['ramadan'], enabled: { autumn: false } })).toEqual(['ramadan']);
  });
  it('September auto-activates the school season; exams within 10 days win; October 6 is victory', () => {
    expect(pickSeasonId(new Date(2026, 8, 10), 0, '2026-09-10')).toBe('school');
    expect(pickSeasonId(new Date(2026, 8, 10), 0, '2026-09-10', 'exams')).toBe('exams');
    expect(pickSeasonId(new Date(2026, 9, 6), 0, '2026-10-06')).toBe('october');
  });
});
