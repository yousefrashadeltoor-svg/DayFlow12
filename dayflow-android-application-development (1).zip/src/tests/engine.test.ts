import { describe, it, expect } from 'vitest';
import { detectConflicts, repack, planCatchUp, simulate, placeAcrossDays, summarizeDay, occursOn, occurrencesBetween, freeSlots, type SchedItem } from '@/services/scheduling/engine';

const b = (id: string, start: number, dur: number, p: Partial<SchedItem> = {}): SchedItem => ({ id, title: id, startMin: start, durationMin: dur, fixed: false, status: 'planned', priority: 3, ...p });

describe('conflict detection', () => {
  it('detects overlapping fixed activities', () => {
    const c = detectConflicts([b('a', 600, 60, { fixed: true }), b('b', 630, 60, { fixed: true })]);
    expect(c).toEqual([{ type: 'fixed_overlap', a: 'a', b: 'b', minutes: 30 }]);
  });
  it('detects buffer violations without core overlap', () => {
    const c = detectConflicts([b('a', 600, 60, { bufferMin: 10 }), b('b', 665, 30)]);
    expect(c[0].type).toBe('buffer');
  });
  it('detects window and dependency violations', () => {
    const c = detectConflicts([b('a', 600, 60), b('b', 620, 30, { dependsOn: ['a'], windowStartMin: 700 })]);
    expect(c.map((x) => x.type).sort()).toEqual(['dependency', 'overlap', 'window']);
  });
  it('ignores cancelled and skipped blocks', () => {
    expect(detectConflicts([b('a', 600, 60), b('b', 600, 60, { status: 'cancelled' })])).toHaveLength(0);
  });
});

describe('repack / fixed protection', () => {
  it('never moves fixed blocks and moves flexible ones after them', () => {
    const { result, proposal } = repack([b('fix', 600, 60, { fixed: true }), b('flex', 620, 30)], { fromMin: 0, dayEndMin: 1440 });
    expect(result.find((x) => x.id === 'fix')!.startMin).toBe(600);
    expect(result.find((x) => x.id === 'flex')!.startMin).toBe(660);
    expect(proposal.feasible).toBe(true);
  });
  it('respects latest-finish windows and reports unplaced', () => {
    const { proposal } = repack([b('fix', 600, 120, { fixed: true }), b('flex', 610, 60, { windowEndMin: 700 })], { fromMin: 0, dayEndMin: 1440 });
    expect(proposal.unplaced).toEqual(['flex']);
    expect(proposal.shortageMin).toBe(60);
  });
  it('splits long activities into sessions when allowed', () => {
    const items = [b('f1', 600, 60, { fixed: true }), b('f2', 720, 60, { fixed: true }), b('long', 600, 100, { splitAllowed: true, minSplitMin: 30, windowEndMin: 900 })];
    const { proposal } = repack(items, { fromMin: 540, dayEndMin: 1440 });
    const ch = proposal.changes.find((c) => c.id === 'long')!;
    expect(ch.kind).toBe('move');
  });
  it('detects impossible days (day overflow)', () => {
    const { proposal } = repack([b('fix', 0, 1400, { fixed: true }), b('flex', 100, 120)], { fromMin: 0, dayEndMin: 1440 });
    expect(proposal.feasible).toBe(false);
  });
});

describe('catch-up', () => {
  it('shifts a delayed block to now and pushes flexible blocks, keeping fixed ones', () => {
    const items = [b('study', 540, 60), b('lunch', 720, 45, { fixed: true }), b('read', 620, 60)];
    const { result, proposal, delayMin } = planCatchUp(items, { delayedId: 'study', nowMin: 580, dayEndMin: 1440 });
    expect(delayMin).toBe(40);
    expect(result.find((x) => x.id === 'study')!.startMin).toBe(580);
    expect(result.find((x) => x.id === 'lunch')!.startMin).toBe(720);
    const read = result.find((x) => x.id === 'read')!;
    expect(read.startMin).toBeGreaterThanOrEqual(640);
    expect(read.startMin + read.durationMin <= 720 || read.startMin >= 765).toBe(true);
    expect(proposal.conflictsAfter.filter((c) => c.type !== 'buffer')).toHaveLength(0);
  });
  it('is deterministic', () => {
    const items = [b('a', 500, 30), b('b', 530, 30), b('c', 560, 30)];
    const r1 = planCatchUp(items, { delayedId: 'a', nowMin: 520, dayEndMin: 1440 });
    const r2 = planCatchUp(items, { delayedId: 'a', nowMin: 520, dayEndMin: 1440 });
    expect(r1).toEqual(r2);
  });
});

describe('what-if simulation', () => {
  it('previews an extension without mutating input', () => {
    const items = [b('w', 600, 60), b('n', 660, 30)];
    const copy = JSON.stringify(items);
    const { proposal } = simulate(items, { type: 'extend', id: 'w', minutes: 30 }, { nowMin: 0, dayEndMin: 1440 });
    expect(JSON.stringify(items)).toBe(copy);
    expect(proposal.changes.find((c) => c.id === 'n')!.to[0].startMin).toBe(690);
  });
  it('adding a fixed appointment moves conflicting flexible work', () => {
    const { proposal } = simulate([b('x', 600, 60)], { type: 'add', item: b('appt', 600, 30, { fixed: true }) }, { nowMin: 0, dayEndMin: 1440 });
    expect(proposal.changes.find((c) => c.id === 'x')!.to[0].startMin).toBe(630);
  });
});

describe('multi-day placement', () => {
  it('prioritises earlier deadlines and reports shortages', () => {
    const days = [{ date: '2030-01-01', items: [b('busy', 480, 600, { fixed: true })], fromMin: 480 }, { date: '2030-01-02', items: [], fromMin: 480 }];
    const { placements, shortages } = placeAcrossDays([
      { refId: 'late', title: 'late', durationMin: 60, priority: 5, difficulty: 2, deadline: '2030-01-02', splitAllowed: false, minSplitMin: 30 },
      { refId: 'soon', title: 'soon', durationMin: 120, priority: 1, difficulty: 2, deadline: '2030-01-01', splitAllowed: false, minSplitMin: 30 },
    ], days, { dayStartMin: 480, dayEndMin: 1200, productiveStartMin: 540, productiveEndMin: 780, bufferMin: 0 });
    expect(placements.find((p) => p.refId === 'soon')?.date).toBe('2030-01-01');
    expect(placements.find((p) => p.refId === 'late')).toBeTruthy();
    expect(shortages).toEqual({});
  });
  it('splits across days when allowed and records the shortage', () => {
    const days = [{ date: '2030-01-01', items: [], fromMin: 1140 }];
    const { placements, shortages } = placeAcrossDays([{ refId: 'x', title: 'x', durationMin: 120, priority: 3, difficulty: 3, splitAllowed: true, minSplitMin: 30 }], days, { dayStartMin: 480, dayEndMin: 1200, productiveStartMin: 540, productiveEndMin: 780, bufferMin: 0 });
    expect(placements[0].durationMin).toBe(60);
    expect(shortages.x).toBe(60);
  });
});

describe('summary uses correct denominators', () => {
  it('excludes cancelled, credits partial by percent', () => {
    const s = summarizeDay([
      { ...b('a', 0, 60), status: 'completed' }, { ...b('b', 60, 60), status: 'partial', completionPercent: 50 },
      { ...b('c', 120, 60), status: 'cancelled' }, { ...b('d', 180, 60), status: 'skipped' },
    ], { isToday: false, isPast: true, nowMin: 0, dayEndMin: 1440 });
    expect(s.plannedMin).toBe(180);
    expect(s.creditedMin).toBe(90);
    expect(s.completionPct).toBe(50);
  });
  it('free slots', () => {
    expect(freeSlots([b('a', 60, 60)], 0, 240)).toEqual([[0, 60], [120, 240]]);
  });
});

describe('recurrence', () => {
  it('weekly on selected weekdays every 2 weeks', () => {
    const r = { freq: 'weekly' as const, interval: 2, byWeekday: [1, 3], start: '2030-01-06' }; // Sunday
    expect(occurrencesBetween(r, '2030-01-06', '2030-01-26')).toEqual(['2030-01-07', '2030-01-09', '2030-01-21', '2030-01-23']);
  });
  it('monthly clamps to last day and honours exceptions and count', () => {
    expect(occursOn({ freq: 'monthly', interval: 1, byMonthDay: 31, start: '2030-01-31' }, '2030-02-28')).toBe(true);
    expect(occursOn({ freq: 'daily', interval: 1, start: '2030-01-01' }, '2030-01-03', ['2030-01-03'])).toBe(false);
    expect(occursOn({ freq: 'daily', interval: 1, start: '2030-01-01', count: 3 }, '2030-01-04')).toBe(false);
  });
  it('crosses DST boundaries using calendar days', () => {
    expect(occurrencesBetween({ freq: 'daily', interval: 7, start: '2030-03-01' }, '2030-03-01', '2030-04-05')).toHaveLength(6);
  });
});
