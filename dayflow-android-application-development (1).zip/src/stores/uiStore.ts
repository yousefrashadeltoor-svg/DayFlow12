import { create } from 'zustand';
import type { DateKey, ID } from '@/models/types';
import { safeBack, safePush } from '@/utils/safe';

export type Tab = 'today' | 'plan' | 'focus' | 'assistant' | 'progress' | 'more';
export type Screen =
  | 'tasks' | 'projects' | 'study' | 'workouts' | 'habits' | 'wellness' | 'goals' | 'notes' | 'notifications'
  | 'reliability' | 'backup' | 'settings' | 'rules' | 'prayer' | 'history' | 'templates' | 'about'
  | 'decor' | 'ai_providers' | 'alarms' | 'calendar' | 'journal' | 'themes' | 'set_look' | 'set_plan' | 'set_alerts' | 'set_sound' | 'set_study' | 'set_data';

export interface EditorState { open: boolean; blockId?: ID; date?: DateKey; startMin?: number; taskId?: ID; title?: string; categoryId?: string; }

interface UIState {
  tab: Tab;
  stack: Screen[];
  selectedDate: DateKey | null;
  editor: EditorState;
  commandOpen: boolean;
  quickOpen: boolean;
  catchUpFor: ID | null;
  whatIfFor: ID | null;
  detailFor: ID | null;
  tourOpen: boolean;
  setTab(t: Tab): void;
  push(s: Screen): void;
  pop(): void;
  openEditor(e: Omit<EditorState, 'open'>): void;
  closeEditor(): void;
  set(p: Partial<UIState>): void;
}

let suppressPop = false;

export const useUI = create<UIState>()((set, get) => ({
  tab: 'today', stack: [], selectedDate: null, editor: { open: false }, commandOpen: false, quickOpen: false, catchUpFor: null, whatIfFor: null, detailFor: null, tourOpen: false,
  setTab(t) { set({ tab: t, stack: [] }); },
  push(s) { safePush({ df: s }); set({ stack: [...get().stack, s] }); },
  pop() { if (get().stack.length) { suppressPop = safeBack(); set({ stack: get().stack.slice(0, -1) }); } },
  openEditor(e) { safePush({ df: 'sheet' }); set({ editor: { open: true, ...e } }); },
  closeEditor() { if (get().editor.open) { suppressPop = safeBack(); } set({ editor: { open: false } }); },
  set(p) { set(p); },
}));

/** Android hardware back / browser back closes the top-most layer first. */
if (typeof window !== 'undefined') {
  window.addEventListener('popstate', () => {
    if (suppressPop) { suppressPop = false; return; }
    const s = useUI.getState();
    if (s.editor.open) { useUI.setState({ editor: { open: false } }); return; }
    if (s.commandOpen || s.quickOpen || s.catchUpFor || s.whatIfFor || s.detailFor) { useUI.setState({ commandOpen: false, quickOpen: false, catchUpFor: null, whatIfFor: null, detailFor: null }); return; }
    if (s.stack.length) { useUI.setState({ stack: s.stack.slice(0, -1) }); return; }
    if (s.tab !== 'today') { safePush({ df: 'root' }); useUI.setState({ tab: 'today' }); }
  });
}
