import { create } from 'zustand';
import type {
  ActivityBlock, ActivityCore, ActivitySeries, BlockSnapshot, CollectionName, Collections, CollectionTypes, DateKey, ID, Lang,
  RecurrenceRule, ScheduleChange, Settings, DailyLog, FocusTimerState,
} from '@/models/types';
import { ALL_COLLECTIONS } from '@/models/types';
import { APP_SCHEMA_VERSION, emptyCollections, getAdapter, useMemoryFallback, validateRecord } from '@/services/database/db';
import { DayflowNative, isNative, getCapabilities, errorMessage, type Capabilities, type DbOp } from '@/services/native/dayflowNative';
import { defaultCategories, defaultRules, defaultSettings, defaultTemplates, defaultRoutines, defaultExercises } from '@/services/defaults';
import { occursOn, type Proposal, type SchedItem } from '@/services/scheduling/engine';
import { addDays, epochOf, todayKey } from '@/utils/date';
import { uid } from '@/utils/id';
import { translate, type TKey } from '@/services/localization/i18n';
import { computePrayerTimes, placeOf } from '@/services/prayer';
import { materializeOccasions } from '@/services/occasions';
import { applyThemeAttributes } from '@/services/themes';
import type { JournalEntry } from '@/models/types';

export interface Toast { id: string; kind: 'success' | 'error' | 'info'; message: string; action?: { label: string; run: () => void }; }
export interface SyncReport { at: number; ok: boolean; scheduled: number; failures: number; cancelled: number; exactAllowed?: boolean; error?: string; planned: { alarmKey: string; title: string; triggerAt: number; kind: string; silent: boolean }[] }

type PutMap = { [K in CollectionName]?: CollectionTypes[K][] };
type DelMap = { [K in CollectionName]?: ID[] };

interface AppState {
  ready: boolean;
  fatal: string | null;
  engine: 'sqlite' | 'indexeddb' | 'memory' | null;
  caps: Capabilities | null;
  data: Collections;
  toasts: Toast[];
  syncReport: SyncReport | null;
  dataVersion: number;

  init(): Promise<void>;
  commit(puts: PutMap, dels?: DelMap, opts?: { silent?: boolean }): Promise<boolean>;
  put<K extends CollectionName>(col: K, rec: CollectionTypes[K] | CollectionTypes[K][]): Promise<boolean>;
  remove(col: CollectionName, ids: ID[], undoable?: boolean): Promise<boolean>;
  reloadNative(): Promise<void>;
  refreshCaps(): Promise<void>;
  toast(kind: Toast['kind'], message: string, action?: Toast['action']): void;
  dismissToast(id: string): void;
  t(key: TKey, params?: Record<string, string | number>): string;

  updateSettings(patch: Partial<Settings>): Promise<void>;
  ensureDays(from: DateKey, count: number): Promise<void>;
  createActivity(core: ActivityCore, date: DateKey, recurrence?: RecurrenceRule | null, source?: ActivityBlock['source']): Promise<ActivityBlock | null>;
  updateActivity(id: ID, patch: Partial<ActivityBlock>, scope?: 'this' | 'future'): Promise<boolean>;
  deleteActivity(id: ID, scope?: 'this' | 'series'): Promise<void>;
  blockAction(id: ID, action: BlockActionType, extra?: { minutes?: number; note?: string; percent?: number }): Promise<boolean>;
  applyTemplate(templateId: ID, date: DateKey): Promise<number>;
  duplicateDay(from: DateKey, to: DateKey): Promise<number>;
  saveDayAsTemplate(date: DateKey, name: string): Promise<void>;
  applyProposal(date: DateKey, items: SchedItem[], proposal: Proposal, reason: string, kind: ScheduleChange['kind'], extraDeletes?: ID[]): Promise<boolean>;
  revertChange(changeId: ID): Promise<boolean>;
  regeneratePrayerBlocks(): Promise<void>;
  setFocusTimer(next: FocusTimerState | null): Promise<void>;
  applyDayPlan(date: DateKey): Promise<number>;
  syncOccasions(): Promise<void>;
}

export type BlockActionType = 'start' | 'complete' | 'pause' | 'resume' | 'partial' | 'skip' | 'snooze' | 'reset' | 'cancel' | 'note';

const now = () => Date.now();
let initStarted = false;
let syncTimer: ReturnType<typeof setTimeout> | null = null;
let syncHook: ((s: AppState) => Promise<void>) | null = null;
/** reminderSync registers itself here to avoid an import cycle. */
export function registerSyncHook(fn: (s: AppState) => Promise<void>) { syncHook = fn; }
export function scheduleReminderSync(delay = 1200) {
  if (syncTimer) clearTimeout(syncTimer);
  syncTimer = setTimeout(() => { syncTimer = null; const s = useApp.getState(); if (s.ready && syncHook) syncHook(s).catch(() => undefined); }, delay);
}

export const blocksForDate = (data: Collections, date: DateKey): ActivityBlock[] =>
  Object.values(data.activities).filter((b) => b.date === date).sort((a, b) => a.startMin - b.startMin || a.title.localeCompare(b.title));

export const snapshot = (b: ActivityBlock): BlockSnapshot => ({ id: b.id, date: b.date, startMin: b.startMin, durationMin: b.durationMin, status: b.status, title: b.title });

export function instantiate(core: ActivityCore, date: DateKey, extra: Partial<ActivityBlock> = {}): ActivityBlock {
  const t = now();
  const auto = useApp.getState().data.settings.app?.autoApplyPlan ?? false;
  const src = extra.source ?? 'manual';
  // Drafts (applied=false) get no reminders/widgets until the day plan is applied. Automatic sources and real records are live immediately.
  const applied = extra.applied ?? (['series', 'prayer', 'catchup'].includes(src) || (extra.status != null && extra.status !== 'planned') || auto);
  return {
    ...structuredClone(core), id: uid('b'), date, status: 'planned', pausedTotalMs: 0, snoozeCount: 0, events: [], source: 'manual',
    actualStart: null, actualEnd: null, pausedAt: null, completionPercent: null, createdAt: t, updatedAt: t, ...extra, applied,
  };
}

export const emptyJournal = (date: DateKey): JournalEntry => {
  const t = now();
  return { id: date, date, mood: 0, energy: 0, title: '', body: '', gratitude: ['', '', ''], highlight: '', lesson: '', tags: [], favorite: false, plans: [], createdAt: t, updatedAt: t };
};

/** Arabic (Egyptian dialect) is the primary language; the welcome tour offers English as the first choice. */
function detectLang(): Lang { return 'ar'; }

export const useApp = create<AppState>()((set, get) => ({
  ready: false, fatal: null, engine: null, caps: null, data: emptyCollections(), toasts: [], syncReport: null, dataVersion: 0,

  t(key, params) { return translate(get().data.settings.app?.language ?? 'ar', key, params); },

  async init() {
    if (initStarted) return; // idempotent: StrictMode / remounts must not re-run startup or duplicate listeners
    initStarted = true;
    try {
      let adapter = getAdapter();
      try { await adapter.open(); }
      catch (e) {
        if (isNative()) throw e;              // on Android the native database must work; report honestly
        adapter = useMemoryFallback();        // browser denied storage (sandboxed preview): run without persistence
        await adapter.open();
        console.warn('DAYFLOW: persistent storage unavailable, using in-memory store', e);
      }
      const raw = await adapter.loadAll();
      const data = emptyCollections();
      for (const col of ALL_COLLECTIONS) {
        for (const rec of (raw[col] ?? []) as { id: string }[]) {
          if (rec && rec.id) (data[col] as Record<string, unknown>)[rec.id] = rec;
        }
      }
      set({ data, engine: adapter.engine });
      await runMigrations();
      await sweepPast();
      await get().ensureDays(todayKey(), Math.max(7, get().data.settings.app.reminderHorizonDays + 1));
      await get().syncOccasions();
      const caps = await getCapabilities().catch(() => null);
      set({ ready: true, caps });
      applyNativePrefs(get().data.settings.app);
      checkTimeZone();

      if (isNative()) {
        DayflowNative.addListener('dataChanged', () => { get().reloadNative(); }).catch(() => undefined);
        DayflowNative.addListener('openBlock', (e) => { if (e.blockId) window.dispatchEvent(new CustomEvent('dayflow:openBlock', { detail: e.blockId })); }).catch(() => undefined);
        DayflowNative.addListener('openScreen', (e) => { if (e.screen) window.dispatchEvent(new CustomEvent('dayflow:openScreen', { detail: e.screen })); }).catch(() => undefined);
        DayflowNative.consumeLaunchTarget().then((r) => { if (r.blockId) window.dispatchEvent(new CustomEvent('dayflow:openBlock', { detail: r.blockId })); if (r.screen) window.dispatchEvent(new CustomEvent('dayflow:openScreen', { detail: r.screen })); }).catch(() => undefined);
      }
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
          if (isNative()) get().reloadNative();
          get().refreshCaps();
          checkTimeZone();
          sweepPast().then(() => get().ensureDays(todayKey(), 7));
        }
      });
      scheduleReminderSync(300);
    } catch (e) {
      set({ fatal: errorMessage(e) });
    }
  },

  async commit(puts, dels = {}, opts) {
    const prev = get().data;
    const next = { ...prev } as Collections;
    const ops: DbOp[] = [];
    for (const [col, recs] of Object.entries(puts) as [CollectionName, { id: string }[]][]) {
      if (!recs?.length) continue;
      const map = { ...(next[col] as Record<string, unknown>) };
      for (const r of recs) {
        const err = validateRecord(col, r as unknown as Record<string, unknown>);
        if (err) { get().toast('error', `${get().t('error')}: ${err}`); return false; }
        map[r.id] = r; ops.push({ op: 'put', collection: col, record: r });
      }
      (next as Record<string, unknown>)[col] = map;
    }
    for (const [col, ids] of Object.entries(dels) as [CollectionName, ID[]][]) {
      if (!ids?.length) continue;
      const map = { ...(next[col] as Record<string, unknown>) };
      for (const id of ids) { delete map[id]; ops.push({ op: 'delete', collection: col, id }); }
      (next as Record<string, unknown>)[col] = map;
    }
    if (!ops.length) return true;
    set({ data: next, dataVersion: get().dataVersion + 1 });
    try {
      await getAdapter().batch(ops);
      if (!opts?.silent && ops.some((o) => ['activities', 'tasks', 'habits', 'settings', 'sounds', 'state', 'flashcards', 'waterLogs', 'occasions', 'journal'].includes(o.collection))) scheduleReminderSync();
      return true;
    } catch (e) {
      set({ data: prev, dataVersion: get().dataVersion + 1 }); // roll back memory to match the database
      get().toast('error', `${get().t('failed')}: ${errorMessage(e)}`);
      return false;
    }
  },

  put(col, rec) {
    const arr = (Array.isArray(rec) ? rec : [rec]).map((r) => ({ ...r, updatedAt: now() }));
    return get().commit({ [col]: arr } as PutMap);
  },

  async remove(col, ids, undoable = true) {
    const before = ids.map((id) => (get().data[col] as Record<string, unknown>)[id]).filter(Boolean) as { id: string }[];
    const ok = await get().commit({}, { [col]: ids } as DelMap);
    if (ok && undoable && before.length) {
      get().toast('info', get().t('deleted'), { label: get().t('undo'), run: () => { get().commit({ [col]: before } as PutMap); } });
    }
    return ok;
  },

  async reloadNative() {
    if (!isNative()) return;
    try {
      const adapter = getAdapter();
      const cols = ['activities', 'tasks', 'alarmClocks', 'prayerLogs'] as const;
      const res = await Promise.all(cols.map((c) => adapter.getAll(c)));
      const data = { ...get().data } as Collections;
      cols.forEach((c, i) => { (data as unknown as Record<string, unknown>)[c] = Object.fromEntries((res[i] as { id: string }[]).map((a) => [a.id, a])); });
      set({ data, dataVersion: get().dataVersion + 1 });
    } catch (e) { get().toast('error', errorMessage(e)); }
  },

  async refreshCaps() { const caps = await getCapabilities().catch(() => null); if (caps) set({ caps }); },

  toast(kind, message, action) {
    const id = uid('t');
    set({ toasts: [...get().toasts.slice(-2), { id, kind, message, action }] });
    setTimeout(() => get().dismissToast(id), action ? 6000 : 3200);
  },
  dismissToast(id) { set({ toasts: get().toasts.filter((x) => x.id !== id) }); },

  async updateSettings(patch) {
    const cur = get().data.settings.app;
    const next = { ...cur, ...patch, updatedAt: now() };
    await get().commit({ settings: [next] });
    applyNativePrefs(next);
    if ('prayer' in patch) await get().regeneratePrayerBlocks();
    if ('hijriAdjust' in patch) await get().syncOccasions();
  },

  async ensureDays(from, count) {
    const { data } = get();
    const s = data.settings.app;
    const today = todayKey();
    const newBlocks: ActivityBlock[] = [];
    const logs: DailyLog[] = [];
    const series = Object.values(data.series).filter((x) => x.active);
    const all = Object.values(data.activities);
    for (let i = 0; i < count; i++) {
      const date = addDays(from, i);
      if (date < today) continue;
      const existing = all.filter((b) => b.date === date);
      for (const se of series) {
        if (!occursOn(se.recurrence, date, se.exceptions)) continue;
        if (existing.some((b) => b.seriesId === se.id)) continue;
        newBlocks.push(instantiate(se.core, date, { seriesId: se.id, source: 'series' }));
      }
      const log = data.dailyLogs[date];
      if (!log?.materialized) {
        const special = Object.values(data.specialDates).find((d) => d.date === date && d.templateId);
        const assign = Object.values(data.weekdayAssignments).find((w) => w.weekday === new Date(date + 'T12:00:00').getDay());
        const tplId = special?.templateId ?? assign?.templateId;
        const tpl = tplId ? data.templates[tplId] : undefined;
        if (tpl && !existing.some((b) => b.templateId === tpl.id)) {
          for (const core of tpl.blocks) newBlocks.push(instantiate(core, date, { templateId: tpl.id, source: 'template', applied: true }));
        }
        const t = now();
        logs.push({ id: date, date, appliedTemplateIds: tpl ? [tpl.id] : [], materialized: true, journal: log?.journal ?? '', createdAt: log?.createdAt ?? t, updatedAt: t });
      }
      if (s.prayer.enabled && s.prayer.createBlocks && s.prayer.lat != null && s.prayer.lng != null && !existing.some((b) => b.source === 'prayer')) {
        newBlocks.push(...prayerBlocks(date, s));
      }
    }
    if (newBlocks.length || logs.length) await get().commit({ activities: newBlocks, dailyLogs: logs });
  },

  async createActivity(core, date, recurrence, source = 'manual') {
    if (recurrence) {
      const t = now();
      const se: ActivitySeries = { id: uid('s'), core: structuredClone(core), recurrence: { ...recurrence, start: recurrence.start || date }, exceptions: [], active: true, createdAt: t, updatedAt: t };
      const ok = await get().commit({ series: [se] });
      if (!ok) return null;
      await get().ensureDays(todayKey() > date ? todayKey() : date, 14);
      return Object.values(get().data.activities).find((b) => b.seriesId === se.id && b.date === date) ?? null;
    }
    const b = instantiate(core, date, { source });
    return (await get().commit({ activities: [b] })) ? b : null;
  },

  async updateActivity(id, patch, scope = 'this') {
    const b = get().data.activities[id];
    if (!b) return false;
    const t = now();
    if (scope === 'future' && b.seriesId && get().data.series[b.seriesId]) {
      const se = get().data.series[b.seriesId];
      const coreKeys: (keyof ActivityCore)[] = ['title', 'description', 'categoryId', 'icon', 'color', 'startMin', 'durationMin', 'fixed', 'windowStartMin', 'windowEndMin', 'preferredMin', 'priority', 'importance', 'energy', 'difficulty', 'reminder', 'goalId', 'projectId', 'lessonId', 'subjectId', 'workoutPlanId', 'taskId', 'habitId', 'prepMin', 'cleanupMin', 'bufferMin', 'dependsOn', 'notes', 'tags', 'splitAllowed', 'minSplitMin'];
      const corePatch: Partial<ActivityCore> = {};
      for (const k of coreKeys) if (k in patch) (corePatch as Record<string, unknown>)[k] = (patch as Record<string, unknown>)[k];
      const nextSeries = { ...se, core: { ...se.core, ...corePatch }, updatedAt: t };
      const future = Object.values(get().data.activities).filter((x) => x.seriesId === se.id && x.date >= b.date && !x.detached && x.status === 'planned');
      return get().commit({ series: [nextSeries], activities: future.map((x) => ({ ...x, ...corePatch, updatedAt: t })) });
    }
    return get().commit({ activities: [{ ...b, ...patch, detached: b.seriesId ? true : b.detached, updatedAt: t }] });
  },

  async deleteActivity(id, scope = 'this') {
    const b = get().data.activities[id];
    if (!b) return;
    if (isNative()) DayflowNative.cancelBlockAlarms({ blockId: id }).catch(() => undefined);
    if (b.seriesId && get().data.series[b.seriesId]) {
      const se = get().data.series[b.seriesId];
      if (scope === 'series') {
        const future = Object.values(get().data.activities).filter((x) => x.seriesId === se.id && x.date >= b.date && x.status === 'planned');
        const prevSeries = se;
        const ok = await get().commit({ series: [{ ...se, active: false, recurrence: { ...se.recurrence, until: addDays(b.date, -1) }, updatedAt: now() }] }, { activities: future.map((x) => x.id) });
        if (ok) get().toast('info', get().t('deleted'), { label: get().t('undo'), run: () => get().commit({ series: [prevSeries], activities: future }) });
        return;
      }
      const ok = await get().commit({ series: [{ ...se, exceptions: [...se.exceptions, b.date], updatedAt: now() }] }, { activities: [id] });
      if (ok) get().toast('info', get().t('deleted'), { label: get().t('undo'), run: () => get().commit({ series: [se], activities: [b] }) });
      return;
    }
    await get().remove('activities', [id]);
  },

  async blockAction(id, action, extra) {
    const b = get().data.activities[id];
    if (!b) return false;
    const t = now();
    const n: ActivityBlock = { ...b, events: [...(b.events ?? []), { at: t, action: action.toUpperCase(), source: 'app' }], updatedAt: t };
    switch (action) {
      case 'start': n.status = 'active'; n.actualStart = t; n.actualEnd = null; n.pausedTotalMs = 0; n.pausedAt = null; break;
      case 'pause': if (b.status !== 'active') return false; n.status = 'paused'; n.pausedAt = t; break;
      case 'resume': if (b.status !== 'paused') return false; n.status = 'active'; n.pausedTotalMs = (b.pausedTotalMs ?? 0) + (b.pausedAt ? t - b.pausedAt : 0); n.pausedAt = null; break;
      case 'complete':
        if (b.status === 'paused' && b.pausedAt) n.pausedTotalMs = (b.pausedTotalMs ?? 0) + (t - b.pausedAt);
        n.status = 'completed'; n.actualStart = b.actualStart ?? epochOf(b.date, b.startMin); n.actualEnd = b.actualStart ? t : Math.min(t, epochOf(b.date, b.startMin + b.durationMin)); n.pausedAt = null; n.completionPercent = 100; break;
      case 'partial':
        if (b.status === 'paused' && b.pausedAt) n.pausedTotalMs = (b.pausedTotalMs ?? 0) + (t - b.pausedAt);
        n.status = 'partial'; n.actualStart = b.actualStart ?? null; n.actualEnd = b.actualStart ? t : null; n.pausedAt = null; n.completionPercent = extra?.percent ?? null; break;
      case 'skip': n.status = 'skipped'; break;
      case 'cancel': n.status = 'cancelled'; break;
      case 'reset': n.status = 'planned'; n.actualStart = null; n.actualEnd = null; n.pausedAt = null; n.pausedTotalMs = 0; n.completionPercent = null; break;
      case 'snooze': {
        const m = extra?.minutes ?? 10;
        if (b.fixed) return false;
        n.startMin = Math.min(1439, b.startMin + m); n.snoozeCount = (b.snoozeCount ?? 0) + 1;
        if (b.seriesId) n.detached = true;
        break;
      }
      case 'note': n.notes = [b.notes, extra?.note].filter(Boolean).join('\n'); break;
    }
    const ok = await get().commit({ activities: [n] });
    if (ok && isNative() && ['complete', 'skip', 'partial', 'cancel'].includes(action)) DayflowNative.cancelBlockAlarms({ blockId: id }).catch(() => undefined);
    // Linked records receive real tracked time
    if (ok && (action === 'complete' || action === 'partial') && n.actualStart && n.actualEnd) {
      const mins = Math.max(0, Math.round((n.actualEnd - n.actualStart - n.pausedTotalMs) / 60000));
      if (n.taskId && get().data.tasks[n.taskId]) { const task = get().data.tasks[n.taskId]; await get().put('tasks', { ...task, trackedMin: task.trackedMin + mins }); }
      if ((n.lessonId || n.subjectId) && mins > 0) {
        const lesson = n.lessonId ? get().data.lessons[n.lessonId] : undefined;
        await get().put('studySessions', { id: uid('ss'), subjectId: n.subjectId ?? lesson?.subjectId, unitId: lesson?.unitId, lessonId: n.lessonId, date: n.date, minutes: mins, note: '', createdAt: t, updatedAt: t });
      }
    }
    return ok;
  },

  async applyTemplate(templateId, date) {
    const tpl = get().data.templates[templateId];
    if (!tpl) return 0;
    const blocks = tpl.blocks.map((c) => instantiate(c, date, { templateId, source: 'template' }));
    const t = now();
    const log = get().data.dailyLogs[date];
    const ok = await get().commit({
      activities: blocks,
      dailyLogs: [{ id: date, date, appliedTemplateIds: [...(log?.appliedTemplateIds ?? []), templateId], materialized: true, journal: log?.journal ?? '', createdAt: log?.createdAt ?? t, updatedAt: t }],
      scheduleChanges: [{ id: uid('sc'), date, reason: tpl.name, kind: 'template', before: [], after: blocks.map(snapshot), created: blocks.map((b) => b.id), deleted: [], reverted: false, createdAt: t, updatedAt: t }],
    });
    return ok ? blocks.length : 0;
  },

  async duplicateDay(from, to) {
    const src = blocksForDate(get().data, from).filter((b) => b.status !== 'cancelled');
    const copies = src.map((b) => {
      const { id: _i, date: _d, status: _s, actualStart: _a, actualEnd: _e, events: _ev, seriesId: _se, ...core } = b;
      void _i; void _d; void _s; void _a; void _e; void _ev; void _se;
      return instantiate(core as ActivityCore, to, { source: 'manual' });
    });
    return (await get().commit({ activities: copies })) ? copies.length : 0;
  },

  async saveDayAsTemplate(date, name) {
    const t = now();
    const blocks = blocksForDate(get().data, date).filter((b) => b.status !== 'cancelled').map((b) => {
      const core: ActivityCore = {
        title: b.title, description: b.description, categoryId: b.categoryId, icon: b.icon, color: b.color, startMin: b.startMin, durationMin: b.durationMin, fixed: b.fixed,
        windowStartMin: b.windowStartMin, windowEndMin: b.windowEndMin, preferredMin: b.preferredMin, priority: b.priority, importance: b.importance, energy: b.energy,
        difficulty: b.difficulty, reminder: b.reminder, prepMin: b.prepMin, cleanupMin: b.cleanupMin, bufferMin: b.bufferMin, dependsOn: [], notes: b.notes, tags: b.tags,
        splitAllowed: b.splitAllowed, minSplitMin: b.minSplitMin,
      };
      return core;
    });
    await get().put('templates', { id: uid('tpl'), name, kind: 'custom', blocks, builtin: false, createdAt: t, updatedAt: t });
  },

  async applyProposal(date, items, proposal, reason, kind, extraDeletes = []) {
    const data = get().data;
    const t = now();
    const before: BlockSnapshot[] = [];
    const after: BlockSnapshot[] = [];
    const updates: ActivityBlock[] = [];
    const created: ActivityBlock[] = [];
    const deleted: ID[] = [...extraDeletes];
    for (const ch of proposal.changes) {
      const orig = data.activities[ch.id];
      if (!orig) continue;
      if (ch.kind === 'move' || ch.kind === 'resize') {
        const it = items.find((i) => i.id === ch.id);
        const nb = { ...orig, startMin: it?.startMin ?? ch.to[0].startMin, durationMin: it?.durationMin ?? ch.to[0].durationMin, detached: orig.seriesId ? true : orig.detached, updatedAt: t,
          events: [...orig.events, { at: t, action: 'RESCHEDULED', source: 'catchup' as const }] };
        before.push(snapshot(orig)); after.push(snapshot(nb)); updates.push(nb);
      } else if (ch.kind === 'split') {
        const group = uid('g');
        before.push(snapshot(orig));
        ch.to.forEach((p, i) => {
          if (i === 0) { const nb = { ...orig, startMin: p.startMin, durationMin: p.durationMin, splitGroup: group, detached: orig.seriesId ? true : orig.detached, updatedAt: t }; updates.push(nb); after.push(snapshot(nb)); }
          else { const nb = { ...orig, id: uid('b'), startMin: p.startMin, durationMin: p.durationMin, splitGroup: group, seriesId: undefined, source: 'catchup' as const, events: [], createdAt: t, updatedAt: t }; created.push(nb); after.push(snapshot(nb)); }
        });
      }
    }
    for (const id of extraDeletes) { const o = data.activities[id]; if (o) before.push(snapshot(o)); }
    const change: ScheduleChange = { id: uid('sc'), date, reason, kind, before, after, created: created.map((c) => c.id), deleted, reverted: false, createdAt: t, updatedAt: t };
    const ok = await get().commit({ activities: [...updates, ...created], scheduleChanges: [change] }, { activities: deleted });
    if (ok) get().toast('success', get().t('applied'), { label: get().t('undo'), run: () => { get().revertChange(change.id); } });
    return ok;
  },

  async revertChange(changeId) {
    const ch = get().data.scheduleChanges[changeId];
    if (!ch || ch.reverted) return false;
    const data = get().data;
    const t = now();
    const restore: ActivityBlock[] = [];
    if (ch.kind === 'apply') {
      for (const snap of ch.after) { const cur = data.activities[snap.id]; if (cur) restore.push({ ...cur, applied: false, updatedAt: t }); }
      const ok0 = await get().commit({ activities: restore, scheduleChanges: [{ ...ch, reverted: true, updatedAt: t }] });
      if (ok0) get().toast('success', get().t('reverted'));
      return ok0;
    }
    for (const snap of ch.before) {
      const cur = data.activities[snap.id];
      if (cur) restore.push({ ...cur, startMin: snap.startMin, durationMin: snap.durationMin, updatedAt: t });
    }
    const ok = await get().commit({ activities: restore, scheduleChanges: [{ ...ch, reverted: true, updatedAt: t }] }, { activities: ch.created.filter((id) => data.activities[id]) });
    if (ok) get().toast('success', get().t('reverted'));
    return ok;
  },

  async regeneratePrayerBlocks() {
    const s = get().data.settings.app;
    const today = todayKey();
    const old = Object.values(get().data.activities).filter((b) => b.source === 'prayer' && b.date >= today && b.status === 'planned');
    const fresh: ActivityBlock[] = [];
    if (s.prayer.enabled && s.prayer.createBlocks && s.prayer.lat != null && s.prayer.lng != null) {
      for (let i = 0; i < 7; i++) fresh.push(...prayerBlocks(addDays(today, i), s));
    }
    await get().commit({ activities: fresh }, { activities: old.map((b) => b.id) });
  },

  async applyDayPlan(date) {
    const data = get().data;
    const all = blocksForDate(data, date).filter((b) => b.status !== 'cancelled');
    const drafts = all.filter((b) => b.applied === false);
    if (!drafts.length) return 0;
    const t = now();
    const updates = drafts.map((b) => ({ ...b, applied: true, updatedAt: t, events: [...(b.events ?? []), { at: t, action: 'APPLIED', source: 'app' as const }] }));
    const reason = get().t('plan_applied_reason', { d: new Intl.DateTimeFormat(data.settings.app.language === 'ar' ? 'ar-EG' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(date + 'T12:00')), n: drafts.length });
    const change: ScheduleChange = { id: uid('sc'), date, reason, kind: 'apply', before: [], after: updates.map(snapshot), created: [], deleted: [], reverted: false, createdAt: t, updatedAt: t };
    const entry = { ...(data.journal[date] ?? emptyJournal(date)) };
    entry.plans = [...entry.plans, { at: t, title: reason, blocks: all.map((b) => ({ id: b.id, title: b.title, startMin: b.startMin, durationMin: b.durationMin })) }];
    entry.updatedAt = t;
    const ok = await get().commit({ activities: updates, scheduleChanges: [change], journal: [entry] });
    if (ok) get().toast('success', get().t('plan_applied_toast', { n: drafts.length }), { label: get().t('undo'), run: () => { get().revertChange(change.id); } });
    return ok ? drafts.length : 0;
  },

  async syncOccasions() {
    const st = get();
    const s = st.data.settings.app;
    if (!s) return;
    const from = addDays(todayKey(), -1);
    const desired = materializeOccasions(from, 400, { hijriAdjust: s.hijriAdjust ?? 0, showOtherReligions: false, user: Object.values(st.data.specialDates) });
    const cur = st.data.occasions;
    const sig = (o: { title: string; titleEn: string; emoji: string; official: boolean; notify: boolean; notifyMin: number; date: string; note: string; image: string }) => `${o.title}|${o.titleEn}|${o.emoji}|${o.official}|${o.notify}|${o.notifyMin}|${o.date}|${o.note}|${o.image}`;
    const want = new Set(desired.map((o) => o.id));
    const puts = desired.filter((o) => !cur[o.id] || sig(cur[o.id]) !== sig(o));
    const dels = Object.values(cur).filter((o) => !want.has(o.id) || o.date < from).map((o) => o.id);
    if (puts.length || dels.length) await get().commit({ occasions: puts }, { occasions: dels });
  },

  async setFocusTimer(next) {
    if (next) await get().commit({ state: [next] });
    else if (get().data.state.focusTimer) await get().commit({}, { state: ['focusTimer'] });
  },
}));

function prayerBlocks(date: DateKey, s: Settings): ActivityBlock[] {
  const times = computePrayerTimes(date, s.prayer.lat!, s.prayer.lng!, s.prayer.method, s.prayer.asr, s.prayer.adjustments);
  if (!times) return [];
  const names: [keyof typeof times, TKey][] = [['fajr', 'pr_fajr'], ['dhuhr', 'pr_dhuhr'], ['asr', 'pr_asr'], ['maghrib', 'pr_maghrib'], ['isha', 'pr_isha']];
  return names.map(([k, key]) => instantiate({
    title: translate(s.language, key), description: '', categoryId: 'cat_prayer', icon: 'sunrise', color: 'var(--c-rest)', startMin: Math.round(times[k]), durationMin: s.prayer.durationMin,
    fixed: true, priority: 5, importance: 5, energy: 'low', difficulty: 1,
    reminder: { enabled: s.prayer.reminder, offsets: [0], atEnd: false, soundMode: 'inherit', repeatIntervalMin: 0, maxRepeats: 0, critical: false, actions: ['DONE', 'SNOOZE_5', 'DISMISS'] },
    prepMin: 0, cleanupMin: 0, bufferMin: 0, dependsOn: [], notes: '', tags: [], splitAllowed: false, minSplitMin: 10,
  }, date, { source: 'prayer' }));
}

async function runMigrations() {
  const st = useApp.getState();
  const applied = new Set(Object.values(st.data.migrations).map((m) => m.version));
  const t = now();
  if (!applied.has(1)) {
    const lang = detectLang();
    const settings = st.data.settings.app ?? defaultSettings(lang);
    const cats = defaultCategories().filter((c) => !st.data.categories[c.id]);
    const tpls = defaultTemplates(settings.language).filter((c) => !st.data.templates[c.id]);
    const rules = defaultRules().filter((c) => !st.data.rules[c.id]);
    const routines = defaultRoutines(settings.language).filter((c) => !st.data.routines[c.id]);
    const exercises = defaultExercises(settings.language).filter((c) => !st.data.exercises[c.id]);
    await st.commit({ settings: [settings], categories: cats, templates: tpls, rules, routines, exercises, migrations: [{ id: 'v1', version: 1, description: 'seed configuration defaults', createdAt: t, updatedAt: t }] }, {}, { silent: true });
  }
  if (!applied.has(2)) {
    // Additive normalisation of activity records created by earlier builds.
    const fixes = Object.values(useApp.getState().data.activities).filter((b) => !Array.isArray(b.events) || typeof b.pausedTotalMs !== 'number')
      .map((b) => ({ ...b, events: Array.isArray(b.events) ? b.events : [], pausedTotalMs: typeof b.pausedTotalMs === 'number' ? b.pausedTotalMs : 0 }));
    // Settings gain new keys with defaults while user values are preserved.
    const cur = useApp.getState().data.settings.app;
    const merged = { ...defaultSettings(cur.language), ...cur };
    await useApp.getState().commit({ activities: fixes, settings: [merged], migrations: [{ id: 'v2', version: 2, description: 'normalise activity events, merge new settings keys', createdAt: t, updatedAt: t }] }, {}, { silent: true });
  }
  if (!applied.has(3)) {
    const cur = useApp.getState().data.settings.app;
    const d = defaultSettings(cur.language);
    const merged = { ...d, ...cur, dashboard: { ...d.dashboard, ...cur.dashboard }, prayer: { ...d.prayer, ...cur.prayer, sound: { ...d.prayer.sound, ...(cur.prayer?.sound ?? {}) }, adjustments: { ...d.prayer.adjustments, ...(cur.prayer?.adjustments ?? {}) } }, journal: { ...d.journal, ...cur.journal },
      accent: cur.accent === ('indigo' as never) && !cur.themeId ? ('theme' as never) : cur.accent, themeId: cur.themeId ?? d.themeId };
    await useApp.getState().commit({ settings: [merged], migrations: [{ id: 'v3', version: 3, description: 'themes, decor, alarms, prayer (Egypt), journal, plan apply, occasions', createdAt: t, updatedAt: t }] }, {}, { silent: true });
  }
  if (!applied.has(4)) {
    const cur = useApp.getState().data.settings.app;
    const d = defaultSettings(cur.language);
    const merged = { ...d, ...cur, ai: { ...d.ai, ...(cur.ai ?? {}), providers: { ...(cur.ai?.providers ?? {}) } },
      decorSpeed: cur.decorSpeed ?? d.decorSpeed, decorOpacity: cur.decorOpacity ?? d.decorOpacity, decorLayer: cur.decorLayer ?? d.decorLayer, decorSeasons: cur.decorSeasons ?? {}, decorPreview: cur.decorPreview ?? '' };
    await useApp.getState().commit({ settings: [merged], migrations: [{ id: 'v4', version: 4, description: 'AI assistant settings, decor controls', createdAt: t, updatedAt: t }] }, {}, { silent: true });
  }
  if (!applied.has(5)) {
    const cur = useApp.getState().data.settings.app;
    const merged = { ...cur, decorActive: cur.decorActive ?? [], decorPreview: cur.decorPreview ?? '' };
    await useApp.getState().commit({ settings: [merged], migrations: [{ id: 'v5', version: 5, description: 'multi-decor, model health, brand', createdAt: t, updatedAt: t }] }, {}, { silent: true });
  }
  void APP_SCHEMA_VERSION;
}

/** Past days: never-started planned blocks become "missed" (a real state, shown honestly). */
async function sweepPast() {
  const st = useApp.getState();
  const today = todayKey();
  const t = now();
  const updates = Object.values(st.data.activities).filter((b) => b.date < today && b.applied !== false && (b.status === 'planned' || b.status === 'active' || b.status === 'paused'))
    .map((b) => b.status === 'planned' ? { ...b, status: 'missed' as const, updatedAt: t } : { ...b, status: 'partial' as const, updatedAt: t });
  if (updates.length) await st.commit({ activities: updates }, {}, { silent: true });
}

function applyNativePrefs(s: Settings) {
  const root = document.documentElement;
  root.lang = s.language;
  root.dir = s.language === 'ar' ? 'rtl' : 'ltr';
  const theme = applyThemeAttributes(root, s.themeId);
  const dark = !!theme.forceDark || s.theme === 'dark' || (s.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  root.classList.toggle('dark', dark);
  root.dataset.accent = s.accent;
  root.style.setProperty('--font-scale', String(s.fontScale));
  root.classList.toggle('reduce-motion', s.reducedMotion === 'on');
  root.classList.toggle('motion-auto', s.reducedMotion === 'system');
  document.title = `${translate(s.language, 'app_name')} · 𝐃α𝗒 𝐅ᥣⱺω`;
  if (isNative()) {
    requestAnimationFrame(() => {
      const accent = getComputedStyle(root).getPropertyValue('--accent').trim();
      DayflowNative.setNativePreferences({ language: s.language, theme: theme.forceDark ? 'dark' : s.theme, clock24: String(s.clock24), widgetLayout: s.widgetLayout, accent, hijriAdjust: String(s.hijriAdjust ?? 0) }).catch(() => undefined);
    });
    DayflowNative.registerNotificationActions({ language: s.language }).catch(() => undefined);
    const pl = s.prayer.lat != null && s.prayer.lng != null ? { lat: s.prayer.lat, lng: s.prayer.lng } : placeOf(s.prayer.governorate);
    const place = placeOf(s.prayer.governorate);
    DayflowNative.configurePrayer({
      enabled: s.prayer.enabled, lat: pl.lat, lng: pl.lng, method: s.prayer.method, asr: s.prayer.asr, adjustments: s.prayer.adjustments, leadMin: s.prayer.leadMin, ongoing: s.prayer.ongoing, reminder: s.prayer.reminder,
      city: s.language === 'ar' ? place.ar : place.en, sound: s.prayer.sound, volume: s.volume, vibrate: s.vibrate, language: s.language,
    }).catch(() => undefined);
  }
}

function checkTimeZone() {
  const st = useApp.getState();
  const s = st.data.settings.app;
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
  if (s && s.lastTimeZone !== tz) {
    st.commit({ settings: [{ ...s, lastTimeZone: tz, updatedAt: now() }] });
    st.toast('info', st.t('tz_changed', { z: tz }));
    scheduleReminderSync(200);
  }
}

if (typeof window !== 'undefined') {
  window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', () => {
    const s = useApp.getState().data.settings.app;
    if (s) applyNativePrefs(s);
  });
}
