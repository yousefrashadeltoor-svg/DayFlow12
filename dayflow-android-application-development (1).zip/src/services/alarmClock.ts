import type { AlarmClock, DateKey, Lang, SoundSpec } from '@/models/types';
import { fmtDuration, toDateKey } from '@/utils/date';

export const defaultAlarm = (minute: number): Omit<AlarmClock, 'id' | 'createdAt' | 'updatedAt'> => ({
  label: '', minute, days: [], enabled: true, sound: { kind: 'default' }, volume: 1, gradual: true, vibrate: true, speakLabel: false, snoozeMin: 9, maxSnoozes: 3, ringMin: 5,
});

/** Next ring time (epoch ms) strictly after `from`, honouring repeat days, one-time date and skipDate. Mirrors UserAlarms.nextTrigger in Kotlin. */
export function nextRing(a: Pick<AlarmClock, 'minute' | 'days' | 'oneTimeDate' | 'skipDate' | 'enabled'>, from: number): number | null {
  if (!a.enabled) return null;
  const base = new Date(from);
  for (let i = 0; i < 9; i++) {
    const d = new Date(base.getFullYear(), base.getMonth(), base.getDate() + i, Math.floor(a.minute / 60), a.minute % 60, 0, 0);
    if (d.getTime() <= from) continue;
    const key: DateKey = toDateKey(d);
    if (a.skipDate === key) continue;
    if (a.days.length) { if (a.days.includes(d.getDay())) return d.getTime(); }
    else if (a.oneTimeDate) { if (key === a.oneTimeDate) return d.getTime(); if (key > a.oneTimeDate) return null; }
    else return d.getTime();
  }
  if (!a.days.length && a.oneTimeDate) {
    const [y, m, dd] = a.oneTimeDate.split('-').map(Number);
    const t = new Date(y, m - 1, dd, Math.floor(a.minute / 60), a.minute % 60).getTime();
    return t > from ? t : null;
  }
  return null;
}
export function ringsIn(ms: number, lang: Lang): string {
  const mins = Math.max(1, Math.round(ms / 60000));
  return lang === 'ar' ? `هيرن بعد ${fmtDuration(mins, lang)}` : `Rings in ${fmtDuration(mins, lang)}`;
}
export function soundName(s: SoundSpec, lang: Lang): string {
  const ar = lang === 'ar';
  switch (s.kind) {
    case 'default': return ar ? 'نغمة المنبه الافتراضية' : 'Default alarm tone';
    case 'ringtone': return s.name ?? (ar ? 'نغمة الموبايل' : 'Phone ringtone');
    case 'alarm': return s.name ?? (ar ? 'نغمة منبه' : 'Alarm tone');
    case 'notification': return s.name ?? (ar ? 'نغمة إشعار' : 'Notification tone');
    case 'file': return `${s.name ?? 'audio'}${s.startMs != null || s.endMs != null ? ` (${Math.round((s.startMs ?? 0) / 1000)}–${Math.round((s.endMs ?? s.durationMs ?? 0) / 1000)}s)` : ''}`;
    case 'tts': return ar ? 'نطق النص بصوت عالي' : 'Spoken text';
    case 'silent': return ar ? 'صامت (اهتزاز بس)' : 'Silent (vibrate only)';
  }
}
