/**
 * DAYFLOW scheduling engine — pure, deterministic and unit-tested (see engine.test.ts).
 * No randomness: ties are broken by start time, priority and id.
 * All times are minutes from local midnight of the block's date (may exceed 1440 for cross-midnight blocks).
 */
import type { BlockStatus, DateKey, RecurrenceRule } from '@/models/types';
import { addDays, diffDays, parseDateKey, startOfWeek, weekday } from '@/utils/date';

export interface SchedItem {
  id: string;
  title: string;
  startMin: number;
  durationMin: number;
  fixed: boolean;
  status: BlockStatus;
  priority: number;
  difficulty?: number;
  windowStartMin?: number;
  windowEndMin?: number;
  prepMin?: number;
  cleanupMin?: number;
  bufferMin?: number;
  dependsOn?: string[];
  splitAllowed?: boolean;
  minSplitMin?: number;
  categoryId?: string;
}

export const CLOSED: ReadonlySet<BlockStatus> = new Set(['completed', 'skipped', 'cancelled', 'partial', 'missed']);
export const INACTIVE: ReadonlySet<BlockStatus> = new Set(['skipped', 'cancelled']);

export const endOf = (b: Pick<SchedItem, 'startMin' | 'durationMin'>) => b.startMin + b.durationMin;
export function isMovable(b: SchedItem): boolean {
  return !b.fixed && !CLOSED.has(b.status) && b.status !== 'active' && b.status !== 'paused';
}
/** Occupied interval including preparation before and cleanup + buffer after. */
export function occupied(b: SchedItem): [number, number] {
  return [b.startMin - (b.prepMin ?? 0), endOf(b) + (b.cleanupMin ?? 0) + (b.bufferMin ?? 0)];
}
const intersects = (a: [number, number], b: [number, number]) => a[0] < b[1] && b[0] < a[1];
const overlapLen = (a: [number, number], b: [number, number]) => Math.max(0, Math.min(a[1], b[1]) - Math.max(a[0], b[0]));
const byStart = (a: SchedItem, b: SchedItem) => a.startMin - b.startMin || b.priority - a.priority || a.id.localeCompare(b.id);

// ------------------------------------------------------------------------------------------------ conflicts

export type ConflictType = 'overlap' | 'fixed_overlap' | 'buffer' | 'window' | 'dependency' | 'overflow';
export interface Conflict { type: ConflictType; a: string; b?: string; minutes: number; }

export function detectConflicts(items: SchedItem[], dayEndMin = 1440): Conflict[] {
  const live = items.filter((i) => !INACTIVE.has(i.status)).slice().sort(byStart);
  const out: Conflict[] = [];
  for (let i = 0; i < live.length; i++) {
    const a = live[i];
    const coreA: [number, number] = [a.startMin, endOf(a)];
    for (let j = i + 1; j < live.length; j++) {
      const b = live[j];
      const occA = occupied(a);
      const occB = occupied(b);
      if (occB[0] >= occA[1] && b.startMin >= endOf(a)) {
        if (b.startMin - (b.prepMin ?? 0) >= occA[1]) break; // sorted: nothing later can intersect a's core either
      }
      const coreB: [number, number] = [b.startMin, endOf(b)];
      const core = overlapLen(coreA, coreB);
      if (core > 0) out.push({ type: a.fixed && b.fixed ? 'fixed_overlap' : 'overlap', a: a.id, b: b.id, minutes: core });
      else if (intersects(occA, occB)) out.push({ type: 'buffer', a: a.id, b: b.id, minutes: overlapLen(occA, occB) });
    }
    if (a.windowStartMin != null && a.startMin < a.windowStartMin) out.push({ type: 'window', a: a.id, minutes: a.windowStartMin - a.startMin });
    if (a.windowEndMin != null && endOf(a) > a.windowEndMin) out.push({ type: 'window', a: a.id, minutes: endOf(a) - a.windowEndMin });
    if (!a.fixed && endOf(a) > dayEndMin) out.push({ type: 'overflow', a: a.id, minutes: endOf(a) - dayEndMin });
    for (const dep of a.dependsOn ?? []) {
      const d = live.find((x) => x.id === dep);
      if (d && endOf(d) > a.startMin && d.status !== 'completed') out.push({ type: 'dependency', a: a.id, b: d.id, minutes: endOf(d) - a.startMin });
    }
  }
  return out;
}

export function conflictsFor(id: string, conflicts: Conflict[]): Conflict[] {
  return conflicts.filter((c) => c.a === id || c.b === id);
}

// ------------------------------------------------------------------------------------------------ free time

export function freeSlots(items: SchedItem[], fromMin: number, toMin: number, minLen = 1): [number, number][] {
  const occ = items.filter((i) => !INACTIVE.has(i.status)).map(occupied).filter((o) => o[1] > fromMin && o[0] < toMin).sort((a, b) => a[0] - b[0]);
  const gaps: [number, number][] = [];
  let cursor = fromMin;
  for (const [s, e] of occ) {
    if (s > cursor && s - cursor >= minLen) gaps.push([cursor, Math.min(s, toMin)]);
    cursor = Math.max(cursor, e);
    if (cursor >= toMin) break;
  }
  if (toMin - cursor >= minLen) gaps.push([cursor, toMin]);
  return gaps.filter(([s, e]) => e - s >= minLen);
}

/** Earliest start >= earliest where [t-pre, t+dur+post) is free and t+dur <= latest. */
export function findSlot(obstacles: [number, number][], earliest: number, dur: number, pre: number, post: number, latest: number): number | null {
  const obs = obstacles.slice().sort((a, b) => a[0] - b[0]);
  let t = earliest;
  for (let guard = 0; guard < obs.length + 2; guard++) {
    if (t + dur > latest) return null;
    const want: [number, number] = [t - pre, t + dur + post];
    const hit = obs.find((o) => intersects(o, want));
    if (!hit) return t;
    t = hit[1] + pre;
  }
  return t + dur <= latest ? t : null;
}

// ------------------------------------------------------------------------------------------------ proposals

export interface Piece { startMin: number; durationMin: number; }
export interface Change {
  id: string;
  title: string;
  kind: 'move' | 'split' | 'unplaced' | 'resize' | 'remove' | 'add';
  from: Piece;
  to: Piece[];
}
export interface Proposal {
  changes: Change[];
  unplaced: string[];
  shortageMin: number;
  feasible: boolean;
  conflictsAfter: Conflict[];
}

export interface RepackOptions {
  fromMin: number;
  dayEndMin: number;
  /** items that must stay where they are even if flexible (e.g. the one the user just changed) */
  lockedIds?: string[];
  /** move overdue planned items (ended before fromMin) to now */
  includeOverdue?: boolean;
}

/**
 * Repacks flexible, not-yet-started items so that none overlap fixed / locked / closed items.
 * Items keep their original time when it is still valid; otherwise they move to the earliest valid
 * time, are split (if allowed), or are reported as unplaced. Order of flexible items is preserved.
 */
export function repack(items: SchedItem[], opts: RepackOptions): { result: SchedItem[]; proposal: Proposal } {
  const locked = new Set(opts.lockedIds ?? []);
  const live = items.filter((i) => !INACTIVE.has(i.status));
  const isCandidate = (i: SchedItem) => isMovable(i) && !locked.has(i.id) && (endOf(i) > opts.fromMin || (opts.includeOverdue && i.status === 'planned'));
  const obstacles = live.filter((i) => !isCandidate(i));
  const movable = live.filter(isCandidate).sort(byStart);
  const occ: [number, number][] = obstacles.map(occupied);
  const placedEnd = new Map<string, number>();
  for (const o of obstacles) placedEnd.set(o.id, endOf(o));

  const changes: Change[] = [];
  const unplaced: string[] = [];
  const result: SchedItem[] = [...obstacles];
  let cursor = opts.fromMin;
  let shortage = 0;

  for (const m of movable) {
    const pre = m.prepMin ?? 0;
    const post = (m.cleanupMin ?? 0) + (m.bufferMin ?? 0);
    let earliest = Math.max(m.startMin, m.windowStartMin ?? 0, opts.fromMin);
    for (const dep of m.dependsOn ?? []) { const e = placedEnd.get(dep); if (e != null) earliest = Math.max(earliest, e); }
    if (m.startMin < cursor && earliest < cursor) earliest = Math.max(earliest, Math.min(cursor, earliest + 24 * 60));
    const latest = Math.min(m.windowEndMin ?? opts.dayEndMin, opts.dayEndMin);
    const t = findSlot(occ, earliest, m.durationMin, pre, post, latest);
    if (t != null) {
      const placed = { ...m, startMin: t };
      result.push(placed);
      occ.push(occupied(placed));
      placedEnd.set(m.id, endOf(placed));
      cursor = Math.max(cursor, t);
      if (t !== m.startMin) changes.push({ id: m.id, title: m.title, kind: 'move', from: { startMin: m.startMin, durationMin: m.durationMin }, to: [{ startMin: t, durationMin: m.durationMin }] });
      continue;
    }
    if (m.splitAllowed) {
      const minPiece = Math.max(5, m.minSplitMin ?? 25);
      const gaps = freeGapsFromOcc(occ, earliest, latest, pre, post).filter(([s, e]) => e - s >= minPiece);
      const pieces: Piece[] = [];
      let left = m.durationMin;
      for (const [s, e] of gaps) {
        if (left <= 0) break;
        const len = Math.min(e - s, left);
        if (len < minPiece && left > len) continue;
        if (left - len > 0 && left - len < minPiece) {
          const adj = left - minPiece;
          if (adj >= minPiece) { pieces.push({ startMin: s, durationMin: adj }); left -= adj; continue; }
          continue;
        }
        pieces.push({ startMin: s, durationMin: len });
        left -= len;
      }
      if (left <= 0 && pieces.length > 1) {
        pieces.forEach((p, i) => {
          const piece = { ...m, id: i === 0 ? m.id : `${m.id}::${i}`, startMin: p.startMin, durationMin: p.durationMin };
          result.push(piece); occ.push(occupied(piece));
        });
        placedEnd.set(m.id, Math.max(...pieces.map((p) => p.startMin + p.durationMin)));
        changes.push({ id: m.id, title: m.title, kind: 'split', from: { startMin: m.startMin, durationMin: m.durationMin }, to: pieces });
        continue;
      }
    }
    unplaced.push(m.id);
    shortage += m.durationMin;
    changes.push({ id: m.id, title: m.title, kind: 'unplaced', from: { startMin: m.startMin, durationMin: m.durationMin }, to: [] });
  }
  const conflictsAfter = detectConflicts(result, opts.dayEndMin).filter((c) => c.type !== 'overflow');
  return {
    result: result.sort(byStart),
    proposal: { changes, unplaced, shortageMin: shortage, feasible: unplaced.length === 0, conflictsAfter },
  };
}

function freeGapsFromOcc(occ: [number, number][], from: number, to: number, pre: number, post: number): [number, number][] {
  const sorted = occ.slice().sort((a, b) => a[0] - b[0]);
  const gaps: [number, number][] = [];
  let cursor = from;
  for (const [s, e] of sorted) {
    if (e <= cursor) continue;
    if (s - post > cursor + pre) gaps.push([cursor + pre, Math.min(s - post, to)]);
    cursor = Math.max(cursor, e);
    if (cursor >= to) break;
  }
  if (to > cursor + pre) gaps.push([cursor + pre, to]);
  return gaps.filter(([s, e]) => e > s);
}

// ------------------------------------------------------------------------------------------------ catch-up & what-if

export interface DelayInput { delayedId: string; nowMin: number; dayEndMin: number; }

/** A block is running late (or overdue): start it now and repack everything flexible after it. */
export function planCatchUp(items: SchedItem[], input: DelayInput): { result: SchedItem[]; proposal: Proposal; delayMin: number } {
  const target = items.find((i) => i.id === input.delayedId);
  if (!target) return { result: items, proposal: { changes: [], unplaced: [], shortageMin: 0, feasible: true, conflictsAfter: [] }, delayMin: 0 };
  const newStart = Math.max(Math.ceil(input.nowMin), target.startMin);
  const delayMin = newStart - target.startMin;
  const moved = items.map((i) => (i.id === target.id ? { ...i, startMin: newStart, fixed: false } : i));
  // The delayed block itself is locked at its new time only if that time is free of fixed items; otherwise it is repacked too.
  const fixedHit = moved.some((i) => i.id !== target.id && (i.fixed || CLOSED.has(i.status) || i.status === 'active') && !INACTIVE.has(i.status) &&
    intersects(occupied(i), occupied({ ...target, startMin: newStart })));
  const { result, proposal } = repack(moved, { fromMin: Math.ceil(input.nowMin), dayEndMin: input.dayEndMin, lockedIds: fixedHit ? [] : [target.id] });
  if (delayMin > 0 && !proposal.changes.some((c) => c.id === target.id)) {
    const r = result.find((x) => x.id === target.id);
    proposal.changes.unshift({ id: target.id, title: target.title, kind: 'move', from: { startMin: target.startMin, durationMin: target.durationMin }, to: [{ startMin: r?.startMin ?? newStart, durationMin: target.durationMin }] });
  }
  return { result, proposal, delayMin };
}

export type WhatIf =
  | { type: 'delay'; id: string; minutes: number }
  | { type: 'extend'; id: string; minutes: number }
  | { type: 'move_tomorrow'; id: string }
  | { type: 'add'; item: SchedItem };

export function simulate(items: SchedItem[], change: WhatIf, opts: { nowMin: number; dayEndMin: number }): { result: SchedItem[]; proposal: Proposal } {
  let next = items.slice();
  let locked: string[] = [];
  const extra: Change[] = [];
  if (change.type === 'delay' || change.type === 'extend') {
    const t = next.find((i) => i.id === change.id);
    if (!t) return repack(next, { fromMin: opts.nowMin, dayEndMin: opts.dayEndMin });
    const upd = change.type === 'delay' ? { ...t, startMin: t.startMin + change.minutes } : { ...t, durationMin: Math.max(1, t.durationMin + change.minutes) };
    next = next.map((i) => (i.id === t.id ? upd : i));
    locked = [t.id];
    extra.push({ id: t.id, title: t.title, kind: change.type === 'delay' ? 'move' : 'resize', from: { startMin: t.startMin, durationMin: t.durationMin }, to: [{ startMin: upd.startMin, durationMin: upd.durationMin }] });
  } else if (change.type === 'move_tomorrow') {
    const t = next.find((i) => i.id === change.id);
    next = next.filter((i) => i.id !== change.id);
    if (t) extra.push({ id: t.id, title: t.title, kind: 'remove', from: { startMin: t.startMin, durationMin: t.durationMin }, to: [] });
  } else if (change.type === 'add') {
    next = [...next, { ...change.item, fixed: true }];
    locked = [change.item.id];
    extra.push({ id: change.item.id, title: change.item.title, kind: 'add', from: { startMin: change.item.startMin, durationMin: 0 }, to: [{ startMin: change.item.startMin, durationMin: change.item.durationMin }] });
  }
  const { result, proposal } = repack(next, { fromMin: Math.min(opts.nowMin, 0) === 0 ? opts.nowMin : opts.nowMin, dayEndMin: opts.dayEndMin, lockedIds: locked });
  proposal.changes = [...extra, ...proposal.changes.filter((c) => !extra.some((e) => e.id === c.id))];
  return { result, proposal };
}

// ------------------------------------------------------------------------------------------------ multi-day placement

export interface PlaceRequest {
  refId: string;
  title: string;
  durationMin: number;
  priority: number;
  difficulty: number;
  deadline?: DateKey;
  splitAllowed: boolean;
  minSplitMin: number;
}
export interface DayCapacity { date: DateKey; items: SchedItem[]; fromMin: number; }
export interface Placement { refId: string; date: DateKey; startMin: number; durationMin: number; }
export interface PlaceOptions { dayStartMin: number; dayEndMin: number; productiveStartMin: number; productiveEndMin: number; bufferMin: number; }

/**
 * Deterministically places work into free time across days.
 * Order: earliest deadline, then priority desc, difficulty desc, id. Difficult work (>=4) prefers
 * gaps overlapping the user's productive hours. Returns placements and per-item shortages.
 */
export function placeAcrossDays(reqs: PlaceRequest[], days: DayCapacity[], opts: PlaceOptions): { placements: Placement[]; shortages: Record<string, number> } {
  const ordered = reqs.slice().sort((a, b) =>
    (a.deadline ?? '9999-12-31').localeCompare(b.deadline ?? '9999-12-31') || b.priority - a.priority || b.difficulty - a.difficulty || a.refId.localeCompare(b.refId));
  const occByDay = new Map<DateKey, [number, number][]>();
  for (const d of days) occByDay.set(d.date, d.items.filter((i) => !INACTIVE.has(i.status)).map(occupied));
  const placements: Placement[] = [];
  const shortages: Record<string, number> = {};

  for (const r of ordered) {
    let left = r.durationMin;
    for (const d of days) {
      if (left <= 0) break;
      if (r.deadline && d.date > r.deadline) break;
      const occ = occByDay.get(d.date)!;
      const from = Math.max(opts.dayStartMin, d.fromMin);
      let gaps = freeGapsFromOcc(occ, from, opts.dayEndMin, opts.bufferMin, opts.bufferMin);
      if (r.difficulty >= 4) {
        const prod = (g: [number, number]) => overlapLen(g, [opts.productiveStartMin, opts.productiveEndMin]);
        gaps = gaps.slice().sort((a, b) => prod(b) - prod(a) || a[0] - b[0]);
      }
      for (const g of gaps) {
        if (left <= 0) break;
        let [s, e] = g;
        if (r.difficulty >= 4 && overlapLen(g, [opts.productiveStartMin, opts.productiveEndMin]) >= Math.min(left, r.minSplitMin)) {
          s = Math.max(s, opts.productiveStartMin);
          if (e - s < Math.min(left, r.minSplitMin)) [s, e] = g;
        }
        const avail = e - s;
        if (avail >= left) { placements.push({ refId: r.refId, date: d.date, startMin: s, durationMin: left }); occ.push([s - opts.bufferMin, s + left + opts.bufferMin]); left = 0; }
        else if (r.splitAllowed && avail >= r.minSplitMin) {
          const len = left - avail < r.minSplitMin && left - avail > 0 ? left - r.minSplitMin : avail;
          if (len >= r.minSplitMin) { placements.push({ refId: r.refId, date: d.date, startMin: s, durationMin: len }); occ.push([s - opts.bufferMin, s + len + opts.bufferMin]); left -= len; }
        }
      }
    }
    if (left > 0) shortages[r.refId] = left;
  }
  return { placements, shortages };
}

// ------------------------------------------------------------------------------------------------ day summary

export interface SummaryItem extends SchedItem { actualStart?: number | null; actualEnd?: number | null; pausedTotalMs?: number; completionPercent?: number | null; }
export interface DaySummary {
  plannedMin: number; creditedMin: number; trackedMin: number; remainingMin: number; completionPct: number;
  completed: number; pending: number; missed: number; skipped: number; total: number; freeLeftMin: number; overdue: number;
}

export function trackedMinutes(b: SummaryItem, now = Date.now()): number {
  if (!b.actualStart) return 0;
  const end = b.actualEnd ?? (b.status === 'active' ? now : b.status === 'paused' ? b.actualStart : b.actualStart);
  return Math.max(0, (end - b.actualStart - (b.pausedTotalMs ?? 0)) / 60000);
}
export function creditedMinutes(b: SummaryItem): number {
  if (b.status === 'completed') return b.durationMin;
  if (b.status === 'partial') {
    if (b.completionPercent != null) return (b.durationMin * Math.max(0, Math.min(100, b.completionPercent))) / 100;
    return Math.min(b.durationMin, trackedMinutes(b));
  }
  return 0;
}

/**
 * Denominator: planned minutes of all non-cancelled blocks (skipped/missed included, they were planned).
 * Credited: full duration for completed, measured fraction for partial.
 * Tracked: actual measured time (start→end minus pauses) — distinct from clock time.
 */
export function summarizeDay(items: SummaryItem[], opts: { isToday: boolean; isPast: boolean; nowMin: number; dayEndMin: number; now?: number }): DaySummary {
  const live = items.filter((i) => i.status !== 'cancelled');
  let planned = 0, credited = 0, tracked = 0, remaining = 0, completed = 0, pending = 0, missed = 0, skipped = 0, overdue = 0;
  for (const b of live) {
    planned += b.durationMin;
    credited += creditedMinutes(b);
    tracked += trackedMinutes(b, opts.now);
    if (b.status === 'completed') completed++;
    else if (b.status === 'skipped') skipped++;
    else if (b.status === 'missed') missed++;
    else if (b.status === 'partial') completed += 0;
    else {
      const isOver = opts.isPast || (opts.isToday && endOf(b) <= opts.nowMin && b.status === 'planned');
      if (isOver && opts.isPast) missed++;
      else { pending++; if (isOver) overdue++; }
      if (!opts.isPast) {
        if (opts.isToday) remaining += Math.max(0, endOf(b) - Math.max(b.startMin, opts.nowMin)) || (isOver ? b.durationMin : 0);
        else remaining += b.durationMin;
      }
    }
  }
  let freeLeft = 0;
  if (opts.isToday) {
    const from = Math.ceil(opts.nowMin);
    freeLeft = freeSlots(live.filter((b) => !CLOSED.has(b.status) || endOf(b) > from), from, opts.dayEndMin).reduce((s, [a, z]) => s + (z - a), 0);
  } else if (!opts.isPast) {
    freeLeft = freeSlots(live, 0, opts.dayEndMin).reduce((s, [a, z]) => s + (z - a), 0);
  }
  return {
    plannedMin: planned, creditedMin: credited, trackedMin: tracked, remainingMin: remaining,
    completionPct: planned > 0 ? Math.round((credited / planned) * 100) : 0,
    completed, pending, missed, skipped, total: live.length, freeLeftMin: Math.max(0, freeLeft), overdue,
  };
}

// ------------------------------------------------------------------------------------------------ recurrence

function monthsBetween(a: DateKey, b: DateKey): number {
  const pa = parseDateKey(a), pb = parseDateKey(b);
  return (pb.getFullYear() - pa.getFullYear()) * 12 + (pb.getMonth() - pa.getMonth());
}
function daysInMonth(k: DateKey): number { const d = parseDateKey(k); return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); }

function matchesPattern(rule: RecurrenceRule, date: DateKey): boolean {
  if (date < rule.start) return false;
  if (rule.until && date > rule.until) return false;
  const interval = Math.max(1, rule.interval || 1);
  switch (rule.freq) {
    case 'daily': return diffDays(rule.start, date) % interval === 0;
    case 'weekly': {
      const days = rule.byWeekday?.length ? rule.byWeekday : [weekday(rule.start)];
      if (!days.includes(weekday(date))) return false;
      const weeks = Math.round(diffDays(startOfWeek(rule.start, 0), startOfWeek(date, 0)) / 7);
      return weeks % interval === 0;
    }
    case 'monthly': {
      const months = monthsBetween(rule.start, date);
      if (months % interval !== 0) return false;
      const target = rule.byMonthDay ?? parseDateKey(rule.start).getDate();
      const dom = parseDateKey(date).getDate();
      return dom === Math.min(target, daysInMonth(date));
    }
    case 'dates': return (rule.dates ?? []).includes(date);
  }
  return false;
}

export function occursOn(rule: RecurrenceRule, date: DateKey, exceptions: DateKey[] = []): boolean {
  if (exceptions.includes(date)) return false;
  if (!matchesPattern(rule, date)) return false;
  if (rule.count && rule.count > 0) {
    let n = 0;
    for (let d = rule.start, guard = 0; d <= date && guard < 3700; d = addDays(d, 1), guard++) {
      if (matchesPattern(rule, d)) n++;
      if (n > rule.count) return false;
    }
    return n <= rule.count;
  }
  return true;
}

export function occurrencesBetween(rule: RecurrenceRule, from: DateKey, to: DateKey, exceptions: DateKey[] = []): DateKey[] {
  const out: DateKey[] = [];
  for (let d = from, g = 0; d <= to && g < 800; d = addDays(d, 1), g++) if (occursOn(rule, d, exceptions)) out.push(d);
  return out;
}

// ------------------------------------------------------------------------------------------------ visual lane layout

export interface LaneItem { id: string; start: number; end: number }
export interface Lane { col: number; cols: number }
/**
 * Lays out blocks of one day side by side so that none hides another.
 * Every block occupies at least `minVisualMin` minutes of vertical space (so tiny blocks stay readable);
 * blocks whose visual extents touch or overlap share a cluster and are split into equal columns (greedy interval colouring).
 * Deterministic: ties are broken by start, longer-first, id.
 */
export function layoutLanes(items: LaneItem[], minVisualMin: number): Record<string, Lane> {
  const vis = items.map((i) => ({ ...i, vend: Math.max(i.end, i.start + minVisualMin) }))
    .sort((a, b) => a.start - b.start || (b.vend - b.start) - (a.vend - a.start) || a.id.localeCompare(b.id));
  const out: Record<string, Lane> = {};
  let cluster: typeof vis = [];
  let clusterEnd = -Infinity;
  const flush = () => {
    if (!cluster.length) return;
    const colEnds: number[] = [];
    const assign: Record<string, number> = {};
    for (const it of cluster) {
      let c = colEnds.findIndex((e) => e <= it.start);
      if (c < 0) { c = colEnds.length; colEnds.push(it.vend); } else colEnds[c] = it.vend;
      assign[it.id] = c;
    }
    for (const it of cluster) out[it.id] = { col: assign[it.id], cols: colEnds.length };
    cluster = [];
  };
  for (const it of vis) {
    if (it.start >= clusterEnd) { flush(); clusterEnd = -Infinity; }
    cluster.push(it); clusterEnd = Math.max(clusterEnd, it.vend);
  }
  flush();
  return out;
}
