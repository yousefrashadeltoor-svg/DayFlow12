import type { ActivityBlock, ActivityCategory, ScheduleRule, Settings, Task, DateKey } from '@/models/types';
import { CLOSED, INACTIVE, endOf, detectConflicts } from './engine';
import type { TKey } from '@/services/localization/i18n';

export interface RuleSuggestion {
  type: 'insert_break' | 'move_later' | 'add_prep' | 'schedule_task' | 'raise_water';
  blockId?: string;
  taskId?: string;
  atMin?: number;
  minutes?: number;
}
export interface RuleViolation {
  ruleId: string;
  ruleType: ScheduleRule['type'];
  messageKey: TKey;
  params: Record<string, string | number>;
  blockIds: string[];
  suggestion?: RuleSuggestion;
  severity: 'info' | 'warning';
}

export interface RuleContext {
  date: DateKey;
  blocks: ActivityBlock[];
  categories: Record<string, ActivityCategory>;
  settings: Settings;
  tasks: Task[];
  scheduledTaskIds: Set<string>;
  fmtTime: (m: number) => string;
  fmtDate: (d: DateKey) => string;
}

const catKey = (ctx: RuleContext, b: ActivityBlock) => ctx.categories[b.categoryId]?.key ?? 'custom';
const isBreak = (ctx: RuleContext, b: ActivityBlock) => ['rest', 'meal', 'prayer', 'sleep'].includes(catKey(ctx, b));
const isWork = (ctx: RuleContext, b: ActivityBlock) => ['study', 'work'].includes(catKey(ctx, b)) || (ctx.categories[b.categoryId]?.productive ?? false);

/** Evaluates every enabled rule (sorted by priority) against one day. Pure and deterministic. */
export function evaluateRules(rules: ScheduleRule[], ctx: RuleContext): RuleViolation[] {
  const blocks = ctx.blocks.filter((b) => !INACTIVE.has(b.status)).slice().sort((a, b) => a.startMin - b.startMin);
  const out: RuleViolation[] = [];
  const enabled = rules.filter((r) => r.enabled && !r.override).sort((a, b) => b.priority - a.priority);

  for (const r of enabled) {
    const p = r.params;
    switch (r.type) {
      case 'recovery_after_study': {
        const minStudy = p.minStudyMin ?? 90, rec = p.recoveryMin ?? 15;
        for (let i = 0; i < blocks.length; i++) {
          const b = blocks[i];
          if (catKey(ctx, b) !== 'study' || b.durationMin < minStudy) continue;
          const next = blocks.find((x) => x.startMin >= endOf(b) && x.id !== b.id);
          if (next && !isBreak(ctx, next) && next.startMin - endOf(b) < rec) {
            out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_recovery', params: { x: b.title, m: rec }, blockIds: [b.id, next.id], severity: 'warning',
              suggestion: { type: 'insert_break', atMin: endOf(b), minutes: rec, blockId: next.id } });
          }
        }
        break;
      }
      case 'prep_before_workout': {
        const prep = p.prepMin ?? 10;
        for (const b of blocks) {
          if (catKey(ctx, b) !== 'exercise' || CLOSED.has(b.status)) continue;
          const prev = blocks.filter((x) => endOf(x) <= b.startMin && x.id !== b.id).pop();
          const gap = prev ? b.startMin - endOf(prev) : Infinity;
          if ((b.prepMin ?? 0) < prep && gap < prep) {
            out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_prep', params: { x: b.title, m: prep }, blockIds: [b.id], severity: 'info',
              suggestion: { type: 'add_prep', blockId: b.id, minutes: prep } });
          }
        }
        break;
      }
      case 'no_overlap': {
        const conflicts = detectConflicts(blocks, ctx.settings.dayEndMin).filter((c) => c.type === 'overlap' || c.type === 'fixed_overlap');
        for (const c of conflicts) {
          const a = blocks.find((x) => x.id === c.a), b = blocks.find((x) => x.id === c.b);
          if (!a || !b) continue;
          const movable = !b.fixed ? b : !a.fixed ? a : undefined;
          out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_overlap', params: { x: a.title, y: b.title }, blockIds: [a.id, b.id], severity: 'warning',
            suggestion: movable ? { type: 'move_later', blockId: movable.id } : undefined });
        }
        break;
      }
      case 'difficult_in_productive_hours': {
        const minD = p.minDifficulty ?? 4;
        for (const b of blocks) {
          if (b.fixed || CLOSED.has(b.status) || (b.difficulty ?? 3) < minD) continue;
          const inside = b.startMin >= ctx.settings.productiveStartMin && endOf(b) <= ctx.settings.productiveEndMin;
          if (!inside) out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_difficult', params: { x: b.title }, blockIds: [b.id], severity: 'info' });
        }
        break;
      }
      case 'min_rest': {
        const maxCont = p.maxContinuousMin ?? 120;
        let runStart: number | null = null, runEnd = 0, lastTitle = '';
        for (const b of blocks) {
          if (isWork(ctx, b)) {
            if (runStart == null || b.startMin - runEnd >= (p.restMin ?? 10)) runStart = b.startMin;
            runEnd = Math.max(runEnd, endOf(b)); lastTitle = b.title;
            if (runEnd - runStart > maxCont) {
              out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_min_rest', params: { m: runEnd - runStart, x: lastTitle }, blockIds: [b.id], severity: 'warning',
                suggestion: { type: 'insert_break', atMin: b.startMin, minutes: p.restMin ?? 10, blockId: b.id } });
              runStart = null; runEnd = 0;
            }
          } else if (isBreak(ctx, b)) { runStart = null; runEnd = 0; }
        }
        break;
      }
      case 'subject_session_limit': {
        const max = p.maxPerDay ?? 3;
        const counts = new Map<string, ActivityBlock[]>();
        for (const b of blocks) if (b.subjectId) counts.set(b.subjectId, [...(counts.get(b.subjectId) ?? []), b]);
        for (const [, list] of counts) if (list.length > max) {
          out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_subject_limit', params: { x: list[0].title, n: list.length, m: max }, blockIds: list.map((b) => b.id), severity: 'info' });
        }
        break;
      }
      case 'deadline_guard': {
        const horizon = p.horizonDays ?? 2;
        const limit = new Date(); limit.setDate(limit.getDate() + horizon);
        const limitKey = `${limit.getFullYear()}-${String(limit.getMonth() + 1).padStart(2, '0')}-${String(limit.getDate()).padStart(2, '0')}`;
        for (const t of ctx.tasks) {
          if (t.status === 'done' || t.status === 'cancelled' || !t.dueDate || t.priority < (p.minPriority ?? 4)) continue;
          if (t.dueDate <= limitKey && !ctx.scheduledTaskIds.has(t.id)) {
            out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_deadline', params: { x: t.title, d: ctx.fmtDate(t.dueDate) }, blockIds: [], severity: 'warning',
              suggestion: { type: 'schedule_task', taskId: t.id } });
          }
        }
        break;
      }
      case 'protect_breaks': {
        for (const b of blocks) {
          if (catKey(ctx, b) !== 'rest') continue;
          const hit = blocks.find((x) => x.id !== b.id && !isBreak(ctx, x) && x.startMin < endOf(b) && b.startMin < endOf(x));
          if (hit) out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_break', params: { x: b.title }, blockIds: [b.id, hit.id], severity: 'warning',
            suggestion: !hit.fixed ? { type: 'move_later', blockId: hit.id } : undefined });
        }
        break;
      }
      case 'quiet_sleep': {
        const q = ctx.settings.quietHours;
        if (!q.enabled) break;
        for (const b of blocks) {
          if (!b.reminder.enabled || b.reminder.critical || CLOSED.has(b.status)) continue;
          for (const off of b.reminder.offsets) {
            if (inQuiet(b.startMin - off, q.startMin, q.endMin)) {
              out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_quiet', params: { x: b.title }, blockIds: [b.id], severity: 'info' });
              break;
            }
          }
        }
        break;
      }
      case 'water_on_active_days': {
        const active = blocks.some((b) => catKey(ctx, b) === 'exercise');
        if (active) out.push({ ruleId: r.id, ruleType: r.type, messageKey: 'rv_water', params: { m: p.extraMl ?? ctx.settings.water.workoutBonusMl }, blockIds: [], severity: 'info',
          suggestion: { type: 'raise_water', minutes: p.extraMl ?? ctx.settings.water.workoutBonusMl } });
        break;
      }
    }
  }
  return out;
}

export function inQuiet(minute: number, start: number, end: number): boolean {
  const m = ((minute % 1440) + 1440) % 1440;
  return start <= end ? m >= start && m < end : m >= start || m < end;
}
