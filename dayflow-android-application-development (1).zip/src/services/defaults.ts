import type { ActivityCategory, ActivityCore, DayTemplate, ReminderConfig, ScheduleRule, Settings, Lang, Routine, Exercise } from '@/models/types';
import { uid } from '@/utils/id';

const now = () => Date.now();

export function defaultSettings(lang: Lang): Settings {
  const t = now();
  return {
    id: 'app', createdAt: t, updatedAt: t,
    userName: '', language: lang, theme: 'system', accent: 'indigo', weekStart: lang === 'ar' ? 6 : 1, clock24: lang !== 'en', fontScale: 1,
    density: 'comfortable', haptics: true, reducedMotion: 'system',
    dashboard: { overview: true, quickActions: true, water: true, habits: true, collapseCompleted: false, prayer: true, tasks: true },
    themeId: 'dayflow', decor: 'full', decorSpeed: 1, decorOpacity: 0.7, decorLayer: 'front', decorSeasons: {}, decorPreview: '', decorActive: [], hijriAdjust: 0, autoApplyPlan: false, showOtherReligions: true, occasionNotify: true,
    journal: { reminderEnabled: false, reminderMin: 21 * 60 },
    widgetLayout: 'medium', defaultDurationMin: 45, defaultBufferMin: 5, defaultReminderOffsets: [0],
    defaultActions: ['DONE', 'SNOOZE_10', 'SKIP'], soundMode: 'tts', volume: 0.9, gradualVolume: true, vibrate: true, audioRepeat: 2,
    escalation: { repeatIntervalMin: 5, maxRepeats: 2 },
    quietHours: { enabled: true, startMin: 23 * 60, endMin: 6 * 60, days: [0, 1, 2, 3, 4, 5, 6], allowCritical: true },
    reminderHorizonDays: 7, dayStartMin: 6 * 60, dayEndMin: 23 * 60, productiveStartMin: 9 * 60, productiveEndMin: 13 * 60,
    water: { targetMl: 2500, cupSizes: [150, 250, 330, 500], reminderEnabled: false, intervalMin: 90, wakeStartMin: 8 * 60, wakeEndMin: 21 * 60, workoutBonusMl: 500 },
    sleep: { bedtimeMin: 23 * 60, wakeMin: 7 * 60, prepReminderMin: 45, prepReminderEnabled: true, wakeReminder: false },
    focus: { pomodoroWork: 25, pomodoroShort: 5, pomodoroLong: 15, cyclesBeforeLong: 4, extendedWork: 50, extendedBreak: 10, deepWork: 90, deepBreak: 20, countdown: 30, customWork: 40, customBreak: 8, autoStartBreaks: false },
    srsIntervals: [1, 3, 7, 21],
    burnout: { enabled: true, maxDailyWorkMin: 540, lowEnergyThreshold: 2, lookbackDays: 7, postponeThreshold: 3 },
    insightsMinObservations: 10,
    prayer: { governorate: 'cairo', leadMin: 10, ongoing: true, sound: { kind: 'default' }, enabled: false, method: 'egypt', asr: 'standard', lat: 30.0444, lng: 31.2357, city: 'cairo', adjustments: { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 }, createBlocks: false, durationMin: 15, reminder: true },
    aiCoachEnabled: false,
    ai: { consent: false, providerId: 'groq', modelId: '', execution: 'confirm_destructive', shareContext: true, temperature: 0.4, providers: {}, freeOnly: false }, onboarded: false, timeZoneBehavior: 'device', lastTimeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  };
}

const CATS: [string, string, string, string, string, boolean][] = [
  ['study', 'دراسة', 'Study', 'book-open', 'var(--c-study)', true],
  ['work', 'عمل', 'Work', 'briefcase', 'var(--c-work)', true],
  ['exercise', 'تمرين', 'Exercise', 'dumbbell', 'var(--c-exercise)', false],
  ['rest', 'راحة', 'Rest', 'coffee', 'var(--c-rest)', false],
  ['meal', 'وجبة', 'Meal', 'utensils', 'var(--c-meal)', false],
  ['sleep', 'نوم', 'Sleep', 'moon', 'var(--c-sleep)', false],
  ['water', 'ماء', 'Water', 'droplets', 'var(--c-water)', false],
  ['personal', 'شخصي', 'Personal', 'user', 'var(--c-custom)', false],
  ['prayer', 'صلاة', 'Prayer', 'sunrise', 'var(--c-rest)', false],
  ['routine', 'روتين', 'Routine', 'list-checks', 'var(--c-custom)', false],
  ['appointment', 'موعد', 'Appointment', 'calendar-clock', 'var(--c-work)', false],
];

export function defaultCategories(): ActivityCategory[] {
  const t = now();
  return CATS.map(([key, nameAr, nameEn, icon, color, productive]) => ({ id: `cat_${key}`, key, nameAr, nameEn, icon, color, builtin: true, productive, createdAt: t, updatedAt: t }));
}

export function defaultReminder(s?: Pick<Settings, 'defaultReminderOffsets' | 'defaultActions' | 'escalation'>): ReminderConfig {
  return {
    enabled: true, offsets: s?.defaultReminderOffsets ?? [0], atEnd: false, soundMode: 'inherit',
    repeatIntervalMin: s?.escalation.repeatIntervalMin ?? 5, maxRepeats: s?.escalation.maxRepeats ?? 2, critical: false,
    actions: s?.defaultActions ?? ['DONE', 'SNOOZE_10', 'SKIP'],
  };
}

export function coreFrom(p: Partial<ActivityCore> & { title: string; categoryId: string; startMin: number; durationMin: number }): ActivityCore {
  const cat = CATS.find((c) => `cat_${c[0]}` === p.categoryId);
  return {
    description: '', icon: cat?.[3] ?? 'circle', color: cat?.[4] ?? 'var(--c-custom)', fixed: false, priority: 3, importance: 3, energy: 'medium', difficulty: 3,
    reminder: defaultReminder(), prepMin: 0, cleanupMin: 0, bufferMin: 0, dependsOn: [], notes: '', tags: [], splitAllowed: false, minSplitMin: 25,
    ...p,
  };
}

type TplRow = [string, string, string, number, number, boolean?];
const h = (x: number, m = 0) => x * 60 + m;
function tpl(id: string, kind: DayTemplate['kind'], nameAr: string, nameEn: string, rows: TplRow[], lang: Lang): DayTemplate {
  const t = now();
  return {
    id, kind, name: lang === 'ar' ? nameAr : nameEn, builtin: true, createdAt: t, updatedAt: t,
    blocks: rows.map(([ar, en, cat, start, dur, fixed]) => coreFrom({ title: lang === 'ar' ? ar : en, categoryId: `cat_${cat}`, startMin: start, durationMin: dur, fixed: !!fixed })),
  };
}

export function defaultTemplates(lang: Lang): DayTemplate[] {
  return [
    tpl('tpl_normal', 'normal', 'يوم عادي', 'Normal day', [
      ['روتين الصباح', 'Morning routine', 'routine', h(7), 30], ['الإفطار', 'Breakfast', 'meal', h(7, 30), 30, true], ['عمل مركّز', 'Focused work', 'work', h(9), 120],
      ['استراحة', 'Break', 'rest', h(11), 15], ['مهام خفيفة', 'Light tasks', 'personal', h(11, 15), 60], ['الغداء', 'Lunch', 'meal', h(13), 45, true],
      ['قراءة', 'Reading', 'study', h(16), 45], ['تمرين', 'Workout', 'exercise', h(18), 60], ['العشاء', 'Dinner', 'meal', h(20), 45], ['روتين ما قبل النوم', 'Pre-sleep routine', 'routine', h(22, 15), 30],
    ], lang),
    tpl('tpl_school', 'school', 'يوم دراسي', 'School day', [
      ['الإفطار', 'Breakfast', 'meal', h(6, 30), 30, true], ['الحصص الدراسية', 'Classes', 'study', h(7, 30), 360, true], ['الغداء', 'Lunch', 'meal', h(14), 45, true],
      ['راحة', 'Rest', 'rest', h(14, 45), 45], ['واجبات', 'Homework', 'study', h(16), 90], ['مراجعة', 'Review', 'study', h(18), 60], ['العشاء', 'Dinner', 'meal', h(20), 40],
    ], lang),
    tpl('tpl_exam', 'exam', 'التحضير للامتحان', 'Exam preparation', [
      ['مراجعة مكثفة ١', 'Deep review 1', 'study', h(8), 100], ['استراحة', 'Break', 'rest', h(9, 40), 20], ['حل نماذج', 'Practice tests', 'study', h(10), 90],
      ['الغداء', 'Lunch', 'meal', h(13), 45, true], ['بطاقات المراجعة', 'Flashcards', 'study', h(15), 45], ['مراجعة مكثفة ٢', 'Deep review 2', 'study', h(16), 90],
      ['مشي خفيف', 'Light walk', 'exercise', h(18), 30], ['مراجعة نهائية', 'Final recap', 'study', h(20, 30), 45],
    ], lang),
    tpl('tpl_work', 'work', 'يوم عمل', 'Work day', [
      ['التنقل', 'Commute', 'personal', h(8), 30, true], ['العمل', 'Work', 'work', h(8, 30), 240, true], ['الغداء', 'Lunch', 'meal', h(12, 30), 45, true],
      ['العمل', 'Work', 'work', h(13, 15), 225, true], ['تمرين', 'Workout', 'exercise', h(18), 60], ['وقت شخصي', 'Personal time', 'personal', h(19, 30), 90],
    ], lang),
    tpl('tpl_weekend', 'weekend', 'عطلة نهاية الأسبوع', 'Weekend', [
      ['إفطار هادئ', 'Slow breakfast', 'meal', h(9), 45], ['مشروع شخصي', 'Personal project', 'personal', h(10, 30), 120], ['الغداء', 'Lunch', 'meal', h(13, 30), 60],
      ['نشاط خارجي', 'Outdoor activity', 'exercise', h(16), 90], ['وقت العائلة', 'Family time', 'personal', h(19), 120],
    ], lang),
    tpl('tpl_vacation', 'vacation', 'إجازة', 'Vacation', [['استرخاء', 'Relax', 'rest', h(10), 120], ['نزهة', 'Outing', 'personal', h(16), 180]], lang),
    tpl('tpl_recovery', 'recovery', 'يوم تعافٍ', 'Recovery day', [
      ['نوم إضافي', 'Extra sleep', 'sleep', h(7), 90], ['مشي خفيف', 'Gentle walk', 'exercise', h(10), 30], ['قراءة ممتعة', 'Leisure reading', 'rest', h(15), 60], ['نوم مبكر', 'Early night', 'routine', h(21, 30), 30],
    ], lang),
    tpl('tpl_light', 'light', 'يوم خفيف', 'Light day', [['أهم مهمة واحدة', 'One key task', 'work', h(10), 90], ['راحة', 'Rest', 'rest', h(12), 60], ['ترتيب المساحة', 'Tidy workspace', 'personal', h(17), 30]], lang),
  ];
}

export function defaultRules(): ScheduleRule[] {
  const t = now();
  const r = (type: ScheduleRule['type'], priority: number, params: Record<string, number>, enabled = true): ScheduleRule =>
    ({ id: `rule_${type}`, type, priority, params, enabled, override: false, createdAt: t, updatedAt: t });
  return [
    r('no_overlap', 10, {}), r('protect_breaks', 9, {}), r('deadline_guard', 8, { horizonDays: 2, minPriority: 4 }),
    r('recovery_after_study', 7, { minStudyMin: 90, recoveryMin: 15 }), r('min_rest', 6, { maxContinuousMin: 150, restMin: 10 }),
    r('prep_before_workout', 5, { prepMin: 10 }), r('difficult_in_productive_hours', 4, { minDifficulty: 4 }),
    r('subject_session_limit', 3, { maxPerDay: 3 }), r('quiet_sleep', 2, {}), r('water_on_active_days', 1, { extraMl: 500 }),
  ];
}

export function defaultRoutines(lang: Lang): Routine[] {
  const t = now();
  const s = (ar: string, en: string, d: number, req = true) => ({ id: uid(), title: lang === 'ar' ? ar : en, durationMin: d, required: req });
  return [
    { id: 'rt_morning', kind: 'morning', name: lang === 'ar' ? 'روتين الصباح' : 'Morning routine', categoryId: 'cat_routine', createdAt: t, updatedAt: t,
      steps: [s('شرب كوب ماء', 'Drink a glass of water', 2), s('ترتيب السرير', 'Make the bed', 3), s('تمدد خفيف', 'Light stretching', 10, false), s('مراجعة خطة اليوم', "Review today's plan", 5)] },
    { id: 'rt_pre_sleep', kind: 'pre_sleep', name: lang === 'ar' ? 'روتين ما قبل النوم' : 'Pre-sleep routine', categoryId: 'cat_routine', createdAt: t, updatedAt: t,
      steps: [s('إبعاد الشاشات', 'Put screens away', 2), s('تحضير أغراض الغد', "Prepare tomorrow's things", 10), s('قراءة هادئة', 'Calm reading', 15, false)] },
    { id: 'rt_pre_study', kind: 'pre_study', name: lang === 'ar' ? 'قبل الدراسة' : 'Before study', categoryId: 'cat_routine', createdAt: t, updatedAt: t,
      steps: [s('ترتيب المكتب', 'Clear the desk', 3), s('تحديد هدف الجلسة', 'Set a session goal', 2), s('إسكات الهاتف', 'Silence the phone', 1)] },
  ];
}

export function defaultExercises(lang: Lang): Exercise[] {
  const t = now();
  const e = (id: string, ar: string, en: string, cat: string, muscles: string[]) => ({ id, name: lang === 'ar' ? ar : en, category: cat, equipment: '', muscles, instructions: '', createdAt: t, updatedAt: t });
  return [
    e('ex_squat', 'قرفصاء', 'Squat', 'strength', ['legs']), e('ex_pushup', 'ضغط', 'Push-up', 'strength', ['chest', 'arms']), e('ex_plank', 'بلانك', 'Plank', 'core', ['core']),
    e('ex_lunge', 'طعنات', 'Lunge', 'strength', ['legs']), e('ex_row', 'تجديف', 'Row', 'strength', ['back']), e('ex_walk', 'مشي سريع', 'Brisk walk', 'cardio', ['full']),
  ];
}
