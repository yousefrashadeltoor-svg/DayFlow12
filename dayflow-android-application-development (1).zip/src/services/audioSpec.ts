import type { SoundSpec } from '@/models/types';
import type { AlarmPayload } from '@/services/native/dayflowNative';

/** Maps a user-chosen SoundSpec to the native payload fields (the Kotlin service understands exactly these). */
export function specToPayload(spec: SoundSpec | undefined, fallback: AlarmPayload['soundMode'] = 'system'): Pick<AlarmPayload, 'soundMode' | 'soundUri'> & { startMs?: number; endMs?: number } {
  if (!spec || spec.kind === 'default') return { soundMode: fallback === 'system' ? 'tone' : fallback };
  switch (spec.kind) {
    case 'ringtone': case 'alarm': case 'notification': return spec.uri ? { soundMode: 'custom', soundUri: spec.uri } : { soundMode: 'tone' };
    case 'file': return spec.uri ? { soundMode: 'custom', soundUri: spec.uri, startMs: spec.startMs, endMs: spec.endMs } : { soundMode: 'tone' };
    case 'tts': return { soundMode: 'tts' };
    case 'silent': return { soundMode: 'none' };
  }
}
