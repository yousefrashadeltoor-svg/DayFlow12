/** Product brand and the exact home-card ASCII wordmark. Do not alter the art. */
export const BRAND = '𝐃α𝗒 𝐅ᥣⱺω';
export const ASCII_ART = '█▀▄ ▄▀█ █▄█   █▀▀ █░░ █▀█ █░█░█\n█▄▀ █▀█ ░█░   █▀░ █▄▄ █▄█ ▀▄▀▄▀';
export const SIGNATURE = 'By,Joseph';
