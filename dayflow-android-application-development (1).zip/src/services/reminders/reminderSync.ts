/**
 * Builds the complete desired alarm set for the rolling horizon and hands it to the native AlarmManager scheduler
 * (rescheduleUpcomingAlarms). Native code upserts by stable key and cancels stale ones, so repeated synchronisation never
 * creates duplicates. Prayer alarms and user alarm clocks are owned by native code (they renew themselves, even when the app
 * is never opened). On the web preview nothing is scheduled; the computed plan is exposed for honest display only.
 */
import type { ActivityBlock, NotificationAction, Settings } from '@/models/types';
import { registerSyncHook, useApp, type SyncReport } from '@/stores/appStore';
import { DayflowNative, isNative, errorMessage, type DesiredAlarm, type AlarmPayload } from '@/services/native/dayflowNative';
import { addDays, epochOf, fmtDuration, fmtTime, todayKey, weekday } from '@/utils/date';
import { translate } from '@/services/localization/i18n';
import { inQuiet } from '@/services/scheduling/rules';
import { CLOSED } from '@/services/scheduling/engine';

type State = ReturnType<typeof useApp.getState>;
const PROTECTED_CATS = new Set(['cat_sleep', 'cat_prayer', 'cat_appointment']);
const TOKEN_HEX: Record<string, string> = { study: '#5b6ee1', exercise: '#e0663a', rest: '#3ea88a', meal: '#d9a032', sleep: '#7c63c9', water: '#2f9fd1', work: '#4f6b8a', custom: '#9a6b8f' };
export const hexOf = (c: string): string => { const m = c.match(/--c-([a-z]+)/); return m ? TOKEN_HEX[m[1]] ?? '#5b5bd6' : /^#[0-9a-f]{6}$/i.test(c) ? c : '#5b5bd6'; };

export function buildDesiredAlarms(st: State, nowMs = Date.now()): DesiredAlarm[] {
  const { data } = st;
  const s = data.settings.app;
  const lang = s.language;
  const tr = (k: Parameters<typeof translate>[1], p?: Record<string, string | number>) => translate(lang, k, p);
  const horizonEnd = nowMs + Math.max(1, s.reminderHorizonDays) * 86400000;
  const today = todayKey();
  const out: DesiredAlarm[] = [];
  const blocksByDate = new Map<string, ActivityBlock[]>();
  for (const b of Object.values(data.activities)) {
    if (b.date < addDays(today, -1) || b.applied === false) continue; // drafts never ring
    (blocksByDate.get(b.date) ?? blocksByDate.set(b.date, []).get(b.date)!).push(b);
  }
  for (const l of blocksByDate.values()) l.sort((a, b) => a.startMin - b.startMin);

  const soundFor = (mode: string, soundId?: string): Pick<AlarmPayload, 'soundMode' | 'soundUri' | 'startMs' | 'endMs'> => {
    const m = (mode === 'inherit' ? s.soundMode : mode) as AlarmPayload['soundMode'];
    const sid = soundId ?? s.defaultSoundId;
    const asset = sid ? data.sounds[sid] : undefined;
    if (m === 'custom') return asset ? { soundMode: 'custom', soundUri: asset.path, startMs: asset.startMs, endMs: asset.endMs } : { soundMode: 'tts' };
    return { soundMode: m };
  };
  const base = (p: Partial<AlarmPayload> & Pick<AlarmPayload, 'kind' | 'title' | 'body'>): AlarmPayload => ({
    soundMode: 'system', vibrate: s.vibrate, silent: false, volume: s.volume, gradual: s.gradualVolume, audioRepeat: s.audioRepeat,
    repeatIntervalMin: 0, maxRepeats: 0, actions: ['DISMISS', 'SNOOZE_10'], ttsLang: lang, ...p,
  });
  const quietAt = (date: string, minute: number) => {
    const q = s.quietHours;
    if (!q.enabled) return false;
    const m = ((minute % 1440) + 1440) % 1440;
    const day = minute >= 1440 ? weekday(addDays(date, 1)) : weekday(date);
    return q.days.includes(day) && inQuiet(m, q.startMin, q.endMin);
  };
  const insideProtected = (date: string, minute: number, selfId: string) =>
    (blocksByDate.get(date) ?? []).some((x) => x.id !== selfId && x.fixed && (PROTECTED_CATS.has(x.categoryId) || x.importance >= 5) && !CLOSED.has(x.status) && minute >= x.startMin && minute < x.startMin + x.durationMin);

  // ---- activity blocks: one notification per reminder point with time, duration, note and what comes next
  for (const [date, list] of blocksByDate) {
    list.forEach((b, idx) => {
      if (!b.reminder?.enabled || CLOSED.has(b.status) || b.status === 'cancelled') return;
      const points: { key: string; minute: number; body: string; isEnd: boolean }[] = [];
      for (const off of b.reminder.offsets) points.push({ key: `blk:${b.id}:${off}`, minute: b.startMin - off, body: off === 0 ? tr('n_starting') : tr('n_in', { m: off }), isEnd: false });
      if (b.reminder.atEnd) points.push({ key: `blk:${b.id}:end`, minute: b.startMin + b.durationMin, body: tr('n_ending'), isEnd: true });
      const nxt = list.slice(idx + 1).find((x) => x.status !== 'cancelled' && x.startMin >= b.startMin + b.durationMin - 1);
      const cat = data.categories[b.categoryId];
      for (const pt of points) {
        if (b.status === 'active' && !pt.isEnd) continue;
        const at = epochOf(date, pt.minute);
        if (at <= nowMs + 5000 || at > horizonEnd) continue;
        const quiet = quietAt(date, pt.minute) && !(b.reminder.critical && s.quietHours.allowCritical);
        const silent = quiet || (!b.fixed && insideProtected(date, pt.minute, b.id));
        const timeLabel = `${fmtTime(b.startMin, lang, s.clock24)} – ${fmtTime(b.startMin + b.durationMin, lang, s.clock24)}`;
        const actions: NotificationAction[] = b.reminder.actions?.length ? b.reminder.actions : s.defaultActions;
        out.push({
          alarmKey: pt.key,
          payload: base({
            kind: 'block', blockId: b.id, title: b.title, body: `${pt.body} · ${timeLabel} · ${fmtDuration(b.durationMin, lang)}`, category: cat?.key ?? 'custom', catName: cat ? (lang === 'ar' ? cat.nameAr : cat.nameEn) : undefined,
            colorHex: hexOf(b.color), note: (b.notes || b.description || '').slice(0, 160), nextLabel: nxt ? `${tr('next_up')}: ${nxt.title} · ${fmtTime(nxt.startMin, lang, s.clock24)}` : undefined,
            localDate: date, localMinute: pt.minute, ...soundFor(b.reminder.soundMode, b.reminder.soundId), ttsText: b.reminder.ttsText || b.title,
            silent, repeatIntervalMin: silent ? 0 : b.reminder.repeatIntervalMin, maxRepeats: silent ? 0 : Math.min(10, b.reminder.maxRepeats), actions: pt.isEnd ? ['DONE', 'PARTIAL', 'SNOOZE_10'] : actions,
          }),
        });
      }
    });
  }

  // ---- occasions (materialised, never includes other-religion occasions): morning notice + eve heads-up for official holidays
  if (s.occasionNotify) {
    const occHorizon = nowMs + 14 * 86400000;
    for (const o of Object.values(data.occasions)) {
      if (!o.notify) continue;
      const at = epochOf(o.date, o.notifyMin);
      const title = lang === 'ar' ? o.title : o.titleEn;
      const status = o.official ? tr('occ_official_today') : tr('occ_today');
      if (at > nowMs + 5000 && at <= occHorizon) out.push({ alarmKey: `occ:${o.id}`, payload: base({ kind: 'occasion', title: `${title}`, body: status, note: o.note, emoji: o.emoji, official: o.official, category: 'occasion', localDate: o.date, localMinute: o.notifyMin, silent: quietAt(o.date, o.notifyMin), actions: ['DISMISS'], colorHex: o.official ? '#22a45d' : '#5b5bd6' }) });
      if (o.official) {
        const eveAt = epochOf(addDays(o.date, -1), 20 * 60);
        if (eveAt > nowMs + 5000 && eveAt <= occHorizon) out.push({ alarmKey: `occ:${o.id}:eve`, payload: base({ kind: 'occasion', title: `${tr('occ_tomorrow')}: ${title}`, body: tr('occ_official_tomorrow'), emoji: o.emoji, official: true, category: 'occasion', localDate: addDays(o.date, -1), localMinute: 20 * 60, actions: ['DISMISS'], colorHex: '#22a45d' }) });
      }
    }
  }

  // ---- tasks with explicit reminders
  for (const t of Object.values(data.tasks)) {
    if (!t.reminderAt || t.status === 'done' || t.status === 'cancelled' || t.reminderAt <= nowMs || t.reminderAt > horizonEnd) continue;
    out.push({ alarmKey: `task:${t.id}`, payload: base({ kind: 'task', blockId: t.id, title: t.title, body: tr('n_task_due'), note: t.notes?.slice(0, 160), triggerAt: t.reminderAt, absolute: true, actions: ['DONE', 'SNOOZE_15', 'DISMISS'], ...soundFor('inherit'), ttsText: t.title }) });
  }

  // ---- habits
  for (const h of Object.values(data.habits)) {
    if (h.archived || h.reminderMin == null) continue;
    for (let i = 0; i < s.reminderHorizonDays + 1; i++) {
      const date = addDays(today, i);
      if (h.pausedUntil && date <= h.pausedUntil) continue;
      if (h.frequency === 'custom' && !h.weekdays.includes(weekday(date))) continue;
      const at = epochOf(date, h.reminderMin);
      if (at <= nowMs || at > horizonEnd) continue;
      out.push({ alarmKey: `habit:${h.id}:${date}`, payload: base({ kind: 'habit', title: h.name, body: tr('n_habit'), localDate: date, localMinute: h.reminderMin, silent: quietAt(date, h.reminderMin) }) });
    }
  }

  // ---- water reminders within the wake window
  if (s.water.reminderEnabled && s.water.intervalMin >= 15) {
    const drunk = Object.values(data.waterLogs).filter((w) => w.date === today).reduce((a, w) => a + w.ml, 0);
    for (let i = 0; i < Math.min(2, s.reminderHorizonDays + 1); i++) {
      const date = addDays(today, i);
      for (let m = s.water.wakeStartMin; m <= s.water.wakeEndMin; m += s.water.intervalMin) {
        const at = epochOf(date, m);
        if (at <= nowMs || at > horizonEnd) continue;
        if (i === 0 && drunk >= s.water.targetMl) continue;
        out.push({ alarmKey: `water:${date}:${m}`, payload: base({ kind: 'water', title: tr('n_water'), body: tr('n_water_body', { x: i === 0 ? drunk : 0, y: s.water.targetMl }), localDate: date, localMinute: m, silent: quietAt(date, m) }) });
      }
    }
  }

  // ---- sleep preparation and wake-up
  for (let i = 0; i < s.reminderHorizonDays + 1; i++) {
    const date = addDays(today, i);
    if (s.sleep.prepReminderEnabled) {
      const m = s.sleep.bedtimeMin - s.sleep.prepReminderMin;
      const at = epochOf(date, m);
      if (at > nowMs && at <= horizonEnd) out.push({ alarmKey: `sleep:prep:${date}`, payload: base({ kind: 'sleep', title: tr('n_sleep_prep'), body: tr('n_sleep_body', { m: s.sleep.prepReminderMin }), localDate: date, localMinute: m }) });
    }
    if (s.sleep.wakeReminder) {
      const at = epochOf(date, s.sleep.wakeMin);
      if (at > nowMs && at <= horizonEnd) out.push({ alarmKey: `sleep:wake:${date}`, payload: base({ kind: 'sleep', title: tr('n_wake'), body: fmtTime(s.sleep.wakeMin, lang, s.clock24), localDate: date, localMinute: s.sleep.wakeMin, soundMode: 'tone', maxRepeats: 2, repeatIntervalMin: 5, actions: ['DISMISS', 'SNOOZE_5', 'SNOOZE_10'] }) });
    }
  }

  // ---- journal evening nudge (only when nothing was written yet that day)
  if (s.journal.reminderEnabled) {
    for (let i = 0; i < Math.min(3, s.reminderHorizonDays + 1); i++) {
      const date = addDays(today, i);
      const e = data.journal[date];
      if (e && (e.body.trim() || e.title.trim() || e.mood > 0)) continue;
      const at = epochOf(date, s.journal.reminderMin);
      if (at > nowMs + 5000 && at <= horizonEnd) out.push({ alarmKey: `journal:${date}`, payload: base({ kind: 'reminder', title: tr('journal_notif_title'), body: tr('journal_notif_body'), category: 'journal', localDate: date, localMinute: s.journal.reminderMin, silent: quietAt(date, s.journal.reminderMin), actions: ['DISMISS', 'SNOOZE_15'] }) });
    }
  }

  // ---- flashcards due today (one evening nudge)
  const due = Object.values(data.flashcards).filter((c) => c.dueDate <= today).length;
  if (due > 0) {
    const at = epochOf(today, 18 * 60);
    if (at > nowMs) out.push({ alarmKey: `review:${today}`, payload: base({ kind: 'review', title: tr('flashcards'), body: tr('n_review', { n: due }), localDate: today, localMinute: 18 * 60 }) });
  }

  // ---- running focus phase end
  const ft = data.state.focusTimer as import('@/models/types').FocusTimerState | undefined;
  if (ft?.running && !ft.pausedAt && ft.phaseDurationMs > 0) {
    const end = ft.phaseStartedAt + ft.pausedTotalMs + ft.phaseDurationMs;
    if (end > nowMs) out.push({ alarmKey: 'focus:phase', payload: base({ kind: 'reminder', title: tr('n_focus_end'), body: tr(`ph_${ft.phase}` as 'ph_work'), triggerAt: end, absolute: true, ...soundFor('inherit'), ttsText: tr('n_focus_end') }) });
  }
  return out.sort((a, b) => (a.payload.triggerAt ?? epochOf(a.payload.localDate!, a.payload.localMinute!)) - (b.payload.triggerAt ?? epochOf(b.payload.localDate!, b.payload.localMinute!)));
}

export async function syncReminders(st: State): Promise<SyncReport> {
  const desired = buildDesiredAlarms(st);
  const planned = desired.map((d) => ({ alarmKey: d.alarmKey, title: d.payload.title, kind: d.payload.kind, silent: d.payload.silent,
    triggerAt: d.payload.triggerAt ?? epochOf(d.payload.localDate!, d.payload.localMinute!) }));
  let report: SyncReport;
  if (!isNative()) {
    report = { at: Date.now(), ok: false, scheduled: 0, failures: 0, cancelled: 0, error: 'UNSUPPORTED', planned };
  } else {
    try {
      const res = await DayflowNative.rescheduleUpcomingAlarms({ alarms: desired });
      const ok = res.results.filter((r) => r.ok).length;
      report = { at: Date.now(), ok: res.failures === 0, scheduled: ok, failures: res.failures, cancelled: res.cancelled, exactAllowed: res.exactAllowed, planned };
      DayflowNative.updateWidget().catch(() => undefined);
    } catch (e) {
      report = { at: Date.now(), ok: false, scheduled: 0, failures: desired.length, cancelled: 0, error: errorMessage(e), planned };
    }
  }
  useApp.setState({ syncReport: report });
  return report;
}

registerSyncHook(async (s) => { await syncReminders(s); });
export const reminderSettingsSummary = (s: Settings) => s.reminderHorizonDays;
