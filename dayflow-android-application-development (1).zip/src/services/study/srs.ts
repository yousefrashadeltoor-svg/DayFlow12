/**
 * Configurable spaced repetition. `intervals` comes from settings (default 1,3,7,21 days).
 * Grades: 0 again, 1 hard, 2 good, 3 easy. Ease scales intervals beyond the configured ladder.
 * Deterministic and unit-tested.
 */
import type { DateKey, Flashcard } from '@/models/types';
import { addDays } from '@/utils/date';

export interface SrsResult { step: number; ease: number; nextDue: DateKey; intervalDays: number; lapses: number; }

export function nextReview(card: Pick<Flashcard, 'step' | 'ease' | 'lapses'>, grade: 0 | 1 | 2 | 3, today: DateKey, intervals: number[]): SrsResult {
  const ladder = intervals.length ? intervals.map((n) => Math.max(1, Math.round(n))) : [1, 3, 7, 21];
  let { step, ease, lapses } = card;
  ease = ease || 2.5;
  let intervalDays: number;
  if (grade === 0) {
    lapses += 1;
    step = 0;
    ease = Math.max(1.3, ease - 0.2);
    intervalDays = ladder[0];
  } else {
    const advance = grade === 1 ? 0 : grade === 2 ? 1 : 2;
    if (grade === 1) ease = Math.max(1.3, ease - 0.15);
    if (grade === 3) ease = Math.min(3.5, ease + 0.15);
    step = Math.max(0, step + advance);
    if (step < ladder.length) intervalDays = ladder[step];
    else {
      const beyond = step - ladder.length + 1;
      intervalDays = Math.round(ladder[ladder.length - 1] * Math.pow(ease / 2.5 + 1, beyond));
    }
    if (grade === 1) intervalDays = Math.max(1, Math.round(intervalDays * 0.6));
  }
  return { step, ease: Math.round(ease * 100) / 100, nextDue: addDays(today, intervalDays), intervalDays, lapses };
}

export const isDue = (c: Flashcard, today: DateKey) => c.dueDate <= today;
