import { ALL_COLLECTIONS, type CollectionName, type Collections } from '@/models/types';
import { DayflowNative, isNative, type DbOp } from '@/services/native/dayflowNative';

/**
 * Storage adapter abstraction. The same domain layer runs on:
 *  - Android: native SQLite through DayflowNativePlugin (records table, transactions, migrations in Kotlin)
 *  - Browser preview: IndexedDB (single object store keyed by [collection, id] with a collection index)
 * Both adapters apply batches atomically.
 */
export interface StorageAdapter {
  readonly engine: 'sqlite' | 'indexeddb' | 'memory';
  open(): Promise<void>;
  loadAll(): Promise<Partial<Record<CollectionName, unknown[]>>>;
  getAll(collection: CollectionName): Promise<unknown[]>;
  batch(ops: DbOp[]): Promise<void>;
}

class NativeSqliteAdapter implements StorageAdapter {
  readonly engine = 'sqlite' as const;
  async open() { await DayflowNative.initialize(); }
  async loadAll() { return (await DayflowNative.dbLoadAll()).collections as Partial<Record<CollectionName, unknown[]>>; }
  async getAll(collection: CollectionName) { return (await DayflowNative.dbGetAll({ collection })).records; }
  async batch(ops: DbOp[]) {
    if (!ops.length) return;
    // Chunk very large batches (e.g. restores) to keep bridge payloads reasonable; each chunk is a transaction.
    for (let i = 0; i < ops.length; i += 500) await DayflowNative.dbBatch({ ops: ops.slice(i, i + 500) });
  }
}

const IDB_NAME = 'dayflow';
const IDB_VERSION = 2;

class IndexedDbAdapter implements StorageAdapter {
  readonly engine = 'indexeddb' as const;
  private db: IDBDatabase | null = null;

  open(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) { reject(new Error('IndexedDB unavailable')); return; }
      const req = indexedDB.open(IDB_NAME, IDB_VERSION);
      req.onupgradeneeded = (ev) => {
        const db = req.result;
        const old = ev.oldVersion;
        // v1: records store. v2: date index. Additive only — existing data preserved.
        if (old < 1) {
          const s = db.createObjectStore('records', { keyPath: ['collection', 'id'] });
          s.createIndex('by_collection', 'collection');
        }
        if (old < 2) {
          const s = req.transaction!.objectStore('records');
          if (!s.indexNames.contains('by_date')) s.createIndex('by_date', ['collection', 'date']);
        }
      };
      req.onsuccess = () => { this.db = req.result; resolve(); };
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error('Database upgrade blocked by another tab'));
    });
  }

  private store(mode: IDBTransactionMode) {
    if (!this.db) throw new Error('Database not open');
    const tx = this.db.transaction('records', mode);
    return { tx, store: tx.objectStore('records') };
  }

  loadAll(): Promise<Partial<Record<CollectionName, unknown[]>>> {
    return new Promise((resolve, reject) => {
      const { store } = this.store('readonly');
      const req = store.getAll();
      req.onsuccess = () => {
        const out: Partial<Record<CollectionName, unknown[]>> = {};
        for (const row of req.result as { collection: CollectionName; data: unknown }[]) {
          (out[row.collection] ??= []).push(row.data);
        }
        resolve(out);
      };
      req.onerror = () => reject(req.error);
    });
  }

  getAll(collection: CollectionName): Promise<unknown[]> {
    return new Promise((resolve, reject) => {
      const { store } = this.store('readonly');
      const req = store.index('by_collection').getAll(collection);
      req.onsuccess = () => resolve((req.result as { data: unknown }[]).map((r) => r.data));
      req.onerror = () => reject(req.error);
    });
  }

  batch(ops: DbOp[]): Promise<void> {
    if (!ops.length) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const { tx, store } = this.store('readwrite');
      for (const op of ops) {
        if (op.op === 'put') {
          const rec = op.record as { id: string; date?: string };
          store.put({ collection: op.collection, id: rec.id, date: rec.date ?? '', data: rec });
        } else if (op.op === 'delete') store.delete([op.collection, op.id]);
        else if (op.op === 'clear') {
          const range = IDBKeyRange.bound([op.collection, ''], [op.collection, '\uffff']);
          store.delete(range);
        }
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error ?? new Error('Transaction aborted'));
    });
  }
}

/** In-memory fallback used only when the browser denies persistent storage (e.g. sandboxed preview iframes). */
export class MemoryAdapter implements StorageAdapter {
  readonly engine = 'memory' as const;
  private rows = new Map<string, { collection: CollectionName; data: unknown }>();
  async open() { /* nothing to open */ }
  async loadAll() {
    const out: Partial<Record<CollectionName, unknown[]>> = {};
    for (const r of this.rows.values()) (out[r.collection] ??= []).push(r.data);
    return out;
  }
  async getAll(collection: CollectionName) { return [...this.rows.values()].filter((r) => r.collection === collection).map((r) => r.data); }
  async batch(ops: DbOp[]) {
    for (const op of ops) {
      if (op.op === 'put') this.rows.set(`${op.collection}\u0000${(op.record as { id: string }).id}`, { collection: op.collection as CollectionName, data: op.record });
      else if (op.op === 'delete') this.rows.delete(`${op.collection}\u0000${op.id}`);
      else for (const k of [...this.rows.keys()]) if (k.startsWith(`${op.collection}\u0000`)) this.rows.delete(k);
    }
  }
}

let adapter: StorageAdapter | null = null;
export function useMemoryFallback(): StorageAdapter { adapter = new MemoryAdapter(); return adapter; }
export function getAdapter(): StorageAdapter {
  if (!adapter) adapter = isNative() ? new NativeSqliteAdapter() : new IndexedDbAdapter();
  return adapter;
}

export function emptyCollections(): Collections {
  const c = {} as Record<CollectionName, Record<string, unknown>>;
  for (const k of ALL_COLLECTIONS) c[k] = {};
  return c as unknown as Collections;
}

/** Validates a record before persistence (defensive; UI validates too). */
export function validateRecord(collection: CollectionName, rec: Record<string, unknown>): string | null {
  if (!rec || typeof rec !== 'object') return 'not_object';
  if (typeof rec.id !== 'string' || !rec.id) return 'missing_id';
  if (typeof rec.createdAt !== 'number' || typeof rec.updatedAt !== 'number') return 'missing_timestamps';
  if (collection === 'activities') {
    if (typeof rec.title !== 'string' || !String(rec.title).trim()) return 'missing_title';
    if (typeof rec.durationMin !== 'number' || rec.durationMin <= 0 || rec.durationMin > 1440) return 'invalid_duration';
    if (typeof rec.startMin !== 'number' || rec.startMin < 0 || rec.startMin >= 1440) return 'invalid_start';
    if (typeof rec.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(rec.date)) return 'invalid_date';
  }
  if (collection === 'tasks' && (typeof rec.title !== 'string' || !String(rec.title).trim())) return 'missing_title';
  if (collection === 'waterLogs' && (typeof rec.ml !== 'number' || rec.ml <= 0)) return 'invalid_amount';
  return null;
}

/** Application-level schema version for JS data migrations (stored in `migrations` collection). */
export const APP_SCHEMA_VERSION = 2;
