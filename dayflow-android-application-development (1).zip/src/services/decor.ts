/**
 * Seasonal / occasion / study / time-of-day decoration engine (pure + deterministic).
 * All imagery is bundled locally: Pexels photos (free licence) and Microsoft Fluent Emoji 3D (MIT).
 */
import type { DateKey } from '@/models/types';
import { diffDays, parseDateKey } from '@/utils/date';
import { hijriOf, occasionsOn, type Occasion } from '@/services/occasions';

const emojiMods = import.meta.glob('../assets/emoji/*.webp', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
const photoMods = import.meta.glob('../assets/photos/*.webp', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
const index = (m: Record<string, string>) => Object.fromEntries(Object.entries(m).map(([k, v]) => [k.split('/').pop()!.replace('.webp', ''), v]));
const EMOJI = index(emojiMods);
const PHOTOS = index(photoMods);
export const emojiUrl = (name: string): string => EMOJI[name] ?? EMOJI.sparkles ?? '';
export const hasEmoji = (name: string) => name in EMOJI;
export const photoUrl = (key: string): string => PHOTOS[key] ?? PHOTOS.sunrise1 ?? '';
export const allEmojiNames = () => Object.keys(EMOJI);

export type TOD = 'dawn' | 'morning' | 'noon' | 'sunset' | 'night';
export const todOf = (h: number): TOD => (h >= 4 && h < 7 ? 'dawn' : h >= 7 && h < 12 ? 'morning' : h >= 12 && h < 16 ? 'noon' : h >= 16 && h < 19 ? 'sunset' : 'night');
export const TOD_OVERLAY: Record<TOD, string> = {
  dawn: 'linear-gradient(180deg, rgba(255,170,100,.42) 0%, rgba(30,25,70,.62) 100%)',
  morning: 'linear-gradient(180deg, rgba(255,255,255,.04) 0%, rgba(8,12,30,.5) 100%)',
  noon: 'linear-gradient(180deg, rgba(0,0,0,.12) 0%, rgba(8,12,30,.55) 100%)',
  sunset: 'linear-gradient(180deg, rgba(255,120,60,.42) 0%, rgba(45,10,60,.68) 100%)',
  night: 'linear-gradient(180deg, rgba(6,12,45,.55) 0%, rgba(0,0,14,.84) 100%)',
};
const TOD_PHOTOS: Record<TOD, string[]> = { dawn: ['sunrise1', 'sunrise2'], morning: ['sunrise2'], noon: [], sunset: ['sunset1', 'sunset2'], night: ['night1', 'night2', 'night3'] };
const CELESTIAL: Record<TOD, string> = { dawn: 'sunrise', morning: 'sun', noon: 'sun_behind_small_cloud', sunset: 'sunset', night: 'crescent_moon' };

export type Motion = 'fall' | 'rise' | 'twinkle' | 'drift' | 'float';
export interface SeasonDef {
  id: string; ar: string; en: string; gAr: string; gEn: string; photos: string[];
  particles: string[]; motion: Motion; count: number; ornaments: string[]; hanging: string[]; tint: string;
  descAr: string; descEn: string;
}
export interface SeasonState {
  id: string; titleAr: string; titleEn: string; greetingAr: string; greetingEn: string; photo: string;
  particles: { names: string[]; motion: Motion; count: number }; ornaments: string[]; hanging: string[];
  tod: TOD; celestial: string; occasion?: Occasion; tint: string;
}

export const SEASONS: Record<string, SeasonDef> = {
  autumn: { id: 'autumn', ar: 'الخريف', en: 'Autumn', gAr: 'صباح الخريف', gEn: 'Autumn morning', descAr: 'أوراق القيقب والبلوط المتساقطة، ثمار وحصاد', descEn: 'Falling maple & oak leaves, harvest',
    photos: ['autumn1', 'autumn2', 'autumn3'], particles: ['fallen_leaf', 'maple_leaf', 'leaf_fluttering_in_wind', 'fallen_leaf', 'maple_leaf'], motion: 'fall', count: 22,
    ornaments: ['fallen_leaf', 'maple_leaf', 'mushroom', 'chestnut', 'sheaf_of_rice', 'red_apple', 'grapes', 'pear', 'tangerine', 'sunflower'], hanging: ['maple_leaf', 'fallen_leaf', 'leaf_fluttering_in_wind'], tint: '#e07a2f' },
  winter: { id: 'winter', ar: 'الشتا', en: 'Winter', gAr: 'صباح الدفا', gEn: 'Cozy winter', descAr: 'ثلج يتساقط، كوباية شاي ساخنة، وشال ودفا', descEn: 'Falling snow, hot drinks, cozy scarves',
    photos: ['winter3', 'winter4', 'winter1'], particles: ['snowflake', 'snowflake', 'snowflake', 'cloud_with_snow', 'sparkles'], motion: 'fall', count: 26,
    ornaments: ['snowman', 'scarf', 'gloves', 'hot_beverage', 'snow_capped_mountain', 'snowflake', 'cloud_with_snow', 'evergreen_tree'], hanging: ['snowflake', 'snowflake', 'snowflake'], tint: '#60a5fa' },
  christmas: { id: 'winter_holidays', ar: 'رأس السنة والكريسماس', en: 'Christmas & New Year', gAr: 'كريسماس مبروك', gEn: 'Merry Christmas', descAr: 'شجرة كريسماس، جوارب، بابا نويل، بلورات ثلج وزينة حمرا وخضرا', descEn: 'Christmas tree, stockings, Santa, snowflakes, red & green ornaments',
    photos: ['winter2', 'winter1', 'winter3', 'winter4'], particles: ['snowflake', 'snowflake', 'snowflake', 'sparkles', 'glowing_star'], motion: 'fall', count: 28,
    ornaments: ['christmas_tree', 'santa_claus', 'socks', 'snowman', 'bell', 'wrapped_gift', 'ribbon', 'candle', 'evergreen_tree', 'glowing_star'], hanging: ['bell', 'star', 'socks', 'bell', 'glowing_star'], tint: '#e04b4b' },
  newyear: { id: 'newyear', ar: 'رأس السنة', en: 'New Year', gAr: 'سنة جديدة سعيدة', gEn: 'Happy New Year', descAr: 'ألعاب نارية وكونفتي وبالونات ونجوم', descEn: 'Fireworks, confetti, balloons and stars',
    photos: ['fireworks1', 'fireworks2'], particles: ['fireworks', 'party_popper', 'confetti_ball', 'sparkles', 'star', 'balloon'], motion: 'rise', count: 22,
    ornaments: ['fireworks', 'party_popper', 'confetti_ball', 'sparkles', 'star', 'mantelpiece_clock', 'hundred_points'], hanging: ['star', 'sparkles', 'star', 'glowing_star', 'star'], tint: '#ffd166' },
  spring: { id: 'spring', ar: 'الربيع', en: 'Spring', gAr: 'صباح الربيع', gEn: 'Spring morning', descAr: 'زهور الكرز تتساقط، فراشات، وورد وتوليب', descEn: 'Cherry blossoms, butterflies, tulips',
    photos: ['spring1', 'spring2', 'spring3'], particles: ['cherry_blossom', 'blossom', 'butterfly', 'tulip', 'cherry_blossom'], motion: 'fall', count: 22,
    ornaments: ['tulip', 'butterfly', 'honeybee', 'rainbow', 'seedling', 'cherry_blossom', 'hatching_chick', 'sunflower', 'rose'], hanging: ['blossom', 'butterfly', 'cherry_blossom'], tint: '#f472b6' },
  summer: { id: 'summer', ar: 'الصيف', en: 'Summer', gAr: 'صباح الصيف', gEn: 'Summer vibes', descAr: 'شمس وشاطئ ومظلات وفواكه صيفية', descEn: 'Sun, beach umbrellas and summer fruit',
    photos: ['summer1', 'summer2', 'summer3', 'redsea1', 'alex1'], particles: ['sun', 'water_wave', 'sparkles', 'beach_with_umbrella'], motion: 'drift', count: 9,
    ornaments: ['sun', 'beach_with_umbrella', 'watermelon', 'soft_ice_cream', 'palm_tree', 'sunglasses', 'spiral_shell', 'pineapple'], hanging: ['sun', 'palm_tree'], tint: '#fbbf24' },
  ramadan: { id: 'ramadan', ar: 'رمضان', en: 'Ramadan', gAr: 'رمضان كريم', gEn: 'Ramadan Kareem', descAr: 'فوانيس وأهلّة ونجوم وسبحة وجامع', descEn: 'Fanous lanterns, crescents, stars and mosques',
    photos: ['ramadan1', 'ramadan2', 'ramadan3', 'ramadan4', 'mosque1', 'mosque2'], particles: ['star', 'glowing_star', 'sparkles', 'crescent_moon', 'red_paper_lantern'], motion: 'twinkle', count: 16,
    ornaments: ['red_paper_lantern', 'crescent_moon', 'mosque', 'prayer_beads', 'glowing_star', 'candle', 'full_moon', 'star'], hanging: ['red_paper_lantern', 'crescent_moon', 'red_paper_lantern', 'glowing_star', 'red_paper_lantern'], tint: '#f2c14e' },
  eid_fitr: { id: 'eid_fitr', ar: 'عيد الفطر', en: 'Eid al-Fitr', gAr: 'كل سنة وانت طيب', gEn: 'Eid Mubarak', descAr: 'بالونات وهدايا وعيدية وأهلّة', descEn: 'Balloons, gifts, crescents and sweets',
    photos: ['eid1', 'eid2', 'mosque1'], particles: ['balloon', 'party_popper', 'confetti_ball', 'sparkles', 'wrapped_gift'], motion: 'rise', count: 16,
    ornaments: ['balloon', 'party_popper', 'crescent_moon', 'wrapped_gift', 'mosque', 'sparkles', 'star_struck'], hanging: ['balloon', 'crescent_moon', 'balloon', 'star', 'balloon'], tint: '#ff9f43' },
  eid_adha: { id: 'eid_adha', ar: 'عيد الأضحى', en: 'Eid al-Adha', gAr: 'عيد أضحى مبارك', gEn: 'Eid Mubarak', descAr: 'بالونات وكعبة وأهلّة وزينة العيد', descEn: 'Balloons, Kaaba and crescents',
    photos: ['kaaba2', 'eid2', 'mosque2'], particles: ['balloon', 'sparkles', 'party_popper', 'star'], motion: 'rise', count: 14,
    ornaments: ['ewe', 'kaaba', 'crescent_moon', 'balloon', 'mosque', 'wrapped_gift'], hanging: ['crescent_moon', 'balloon', 'star', 'balloon', 'crescent_moon'], tint: '#2fbf71' },
  hajj: { id: 'hajj', ar: 'أيام الحج', en: 'Hajj days', gAr: 'حج مبرور وسعي مشكور', gEn: 'Hajj Mabrour', descAr: 'الكعبة وسبحة وهلال', descEn: 'Kaaba, prayer beads, crescents',
    photos: ['kaaba1', 'kaaba2'], particles: ['sparkles', 'star'], motion: 'twinkle', count: 10,
    ornaments: ['kaaba', 'crescent_moon', 'prayer_beads', 'mosque'], hanging: ['crescent_moon', 'star'], tint: '#d4af37' },
  sham: { id: 'sham', ar: 'شم النسيم', en: 'Sham El-Nessim', gAr: 'كل سنة وانت طيب بشم النسيم', gEn: 'Happy Sham El-Nessim', descAr: 'بيض ملون وزهور الربيع والفسيخ والبصل', descEn: 'Painted eggs, spring flowers, fish and onions',
    photos: ['eggs1', 'eggs2', 'spring3'], particles: ['egg', 'blossom', 'butterfly', 'herb', 'hatching_chick'], motion: 'fall', count: 16,
    ornaments: ['egg', 'onion', 'herb', 'leafy_green', 'fish', 'hatching_chick', 'tulip', 'sunflower'], hanging: ['egg', 'blossom', 'egg'], tint: '#4ade80' },
  exams: { id: 'exams', ar: 'الامتحانات', en: 'Exams', gAr: 'ربنا يوفقك في الامتحان', gEn: 'Good luck on your exams', descAr: 'كتب ومذكرات وقلم وساعة ومصباح مذاكرة', descEn: 'Books, notes, pencils, clock and study lamp',
    photos: ['journal1', 'journal2'], particles: ['pencil', 'light_bulb', 'star', 'brain', 'books'], motion: 'float', count: 12,
    ornaments: ['books', 'pencil', 'memo', 'brain', 'alarm_clock', 'light_bulb', 'check_mark_button', 'bullseye', 'notebook', 'clipboard', 'compass'], hanging: ['light_bulb', 'star', 'light_bulb'], tint: '#6366f1' },
  school: { id: 'school', ar: 'الدراسة', en: 'Study time', gAr: 'يوم دراسي موفق', gEn: 'Have a great study day', descAr: 'كتب وأقلام وأهداف ونجوم المذاكرة', descEn: 'Books, pencils, goals and gold stars',
    photos: ['journal1', 'journal2', 'cairo2'], particles: ['star', 'pencil', 'sparkles', 'books'], motion: 'float', count: 12,
    ornaments: ['books', 'blue_book', 'ledger', 'pencil', 'notebook', 'trophy', 'star', 'rocket', 'red_apple'], hanging: ['star', 'sparkles', 'star'], tint: '#0ea5e9' },
  october: { id: 'october', ar: 'انتصار أكتوبر', en: 'October Victory', gAr: 'كل عام ومصر بخير - نصر أكتوبر', gEn: 'October Victory Day', descAr: 'نجوم ونجمة ونصر وأحداث العبور', descEn: 'Stars, trophies and celebratory fireworks',
    photos: ['flag1', 'flag2', 'cairo1'], particles: ['star', 'sparkles', 'fireworks', 'party_popper', 'star_struck'], motion: 'rise', count: 16,
    ornaments: ['military_helmet', 'trophy', 'star', 'sparkles', 'glowing_star', 'hundred_points', 'fireworks'], hanging: ['star', 'glowing_star', 'star'], tint: '#ce1126' },
  national: { id: 'national', ar: 'يوم وطني', en: 'National day', gAr: 'تحيا مصر', gEn: 'Long live Egypt', descAr: 'نجوم وأعلام وذكرى الوطن', descEn: 'Stars and national celebrations',
    photos: ['flag1', 'flag2'], particles: ['star', 'sparkles', 'party_popper'], motion: 'rise', count: 12,
    ornaments: ['military_helmet', 'star', 'trophy', 'sparkles', 'glowing_star'], hanging: ['star', 'glowing_star', 'star'], tint: '#ce1126' },
  mothers: { id: 'mothers', ar: 'عيد الأم', en: 'Mother’s Day', gAr: 'كل سنة وكل أم طيبة', gEn: 'Happy Mother’s Day', descAr: 'ورد وقلوب وتوليب', descEn: 'Roses, hearts and tulips',
    photos: ['mother1', 'mother2'], particles: ['red_heart', 'sparkling_heart', 'rose', 'tulip'], motion: 'rise', count: 14,
    ornaments: ['bouquet', 'rose', 'red_heart', 'tulip', 'sparkling_heart'], hanging: ['red_heart', 'rose', 'red_heart'], tint: '#ec4899' },
};
export const SEASON_LIST = Object.values(SEASONS);

const dayOfYear = (d: Date) => Math.floor((d.getTime() - new Date(d.getFullYear(), 0, 0).getTime()) / 86400000);
const rot = <T,>(arr: T[], n: number, seed: number) => Array.from({ length: Math.min(n, arr.length) }, (_, i) => arr[(seed + i) % arr.length]);
const NATIONAL = new Set(['jan25', 'apr25', 'jun30', 'jul23', 'oct6', 'oct24', 'dec23']);

/** Which season applies right now. `forced` (preview) wins; `studying` = exams/school flags from the user's data. */
export function pickSeasonId(now: Date, hijriAdjust: number, key: DateKey, studying: 'exams' | 'school' | null = null): string {
  const m = now.getMonth() + 1, d = now.getDate();
  const occ = occasionsOn(key, { hijriAdjust, showOtherReligions: false, user: [] });
  const has = (k: string) => occ.some((o) => o.key === k);
  const hj = hijriOf(key, hijriAdjust);
  if (hj.m === 10 && hj.d <= 3) return 'eid_fitr';
  if (hj.m === 12 && hj.d >= 10 && hj.d <= 13) return 'eid_adha';
  if (hj.m === 9) return 'ramadan';
  if (hj.m === 12 && hj.d <= 9) return 'hajj';
  if (has('sham')) return 'sham';
  if (has('oct6')) return 'october';
  if (occ.some((o) => NATIONAL.has(o.key))) return 'national';
  if (has('mothers_day')) return 'mothers';
  if (studying) return studying;
  if (m === 9) return 'school';
  if ((m === 12 && d >= 28) || (m === 1 && d <= 2)) return 'newyear';
  if ((m === 12 && d >= 1) || (m === 1 && d <= 10)) return 'christmas';
  if (m === 12 || m <= 2) return 'winter';
  if (m <= 5) return 'spring';
  if (m <= 8) return 'summer';
  return 'autumn';
}

export function seasonFor(now: Date, hijriAdjust: number, key: DateKey, opts: { forced?: string; studying?: 'exams' | 'school' | null; enabled?: Record<string, boolean> } = {}): SeasonState {
  const id0 = opts.forced && SEASONS[opts.forced] ? opts.forced : pickSeasonId(now, hijriAdjust, key, opts.studying ?? null);
  const def = SEASONS[id0] ?? SEASONS.autumn;
  const occ = occasionsOn(key, { hijriAdjust, showOtherReligions: false, user: [] });
  const h = now.getHours();
  const tod = todOf(h);
  const seed = dayOfYear(now);
  const todPool = TOD_PHOTOS[tod];
  const occPhoto = occ.find((o) => o.source === 'builtin' && o.image)?.image;
  const pool = [...def.photos, ...todPool, ...(occPhoto && def.id === 'october' ? [occPhoto] : [])];
  const motion: Motion = tod === 'night' && def.motion === 'drift' ? 'twinkle' : def.motion;
  void diffDays;
  void parseDateKey;
  return {
    id: def.id, titleAr: def.ar, titleEn: def.en, greetingAr: def.gAr, greetingEn: def.gEn,
    photo: pool[(seed + Math.floor(h / 4)) % pool.length],
    particles: { names: def.particles, motion, count: def.count },
    ornaments: rot(def.ornaments, 5, seed), hanging: def.hanging, tod, celestial: CELESTIAL[tod], occasion: occ[0], tint: def.tint,
  };
}

/** Days until the next occurrence of a Hijri day (used for friendly countdowns). */
export function daysUntilHijri(from: DateKey, hm: number, hd: number, adjust: number): number {
  for (let i = 0; i < 400; i++) {
    const k = new Date(parseDateKey(from).getTime() + i * 86400000);
    const key = `${k.getFullYear()}-${String(k.getMonth() + 1).padStart(2, '0')}-${String(k.getDate()).padStart(2, '0')}`;
    const h = hijriOf(key, adjust);
    if (h.m === hm && h.d === hd) return diffDays(from, key);
  }
  return -1;
}

/** Which decoration sets are visible now: solo preview wins; otherwise the automatic season is ALWAYS first,
 *  followed by the user's manual picks (deduped). Returns at most 4 ids. */
export function resolveSeasonIds(now: Date, hijriAdjust: number, key: DateKey, opts: { solo?: string; active?: string[]; studying?: 'exams' | 'school' | null; enabled?: Record<string, boolean> } = {}): string[] {
  if (opts.solo && SEASONS[opts.solo]) return [opts.solo];
  const auto = pickSeasonId(now, hijriAdjust, key, opts.studying ?? null);
  const ids = [auto, ...(opts.active ?? [])].filter((id, i, a) => SEASONS[id] && a.indexOf(id) === i && (opts.enabled?.[id] ?? true));
  if (!ids.length) ids.push('autumn');
  return ids.slice(0, 4);
}
export const MAX_DECOR_PICKS = 3;
