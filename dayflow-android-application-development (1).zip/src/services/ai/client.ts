/**
 * Provider-agnostic chat client. OpenAI-compatible Chat Completions (most providers) + Anthropic Messages.
 * Android: requests go through Capacitor's native HTTP (no CORS, works for every provider).
 * Browser preview: window.fetch (providers without CORS support fail and are reported honestly).
 */
import { CapacitorHttp } from '@capacitor/core';
import { isNative } from '@/services/native/dayflowNative';
import type { ProviderDef } from './providers';

export interface ChatTool { name: string; description: string; parameters: Record<string, unknown> }
export type WireMessage =
  | { role: 'system' | 'user'; content: string }
  | { role: 'assistant'; content: string; tool_calls?: { id: string; name: string; args: Record<string, unknown> }[] }
  | { role: 'tool'; content: string; tool_call_id: string; name: string };

export interface ChatResult { text: string; toolCalls: { id: string; name: string; args: Record<string, unknown> }[]; usage?: { input?: number; output?: number } }
export interface Endpoint { provider: ProviderDef; apiKey: string; baseUrl: string }

export class AiError extends Error {
  constructor(message: string, public code: 'network' | 'cors' | 'auth' | 'rate' | 'model' | 'tools' | 'server' | 'bad_request' | 'cancelled', public status?: number) { super(message); }
}

export function resolveBase(p: ProviderDef, custom?: string, accountId?: string): string {
  let b = (custom && custom.trim()) || p.baseUrl;
  if (p.needsAccountId) b = b.replace('{accountId}', encodeURIComponent((accountId ?? '').trim()));
  return b.replace(/\/+$/, '');
}

async function request(method: 'GET' | 'POST', url: string, headers: Record<string, string>, body: unknown, signal?: AbortSignal): Promise<{ status: number; data: unknown }> {
  if (signal?.aborted) throw new AiError('cancelled', 'cancelled');
  if (isNative()) {
    const res = await CapacitorHttp.request({ method, url, headers, data: body, connectTimeout: 30000, readTimeout: 120000, responseType: 'json' });
    if (signal?.aborted) throw new AiError('cancelled', 'cancelled');
    let data: unknown = res.data;
    if (typeof data === 'string') { try { data = JSON.parse(data); } catch { /* keep text */ } }
    return { status: res.status, data };
  }
  let res: Response;
  try {
    res = await fetch(url, { method, headers, body: body == null ? undefined : JSON.stringify(body), signal });
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw new AiError('cancelled', 'cancelled');
    throw new AiError('network_or_cors', 'cors');
    void 0;
  }
  const text = await res.text();
  let data: unknown = text;
  try { data = JSON.parse(text); } catch { /* not JSON */ }
  return { status: res.status, data };
}

function errorFrom(status: number, data: unknown): AiError {
  const raw = data as { error?: { message?: string } | string; message?: string; detail?: string } | string;
  const msg = typeof raw === 'string' ? raw.slice(0, 300) : (typeof raw?.error === 'string' ? raw.error : raw?.error?.message) ?? raw?.message ?? raw?.detail ?? `HTTP ${status}`;
  const m = String(msg);
  if (status === 401 || status === 403) return new AiError(m, 'auth', status);
  if (status === 429) return new AiError(m, 'rate', status);
  if (status === 404) return new AiError(m, 'model', status);
  if (status >= 500) return new AiError(m, 'server', status);
  if (/tool|function/i.test(m)) return new AiError(m, 'tools', status);
  return new AiError(m, 'bad_request', status);
}

function headersFor(ep: Endpoint): Record<string, string> {
  const h: Record<string, string> = { 'Content-Type': 'application/json' };
  if (ep.provider.format === 'anthropic') {
    h['x-api-key'] = ep.apiKey;
    h['anthropic-version'] = '2023-06-01';
    h['anthropic-dangerous-direct-browser-access'] = 'true';
  } else if (ep.apiKey) h.Authorization = `Bearer ${ep.apiKey}`;
  if (ep.provider.id === 'openrouter') { h['HTTP-Referer'] = 'https://dayflow.app'; h['X-Title'] = 'Dayflow'; }
  return h;
}

/** Lists the provider's real models. OpenRouter also returns real prices → `free` is accurate there. */
export async function listModels(ep: Endpoint): Promise<{ id: string; name?: string; free?: boolean; tools?: boolean; context?: number }[]> {
  const { status, data } = await request('GET', `${ep.baseUrl}/models`, headersFor(ep), null);
  if (status >= 400) throw errorFrom(status, data);
  const d0 = data as { data?: unknown[]; models?: unknown[]; result?: unknown[] };
  const arr = d0.data ?? d0.models ?? d0.result ?? (Array.isArray(data) ? data : []);
  const out: { id: string; name?: string; free?: boolean; tools?: boolean; context?: number }[] = [];
  for (const m of arr as Record<string, unknown>[]) {
    const id = String(m.id ?? m.name ?? '').replace(/^models\//, '');
    if (!id) continue;
    if (/embed|whisper|tts|dall-e|image|moderation|rerank|guard|transcri|audio|vision-only|playai|safeguard/i.test(id) && !/gemma/i.test(id)) continue;
    const arch = m.architecture as { output_modalities?: string[]; modality?: string } | undefined;
    if (arch?.output_modalities && !arch.output_modalities.includes('text')) continue;      // image/audio-generation models
    if (arch?.modality && !arch.modality.includes('text')) continue;
    const pricing = m.pricing as { prompt?: string; completion?: string } | undefined;
    const free = pricing ? Number(pricing.prompt) === 0 && Number(pricing.completion) === 0 : undefined;
    const params = m.supported_parameters as string[] | undefined;
    out.push({ id, name: (m.name as string) || (m.display_name as string) || undefined, free, tools: params ? params.includes('tools') : undefined, context: (m.context_length as number) || (m.context_window as number) || undefined });
  }
  return out;
}

export async function testConnection(ep: Endpoint): Promise<number> {
  return (await listModels(ep)).length;
}

function toOpenAI(messages: WireMessage[]) {
  return messages.map((m) => {
    if (m.role === 'assistant') return { role: 'assistant', content: m.content || (m.tool_calls?.length ? null : ''), ...(m.tool_calls?.length ? { tool_calls: m.tool_calls.map((c) => ({ id: c.id, type: 'function', function: { name: c.name, arguments: JSON.stringify(c.args) } })) } : {}) };
    if (m.role === 'tool') return { role: 'tool', tool_call_id: m.tool_call_id, content: m.content };
    return m;
  });
}

function toAnthropic(messages: WireMessage[]) {
  const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
  const out: { role: 'user' | 'assistant'; content: unknown[] }[] = [];
  const push = (role: 'user' | 'assistant', block: unknown) => { const last = out[out.length - 1]; if (last && last.role === role) last.content.push(block); else out.push({ role, content: [block] }); };
  for (const m of messages) {
    if (m.role === 'system') continue;
    if (m.role === 'user') push('user', { type: 'text', text: m.content });
    else if (m.role === 'assistant') { if (m.content) push('assistant', { type: 'text', text: m.content }); for (const c of m.tool_calls ?? []) push('assistant', { type: 'tool_use', id: c.id, name: c.name, input: c.args }); }
    else if (m.role === 'tool') push('user', { type: 'tool_result', tool_use_id: m.tool_call_id, content: m.content });
  }
  return { system, messages: out };
}

export async function chat(ep: Endpoint, model: string, messages: WireMessage[], tools: ChatTool[] | null, temperature: number, signal?: AbortSignal): Promise<ChatResult> {
  if (ep.provider.format === 'anthropic') {
    const { system, messages: msgs } = toAnthropic(messages);
    const body: Record<string, unknown> = { model, max_tokens: 2048, system, messages: msgs, temperature };
    if (tools?.length) body.tools = tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters }));
    const { status, data } = await request('POST', `${ep.baseUrl}/messages`, headersFor(ep), body, signal);
    if (status >= 400) throw errorFrom(status, data);
    const d = data as { content?: { type: string; text?: string; id?: string; name?: string; input?: Record<string, unknown> }[]; usage?: { input_tokens?: number; output_tokens?: number } };
    return {
      text: (d.content ?? []).filter((c) => c.type === 'text').map((c) => c.text).join(''),
      toolCalls: (d.content ?? []).filter((c) => c.type === 'tool_use').map((c) => ({ id: c.id!, name: c.name!, args: c.input ?? {} })),
      usage: { input: d.usage?.input_tokens, output: d.usage?.output_tokens },
    };
  }
  const body: Record<string, unknown> = { model, messages: toOpenAI(messages), temperature };
  if (tools?.length) { body.tools = tools.map((t) => ({ type: 'function', function: t })); body.tool_choice = 'auto'; }
  const { status, data } = await request('POST', `${ep.baseUrl}/chat/completions`, headersFor(ep), body, signal);
  if (status >= 400) throw errorFrom(status, data);
  const d = data as { choices?: { message?: { content?: string | null; tool_calls?: { id?: string; function?: { name?: string; arguments?: string | Record<string, unknown> } }[] } }[]; usage?: { prompt_tokens?: number; completion_tokens?: number }; error?: { message?: string } };
  if (d.error) throw new AiError(d.error.message ?? 'error', 'server');
  const msg = d.choices?.[0]?.message;
  if (!msg) throw new AiError('empty response', 'server');
  const toolCalls = (msg.tool_calls ?? []).map((c, i) => {
    let args: Record<string, unknown> = {};
    const raw = c.function?.arguments;
    if (typeof raw === 'string') { try { args = raw.trim() ? JSON.parse(raw) : {}; } catch { args = {}; } } else if (raw && typeof raw === 'object') args = raw;
    return { id: c.id || `call_${Date.now()}_${i}`, name: c.function?.name ?? '', args };
  }).filter((c) => c.name);
  return { text: msg.content ?? '', toolCalls, usage: { input: d.usage?.prompt_tokens, output: d.usage?.completion_tokens } };
}

/** For models without native tool calling: the reply contains ```tool {json}``` blocks. */
export function parseJsonToolCalls(text: string): { calls: { id: string; name: string; args: Record<string, unknown> }[]; rest: string } {
  const calls: { id: string; name: string; args: Record<string, unknown> }[] = [];
  const rest = text.replace(/```(?:tool|json)?\s*(\{[\s\S]*?\})\s*```/g, (all, json: string) => {
    try {
      const o = JSON.parse(json);
      const list = Array.isArray(o.calls) ? o.calls : [o];
      let used = false;
      for (const c of list) if (c && typeof c.name === 'string') { calls.push({ id: `json_${Date.now()}_${calls.length}`, name: c.name, args: c.arguments ?? c.args ?? {} }); used = true; }
      return used ? '' : all;
    } catch { return all; }
  });
  return { calls, rest: rest.trim() };
}
