/**
 * AI provider catalogue. Free-tier facts were checked against several independent comparisons dated
 * Aug–Nov 2026 (see docs/AI_ASSISTANT.md). Free tiers change often, so:
 *  - every provider's real model list is loaded live from its /models endpoint (refresh button);
 *  - OpenRouter free models are detected from the real per-model price the API returns;
 *  - the curated `models` below are only a starting point and may be outdated.
 */
export type Tier = 'free' | 'trial' | 'paid' | 'local';
export type ApiFormat = 'openai' | 'anthropic';

export interface CatalogModel { id: string; name?: string; free?: boolean; tools?: boolean; context?: number }
export interface ProviderDef {
  id: string; name: string; logo: string; tier: Tier; format: ApiFormat;
  baseUrl: string; needsKey: boolean; keyUrl?: string; docsUrl?: string;
  /** Arabic (Egyptian) + English summary of what is free and the catch */
  freeAr: string; freeEn: string;
  /** browsers can call it directly (CORS). Android always works because requests go through native HTTP. */
  cors: boolean;
  needsAccountId?: boolean;
  /** decides which models of this provider count as free when the API does not say so */
  freeRule?: (modelId: string) => boolean;
  models: CatalogModel[];
  rank: number; // lower = shown first inside its tier (more generous free offer)
}

const all = () => true;

export const PROVIDERS: ProviderDef[] = [
  // ---------------------------------------------------------------- renewing free quota (no card)
  {
    id: 'groq', name: 'Groq', logo: 'groq', tier: 'free', format: 'openai', baseUrl: 'https://api.groq.com/openai/v1', needsKey: true, cors: true, rank: 1,
    keyUrl: 'https://console.groq.com/keys', docsUrl: 'https://console.groq.com/docs/rate-limits',
    freeAr: 'مجاني ومتجدد يوميًا من غير كارت: حوالي ١٠٠٠ طلب و٢٠٠ ألف توكن في اليوم لكل موديل. أسرع ردود. الحد في الدقيقة صغير (٨ آلاف توكن).',
    freeEn: 'Free daily quota, no card: ~1,000 requests and 200K tokens/day per model. Fastest replies; small per-minute token cap (8K).',
    freeRule: all,
    models: [{ id: 'openai/gpt-oss-120b', tools: true, context: 131072 }, { id: 'openai/gpt-oss-20b', tools: true, context: 131072 }, { id: 'llama-3.3-70b-versatile', tools: true, context: 131072 }],
  },
  {
    id: 'gemini', name: 'Google Gemini (AI Studio)', logo: 'gemini', tier: 'free', format: 'openai', baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai', needsKey: true, cors: true, rank: 2,
    keyUrl: 'https://aistudio.google.com/apikey', docsUrl: 'https://ai.google.dev/gemini-api/docs/pricing',
    freeAr: 'موديلات Flash وFlash-Lite وGemma مجانية بحدود يومية تظهر في AI Studio، وسياق كبير جدًا. موديلات Pro مدفوعة. العيب: محتوى الخطة المجانية بيُستخدم لتحسين منتجات جوجل.',
    freeEn: 'Flash, Flash-Lite and Gemma models are free with per-project limits and a very large context. Pro models are paid. Catch: free-tier content is used to improve Google products.',
    freeRule: (m) => /flash|gemma/i.test(m) && !/pro/i.test(m),
    models: [{ id: 'gemini-2.5-flash', tools: true, context: 1048576, free: true }, { id: 'gemini-2.5-flash-lite', tools: true, context: 1048576, free: true }, { id: 'gemini-2.5-pro', tools: true, context: 1048576, free: false }],
  },
  {
    id: 'openrouter', name: 'OpenRouter', logo: 'openrouter', tier: 'free', format: 'openai', baseUrl: 'https://openrouter.ai/api/v1', needsKey: true, cors: true, rank: 3,
    keyUrl: 'https://openrouter.ai/keys', docsUrl: 'https://openrouter.ai/docs/api-reference/limits',
    freeAr: 'مفتاح واحد لعشرات الموديلات. الموديلات اللي اسمها بينتهي بـ :free مجانية: ٢٠ طلب في الدقيقة و٥٠ في اليوم (١٠٠٠ في اليوم لو شحنت ١٠ دولار مرة واحدة). المجاني بيتحدد هنا من السعر الحقيقي اللي بيرجعه الـ API.',
    freeEn: 'One key, many models. IDs ending in :free are free: 20 req/min and 50/day (1,000/day after a one-time $10 top-up). Free status here comes from the real price the API returns.',
    freeRule: (m) => m.endsWith(':free'),
    models: [{ id: 'openrouter/free', name: 'OpenRouter Free Router', free: true, tools: true }],
  },
  {
    id: 'nvidia', name: 'NVIDIA NIM', logo: 'nvidia', tier: 'free', format: 'openai', baseUrl: 'https://integrate.api.nvidia.com/v1', needsKey: true, cors: false, rank: 4,
    keyUrl: 'https://build.nvidia.com/settings/api-keys', docsUrl: 'https://build.nvidia.com/models',
    freeAr: 'موديلات مفتوحة كبيرة (DeepSeek وKimi وGLM وNemotron…) مجانًا للتجربة بحوالي ٤٠ طلب في الدقيقة. مخصّص للتجربة مش للإنتاج. بيشتغل في تطبيق أندرويد (المتصفح بيمنعه).',
    freeEn: 'Large open models free for evaluation at about 40 req/min. Testing only, not production. Works in the Android app (browsers block it via CORS).',
    freeRule: all,
    models: [{ id: 'meta/llama-3.3-70b-instruct', tools: true }, { id: 'deepseek-ai/deepseek-v3.1', tools: true }, { id: 'moonshotai/kimi-k2-instruct', tools: true }],
  },
  {
    id: 'cloudflare', name: 'Cloudflare Workers AI', logo: 'cloudflare', tier: 'free', format: 'openai', baseUrl: 'https://api.cloudflare.com/client/v4/accounts/{accountId}/ai/v1', needsKey: true, needsAccountId: true, cors: false, rank: 5,
    keyUrl: 'https://dash.cloudflare.com/profile/api-tokens', docsUrl: 'https://developers.cloudflare.com/workers-ai/platform/pricing/',
    freeAr: '١٠ آلاف «نيورون» مجانًا كل يوم. محتاج رقم الحساب (Account ID) وتوكن بصلاحية Workers AI. بيشتغل في تطبيق أندرويد.',
    freeEn: '10,000 Neurons free every day. Needs your Account ID and a token with Workers AI permission. Works in the Android app.',
    freeRule: all,
    models: [{ id: '@cf/meta/llama-3.3-70b-instruct-fp8-fast', tools: true }, { id: '@cf/qwen/qwen2.5-coder-32b-instruct' }],
  },
  {
    id: 'huggingface', name: 'Hugging Face', logo: 'huggingface', tier: 'free', format: 'openai', baseUrl: 'https://router.huggingface.co/v1', needsKey: true, cors: true, rank: 6,
    keyUrl: 'https://huggingface.co/settings/tokens', docsUrl: 'https://huggingface.co/docs/inference-providers',
    freeAr: 'رصيد مجاني صغير كل شهر على «Inference Providers» لموديلات مفتوحة كتير. اعمل توكن بصلاحية Inference.',
    freeEn: 'A small free monthly credit on Inference Providers for many open models. Create a token with Inference permission.',
    freeRule: all,
    models: [{ id: 'meta-llama/Llama-3.3-70B-Instruct', tools: true }, { id: 'Qwen/Qwen2.5-72B-Instruct', tools: true }],
  },
  {
    id: 'sambanova', name: 'SambaNova', logo: 'sambanova', tier: 'free', format: 'openai', baseUrl: 'https://api.sambanova.ai/v1', needsKey: true, cors: true, rank: 7,
    keyUrl: 'https://cloud.sambanova.ai/apis', docsUrl: 'https://docs.sambanova.ai/cloud/docs/get-started/rate-limits',
    freeAr: 'مجاني من غير كارت لكن قليل: حوالي ٢٠ طلب في اليوم لكل موديل. سريع جدًا.',
    freeEn: 'Free, no card, but small: about 20 requests/day per model. Very fast.',
    freeRule: all,
    models: [{ id: 'Meta-Llama-3.3-70B-Instruct', tools: true }, { id: 'DeepSeek-V3.1', tools: true }, { id: 'gpt-oss-120b', tools: true }],
  },
  {
    id: 'zai', name: 'Z.ai (GLM)', logo: 'zai', tier: 'free', format: 'openai', baseUrl: 'https://api.z.ai/api/paas/v4', needsKey: true, cors: true, rank: 8,
    keyUrl: 'https://z.ai/manage-apikey/apikey-list', docsUrl: 'https://docs.z.ai',
    freeAr: 'موديل GLM-Flash مجاني، والباقي مدفوع بأسعار قليلة.',
    freeEn: 'The GLM Flash model is free; the others are low-cost paid.',
    freeRule: (m) => /flash/i.test(m),
    models: [{ id: 'glm-4.5-flash', free: true, tools: true }, { id: 'glm-4.6', tools: true }],
  },
  {
    id: 'siliconflow', name: 'SiliconFlow', logo: 'siliconcloud', tier: 'free', format: 'openai', baseUrl: 'https://api.siliconflow.com/v1', needsKey: true, cors: true, rank: 9,
    keyUrl: 'https://cloud.siliconflow.com/account/ak', docsUrl: 'https://docs.siliconflow.com',
    freeAr: 'فيه موديلات صغيرة مجانية دائمًا (Qwen وGLM الصغيرين)، والكبيرة مدفوعة.',
    freeEn: 'Some small models are permanently free (small Qwen/GLM); larger ones are paid.',
    freeRule: (m) => /7B|8B|9B|Flash/i.test(m),
    models: [{ id: 'Qwen/Qwen2.5-7B-Instruct', free: true, tools: true }, { id: 'deepseek-ai/DeepSeek-V3', tools: true }],
  },
  {
    id: 'cohere', name: 'Cohere', logo: 'cohere', tier: 'free', format: 'openai', baseUrl: 'https://api.cohere.ai/compatibility/v1', needsKey: true, cors: true, rank: 10,
    keyUrl: 'https://dashboard.cohere.com/api-keys', docsUrl: 'https://docs.cohere.com/docs/rate-limits',
    freeAr: 'مفتاح «Trial» مجاني بحد شهري صغير، لغير الاستخدام التجاري.',
    freeEn: 'Free trial key with a small monthly cap, non-commercial use.',
    freeRule: all,
    models: [{ id: 'command-a-03-2025', tools: true }, { id: 'command-r-plus-08-2024', tools: true }],
  },
  {
    id: 'vercel', name: 'Vercel AI Gateway', logo: 'vercel', tier: 'free', format: 'openai', baseUrl: 'https://ai-gateway.vercel.sh/v1', needsKey: true, cors: true, rank: 11,
    keyUrl: 'https://vercel.com/dashboard/ai-gateway', docsUrl: 'https://vercel.com/docs/ai-gateway/pricing',
    freeAr: 'رصيد ٥ دولار مجاني كل شهر على الخطة المجانية لموديلات كتير (OpenAI وAnthropic وغيرهم).',
    freeEn: '$5 free credit every month on the free plan, across many models (OpenAI, Anthropic and more).',
    freeRule: all,
    models: [{ id: 'openai/gpt-4.1-mini', tools: true }, { id: 'anthropic/claude-haiku-4.5', tools: true }],
  },
  // ---------------------------------------------------------------- one-time trial credit / changing terms
  {
    id: 'mistral', name: 'Mistral AI', logo: 'mistral', tier: 'trial', format: 'openai', baseUrl: 'https://api.mistral.ai/v1', needsKey: true, cors: true, rank: 1,
    keyUrl: 'https://console.mistral.ai/api-keys', docsUrl: 'https://docs.mistral.ai',
    freeAr: 'كانت عندها خطة «Experiment» مجانية، لكن مصادر نوفمبر ٢٠٢٦ بتقول إن الـ API بقى محتاج تفعيل دفع. اتأكد من صفحة الحدود في حسابك.',
    freeEn: 'Had a free “Experiment” plan; reports from Nov 2026 say API access now needs billing. Check the limits page in your console.',
    models: [{ id: 'mistral-small-latest', tools: true }, { id: 'mistral-large-latest', tools: true }],
  },
  {
    id: 'cerebras', name: 'Cerebras', logo: 'cerebras', tier: 'trial', format: 'openai', baseUrl: 'https://api.cerebras.ai/v1', needsKey: true, cors: true, rank: 2,
    keyUrl: 'https://cloud.cerebras.ai', docsUrl: 'https://inference-docs.cerebras.ai/support/rate-limits',
    freeAr: 'رصيد تجريبي ٥ دولار لمدة ٣٠ يوم بعد إضافة كارت. سريع جدًا.',
    freeEn: '$5 trial credit for 30 days after adding a card. Very fast.',
    models: [{ id: 'gpt-oss-120b', tools: true }, { id: 'llama-3.3-70b', tools: true }],
  },
  { id: 'fireworks', name: 'Fireworks AI', logo: 'fireworks', tier: 'trial', format: 'openai', baseUrl: 'https://api.fireworks.ai/inference/v1', needsKey: true, cors: true, rank: 3, keyUrl: 'https://fireworks.ai/account/api-keys',
    freeAr: 'رصيد تجريبي صغير عند التسجيل.', freeEn: 'Small trial credit on sign-up.', models: [{ id: 'accounts/fireworks/models/llama-v3p3-70b-instruct', tools: true }] },
  { id: 'together', name: 'Together AI', logo: 'together', tier: 'trial', format: 'openai', baseUrl: 'https://api.together.xyz/v1', needsKey: true, cors: true, rank: 4, keyUrl: 'https://api.together.ai/settings/api-keys',
    freeAr: 'رصيد تجريبي أحيانًا، والأساس مدفوع.', freeEn: 'Occasional trial credit; mainly paid.', models: [{ id: 'meta-llama/Llama-3.3-70B-Instruct-Turbo', tools: true }] },
  { id: 'hyperbolic', name: 'Hyperbolic', logo: 'hyperbolic', tier: 'trial', format: 'openai', baseUrl: 'https://api.hyperbolic.xyz/v1', needsKey: true, cors: true, rank: 5, keyUrl: 'https://app.hyperbolic.xyz/settings',
    freeAr: 'رصيد تجريبي عند التسجيل.', freeEn: 'Trial credit on sign-up.', models: [{ id: 'meta-llama/Llama-3.3-70B-Instruct', tools: true }] },
  { id: 'novita', name: 'Novita AI', logo: 'novita', tier: 'trial', format: 'openai', baseUrl: 'https://api.novita.ai/v3/openai', needsKey: true, cors: true, rank: 6, keyUrl: 'https://novita.ai/settings/key-management',
    freeAr: 'رصيد تجريبي عند التسجيل.', freeEn: 'Trial credit on sign-up.', models: [{ id: 'meta-llama/llama-3.3-70b-instruct', tools: true }] },
  { id: 'chutes', name: 'Chutes', logo: 'chutes', tier: 'trial', format: 'openai', baseUrl: 'https://llm.chutes.ai/v1', needsKey: true, cors: true, rank: 7, keyUrl: 'https://chutes.ai/app/api',
    freeAr: 'رصيد بسيط للتجربة، والشروط بتتغيّر كتير.', freeEn: 'Small trial; terms change often.', models: [{ id: 'deepseek-ai/DeepSeek-V3-0324', tools: true }] },
  // ---------------------------------------------------------------- paid
  { id: 'openai', name: 'OpenAI', logo: 'openai', tier: 'paid', format: 'openai', baseUrl: 'https://api.openai.com/v1', needsKey: true, cors: true, rank: 1, keyUrl: 'https://platform.openai.com/api-keys',
    freeAr: 'مدفوع (محتاج رصيد).', freeEn: 'Paid (needs credit).', models: [{ id: 'gpt-4.1-mini', tools: true }, { id: 'gpt-4.1', tools: true }] },
  { id: 'anthropic', name: 'Anthropic (Claude)', logo: 'claude', tier: 'paid', format: 'anthropic', baseUrl: 'https://api.anthropic.com/v1', needsKey: true, cors: true, rank: 2, keyUrl: 'https://console.anthropic.com/settings/keys',
    freeAr: 'مدفوع (محتاج رصيد).', freeEn: 'Paid (needs credit).', models: [{ id: 'claude-haiku-4-5', tools: true }, { id: 'claude-sonnet-4-5', tools: true }] },
  { id: 'deepseek', name: 'DeepSeek', logo: 'deepseek', tier: 'paid', format: 'openai', baseUrl: 'https://api.deepseek.com/v1', needsKey: true, cors: true, rank: 3, keyUrl: 'https://platform.deepseek.com/api_keys',
    freeAr: 'مدفوع لكن رخيص جدًا.', freeEn: 'Paid but very cheap.', models: [{ id: 'deepseek-chat', tools: true }, { id: 'deepseek-reasoner' }] },
  { id: 'xai', name: 'xAI (Grok)', logo: 'grok', tier: 'paid', format: 'openai', baseUrl: 'https://api.x.ai/v1', needsKey: true, cors: true, rank: 4, keyUrl: 'https://console.x.ai',
    freeAr: 'مدفوع.', freeEn: 'Paid.', models: [{ id: 'grok-3-mini', tools: true }] },
  { id: 'moonshot', name: 'Moonshot (Kimi)', logo: 'kimi', tier: 'paid', format: 'openai', baseUrl: 'https://api.moonshot.ai/v1', needsKey: true, cors: true, rank: 5, keyUrl: 'https://platform.moonshot.ai/console/api-keys',
    freeAr: 'مدفوع.', freeEn: 'Paid.', models: [{ id: 'kimi-k2-0905-preview', tools: true }] },
  { id: 'minimax', name: 'MiniMax', logo: 'minimax', tier: 'paid', format: 'openai', baseUrl: 'https://api.minimax.io/v1', needsKey: true, cors: true, rank: 6, keyUrl: 'https://www.minimax.io/platform',
    freeAr: 'مدفوع.', freeEn: 'Paid.', models: [{ id: 'MiniMax-M1', tools: true }] },
  { id: 'deepinfra', name: 'DeepInfra', logo: 'deepinfra', tier: 'paid', format: 'openai', baseUrl: 'https://api.deepinfra.com/v1/openai', needsKey: true, cors: true, rank: 7, keyUrl: 'https://deepinfra.com/dash/api_keys',
    freeAr: 'مدفوع بأسعار قليلة.', freeEn: 'Low-cost paid.', models: [{ id: 'meta-llama/Llama-3.3-70B-Instruct', tools: true }] },
  { id: 'perplexity', name: 'Perplexity', logo: 'perplexity', tier: 'paid', format: 'openai', baseUrl: 'https://api.perplexity.ai', needsKey: true, cors: true, rank: 8, keyUrl: 'https://www.perplexity.ai/settings/api',
    freeAr: 'مدفوع، بيبحث في الإنترنت، ومش بيدعم تنفيذ الأوامر (الأدوات).', freeEn: 'Paid, web-search answers, no tool calling.', models: [{ id: 'sonar', tools: false }] },
  // ---------------------------------------------------------------- local
  { id: 'ollama', name: 'Ollama (محلي)', logo: 'ollama', tier: 'local', format: 'openai', baseUrl: 'http://localhost:11434/v1', needsKey: false, cors: true, rank: 1, docsUrl: 'https://ollama.com',
    freeAr: 'مجاني بالكامل على جهازك أو على كمبيوتر في نفس الشبكة. غيّر العنوان لعنوان الكمبيوتر لو بتشغّله من الموبايل.', freeEn: 'Fully free on your own machine. Change the address to your computer’s LAN IP when using it from the phone.',
    freeRule: all, models: [{ id: 'llama3.2', tools: true }, { id: 'qwen2.5', tools: true }] },
  { id: 'lmstudio', name: 'LM Studio (محلي)', logo: 'lmstudio', tier: 'local', format: 'openai', baseUrl: 'http://localhost:1234/v1', needsKey: false, cors: true, rank: 2, docsUrl: 'https://lmstudio.ai',
    freeAr: 'مجاني بالكامل على كمبيوترك.', freeEn: 'Fully free on your computer.', freeRule: all, models: [] },
  { id: 'custom', name: 'مزوّد مخصص (OpenAI-compatible)', logo: 'openai', tier: 'local', format: 'openai', baseUrl: '', needsKey: false, cors: true, rank: 3,
    freeAr: 'أي خدمة متوافقة مع OpenAI: حط العنوان والمفتاح.', freeEn: 'Any OpenAI-compatible service: set the URL and key.', models: [] },
];

export const providerById = (id: string) => PROVIDERS.find((p) => p.id === id);
export const TIER_ORDER: Tier[] = ['free', 'trial', 'paid', 'local'];
export const TIER_LABEL: Record<Tier, [string, string]> = {
  free: ['مجاني ومتجدد', 'Renewing free tier'], trial: ['رصيد تجريبي', 'Trial credit'], paid: ['مدفوع', 'Paid'], local: ['محلي / مخصص', 'Local / custom'],
};
export const FACTS_CHECKED = '2026-11';

/** Model-family logo from the model id (falls back to the provider logo). */
export function modelLogo(modelId: string, providerLogo: string): string {
  const m = modelId.toLowerCase();
  const rules: [RegExp, string][] = [
    [/gpt-oss|gpt-|\bo[134]\b|o[134]-|chatgpt|davinci/, 'openai'], [/claude/, 'claude'], [/gemini/, 'gemini'], [/gemma/, 'gemma'], [/llama|meta-/, 'meta'],
    [/qwen|qwq/, 'qwen'], [/deepseek/, 'deepseek'], [/mistral|mixtral|codestral|ministral|magistral|pixtral|devstral/, 'mistral'], [/grok/, 'grok'],
    [/kimi|moonshot/, 'kimi'], [/glm|chatglm/, 'zhipu'], [/command|aya|cohere/, 'cohere'], [/nemotron|nvidia/, 'nvidia'], [/phi-|phi[0-9]|microsoft/, 'microsoft'],
    [/granite|ibm/, 'ibm'], [/minimax/, 'minimax'], [/step-|stepfun/, 'stepfun'], [/baichuan/, 'baichuan'], [/\byi-/, 'yi'], [/doubao/, 'doubao'], [/hermes|nous/, 'nousresearch'], [/lfm|liquid/, 'liquid'], [/sonar/, 'perplexity'],
  ];
  for (const [re, logo] of rules) if (re.test(m)) return logo;
  return providerLogo;
}
export function prettyModel(id: string): string {
  const last = id.split('/').pop() ?? id;
  return last.replace(/^models\//, '').replace(/:free$/, '').replace(/[-_]/g, ' ').replace(/\b(\w)/g, (c) => c.toUpperCase()).replace(/\bGpt\b/, 'GPT').replace(/\bGlm\b/, 'GLM').replace(/\bOss\b/, 'OSS');
}

// ---------------------------------------------------------------- model helpers (pure)
import type { Settings } from '@/models/types';
export function isFreeModel(p: ProviderDef, m: { id: string; free?: boolean }): boolean {
  if (m.free != null) return m.free;
  if (p.tier === 'local') return true;
  if (p.freeRule) return p.freeRule(m.id);
  return false;
}
/** Real fetched list wins; curated list is only a suggestion until the provider is queried. */
export function modelsOf(s: Settings, p: ProviderDef) {
  const cfg = s.ai.providers[p.id];
  const base = cfg?.models?.length ? cfg.models : p.models;
  const bad = new Set(cfg?.badModels ?? []);
  return base.map((m) => ({ ...m, free: isFreeModel(p, m), bad: bad.has(m.id) }));
}
