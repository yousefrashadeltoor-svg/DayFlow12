/**
 * The agent loop: model ↔ tools until a final answer. Every tool call runs a real app operation (tools.ts).
 * Conversations persist in the `aiChats` collection; API keys live in `state/aiKeys` (excluded from backups).
 */
import type { AiChat, AiMessage, AiToolRun, Settings } from '@/models/types';
import { useApp, blocksForDate } from '@/stores/appStore';
import { uid } from '@/utils/id';
import { addDays, minToInput, todayKey } from '@/utils/date';
import { chat, listModels, parseJsonToolCalls, resolveBase, AiError, type Endpoint, type WireMessage } from './client';
import { isFreeModel, modelsOf, providerById, type ProviderDef } from './providers';
import { needsConfirmation, toolByName, toolSchemas } from './tools';
import { create } from 'zustand';

const MAX_STEPS = 8;
const undoMap = new Map<string, () => Promise<void>>();
const aborts = new Map<string, AbortController>();

export const useAgent = create<{ busy: Record<string, string | null> }>(() => ({ busy: {} }));
const setBusy = (chatId: string, label: string | null) => useAgent.setState((s) => ({ busy: { ...s.busy, [chatId]: label } }));

// ---------------------------------------------------------------- keys
type KeyState = { id: 'aiKeys'; keys: Record<string, string>; createdAt: number; updatedAt: number };
export function getKeys(): Record<string, string> { return ((useApp.getState().data.state as Record<string, unknown>).aiKeys as KeyState | undefined)?.keys ?? {}; }
export async function setKey(providerId: string, key: string) {
  const t = Date.now(); const cur = getKeys();
  const next: KeyState = { id: 'aiKeys', keys: { ...cur, [providerId]: key.trim() }, createdAt: t, updatedAt: t };
  if (!key.trim()) delete next.keys[providerId];
  await useApp.getState().commit({ state: [next as never] }, {}, { silent: true });
}
export function endpointFor(s: Settings, providerId: string): Endpoint | null {
  const p = providerById(providerId); if (!p) return null;
  const cfg = s.ai.providers[providerId] ?? { enabled: false };
  const key = getKeys()[providerId] ?? '';
  if (p.needsKey && !key) return null;
  if (p.needsAccountId && !cfg.accountId) return null;
  const base = resolveBase(p, cfg.baseUrl, cfg.accountId);
  if (!base) return null;
  return { provider: p, apiKey: key, baseUrl: base };
}

// ---------------------------------------------------------------- model catalogue health
const refreshing = new Set<string>();
/** Loads the provider's REAL model list (OpenRouter works without a key). Silent failures keep the old list. */
export async function refreshProviderModels(p: ProviderDef, silent = false): Promise<number> {
  if (refreshing.has(p.id)) return -1;
  const s = useApp.getState().data.settings.app;
  const key = getKeys()[p.id] ?? '';
  if (p.needsKey && !key && p.id !== 'openrouter') { if (!silent) throw new AiError('no_endpoint', 'auth'); return -1; }
  const cfg = s.ai.providers[p.id];
  const base = resolveBase(p, cfg?.baseUrl, cfg?.accountId);
  if (!base) return -1;
  refreshing.add(p.id);
  try {
    const models = await listModels({ provider: p, apiKey: key, baseUrl: base });
    if (models.length) {
      const cur = useApp.getState().data.settings.app;
      const pc = cur.ai.providers[p.id] ?? { enabled: true };
      const ids = new Set(models.map((m) => m.id));
      await useApp.getState().updateSettings({ ai: { ...cur.ai, providers: { ...cur.ai.providers, [p.id]: { ...pc, models, modelsFetchedAt: Date.now(), badModels: (pc.badModels ?? []).filter((b) => ids.has(b)) } } } });
    }
    return models.length;
  } finally { refreshing.delete(p.id); }
}
async function markBadModel(providerId: string, modelId: string) {
  const cur = useApp.getState().data.settings.app;
  const pc = cur.ai.providers[providerId] ?? { enabled: true };
  const bad = [...new Set([...(pc.badModels ?? []), modelId])].slice(-60);
  await useApp.getState().updateSettings({ ai: { ...cur.ai, providers: { ...cur.ai.providers, [providerId]: { ...pc, badModels: bad } } } });
}
/** Next best model on the same provider: verified list, free first, tool-capable, not known-bad. */
function pickAlternate(providerId: string, tried: Set<string>): string | null {
  const s = useApp.getState().data.settings.app;
  const p = providerById(providerId); if (!p) return null;
  const list = modelsOf(s, p).filter((m) => !tried.has(m.id) && !m.bad && m.tools !== false)
    .sort((a, b) => Number(b.free ?? isFreeModel(p, b)) - Number(a.free ?? isFreeModel(p, a)) || a.id.localeCompare(b.id));
  return list[0]?.id ?? null;
}

// ---------------------------------------------------------------- chats
export function newChat(s: Settings): AiChat {
  const t = Date.now();
  return { id: uid('chat'), title: '', messages: [], providerId: s.ai.providerId, modelId: s.ai.modelId, pinned: false, createdAt: t, updatedAt: t };
}
const getChat = (id: string) => useApp.getState().data.aiChats[id];
async function saveChat(c: AiChat) { await useApp.getState().commit({ aiChats: [{ ...c, updatedAt: Date.now() }] }, {}, { silent: true }); }

function systemPrompt(s: Settings, jsonMode: boolean): string {
  const now = new Date(); const today = todayKey(); const lang = s.language;
  const wd = (d: string) => new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date(d + 'T12:00'));
  const week = Array.from({ length: 7 }, (_, i) => { const d = addDays(today, i); return `${wd(d)} = ${d}`; }).join('; ');
  let ctx = '';
  if (s.ai.shareContext) {
    const d = useApp.getState().data;
    const blocks = blocksForDate(d, today).filter((b) => b.status !== 'cancelled').slice(0, 25).map((b) => `${minToInput(b.startMin)}-${minToInput(b.startMin + b.durationMin)} ${b.title} [${b.status}${b.applied === false ? ', draft' : ''}] id=${b.id}`).join('\n');
    const alarms = Object.values(d.alarmClocks).filter((a) => a.enabled).slice(0, 15).map((a) => `${minToInput(a.minute)} ${a.label || '(no label)'} id=${a.id}`).join('\n');
    const tasks = Object.values(d.tasks).filter((t) => t.status !== 'done' && t.status !== 'cancelled').slice(0, 15).map((t) => `${t.title}${t.dueDate ? ` (due ${t.dueDate})` : ''} id=${t.id}`).join('\n');
    ctx = `\n\nCURRENT DATA (may be partial — use tools for details):\nToday's activities:\n${blocks || '(none)'}\nActive alarms:\n${alarms || '(none)'}\nOpen tasks:\n${tasks || '(none)'}`;
  }
  const json = jsonMode ? `\n\nTOOL CALLING FORMAT (your model has no native tools): to call tools, output one block exactly like\n\`\`\`tool\n{"calls":[{"name":"create_alarm","arguments":{"time":"06:00","days":["workdays"]}}]}\n\`\`\`\nand nothing else in that message. You will then receive TOOL_RESULT messages. After the results, reply normally.\nTools:\n${toolSchemas().map((t) => `- ${t.name}: ${t.description} params=${JSON.stringify((t.parameters as { properties?: unknown }).properties ?? {})}`).join('\n')}` : '';
  return `You are "مساعد مدير اليوم" (Dayflow Assistant), an AI agent built into the DAYFLOW personal planner app. You can actually operate the app through tools: create/edit/delete activities and day plans, alarms, tasks, notes, diary entries, occasions, habits, goals, log water and prayers, start focus timers, change themes/decor/settings and open screens.

RULES
- Reply in the user's language. Default to friendly Egyptian Arabic (عامية مصرية) when the user writes Arabic${lang === 'en' ? '; the app is set to English' : ''}.
- When the user asks you to do something, DO it with tools, then confirm briefly (1–3 short lines). Never claim something was done unless the tool returned ok:true. If a tool fails, say so and explain.
- To change or delete existing items, first find them (get_overview, search, list_alarms, list_tasks) and use their ids.
- Dates: YYYY-MM-DD. Times: HH:MM 24-hour. Resolve relative words (بكرة = tomorrow, بعد بكرة, الخميس الجاي…) using the calendar below.
- Ask one short question only when essential information is missing (e.g. the time of an alarm). Otherwise choose sensible defaults.
- You may call several tools in one turn. Keep answers short; the app shows rich previews of what you did.
- You are not a doctor; health/sleep/exercise suggestions are general and non-medical.

NOW: ${today} ${now.toTimeString().slice(0, 5)} (${wd(today)}), time zone ${Intl.DateTimeFormat().resolvedOptions().timeZone}. Next 7 days: ${week}.
User name: ${s.userName || 'unknown'}. Egyptian work week: Saturday–Thursday, weekend Friday (+Saturday for many).${ctx}${json}`;
}

function toWire(c: AiChat, s: Settings, jsonMode: boolean): WireMessage[] {
  const out: WireMessage[] = [{ role: 'system', content: systemPrompt(s, jsonMode) }];
  const msgs = c.messages.filter((m) => m.role !== 'error').slice(-40);
  for (const m of msgs) {
    if (m.role === 'user') out.push({ role: 'user', content: m.content });
    else if (m.role === 'assistant') {
      if (jsonMode) out.push({ role: 'assistant', content: m.content + (m.toolCalls?.length ? `\n\`\`\`tool\n${JSON.stringify({ calls: m.toolCalls.map((t) => ({ name: t.name, arguments: t.args })) })}\n\`\`\`` : '') });
      else out.push({ role: 'assistant', content: m.content, tool_calls: m.toolCalls?.map((t) => ({ id: t.id, name: t.name, args: t.args })) });
    } else if (m.role === 'tool') {
      if (jsonMode) out.push({ role: 'user', content: `TOOL_RESULT ${m.toolName}: ${m.content}` });
      else out.push({ role: 'tool', content: m.content, tool_call_id: m.toolCallId!, name: m.toolName! });
    }
  }
  // providers reject assistant tool_calls without matching tool results: drop dangling calls (e.g. a pending confirmation)
  if (!jsonMode) {
    const answered = new Set(out.filter((m) => m.role === 'tool').map((m) => (m as { tool_call_id: string }).tool_call_id));
    for (const m of out) if (m.role === 'assistant' && m.tool_calls) m.tool_calls = m.tool_calls.filter((t) => answered.has(t.id));
  }
  return out;
}

async function execute(chatId: string, msgId: string, callId: string): Promise<void> {
  let c = getChat(chatId); const msg = c.messages.find((m) => m.id === msgId); const call = msg?.toolCalls?.find((t) => t.id === callId);
  if (!msg || !call) return;
  const tool = toolByName(call.name);
  const setRun = async (patch: Partial<AiToolRun>) => {
    c = getChat(chatId);
    const messages = c.messages.map((m) => m.id !== msgId ? m : { ...m, runs: (m.runs ?? []).map((r) => r.callId === callId ? { ...r, ...patch } : r) });
    await saveChat({ ...c, messages });
  };
  let content: string;
  if (!tool) { content = JSON.stringify({ ok: false, error: `unknown tool ${call.name}` }); await setRun({ status: 'error', error: 'unknown tool' }); }
  else {
    await setRun({ status: 'running' });
    setBusy(chatId, call.name);
    try {
      const r = await tool.run(call.args ?? {});
      if (r.undo) undoMap.set(callId, r.undo);
      content = JSON.stringify({ ok: r.ok, summary: r.summary, ...(r.error ? { error: r.error } : {}), ...(r.data !== undefined ? { data: r.data } : {}) }).slice(0, 7000);
      await setRun({ status: r.ok ? 'done' : 'error', summary: r.summary, error: r.error, cards: r.cards, undoable: !!r.undo });
    } catch (e) {
      const err = (e as Error).message;
      content = JSON.stringify({ ok: false, error: err });
      await setRun({ status: 'error', error: err });
    }
  }
  c = getChat(chatId);
  const toolMsg: AiMessage = { id: uid('m'), role: 'tool', content, at: Date.now(), toolCallId: callId, toolName: call.name };
  await saveChat({ ...c, messages: [...c.messages, toolMsg] });
}

/** Runs the model/tool loop from the current end of the conversation. */
async function loop(chatId: string): Promise<void> {
  const ac = new AbortController(); aborts.set(chatId, ac);
  try {
    for (let step = 0; step < MAX_STEPS; step++) {
      const s = useApp.getState().data.settings.app;
      let c = getChat(chatId);
      const ep = endpointFor(s, c.providerId);
      if (!ep) throw new AiError('no_endpoint', 'auth');
      const pcfg = s.ai.providers[c.providerId];
      let jsonMode = pcfg?.toolMode?.[c.modelId] === 'json' || ep.provider.models.find((m) => m.id === c.modelId)?.tools === false || pcfg?.models?.find((m) => m.id === c.modelId)?.tools === false;
      setBusy(chatId, 'thinking');
      const t0 = Date.now();
      let res; let usedModel = c.modelId; let fallbackFrom: string | undefined;
      const tried = new Set<string>([usedModel]);
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          res = await chat(ep, usedModel, toWire(c, s, jsonMode), jsonMode ? null : toolSchemas(), s.ai.temperature, ac.signal);
          break;
        } catch (e) {
          if (ac.signal.aborted) throw e;
          if (!jsonMode && e instanceof AiError && (e.code === 'tools' || (e.code === 'bad_request' && /tool|function/i.test(e.message)))) {
            jsonMode = true; // this model has no native tools: remember and retry with the text protocol
            const cur = useApp.getState().data.settings.app;
            const pc = cur.ai.providers[c.providerId] ?? { enabled: true };
            await useApp.getState().updateSettings({ ai: { ...cur.ai, providers: { ...cur.ai.providers, [c.providerId]: { ...pc, toolMode: { ...(pc.toolMode ?? {}), [usedModel]: 'json' as const } } } } });
            attempt--; continue;
          }
          const retryable = e instanceof AiError && (e.code === 'rate' || e.code === 'server' || e.code === 'model');
          if (retryable) {
            if ((e as AiError).code === 'model') await markBadModel(c.providerId, usedModel);
            const alt = pickAlternate(c.providerId, tried);
            if (alt && attempt < 2) {
              tried.add(alt); fallbackFrom = fallbackFrom ?? usedModel; usedModel = alt;
              useApp.getState().toast('info', useApp.getState().t('ai_fallback', { m: alt.split('/').pop() ?? alt }));
              setBusy(chatId, 'thinking');
              continue;
            }
          }
          throw e;
        }
      }
      if (!res) throw new AiError('empty response', 'server');
      let text = res!.text; let calls = res!.toolCalls;
      if (jsonMode || !calls.length) { const parsed = parseJsonToolCalls(text); if (parsed.calls.length) { calls = parsed.calls; text = parsed.rest; } }
      calls = calls.filter((x) => toolByName(x.name)).map((x) => ({ ...x, args: x.args ?? {} }));
      c = getChat(chatId);
      const msg: AiMessage = { id: uid('m'), role: 'assistant', content: text, at: Date.now(), providerId: c.providerId, modelId: usedModel, fallbackFrom, usage: res!.usage, ms: Date.now() - t0,
        toolCalls: calls.length ? calls : undefined, runs: calls.map((x) => ({ callId: x.id, name: x.name, args: x.args, status: needsConfirmation(x.name, s.ai.execution) ? 'needs_confirm' : 'pending' })) };
      await saveChat({ ...c, messages: [...c.messages, msg] });
      if (!calls.length) return;
      let paused = false;
      for (const x of calls) {
        if (ac.signal.aborted) throw new AiError('cancelled', 'cancelled');
        if (needsConfirmation(x.name, s.ai.execution)) { paused = true; continue; }
        await execute(chatId, msg.id, x.id);
      }
      if (paused) return; // waits for confirm()/reject() from the UI
    }
  } catch (e) {
    const err = e as AiError;
    if (err.code !== 'cancelled') {
      const c = getChat(chatId);
      await saveChat({ ...c, messages: [...c.messages, { id: uid('m'), role: 'error', content: `${err.code ?? 'error'}|${err.message}`, at: Date.now() }] });
    }
  } finally {
    aborts.delete(chatId); setBusy(chatId, null);
  }
}

export async function send(chatId: string, text: string) {
  const c = getChat(chatId); if (!c || !text.trim()) return;
  const msg: AiMessage = { id: uid('m'), role: 'user', content: text.trim(), at: Date.now() };
  await saveChat({ ...c, title: c.title || text.trim().slice(0, 48), messages: [...c.messages, msg] });
  await loop(chatId);
}
export function stop(chatId: string) { aborts.get(chatId)?.abort(); setBusy(chatId, null); }

/** Approve or reject a tool call that is waiting for confirmation, then continue the loop. */
export async function decide(chatId: string, msgId: string, callId: string, approve: boolean) {
  if (approve) await execute(chatId, msgId, callId);
  else {
    const c = getChat(chatId);
    const messages = c.messages.map((m) => m.id !== msgId ? m : { ...m, runs: (m.runs ?? []).map((r) => r.callId === callId ? { ...r, status: 'cancelled' as const } : r) });
    const call = c.messages.find((m) => m.id === msgId)?.toolCalls?.find((t) => t.id === callId);
    await saveChat({ ...c, messages: [...messages, { id: uid('m'), role: 'tool', content: JSON.stringify({ ok: false, error: 'the user declined this action' }), at: Date.now(), toolCallId: callId, toolName: call?.name ?? '' }] });
  }
  const c = getChat(chatId);
  const waiting = c.messages.find((m) => m.id === msgId)?.runs?.some((r) => r.status === 'needs_confirm');
  if (!waiting) await loop(chatId);
}

export async function undo(chatId: string, msgId: string, callId: string): Promise<boolean> {
  const fn = undoMap.get(callId); if (!fn) return false;
  await fn(); undoMap.delete(callId);
  const c = getChat(chatId);
  await saveChat({ ...c, messages: c.messages.map((m) => m.id !== msgId ? m : { ...m, runs: (m.runs ?? []).map((r) => r.callId === callId ? { ...r, undone: true, undoable: false } : r) }) });
  return true;
}
export const canUndo = (callId: string) => undoMap.has(callId);

/** Regenerate: remove everything after the last user message and run again. */
export async function regenerate(chatId: string) {
  const c = getChat(chatId);
  const idx = c.messages.map((m) => m.role).lastIndexOf('user');
  if (idx < 0) return;
  await saveChat({ ...c, messages: c.messages.slice(0, idx + 1) });
  await loop(chatId);
}
