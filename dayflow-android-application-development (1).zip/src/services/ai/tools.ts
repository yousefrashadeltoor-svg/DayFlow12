/**
 * Agent tools. Every tool performs a REAL operation through the same store actions the UI uses, so changes are
 * persisted (SQLite on Android / IndexedDB on web), synced to native alarms/notifications/widgets, and undoable.
 */
import type { ActivityBlock, AiCard, AlarmClock, DateKey, Goal, Habit, PersonalNote, RecurrenceRule, Settings, SpecialDate, Task } from '@/models/types';
import { useApp, blocksForDate, emptyJournal } from '@/stores/appStore';
import { useUI, type Screen, type Tab } from '@/stores/uiStore';
import { coreFrom } from '@/services/defaults';
import { defaultAlarm, nextRing } from '@/services/alarmClock';
import { nextPrayer, prayerStats, timesFor, PRAYER_KEYS } from '@/services/prayer';
import { occasionsOn } from '@/services/occasions';
import { dayStat, rangeStats } from '@/services/analytics/stats';
import { addDays, epochOf, inputToMin, isValidDateKey, minToInput, parseTime, toDateKey, todayKey, weekday } from '@/utils/date';
import { uid } from '@/utils/id';
import { THEMES } from '@/services/themes';
import { SEASONS } from '@/services/decor';
import type { ChatTool } from './client';

export interface ToolResult { ok: boolean; summary: string; data?: unknown; cards?: AiCard[]; undo?: () => Promise<void>; error?: string }
interface ToolDef extends ChatTool { destructive?: boolean; readOnly?: boolean; run: (a: Record<string, unknown>) => Promise<ToolResult> }

const st = () => useApp.getState();
const S = (v: unknown, d = '') => (v == null ? d : String(v).trim());
const N = (v: unknown, d: number) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const B = (v: unknown, d: boolean) => (v == null ? d : v === true || v === 'true' || v === 1);
const fail = (error: string): ToolResult => ({ ok: false, summary: error, error });

function dateArg(v: unknown): DateKey {
  const s = S(v).toLowerCase();
  if (!s || s === 'today' || s === 'النهاردة' || s === 'اليوم') return todayKey();
  if (s === 'tomorrow' || s === 'بكرة' || s === 'غدا') return addDays(todayKey(), 1);
  if (s === 'yesterday' || s === 'امبارح') return addDays(todayKey(), -1);
  const ar = s.replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
  if (isValidDateKey(ar)) return ar;
  throw new Error(`invalid date "${s}" — use YYYY-MM-DD`);
}
function timeArg(v: unknown): number {
  const s = S(v);
  const m = parseTime(s) ?? (/^\d{1,2}$/.test(s) ? Number(s) * 60 : null);
  if (m == null) throw new Error(`invalid time "${s}" — use HH:MM (24h)`);
  return m;
}
const CAT: Record<string, string> = { study: 'cat_study', work: 'cat_work', exercise: 'cat_exercise', workout: 'cat_exercise', rest: 'cat_rest', break: 'cat_rest', meal: 'cat_meal', food: 'cat_meal', sleep: 'cat_sleep', water: 'cat_water', personal: 'cat_personal', prayer: 'cat_prayer', routine: 'cat_routine', appointment: 'cat_appointment', meeting: 'cat_appointment' };
const catOf = (v: unknown) => CAT[S(v).toLowerCase()] ?? (st().data.categories[S(v)] ? S(v) : 'cat_personal');
const DAY_NAMES: Record<string, number> = { sun: 0, sunday: 0, 'الأحد': 0, 'الاحد': 0, mon: 1, monday: 1, 'الاثنين': 1, 'الإثنين': 1, tue: 2, tuesday: 2, 'الثلاثاء': 2, wed: 3, wednesday: 3, 'الأربعاء': 3, 'الاربعاء': 3, thu: 4, thursday: 4, 'الخميس': 4, fri: 5, friday: 5, 'الجمعة': 5, sat: 6, saturday: 6, 'السبت': 6 };
function daysArg(v: unknown): number[] {
  if (!v) return [];
  const arr = Array.isArray(v) ? v : String(v).split(/[,،\s]+/);
  const out = new Set<number>();
  for (const x of arr) {
    const s = String(x).trim().toLowerCase();
    if (s === 'everyday' || s === 'daily' || s === 'كل يوم') [0, 1, 2, 3, 4, 5, 6].forEach((d) => out.add(d));
    else if (s === 'workdays' || s === 'weekdays') [6, 0, 1, 2, 3, 4].forEach((d) => out.add(d));
    else if (s === 'weekend') [5, 6].forEach((d) => out.add(d));
    else if (/^[0-6]$/.test(s)) out.add(Number(s));
    else if (s in DAY_NAMES) out.add(DAY_NAMES[s]);
  }
  return [...out].sort();
}
function findBlock(a: Record<string, unknown>): ActivityBlock | undefined {
  const data = st().data;
  if (a.id && data.activities[S(a.id)]) return data.activities[S(a.id)];
  const q = S(a.title ?? a.query).toLowerCase();
  if (!q) return undefined;
  const date = a.date ? dateArg(a.date) : null;
  const list = Object.values(data.activities).filter((b) => b.status !== 'cancelled' && (!date || b.date === date) && b.title.toLowerCase().includes(q));
  return list.sort((x, y) => Math.abs(Date.parse(x.date) - Date.now()) - Math.abs(Date.parse(y.date) - Date.now()))[0];
}
const blockCard = (b: ActivityBlock): AiCard => ({ type: 'activity', data: { id: b.id, title: b.title, date: b.date, start: minToInput(b.startMin), end: minToInput(b.startMin + b.durationMin), duration: b.durationMin, color: b.color, icon: b.icon, notes: b.notes, status: b.status, applied: b.applied !== false }, open: { tab: 'plan', blockId: b.id } });
const scheduleCard = (date: DateKey): AiCard => ({ type: 'schedule', data: { date, blocks: blocksForDate(st().data, date).filter((b) => b.status !== 'cancelled').map((b) => ({ id: b.id, title: b.title, start: minToInput(b.startMin), end: minToInput(b.startMin + b.durationMin), color: b.color, status: b.status, notes: b.notes, applied: b.applied !== false })) }, open: { tab: 'today' } });
const alarmCard = (a: AlarmClock): AiCard => ({ type: 'alarm', data: { id: a.id, time: minToInput(a.minute), label: a.label, days: a.days, enabled: a.enabled, next: nextRing(a, Date.now()), snoozeMin: a.snoozeMin }, open: { screen: 'alarms' } });
const taskCard = (t: Task): AiCard => ({ type: 'task', data: { id: t.id, title: t.title, due: t.dueDate, priority: t.priority, status: t.status, checklist: t.checklist.map((c) => c.title) }, open: { screen: 'tasks' } });

type Removable = 'activities' | 'alarmClocks' | 'tasks' | 'notes' | 'specialDates' | 'waterLogs' | 'habits' | 'goals' | 'prayerLogs' | 'habitLogs';
async function removeIds(col: Removable, ids: string[]) { await st().commit({}, { [col]: ids }); }

export const TOOLS: ToolDef[] = [
  // ---------------------------------------------------------------- read
  { name: 'get_overview', readOnly: true, description: 'Get the user’s day: activities (with ids, times, status), tasks due, alarms, next prayer, occasions, water. Call this before changing existing items.',
    parameters: { type: 'object', properties: { date: { type: 'string', description: 'YYYY-MM-DD, "today" or "tomorrow"' } } },
    run: async (a) => {
      const date = dateArg(a.date); const d = st().data; const s = d.settings.app;
      const blocks = blocksForDate(d, date).filter((b) => b.status !== 'cancelled');
      const tasks = Object.values(d.tasks).filter((t) => t.status !== 'done' && t.status !== 'cancelled' && t.dueDate && t.dueDate <= date);
      const alarms = Object.values(d.alarmClocks).filter((x) => x.enabled);
      const np = s.prayer.enabled ? nextPrayer(Date.now(), s.prayer) : null;
      const occ = occasionsOn(date, { hijriAdjust: s.hijriAdjust, showOtherReligions: false, user: Object.values(d.specialDates) });
      const water = Object.values(d.waterLogs).filter((w) => w.date === date).reduce((x, w) => x + w.ml, 0);
      const stat = dayStat(d, date);
      return { ok: true, summary: `${blocks.length} activities, ${tasks.length} tasks due`, cards: [scheduleCard(date)],
        data: { date, completion: stat.completionPct, activities: blocks.map((b) => ({ id: b.id, title: b.title, start: minToInput(b.startMin), end: minToInput(b.startMin + b.durationMin), status: b.status, draft: b.applied === false, notes: b.notes })),
          tasks: tasks.map((t) => ({ id: t.id, title: t.title, due: t.dueDate })), alarms: alarms.map((x) => ({ id: x.id, time: minToInput(x.minute), label: x.label, days: x.days })),
          nextPrayer: np ? { prayer: np.key, at: new Date(np.at).toTimeString().slice(0, 5) } : null, occasions: occ.map((o) => ({ title: o.title, official: o.official })), waterMl: water, waterTarget: s.water.targetMl } };
    } },
  { name: 'search', readOnly: true, description: 'Search activities, tasks, notes, journal, alarms, habits and goals by text.',
    parameters: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] },
    run: async (a) => {
      const q = S(a.query).toLowerCase(); const d = st().data; const hit = (x?: string) => !!x && x.toLowerCase().includes(q);
      const res = [
        ...Object.values(d.activities).filter((b) => hit(b.title) || hit(b.notes)).slice(0, 10).map((b) => ({ kind: 'activity', id: b.id, title: b.title, date: b.date, time: minToInput(b.startMin) })),
        ...Object.values(d.tasks).filter((t) => hit(t.title) || hit(t.notes)).slice(0, 10).map((t) => ({ kind: 'task', id: t.id, title: t.title, due: t.dueDate, status: t.status })),
        ...Object.values(d.notes).filter((n) => hit(n.title) || hit(n.body)).slice(0, 10).map((n) => ({ kind: 'note', id: n.id, title: n.title || n.body.slice(0, 40) })),
        ...Object.values(d.journal).filter((j) => hit(j.body) || hit(j.title)).slice(0, 10).map((j) => ({ kind: 'journal', id: j.id, date: j.date, title: j.title || j.body.slice(0, 40) })),
        ...Object.values(d.alarmClocks).filter((x) => hit(x.label)).map((x) => ({ kind: 'alarm', id: x.id, label: x.label, time: minToInput(x.minute) })),
        ...Object.values(d.habits).filter((h) => hit(h.name)).map((h) => ({ kind: 'habit', id: h.id, name: h.name })),
        ...Object.values(d.goals).filter((g) => hit(g.title)).map((g) => ({ kind: 'goal', id: g.id, title: g.title })),
      ];
      return { ok: true, summary: `${res.length} results`, data: res, cards: [{ type: 'search', data: { query: a.query, results: res.slice(0, 12) } }] };
    } },
  { name: 'get_stats', readOnly: true, description: 'Productivity statistics for today, this week or this month (completion %, planned vs done minutes, study and exercise time).',
    parameters: { type: 'object', properties: { range: { type: 'string', enum: ['today', 'week', 'month'] } } },
    run: async (a) => {
      const r = S(a.range, 'week'); const days = r === 'today' ? 1 : r === 'month' ? 30 : 7;
      const stats = rangeStats(st().data, addDays(todayKey(), -(days - 1)), days);
      const withPlan = stats.filter((x) => x.plannedMin > 0);
      const data = { range: r, avgCompletion: withPlan.length ? Math.round(withPlan.reduce((x, y) => x + y.completionPct, 0) / withPlan.length) : 0,
        plannedMin: stats.reduce((x, y) => x + y.plannedMin, 0), doneMin: Math.round(stats.reduce((x, y) => x + y.creditedMin, 0)), studyMin: Math.round(stats.reduce((x, y) => x + y.studyMin, 0)),
        exerciseMin: Math.round(stats.reduce((x, y) => x + y.exerciseMin, 0)), completed: stats.reduce((x, y) => x + y.completed, 0), missed: stats.reduce((x, y) => x + y.missed, 0), days: stats.map((x) => ({ date: x.date, pct: x.completionPct, planned: x.plannedMin })) };
      return { ok: true, summary: `average ${data.avgCompletion}%`, data, cards: [{ type: 'stats', data, open: { tab: 'progress' } }] };
    } },
  { name: 'get_prayer_times', readOnly: true, description: 'Prayer times for a date at the user’s configured Egyptian governorate, plus the next prayer and today’s prayed count.',
    parameters: { type: 'object', properties: { date: { type: 'string' } } },
    run: async (a) => {
      const s = st().data.settings.app; const date = dateArg(a.date); const t = timesFor(date, s.prayer);
      if (!t) return fail('prayer times unavailable for this location');
      const np = nextPrayer(Date.now(), s.prayer); const ps = prayerStats(Object.values(st().data.prayerLogs));
      const data = { date, enabled: s.prayer.enabled, times: Object.fromEntries((['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'] as const).map((k) => [k, minToInput(Math.round(t[k]))])), next: np ? { prayer: np.key, at: np.at, progress: Math.round(np.progress) } : null, prayedToday: ps.today };
      return { ok: true, summary: `next: ${np?.key ?? '-'}`, data, cards: [{ type: 'prayer', data, open: { screen: 'prayer' } }] };
    } },
  { name: 'list_tasks', readOnly: true, description: 'List tasks. filter: open | today | overdue | done | all.',
    parameters: { type: 'object', properties: { filter: { type: 'string', enum: ['open', 'today', 'overdue', 'done', 'all'] } } },
    run: async (a) => {
      const f = S(a.filter, 'open'); const today = todayKey();
      const list = Object.values(st().data.tasks).filter((t) => f === 'all' ? true : f === 'done' ? t.status === 'done' : t.status !== 'done' && t.status !== 'cancelled' && (f === 'open' || (f === 'today' ? t.dueDate === today : !!t.dueDate && t.dueDate < today)));
      return { ok: true, summary: `${list.length} tasks`, data: list.map((t) => ({ id: t.id, title: t.title, due: t.dueDate, priority: t.priority, status: t.status })), cards: [{ type: 'tasks', data: list.slice(0, 15).map((t) => ({ id: t.id, title: t.title, due: t.dueDate, status: t.status, priority: t.priority })), open: { screen: 'tasks' } }] };
    } },
  { name: 'list_alarms', readOnly: true, description: 'List all alarm clocks with ids.', parameters: { type: 'object', properties: {} },
    run: async () => { const list = Object.values(st().data.alarmClocks).sort((x, y) => x.minute - y.minute); return { ok: true, summary: `${list.length} alarms`, data: list.map((x) => ({ id: x.id, time: minToInput(x.minute), label: x.label, days: x.days, enabled: x.enabled })), cards: [{ type: 'alarms', data: list.map((x) => alarmCard(x).data), open: { screen: 'alarms' } }] }; } },

  // ---------------------------------------------------------------- plan / activities
  { name: 'create_activity', description: 'Add an activity (time block) to the plan. It is applied immediately (reminders + widgets) unless apply=false. Use repeat for recurring blocks.',
    parameters: { type: 'object', properties: {
      title: { type: 'string' }, date: { type: 'string', description: 'YYYY-MM-DD / today / tomorrow' }, start: { type: 'string', description: 'HH:MM 24h' },
      duration_min: { type: 'number' }, end: { type: 'string', description: 'HH:MM, alternative to duration_min' },
      category: { type: 'string', enum: ['study', 'work', 'exercise', 'rest', 'meal', 'sleep', 'personal', 'prayer', 'routine', 'appointment'] },
      notes: { type: 'string' }, fixed: { type: 'boolean' }, remind_before_min: { type: 'number', description: 'minutes before start for the reminder (0 = at start)' },
      repeat: { type: 'string', enum: ['none', 'daily', 'weekly'] }, repeat_days: { type: 'array', items: { type: 'string' }, description: 'weekday names for weekly repeat' },
      apply: { type: 'boolean', description: 'default true' } }, required: ['title', 'start'] },
    run: async (a) => {
      const title = S(a.title); if (!title) return fail('title is required');
      const date = dateArg(a.date); const start = timeArg(a.start);
      let dur = N(a.duration_min, 0);
      if (!dur && a.end) { const e = timeArg(a.end); dur = e > start ? e - start : e + 1440 - start; }
      if (!dur) dur = st().data.settings.app.defaultDurationMin;
      if (dur < 1 || dur > 1440) return fail('duration must be 1–1440 minutes');
      const core = coreFrom({ title, categoryId: catOf(a.category), startMin: start, durationMin: dur, fixed: B(a.fixed, false), notes: S(a.notes) });
      core.reminder = { ...core.reminder, offsets: [Math.max(0, N(a.remind_before_min, 0))] };
      const rep = S(a.repeat, 'none');
      const rec: RecurrenceRule | null = rep === 'daily' ? { freq: 'daily', interval: 1, start: date } : rep === 'weekly' ? { freq: 'weekly', interval: 1, byWeekday: daysArg(a.repeat_days).length ? daysArg(a.repeat_days) : [weekday(date)], start: date } : null;
      const before = new Set(Object.keys(st().data.activities));
      const b = await st().createActivity(core, date, rec);
      if (!b && !rec) return fail('could not save the activity');
      if (B(a.apply, true)) await st().applyDayPlan(date);
      const created = Object.keys(st().data.activities).filter((id) => !before.has(id));
      const series = rec ? Object.values(st().data.series).sort((x, y) => y.createdAt - x.createdAt)[0] : undefined;
      const fresh = (b && st().data.activities[b.id]) || st().data.activities[created[0]];
      return { ok: true, summary: `created "${title}" ${date} ${minToInput(start)} (${dur} min)${rec ? ' repeating' : ''}`, data: { id: fresh?.id, date }, cards: fresh ? [blockCard(fresh)] : [],
        undo: async () => { await st().commit(series ? { series: [{ ...series, active: false, updatedAt: Date.now() }] } : {}, { activities: created }); } };
    } },
  { name: 'update_activity', description: 'Change an existing activity (find it by id, or by title + date). Only given fields change.',
    parameters: { type: 'object', properties: { id: { type: 'string' }, title: { type: 'string', description: 'current title to find it' }, date: { type: 'string' }, new_title: { type: 'string' }, new_date: { type: 'string' }, start: { type: 'string' }, duration_min: { type: 'number' }, notes: { type: 'string' }, fixed: { type: 'boolean' } } },
    run: async (a) => {
      const b = findBlock(a); if (!b) return fail('activity not found — call get_overview first');
      const prev = { ...b };
      const patch: Partial<ActivityBlock> = {};
      if (a.new_title) patch.title = S(a.new_title);
      if (a.new_date) patch.date = dateArg(a.new_date);
      if (a.start) patch.startMin = timeArg(a.start);
      if (a.duration_min) patch.durationMin = Math.max(1, Math.min(1440, N(a.duration_min, b.durationMin)));
      if (a.notes != null) patch.notes = S(a.notes);
      if (a.fixed != null) patch.fixed = B(a.fixed, b.fixed);
      if (!(await st().updateActivity(b.id, patch))) return fail('could not update');
      const nb = st().data.activities[b.id];
      return { ok: true, summary: `updated "${nb.title}"`, cards: [blockCard(nb)], undo: async () => { await st().commit({ activities: [{ ...prev, updatedAt: Date.now() }] }); } };
    } },
  { name: 'delete_activity', destructive: true, description: 'Delete an activity (by id, or title + date).', parameters: { type: 'object', properties: { id: { type: 'string' }, title: { type: 'string' }, date: { type: 'string' } } },
    run: async (a) => {
      const b = findBlock(a); if (!b) return fail('activity not found');
      const prev = { ...b };
      await removeIds('activities', [b.id]);
      return { ok: true, summary: `deleted "${b.title}"`, cards: [{ type: 'deleted', data: { kind: 'activity', title: b.title } }], undo: async () => { await st().commit({ activities: [prev] }); } };
    } },
  { name: 'set_activity_status', description: 'Start, complete, skip, pause, resume or partially finish an activity.',
    parameters: { type: 'object', properties: { id: { type: 'string' }, title: { type: 'string' }, date: { type: 'string' }, action: { type: 'string', enum: ['start', 'complete', 'skip', 'pause', 'resume', 'partial'] }, percent: { type: 'number' } }, required: ['action'] },
    run: async (a) => {
      const b = findBlock(a); if (!b) return fail('activity not found');
      const prev = { ...b };
      const ok = await st().blockAction(b.id, S(a.action) as 'start', { percent: a.percent != null ? N(a.percent, 50) : undefined });
      if (!ok) return fail(`cannot ${a.action} this activity in its current state`);
      return { ok: true, summary: `${a.action}: ${b.title}`, cards: [blockCard(st().data.activities[b.id])], undo: async () => { await st().commit({ activities: [{ ...prev, updatedAt: Date.now() }] }); } };
    } },
  { name: 'apply_plan', description: 'Apply (activate) all draft activities of a day so reminders, notifications and widgets start working. Logged in history and journal.',
    parameters: { type: 'object', properties: { date: { type: 'string' } } },
    run: async (a) => {
      const date = dateArg(a.date); const n = await st().applyDayPlan(date);
      const ch = Object.values(st().data.scheduleChanges).filter((c) => c.kind === 'apply' && c.date === date).sort((x, y) => y.createdAt - x.createdAt)[0];
      return { ok: true, summary: n ? `applied ${n} activities` : 'nothing to apply (already applied)', cards: [scheduleCard(date)], undo: n && ch ? async () => { await st().revertChange(ch.id); } : undefined };
    } },
  { name: 'plan_day', description: 'Create several activities for one day in one go (e.g. “plan my day tomorrow”). Each item: title, start HH:MM, duration_min, category, notes. Applied immediately unless apply=false.',
    parameters: { type: 'object', properties: { date: { type: 'string' }, apply: { type: 'boolean' }, items: { type: 'array', items: { type: 'object', properties: { title: { type: 'string' }, start: { type: 'string' }, duration_min: { type: 'number' }, category: { type: 'string' }, notes: { type: 'string' } }, required: ['title', 'start'] } } }, required: ['items'] },
    run: async (a) => {
      const date = dateArg(a.date); const items = Array.isArray(a.items) ? (a.items as Record<string, unknown>[]) : [];
      if (!items.length) return fail('no items');
      const ids: string[] = [];
      for (const it of items) {
        const core = coreFrom({ title: S(it.title), categoryId: catOf(it.category), startMin: timeArg(it.start), durationMin: Math.max(5, N(it.duration_min, 45)), notes: S(it.notes) });
        const b = await st().createActivity(core, date, null);
        if (b) ids.push(b.id);
      }
      if (B(a.apply, true)) await st().applyDayPlan(date);
      return { ok: true, summary: `planned ${ids.length} activities on ${date}`, cards: [scheduleCard(date)], undo: async () => { await removeIds('activities', ids); } };
    } },

  // ---------------------------------------------------------------- alarms
  { name: 'create_alarm', description: 'Create a real alarm clock (rings full-screen on Android even if the app is closed). days: weekday names, "workdays", "weekend", "everyday"; empty = one time.',
    parameters: { type: 'object', properties: { time: { type: 'string', description: 'HH:MM 24h' }, label: { type: 'string' }, days: { type: 'array', items: { type: 'string' } }, date: { type: 'string', description: 'for one-time alarms on a specific day' },
      snooze_min: { type: 'number' }, max_snoozes: { type: 'number' }, ring_min: { type: 'number' }, speak_label: { type: 'boolean' }, vibrate: { type: 'boolean' }, gradual: { type: 'boolean' } }, required: ['time'] },
    run: async (a) => {
      const minute = timeArg(a.time); const t = Date.now();
      const rec: AlarmClock = { id: uid('al'), ...defaultAlarm(minute), label: S(a.label), days: daysArg(a.days), snoozeMin: Math.max(1, Math.min(30, N(a.snooze_min, 9))), maxSnoozes: Math.max(0, Math.min(10, N(a.max_snoozes, 3))),
        ringMin: Math.max(1, Math.min(30, N(a.ring_min, 5))), speakLabel: B(a.speak_label, false), vibrate: B(a.vibrate, true), gradual: B(a.gradual, true), createdAt: t, updatedAt: t };
      if (!rec.days.length) {
        if (a.date) rec.oneTimeDate = dateArg(a.date);
        const at = nextRing(rec, Date.now());
        if (!at) return fail('that time has already passed — give a future date or time');
        rec.oneTimeDate = toDateKey(new Date(at));
      }
      if (!(await st().put('alarmClocks', rec))) return fail('could not save alarm');
      return { ok: true, summary: `alarm ${minToInput(minute)} ${rec.label}`, cards: [alarmCard(rec)], undo: async () => { await removeIds('alarmClocks', [rec.id]); } };
    } },
  { name: 'update_alarm', description: 'Change an alarm (find by id or label). Can also enable/disable it or skip only the next ring.',
    parameters: { type: 'object', properties: { id: { type: 'string' }, label: { type: 'string', description: 'to find it' }, time: { type: 'string' }, new_label: { type: 'string' }, days: { type: 'array', items: { type: 'string' } }, enabled: { type: 'boolean' }, skip_next: { type: 'boolean' }, snooze_min: { type: 'number' }, max_snoozes: { type: 'number' } } },
    run: async (a) => {
      const d = st().data.alarmClocks; const al = d[S(a.id)] ?? Object.values(d).find((x) => a.label && x.label.toLowerCase().includes(S(a.label).toLowerCase())) ?? (a.time && !a.id && !a.label ? Object.values(d).find((x) => x.minute === timeArg(a.time)) : undefined);
      if (!al) return fail('alarm not found — call list_alarms');
      const prev = { ...al }; const n: AlarmClock = { ...al, updatedAt: Date.now() };
      if (a.time && (a.id || a.label)) n.minute = timeArg(a.time);
      if (a.new_label != null) n.label = S(a.new_label);
      if (a.days) { n.days = daysArg(a.days); if (n.days.length) n.oneTimeDate = undefined; }
      if (a.enabled != null) { n.enabled = B(a.enabled, true); n.skipDate = undefined; }
      if (a.snooze_min) n.snoozeMin = N(a.snooze_min, n.snoozeMin);
      if (a.max_snoozes != null) n.maxSnoozes = N(a.max_snoozes, n.maxSnoozes);
      if (B(a.skip_next, false)) { const at = nextRing(n, Date.now()); if (at) n.skipDate = toDateKey(new Date(at)); }
      await st().put('alarmClocks', n);
      return { ok: true, summary: `updated alarm ${minToInput(n.minute)}`, cards: [alarmCard(n)], undo: async () => { await st().commit({ alarmClocks: [prev] }); } };
    } },
  { name: 'delete_alarm', destructive: true, description: 'Delete an alarm (by id or label).', parameters: { type: 'object', properties: { id: { type: 'string' }, label: { type: 'string' } } },
    run: async (a) => {
      const d = st().data.alarmClocks; const al = d[S(a.id)] ?? Object.values(d).find((x) => a.label && x.label.toLowerCase().includes(S(a.label).toLowerCase()));
      if (!al) return fail('alarm not found');
      await removeIds('alarmClocks', [al.id]);
      return { ok: true, summary: `deleted alarm ${minToInput(al.minute)}`, cards: [{ type: 'deleted', data: { kind: 'alarm', title: `${minToInput(al.minute)} ${al.label}` } }], undo: async () => { await st().commit({ alarmClocks: [al] }); } };
    } },

  // ---------------------------------------------------------------- tasks
  { name: 'create_task', description: 'Add a task (to-do). Optional due date, priority 1-5, estimate, checklist items and a reminder time on the due date.',
    parameters: { type: 'object', properties: { title: { type: 'string' }, due_date: { type: 'string' }, priority: { type: 'number' }, estimate_min: { type: 'number' }, notes: { type: 'string' }, checklist: { type: 'array', items: { type: 'string' } }, remind_at: { type: 'string', description: 'HH:MM on the due date' } }, required: ['title'] },
    run: async (a) => {
      const t0 = Date.now(); const due = a.due_date ? dateArg(a.due_date) : undefined;
      const task: Task = { id: uid('t'), title: S(a.title), description: '', dueDate: due, priority: Math.max(1, Math.min(5, N(a.priority, 3))), status: 'todo', estimateMin: Math.max(0, N(a.estimate_min, 30)), trackedMin: 0, tags: [],
        checklist: (Array.isArray(a.checklist) ? a.checklist : []).map((c) => ({ id: uid(), title: String(c), done: false })), subtasks: [], notes: S(a.notes), dependsOn: [], starred: false, someday: false, createdAt: t0, updatedAt: t0,
        reminderAt: a.remind_at ? epochOf(due ?? todayKey(), timeArg(a.remind_at)) : undefined };
      if (!task.title) return fail('title is required');
      await st().put('tasks', task);
      return { ok: true, summary: `task "${task.title}"`, cards: [taskCard(task)], undo: async () => { await removeIds('tasks', [task.id]); } };
    } },
  { name: 'update_task', description: 'Complete, reopen or edit a task (find by id or title).',
    parameters: { type: 'object', properties: { id: { type: 'string' }, title: { type: 'string' }, done: { type: 'boolean' }, new_title: { type: 'string' }, due_date: { type: 'string' }, priority: { type: 'number' }, notes: { type: 'string' } } },
    run: async (a) => {
      const d = st().data.tasks; const t = d[S(a.id)] ?? Object.values(d).find((x) => a.title && x.title.toLowerCase().includes(S(a.title).toLowerCase()));
      if (!t) return fail('task not found');
      const prev = { ...t }; const n: Task = { ...t };
      if (a.done != null) { n.status = B(a.done, true) ? 'done' : 'todo'; n.completedAt = n.status === 'done' ? Date.now() : undefined; }
      if (a.new_title) n.title = S(a.new_title);
      if (a.due_date) n.dueDate = dateArg(a.due_date);
      if (a.priority) n.priority = Math.max(1, Math.min(5, N(a.priority, 3)));
      if (a.notes != null) n.notes = S(a.notes);
      await st().put('tasks', n);
      return { ok: true, summary: `task "${n.title}" ${n.status}`, cards: [taskCard(n)], undo: async () => { await st().commit({ tasks: [prev] }); } };
    } },
  { name: 'delete_task', destructive: true, description: 'Delete a task.', parameters: { type: 'object', properties: { id: { type: 'string' }, title: { type: 'string' } } },
    run: async (a) => {
      const d = st().data.tasks; const t = d[S(a.id)] ?? Object.values(d).find((x) => a.title && x.title.toLowerCase().includes(S(a.title).toLowerCase()));
      if (!t) return fail('task not found');
      await removeIds('tasks', [t.id]);
      return { ok: true, summary: `deleted task "${t.title}"`, cards: [{ type: 'deleted', data: { kind: 'task', title: t.title } }], undo: async () => { await st().commit({ tasks: [t] }); } };
    } },

  // ---------------------------------------------------------------- notes & journal
  { name: 'create_note', description: 'Create a note. kind: quick | rich | checklist | study | meeting | journal. For checklists pass items.',
    parameters: { type: 'object', properties: { title: { type: 'string' }, body: { type: 'string' }, kind: { type: 'string', enum: ['quick', 'rich', 'checklist', 'study', 'meeting', 'journal'] }, items: { type: 'array', items: { type: 'string' } }, tags: { type: 'array', items: { type: 'string' } }, favorite: { type: 'boolean' } } },
    run: async (a) => {
      const t0 = Date.now();
      const n: PersonalNote = { id: uid('n'), title: S(a.title), body: S(a.body), kind: (S(a.kind, 'quick') as PersonalNote['kind']), checklist: (Array.isArray(a.items) ? a.items : []).map((c) => ({ id: uid(), title: String(c), done: false })),
        tags: (Array.isArray(a.tags) ? a.tags : []).map(String), favorite: B(a.favorite, false), linkedNoteIds: [], date: todayKey(), createdAt: t0, updatedAt: t0 };
      if (!n.title && !n.body && !n.checklist.length) return fail('note is empty');
      if (n.checklist.length) n.kind = 'checklist';
      await st().put('notes', n);
      return { ok: true, summary: `note "${n.title || n.body.slice(0, 30)}"`, cards: [{ type: 'note', data: { id: n.id, title: n.title, body: n.body, items: n.checklist.map((c) => c.title), kind: n.kind }, open: { screen: 'notes' } }], undo: async () => { await removeIds('notes', [n.id]); } };
    } },
  { name: 'write_journal', description: 'Write in the user’s diary for a date. mode "append" adds to the existing text (default), "replace" overwrites. mood 1-5 (1 awful … 5 great), energy 1-5.',
    parameters: { type: 'object', properties: { date: { type: 'string' }, text: { type: 'string' }, mode: { type: 'string', enum: ['append', 'replace'] }, title: { type: 'string' }, mood: { type: 'number' }, energy: { type: 'number' }, gratitude: { type: 'array', items: { type: 'string' } }, highlight: { type: 'string' }, lesson: { type: 'string' }, tags: { type: 'array', items: { type: 'string' } } } },
    run: async (a) => {
      const date = dateArg(a.date); const prev = st().data.journal[date];
      const e = { ...(prev ?? emptyJournal(date)) };
      if (a.text) e.body = S(a.mode) === 'replace' || !e.body ? S(a.text) : `${e.body}\n\n${S(a.text)}`;
      if (a.title) e.title = S(a.title);
      if (a.mood) e.mood = Math.max(1, Math.min(5, Math.round(N(a.mood, 3))));
      if (a.energy) e.energy = Math.max(1, Math.min(5, Math.round(N(a.energy, 3))));
      if (Array.isArray(a.gratitude)) e.gratitude = [...(a.gratitude as string[]).map(String), '', '', ''].slice(0, 3);
      if (a.highlight) e.highlight = S(a.highlight);
      if (a.lesson) e.lesson = S(a.lesson);
      if (Array.isArray(a.tags)) e.tags = [...new Set([...e.tags, ...(a.tags as string[]).map(String)])];
      e.updatedAt = Date.now();
      await st().put('journal', e);
      return { ok: true, summary: `journal ${date} updated`, cards: [{ type: 'journal', data: { date, title: e.title, body: e.body, mood: e.mood, energy: e.energy, gratitude: e.gratitude.filter(Boolean) }, open: { screen: 'journal' } }],
        undo: async () => { if (prev) await st().commit({ journal: [prev] }); else await st().commit({}, { journal: [date] }); } };
    } },

  // ---------------------------------------------------------------- calendar & wellbeing
  { name: 'add_occasion', description: 'Add a personal occasion to the calendar (birthday, anniversary, event). Shown in calendar, notifications and widgets.',
    parameters: { type: 'object', properties: { title: { type: 'string' }, date: { type: 'string' }, yearly: { type: 'boolean' }, notify_time: { type: 'string', description: 'HH:MM, default 08:00' }, note: { type: 'string' }, official_holiday: { type: 'boolean' } }, required: ['title', 'date'] },
    run: async (a) => {
      const t0 = Date.now();
      const o: SpecialDate = { id: uid('sd'), date: dateArg(a.date), label: S(a.title), kind: 'special', emoji: 'sparkles', yearly: B(a.yearly, false), notify: true, notifyMin: a.notify_time ? timeArg(a.notify_time) : 480, note: S(a.note), official: B(a.official_holiday, false), createdAt: t0, updatedAt: t0 };
      await st().put('specialDates', o); await st().syncOccasions();
      return { ok: true, summary: `occasion "${o.label}" ${o.date}`, cards: [{ type: 'occasion', data: { title: o.label, date: o.date, yearly: o.yearly, note: o.note }, open: { screen: 'calendar' } }], undo: async () => { await removeIds('specialDates', [o.id]); await st().syncOccasions(); } };
    } },
  { name: 'log_water', description: 'Log water the user drank (ml).', parameters: { type: 'object', properties: { ml: { type: 'number' } }, required: ['ml'] },
    run: async (a) => {
      const ml = Math.round(N(a.ml, 250)); if (ml <= 0 || ml > 3000) return fail('ml must be 1–3000');
      const t0 = Date.now(); const rec = { id: uid('w'), date: todayKey(), ml, at: t0, createdAt: t0, updatedAt: t0 };
      await st().put('waterLogs', rec);
      const total = Object.values(st().data.waterLogs).filter((w) => w.date === todayKey()).reduce((x, w) => x + w.ml, 0);
      return { ok: true, summary: `+${ml} ml (today ${total})`, cards: [{ type: 'water', data: { added: ml, total, target: st().data.settings.app.water.targetMl }, open: { screen: 'wellness' } }], undo: async () => { await removeIds('waterLogs', [rec.id]); } };
    } },
  { name: 'mark_prayer', description: 'Record that the user prayed a prayer (fajr, dhuhr, asr, maghrib, isha).', parameters: { type: 'object', properties: { prayer: { type: 'string', enum: PRAYER_KEYS }, date: { type: 'string' } }, required: ['prayer'] },
    run: async (a) => {
      const p = S(a.prayer).toLowerCase() as typeof PRAYER_KEYS[number]; if (!PRAYER_KEYS.includes(p)) return fail('unknown prayer');
      const date = dateArg(a.date); const id = `${date}:${p}`; const t0 = Date.now();
      await st().put('prayerLogs', { id, date, prayer: p, prayedAt: t0, onTime: true, createdAt: t0, updatedAt: t0 });
      return { ok: true, summary: `${p} recorded`, cards: [{ type: 'prayer', data: { recorded: p, prayedToday: prayerStats(Object.values(st().data.prayerLogs)).today }, open: { screen: 'prayer' } }], undo: async () => { await removeIds('prayerLogs', [id]); } };
    } },
  { name: 'create_habit', description: 'Create a habit to track. kind: check | numeric | timed | avoid. frequency: daily | weekly | custom (with days).',
    parameters: { type: 'object', properties: { name: { type: 'string' }, kind: { type: 'string', enum: ['check', 'numeric', 'timed', 'avoid'] }, target: { type: 'number' }, unit: { type: 'string' }, frequency: { type: 'string', enum: ['daily', 'weekly', 'custom'] }, times_per_week: { type: 'number' }, days: { type: 'array', items: { type: 'string' } }, reminder_time: { type: 'string' } }, required: ['name'] },
    run: async (a) => {
      const t0 = Date.now(); const kind = S(a.kind, 'check') as Habit['kind'];
      const h: Habit = { id: uid('h'), name: S(a.name), icon: 'star', color: 'var(--c-rest)', category: 'personal', kind, frequency: S(a.frequency, 'daily') as Habit['frequency'], weekdays: daysArg(a.days).length ? daysArg(a.days) : [0, 1, 2, 3, 4, 5, 6],
        timesPerWeek: Math.max(1, Math.min(7, N(a.times_per_week, 3))), target: N(a.target, kind === 'avoid' ? 0 : 1), unit: S(a.unit), reminderMin: a.reminder_time ? timeArg(a.reminder_time) : undefined, notes: '', archived: false, createdAt: t0, updatedAt: t0 };
      await st().put('habits', h);
      return { ok: true, summary: `habit "${h.name}"`, cards: [{ type: 'habit', data: { name: h.name, kind: h.kind, target: h.target, unit: h.unit, frequency: h.frequency }, open: { screen: 'habits' } }], undo: async () => { await removeIds('habits', [h.id]); } };
    } },
  { name: 'log_habit', description: 'Log today’s value for a habit (find by name). For check habits value 1 = done.', parameters: { type: 'object', properties: { name: { type: 'string' }, id: { type: 'string' }, value: { type: 'number' } } },
    run: async (a) => {
      const d = st().data; const h = d.habits[S(a.id)] ?? Object.values(d.habits).find((x) => !x.archived && a.name && x.name.toLowerCase().includes(S(a.name).toLowerCase()));
      if (!h) return fail('habit not found');
      const today = todayKey(); const ex = Object.values(d.habitLogs).find((l) => l.habitId === h.id && l.date === today); const t0 = Date.now();
      const rec = ex ? { ...ex, value: N(a.value, 1), skipped: false, updatedAt: t0 } : { id: uid('hl'), habitId: h.id, date: today, value: N(a.value, 1), note: '', skipped: false, createdAt: t0, updatedAt: t0 };
      await st().put('habitLogs', rec);
      return { ok: true, summary: `${h.name}: ${rec.value}`, cards: [{ type: 'habit', data: { name: h.name, logged: rec.value, unit: h.unit }, open: { screen: 'habits' } }], undo: async () => { if (ex) await st().commit({ habitLogs: [ex] }); else await removeIds('habitLogs', [rec.id]); } };
    } },
  { name: 'create_goal', description: 'Create a goal. horizon: short | monthly | long.', parameters: { type: 'object', properties: { title: { type: 'string' }, description: { type: 'string' }, horizon: { type: 'string', enum: ['short', 'monthly', 'long'] }, target_date: { type: 'string' } }, required: ['title'] },
    run: async (a) => {
      const t0 = Date.now();
      const g: Goal = { id: uid('g'), title: S(a.title), description: S(a.description), horizon: S(a.horizon, 'monthly') as Goal['horizon'], targetDate: a.target_date ? dateArg(a.target_date) : undefined, metric: 'tasks', targetValue: 100, manualValue: 0, unit: '', habitIds: [], subjectIds: [], reviews: [], archived: false, createdAt: t0, updatedAt: t0 };
      await st().put('goals', g);
      return { ok: true, summary: `goal "${g.title}"`, cards: [{ type: 'goal', data: { title: g.title, horizon: g.horizon, targetDate: g.targetDate }, open: { screen: 'goals' } }], undo: async () => { await removeIds('goals', [g.id]); } };
    } },
  { name: 'start_focus', description: 'Start a focus timer. mode: pomodoro | extended | deep | open | countdown.', parameters: { type: 'object', properties: { mode: { type: 'string', enum: ['pomodoro', 'extended', 'deep', 'open', 'countdown'] }, minutes: { type: 'number', description: 'override for countdown' } } },
    run: async (a) => {
      const s = st().data.settings.app; const mode = S(a.mode, 'pomodoro') as 'pomodoro';
      const mins = a.minutes ? N(a.minutes, 25) : ({ pomodoro: s.focus.pomodoroWork, extended: s.focus.extendedWork, deep: s.focus.deepWork, countdown: s.focus.countdown, open: 0 } as Record<string, number>)[mode] ?? 25;
      const t0 = Date.now();
      await st().setFocusTimer({ id: 'focusTimer', running: true, mode, phase: 'work', phaseStartedAt: t0, phaseDurationMs: mins * 60000, pausedAt: null, pausedTotalMs: 0, cycle: 1, checklist: [], note: '', distractions: 0, createdAt: t0, updatedAt: t0 });
      return { ok: true, summary: `focus ${mode} ${mins || '∞'} min`, cards: [{ type: 'focus', data: { mode, minutes: mins }, open: { tab: 'focus' } }], undo: async () => { await st().setFocusTimer(null); } };
    } },

  // ---------------------------------------------------------------- app
  { name: 'change_settings', description: `Change app appearance/preferences. theme_id: ${THEMES.map((t) => t.id).join(', ')}. decor_preview: ${Object.keys(SEASONS).join(', ')} or "" for automatic.`,
    parameters: { type: 'object', properties: { theme_id: { type: 'string' }, theme_mode: { type: 'string', enum: ['system', 'light', 'dark'] }, decor: { type: 'string', enum: ['off', 'light', 'full'] }, decor_preview: { type: 'string' }, decor_speed: { type: 'number', description: '0.4–2.5' }, decor_opacity: { type: 'number', description: '0.2–1' }, language: { type: 'string', enum: ['ar', 'en'] }, clock_24: { type: 'boolean' }, water_target_ml: { type: 'number' }, user_name: { type: 'string' } } },
    run: async (a) => {
      const s = st().data.settings.app; const patch: Partial<Settings> = {};
      if (a.theme_id) { if (!THEMES.some((t) => t.id === a.theme_id)) return fail('unknown theme'); patch.themeId = S(a.theme_id); }
      if (a.theme_mode) patch.theme = S(a.theme_mode) as Settings['theme'];
      if (a.decor) patch.decor = S(a.decor) as Settings['decor'];
      if (a.decor_preview != null) patch.decorPreview = SEASONS[S(a.decor_preview)] ? S(a.decor_preview) : '';
      if (a.decor_speed) patch.decorSpeed = Math.max(0.4, Math.min(2.5, N(a.decor_speed, 1)));
      if (a.decor_opacity) patch.decorOpacity = Math.max(0.2, Math.min(1, N(a.decor_opacity, 0.7)));
      if (a.language) patch.language = S(a.language) as Settings['language'];
      if (a.clock_24 != null) patch.clock24 = B(a.clock_24, true);
      if (a.water_target_ml) patch.water = { ...s.water, targetMl: Math.max(250, Math.min(8000, N(a.water_target_ml, 2500))) };
      if (a.user_name != null) patch.userName = S(a.user_name);
      if (!Object.keys(patch).length) return fail('nothing to change');
      const prev = Object.fromEntries(Object.keys(patch).map((k) => [k, (s as unknown as Record<string, unknown>)[k]])) as Partial<Settings>;
      await st().updateSettings(patch);
      return { ok: true, summary: `settings: ${Object.keys(patch).join(', ')}`, cards: [{ type: 'settings', data: patch }], undo: async () => { await st().updateSettings(prev); } };
    } },
  { name: 'open_screen', readOnly: true, description: 'Open a screen of the app for the user.',
    parameters: { type: 'object', properties: { screen: { type: 'string', enum: ['today', 'plan', 'focus', 'progress', 'calendar', 'alarms', 'prayer', 'journal', 'tasks', 'notes', 'habits', 'goals', 'wellness', 'study', 'workouts', 'settings', 'themes', 'decor', 'assistant_providers'] } }, required: ['screen'] },
    run: async (a) => {
      const sc = S(a.screen); const tabs: Tab[] = ['today', 'plan', 'focus', 'progress'];
      setTimeout(() => { if (tabs.includes(sc as Tab)) useUI.getState().setTab(sc as Tab); else { useUI.getState().setTab('more'); useUI.getState().push((sc === 'assistant_providers' ? 'ai_providers' : sc) as Screen); } }, 600);
      return { ok: true, summary: `opening ${sc}` };
    } },
];

export const toolByName = (n: string) => TOOLS.find((t) => t.name === n);
export const toolSchemas = (): ChatTool[] => TOOLS.map(({ name, description, parameters }) => ({ name, description, parameters }));
export function needsConfirmation(name: string, mode: Settings['ai']['execution']): boolean {
  const t = toolByName(name);
  if (!t || t.readOnly) return false;
  return mode === 'confirm_all' || (mode === 'confirm_destructive' && !!t.destructive);
}
export const minutesToHHMM = minToInput;
export const hhmmToMinutes = inputToMin;
