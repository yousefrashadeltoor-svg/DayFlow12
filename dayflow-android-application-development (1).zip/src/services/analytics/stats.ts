/**
 * Analytics computed exclusively from stored records. Nothing is estimated or fabricated:
 * when data is insufficient, functions return `null` / `insufficient` so the UI can say so.
 */
import type { ActivityBlock, Collections, DateKey, Habit, HabitLog, Settings } from '@/models/types';
import { creditedMinutes, summarizeDay, trackedMinutes, type DaySummary } from '@/services/scheduling/engine';
import { addDays, diffDays, rangeKeys, startOfWeek, todayKey, weekday, nowMinutes } from '@/utils/date';

export interface DayStat extends DaySummary {
  date: DateKey;
  byCategory: Record<string, { planned: number; credited: number }>;
  studyMin: number; exerciseMin: number; restMin: number; productiveMin: number; unallocatedMin: number;
}

export function indexByDate(data: Collections): Map<DateKey, ActivityBlock[]> {
  const m = new Map<DateKey, ActivityBlock[]>();
  for (const b of Object.values(data.activities)) (m.get(b.date) ?? m.set(b.date, []).get(b.date)!).push(b);
  return m;
}

export function dayStat(data: Collections, date: DateKey, idx?: Map<DateKey, ActivityBlock[]>, filter?: { categoryId?: string; projectId?: string }): DayStat {
  const s = data.settings.app;
  const today = todayKey();
  let blocks = (idx?.get(date) ?? Object.values(data.activities).filter((b) => b.date === date));
  if (filter?.categoryId) blocks = blocks.filter((b) => b.categoryId === filter.categoryId);
  if (filter?.projectId) blocks = blocks.filter((b) => b.projectId === filter.projectId);
  const sum = summarizeDay(blocks, { isToday: date === today, isPast: date < today, nowMin: nowMinutes(), dayEndMin: s.dayEndMin });
  const byCategory: DayStat['byCategory'] = {};
  let studyMin = 0, exerciseMin = 0, restMin = 0, productiveMin = 0;
  for (const b of blocks) {
    if (b.status === 'cancelled') continue;
    const c = (byCategory[b.categoryId] ??= { planned: 0, credited: 0 });
    const cr = creditedMinutes(b);
    c.planned += b.durationMin; c.credited += cr;
    const key = data.categories[b.categoryId]?.key;
    if (key === 'study') studyMin += cr;
    if (key === 'exercise') exerciseMin += cr;
    if (key === 'rest') restMin += cr;
    if (data.categories[b.categoryId]?.productive) productiveMin += cr;
  }
  const window = Math.max(0, s.dayEndMin - s.dayStartMin);
  return { ...sum, date, byCategory, studyMin, exerciseMin, restMin, productiveMin, unallocatedMin: Math.max(0, window - sum.plannedMin) };
}

export function rangeStats(data: Collections, from: DateKey, days: number, filter?: { categoryId?: string; projectId?: string }): DayStat[] {
  const idx = indexByDate(data);
  return rangeKeys(from, days).map((d) => dayStat(data, d, idx, filter));
}

export function reschedules(data: Collections, from: DateKey, to: DateKey): number {
  return Object.values(data.scheduleChanges).filter((c) => c.date >= from && c.date <= to && !c.reverted && c.kind !== 'template').length
    + Object.values(data.activities).filter((b) => b.date >= from && b.date <= to).reduce((a, b) => a + (b.snoozeCount ?? 0), 0);
}

// ---------------------------------------------------------------- habits

export function habitScheduledOn(h: Habit, date: DateKey): boolean {
  if (h.pausedUntil && date <= h.pausedUntil) return false;
  if (date < new Date(h.createdAt).toISOString().slice(0, 10) && date < todayKey()) {
    // dates before creation are not scheduled (compare local date of createdAt)
    const c = new Date(h.createdAt); const ck = `${c.getFullYear()}-${String(c.getMonth() + 1).padStart(2, '0')}-${String(c.getDate()).padStart(2, '0')}`;
    if (date < ck) return false;
  }
  if (h.frequency === 'custom') return h.weekdays.includes(weekday(date));
  return true;
}
export function habitDoneValue(h: Habit, log: HabitLog | undefined): 'done' | 'missed' | 'skipped' | 'none' {
  if (log?.skipped) return 'skipped';
  if (h.kind === 'avoid') return log ? (log.value <= h.target ? 'done' : 'missed') : 'none';
  if (!log) return 'none';
  return log.value >= Math.max(1, h.target) ? 'done' : 'missed';
}

export interface HabitStats { current: number; longest: number; rate: number | null; done: number; scheduled: number; heat: { date: DateKey; level: number }[]; weekCount: number; }

export function habitStats(h: Habit, logs: HabitLog[], weekStart: number, days = 30): HabitStats {
  const byDate = new Map(logs.filter((l) => l.habitId === h.id).map((l) => [l.date, l]));
  const today = todayKey();
  if (h.frequency === 'weekly') {
    let current = 0, longest = 0, run = 0;
    const thisWeek = startOfWeek(today, weekStart);
    const count = (ws: DateKey) => rangeKeys(ws, 7).filter((d) => d <= today && habitDoneValue(h, byDate.get(d)) === 'done').length;
    for (let w = 25; w >= 0; w--) {
      const ws = addDays(thisWeek, -7 * w);
      const ok = count(ws) >= h.timesPerWeek;
      if (ok) { run++; longest = Math.max(longest, run); } else if (w !== 0) run = 0;
    }
    current = run;
    const weekCount = count(thisWeek);
    const heat = rangeKeys(addDays(today, -34), 35).map((d) => ({ date: d, level: habitDoneValue(h, byDate.get(d)) === 'done' ? 3 : 0 }));
    const scheduledW = 4, doneW = [1, 2, 3, 4].filter((i) => count(addDays(thisWeek, -7 * i)) >= h.timesPerWeek).length;
    return { current, longest, rate: Math.round((doneW / scheduledW) * 100), done: doneW, scheduled: scheduledW, heat, weekCount };
  }
  // daily / custom
  let current = 0, longest = 0, run = 0, done = 0, scheduled = 0;
  const start = addDays(today, -365);
  let firstLogged: DateKey | null = null;
  for (const l of byDate.keys()) if (!firstLogged || l < firstLogged) firstLogged = l;
  const begin = firstLogged && firstLogged > start ? firstLogged : start;
  for (let d = begin; d <= today; d = addDays(d, 1)) {
    if (!habitScheduledOn(h, d)) continue;
    const st = habitDoneValue(h, byDate.get(d));
    if (st === 'skipped') continue; // rest days never break a streak
    if (st === 'done') { run++; longest = Math.max(longest, run); }
    else if (d !== today) run = 0; // today not done yet does not break the streak
    if (diffDays(d, today) < days) { if (st === 'done') done++; if (d !== today || st === 'done') scheduled++; }
  }
  current = run;
  const heat = rangeKeys(addDays(today, -34), 35).map((d) => {
    const log = byDate.get(d);
    const st = habitDoneValue(h, log);
    let level = 0;
    if (st === 'done') level = h.kind === 'numeric' || h.kind === 'timed' ? Math.min(3, 1 + Math.floor(((log?.value ?? 0) / Math.max(1, h.target)) * 2)) : 3;
    else if (st === 'missed' && log) level = 1;
    return { date: d, level };
  });
  return { current, longest, rate: scheduled ? Math.round((done / scheduled) * 100) : null, done, scheduled, heat, weekCount: 0 };
}

// ---------------------------------------------------------------- insights

export interface Insight { key: string; value: string; confidence: number; samples: number; from: DateKey; to: DateKey; }
export interface InsightResult { insufficient: boolean; observations: number; required: number; insights: Insight[]; }

export function computeInsights(data: Collections, s: Settings, labelCat: (id: string) => string, fmtHour: (h: number) => string): InsightResult {
  const to = todayKey(), from = addDays(to, -42);
  const closed = Object.values(data.activities).filter((b) => b.date >= from && b.date < to && b.status !== 'cancelled');
  const required = s.insightsMinObservations;
  if (closed.length < required) return { insufficient: true, observations: closed.length, required, insights: [] };
  const conf = (n: number) => Math.min(0.95, Math.round((n / (required * 4)) * 100) / 100);
  const insights: Insight[] = [];

  const byHour = new Map<number, { n: number; done: number }>();
  for (const b of closed) {
    const h = Math.floor(b.startMin / 60);
    const e = byHour.get(h) ?? { n: 0, done: 0 };
    e.n++; if (b.status === 'completed') e.done++;
    byHour.set(h, e);
  }
  const bestHour = [...byHour.entries()].filter(([, v]) => v.n >= 3).sort((a, b) => b[1].done / b[1].n - a[1].done / a[1].n || b[1].n - a[1].n)[0];
  if (bestHour) insights.push({ key: 'ins_best_hour', value: `${fmtHour(bestHour[0])} (${Math.round((bestHour[1].done / bestHour[1].n) * 100)}%)`, confidence: conf(bestHour[1].n), samples: bestHour[1].n, from, to });

  const delayByCat = new Map<string, number>();
  for (const b of closed) {
    const delays = (b.snoozeCount ?? 0) + b.events.filter((e) => e.action === 'RESCHEDULED').length + (b.actualStart && b.actualStart - new Date(`${b.date}T00:00:00`).getTime() - b.startMin * 60000 > 10 * 60000 ? 1 : 0);
    if (delays) delayByCat.set(b.categoryId, (delayByCat.get(b.categoryId) ?? 0) + delays);
  }
  const worstDelay = [...delayByCat.entries()].sort((a, b) => b[1] - a[1])[0];
  if (worstDelay && worstDelay[1] >= 3) insights.push({ key: 'ins_delayed_cat', value: labelCat(worstDelay[0]), confidence: conf(worstDelay[1]), samples: worstDelay[1], from, to });

  const ratioByCat = new Map<string, { p: number; c: number; n: number }>();
  for (const b of closed) { const e = ratioByCat.get(b.categoryId) ?? { p: 0, c: 0, n: 0 }; e.p += b.durationMin; e.c += creditedMinutes(b); e.n++; ratioByCat.set(b.categoryId, e); }
  const lowCat = [...ratioByCat.entries()].filter(([, v]) => v.n >= 4).sort((a, b) => a[1].c / a[1].p - b[1].c / b[1].p)[0];
  if (lowCat && lowCat[1].c / lowCat[1].p < 0.6) insights.push({ key: 'ins_low_cat', value: `${labelCat(lowCat[0])} (${Math.round((lowCat[1].c / lowCat[1].p) * 100)}%)`, confidence: conf(lowCat[1].n), samples: lowCat[1].n, from, to });

  const resByTitle = new Map<string, number>();
  for (const b of closed) { const n = (b.snoozeCount ?? 0) + b.events.filter((e) => e.action === 'RESCHEDULED').length; if (n) resByTitle.set(b.title, (resByTitle.get(b.title) ?? 0) + n); }
  const mostRes = [...resByTitle.entries()].sort((a, b) => b[1] - a[1])[0];
  if (mostRes && mostRes[1] >= 2) insights.push({ key: 'ins_rescheduled', value: `${mostRes[0]} (×${mostRes[1]})`, confidence: conf(mostRes[1]), samples: mostRes[1], from, to });

  const timed = closed.filter((b) => b.status === 'completed' && b.actualStart && b.actualEnd && b.actualEnd - b.actualStart > 60000 && b.events.some((e) => e.action === 'START'));
  if (timed.length >= 5) {
    const ratio = timed.reduce((a, b) => a + trackedMinutes(b) / b.durationMin, 0) / timed.length;
    insights.push({ key: 'ins_estimate', value: String(Math.round(ratio * 100)), confidence: conf(timed.length), samples: timed.length, from, to });
  }
  const fs = Object.values(data.focusSessions).filter((f) => f.date >= from && f.phase === 'work');
  if (fs.length >= 5) insights.push({ key: 'ins_avg_completion', value: String(Math.round((fs.filter((f) => f.completed).length / fs.length) * 100)), confidence: conf(fs.length), samples: fs.length, from, to });

  const ratings = Object.values(data.ratings).filter((r) => r.date >= from);
  if (ratings.length >= required) {
    const byH = new Map<number, number[]>();
    for (const r of ratings) byH.set(r.hour, [...(byH.get(r.hour) ?? []), r.energy]);
    const peak = [...byH.entries()].filter(([, v]) => v.length >= 2).map(([h, v]) => [h, v.reduce((a, b) => a + b, 0) / v.length] as const).sort((a, b) => b[1] - a[1])[0];
    if (peak) insights.push({ key: 'ins_energy_peak', value: fmtHour(peak[0]), confidence: conf(ratings.length), samples: ratings.length, from, to });
  }
  return { insufficient: false, observations: closed.length, required, insights };
}

// ---------------------------------------------------------------- burnout awareness

export interface BurnoutSignal { key: 'bo_workload' | 'bo_recovery' | 'bo_postponed' | 'bo_energy'; params: Record<string, string | number>; }
export function burnoutSignals(data: Collections, s: Settings): BurnoutSignal[] {
  if (!s.burnout.enabled) return [];
  const to = todayKey(), from = addDays(to, -s.burnout.lookbackDays);
  const idx = indexByDate(data);
  const out: BurnoutSignal[] = [];
  let heavy = 0;
  for (const d of rangeKeys(from, s.burnout.lookbackDays)) {
    const work = (idx.get(d) ?? []).filter((b) => data.categories[b.categoryId]?.productive && b.status !== 'cancelled').reduce((a, b) => a + b.durationMin, 0);
    if (work > s.burnout.maxDailyWorkMin) heavy++;
  }
  if (heavy >= Math.ceil(s.burnout.lookbackDays / 2)) out.push({ key: 'bo_workload', params: { n: heavy, m: s.burnout.lookbackDays } });
  const skippedRest = Object.values(data.activities).filter((b) => b.date >= from && b.date <= to && data.categories[b.categoryId]?.key === 'rest' && (b.status === 'skipped' || b.status === 'missed')).length;
  if (skippedRest >= 3) out.push({ key: 'bo_recovery', params: { n: skippedRest } });
  const postponed = Object.values(data.activities).filter((b) => b.date >= from && ((b.snoozeCount ?? 0) + b.events.filter((e) => e.action === 'RESCHEDULED').length) >= s.burnout.postponeThreshold).length;
  if (postponed >= 2) out.push({ key: 'bo_postponed', params: { n: postponed } });
  const ratings = Object.values(data.ratings).filter((r) => r.date >= from);
  if (ratings.length >= 3) {
    const avg = ratings.reduce((a, r) => a + r.energy, 0) / ratings.length;
    if (avg <= s.burnout.lowEnergyThreshold) out.push({ key: 'bo_energy', params: { x: avg.toFixed(1) } });
  }
  return out;
}

// ---------------------------------------------------------------- weekly report

export interface WeeklyReport {
  from: DateKey; to: DateKey; days: DayStat[];
  completedPriorities: ActivityBlock[]; missed: ActivityBlock[];
  habits: { habit: Habit; rate: number | null }[];
  studyMin: number; studyPrevMin: number; workoutsDone: number; workoutsPlanned: number;
  accuracy: number | null; deadlines: { title: string; date: DateKey }[];
  avgCompletion: number;
}

export function weeklyReport(data: Collections, s: Settings, weekStartKey: DateKey): WeeklyReport {
  const days = rangeStats(data, weekStartKey, 7);
  const to = addDays(weekStartKey, 6);
  const inWeek = Object.values(data.activities).filter((b) => b.date >= weekStartKey && b.date <= to);
  const completedPriorities = inWeek.filter((b) => b.status === 'completed' && b.priority >= 4).sort((a, b) => b.priority - a.priority).slice(0, 8);
  const missed = inWeek.filter((b) => b.status === 'missed' || b.status === 'skipped').slice(0, 8);
  const logs = Object.values(data.habitLogs);
  const habits = Object.values(data.habits).filter((h) => !h.archived).map((h) => ({ habit: h, rate: habitStats(h, logs, s.weekStart, 7).rate })).sort((a, b) => (b.rate ?? -1) - (a.rate ?? -1)).slice(0, 5);
  const studyMin = Object.values(data.studySessions).filter((x) => x.date >= weekStartKey && x.date <= to).reduce((a, x) => a + x.minutes, 0);
  const prevFrom = addDays(weekStartKey, -7), prevTo = addDays(weekStartKey, -1);
  const studyPrevMin = Object.values(data.studySessions).filter((x) => x.date >= prevFrom && x.date <= prevTo).reduce((a, x) => a + x.minutes, 0);
  const workoutsDone = Object.values(data.workoutLogs).filter((w) => w.date >= weekStartKey && w.date <= to && w.status === 'completed').length;
  const workoutsPlanned = Object.values(data.workoutPlans).reduce((a, p) => a + p.weekdays.length, 0);
  const startedOnTime = inWeek.filter((b) => b.actualStart);
  const accuracy = startedOnTime.length >= 3
    ? Math.round((startedOnTime.filter((b) => Math.abs(b.actualStart! - new Date(`${b.date}T00:00:00`).getTime() - b.startMin * 60000) <= 10 * 60000).length / startedOnTime.length) * 100)
    : null;
  const horizon = addDays(to, 14);
  const deadlines = [
    ...Object.values(data.tasks).filter((t) => t.dueDate && t.dueDate > to && t.dueDate <= horizon && t.status !== 'done').map((t) => ({ title: t.title, date: t.dueDate! })),
    ...Object.values(data.exams).filter((e) => e.date > to && e.date <= horizon).map((e) => ({ title: e.name, date: e.date })),
    ...Object.values(data.projects).filter((p) => p.deadline && p.deadline > to && p.deadline <= horizon && !p.archived).map((p) => ({ title: p.title, date: p.deadline! })),
  ].sort((a, b) => a.date.localeCompare(b.date));
  const withPlan = days.filter((d) => d.plannedMin > 0);
  const avgCompletion = withPlan.length ? Math.round(withPlan.reduce((a, d) => a + d.completionPct, 0) / withPlan.length) : 0;
  return { from: weekStartKey, to, days, completedPriorities, missed, habits, studyMin, studyPrevMin, workoutsDone, workoutsPlanned, accuracy, deadlines, avgCompletion };
}

export function statsToCsvRows(days: DayStat[], catName: (id: string) => string): string[][] {
  const cats = [...new Set(days.flatMap((d) => Object.keys(d.byCategory)))];
  return [
    ['date', 'planned_min', 'credited_min', 'tracked_min', 'completion_pct', 'completed', 'missed', 'skipped', 'pending', ...cats.map((c) => `cat_${catName(c)}_min`)],
    ...days.map((d) => [d.date, String(d.plannedMin), String(Math.round(d.creditedMin)), String(Math.round(d.trackedMin)), String(d.completionPct), String(d.completed), String(d.missed), String(d.skipped), String(d.pending),
      ...cats.map((c) => String(Math.round(d.byCategory[c]?.credited ?? 0)))]),
  ];
}
