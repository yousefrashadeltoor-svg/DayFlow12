/**
 * CSV / XLSX import & export with validation, column mapping, duplicate and overlap detection.
 * XLSX uses the locally bundled SheetJS library loaded on demand.
 */
import type { ActivityBlock, Collections, DateKey, Habit, StudyLesson, Task, WorkoutPlan } from '@/models/types';
import { isValidDateKey, parseTime, todayKey } from '@/utils/date';

export type ImportTarget = 'activities' | 'tasks' | 'study' | 'exercises' | 'habits';

export const TARGET_FIELDS: Record<ImportTarget, { key: string; required: boolean; synonyms: string[] }[]> = {
  activities: [
    { key: 'date', required: false, synonyms: ['date', 'day', 'التاريخ', 'اليوم'] },
    { key: 'start', required: true, synonyms: ['start', 'start time', 'from', 'begin', 'البداية', 'البدء', 'من', 'وقت البدء'] },
    { key: 'end', required: false, synonyms: ['end', 'end time', 'to', 'finish', 'النهاية', 'الانتهاء', 'إلى'] },
    { key: 'duration', required: false, synonyms: ['duration', 'minutes', 'mins', 'المدة', 'دقائق'] },
    { key: 'title', required: true, synonyms: ['title', 'activity', 'name', 'task', 'العنوان', 'النشاط', 'الاسم'] },
    { key: 'category', required: false, synonyms: ['category', 'type', 'الفئة', 'النوع', 'التصنيف'] },
    { key: 'fixed', required: false, synonyms: ['fixed', 'locked', 'ثابت'] },
    { key: 'priority', required: false, synonyms: ['priority', 'الأولوية'] },
    { key: 'notes', required: false, synonyms: ['notes', 'note', 'description', 'ملاحظات', 'الوصف'] },
  ],
  tasks: [
    { key: 'title', required: true, synonyms: ['title', 'task', 'name', 'العنوان', 'المهمة'] },
    { key: 'due', required: false, synonyms: ['due', 'due date', 'deadline', 'الاستحقاق', 'الموعد'] },
    { key: 'priority', required: false, synonyms: ['priority', 'الأولوية'] },
    { key: 'estimate', required: false, synonyms: ['estimate', 'minutes', 'duration', 'التقدير', 'المدة'] },
    { key: 'tags', required: false, synonyms: ['tags', 'labels', 'وسوم'] },
    { key: 'notes', required: false, synonyms: ['notes', 'description', 'ملاحظات'] },
  ],
  study: [
    { key: 'subject', required: true, synonyms: ['subject', 'course', 'المادة'] },
    { key: 'unit', required: false, synonyms: ['unit', 'chapter', 'الوحدة', 'الفصل'] },
    { key: 'lesson', required: true, synonyms: ['lesson', 'topic', 'title', 'الدرس', 'الموضوع'] },
    { key: 'hours', required: false, synonyms: ['hours', 'estimate', 'الساعات'] },
    { key: 'due', required: false, synonyms: ['due', 'date', 'الموعد', 'التاريخ'] },
  ],
  exercises: [
    { key: 'plan', required: true, synonyms: ['plan', 'session', 'workout', 'الخطة', 'الجلسة'] },
    { key: 'days', required: false, synonyms: ['days', 'weekday', 'day', 'الأيام', 'اليوم'] },
    { key: 'exercise', required: true, synonyms: ['exercise', 'name', 'التمرين'] },
    { key: 'sets', required: false, synonyms: ['sets', 'المجموعات'] },
    { key: 'reps', required: false, synonyms: ['reps', 'repetitions', 'التكرارات'] },
    { key: 'rest', required: false, synonyms: ['rest', 'rest sec', 'الراحة'] },
  ],
  habits: [
    { key: 'name', required: true, synonyms: ['name', 'habit', 'title', 'العادة', 'الاسم'] },
    { key: 'kind', required: false, synonyms: ['kind', 'type', 'النوع'] },
    { key: 'target', required: false, synonyms: ['target', 'goal', 'الهدف'] },
    { key: 'unit', required: false, synonyms: ['unit', 'الوحدة'] },
  ],
};

/** RFC4180-style parser supporting quotes, escaped quotes, CRLF, BOM and ; or tab delimiters. */
export function parseCSV(text: string): string[][] {
  const src = text.replace(/^\uFEFF/, '');
  const firstLine = src.split(/\r?\n/)[0] ?? '';
  const delim = [',', ';', '\t'].map((d) => [d, firstLine.split(d).length] as const).sort((a, b) => b[1] - a[1])[0][0];
  const rows: string[][] = [];
  let row: string[] = [], field = '', inQ = false;
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (inQ) {
      if (c === '"') { if (src[i + 1] === '"') { field += '"'; i++; } else inQ = false; }
      else field += c;
    } else if (c === '"') inQ = true;
    else if (c === delim) { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && src[i + 1] === '\n') i++; row.push(field); rows.push(row); row = []; field = ''; }
    else field += c;
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((x) => x.trim() !== ''));
}

export function toCSV(rows: (string | number | null | undefined)[][]): string {
  const esc = (v: string | number | null | undefined) => { const s = v == null ? '' : String(v); return /[",\n\r;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return '\uFEFF' + rows.map((r) => r.map(esc).join(',')).join('\r\n');
}

export async function parseXLSX(base64: string): Promise<string[][]> {
  const XLSX = await import('xlsx');
  const wb = XLSX.read(base64, { type: 'base64', cellDates: false });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<(string | number)[]>(ws, { header: 1, raw: false, defval: '' });
  return rows.map((r) => r.map((c) => String(c ?? ''))).filter((r) => r.some((x) => x.trim() !== ''));
}
export async function toXLSXBase64(rows: (string | number)[][], sheet = 'Dayflow'): Promise<string> {
  const XLSX = await import('xlsx');
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), sheet);
  return XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });
}

export function autoMap(headers: string[], target: ImportTarget): Record<string, number> {
  const map: Record<string, number> = {};
  const norm = headers.map((h) => h.trim().toLowerCase());
  for (const f of TARGET_FIELDS[target]) {
    const idx = norm.findIndex((h) => f.synonyms.includes(h));
    if (idx >= 0) map[f.key] = idx;
  }
  return map;
}

export interface RowResult<T> { row: number; value?: T; errors: string[]; duplicate: boolean; overlap: boolean; }

const num = (s: string | undefined, d: number) => { const n = Number(String(s ?? '').replace(/[٠-٩]/g, (x) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(x))).trim()); return Number.isFinite(n) && String(s ?? '').trim() !== '' ? n : d; };
const normDate = (s: string | undefined): DateKey | null => {
  if (!s || !s.trim()) return null;
  const t = s.trim().replace(/[٠-٩]/g, (x) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(x)));
  if (isValidDateKey(t)) return t;
  const m = t.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/);
  if (m) { const k = `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; return isValidDateKey(k) ? k : null; }
  return null;
};
const truthy = (s?: string) => ['1', 'true', 'yes', 'y', 'نعم', 'ثابت', 'x'].includes(String(s ?? '').trim().toLowerCase());

export interface ActivityDraft { date: DateKey; startMin: number; durationMin: number; title: string; categoryKey: string; fixed: boolean; priority: number; notes: string; }

export function validateActivities(rows: string[][], map: Record<string, number>, data: Collections, defaultDate: DateKey): RowResult<ActivityDraft>[] {
  const get = (r: string[], k: string) => (map[k] != null ? r[map[k]] : undefined);
  const results: RowResult<ActivityDraft>[] = rows.map((r, i) => {
    const errors: string[] = [];
    const title = (get(r, 'title') ?? '').trim();
    if (!title) errors.push('err_missing_title');
    const rawDate = get(r, 'date');
    const date = rawDate && rawDate.trim() ? normDate(rawDate) : defaultDate;
    if (!date) errors.push('err_date');
    const start = parseTime(get(r, 'start') ?? '');
    if (start == null) errors.push('err_time');
    let duration = num(get(r, 'duration'), NaN);
    const endRaw = get(r, 'end');
    if (endRaw && endRaw.trim()) {
      const end = parseTime(endRaw);
      if (end == null) errors.push('err_time');
      else if (start != null) duration = end > start ? end - start : end + 1440 - start;
    }
    if (!Number.isFinite(duration)) duration = 30;
    if (duration <= 0 || duration > 1440) errors.push('err_negative');
    const catRaw = (get(r, 'category') ?? '').trim().toLowerCase();
    const cat = Object.values(data.categories).find((c) => [c.key, c.nameAr.toLowerCase(), c.nameEn.toLowerCase()].includes(catRaw));
    const value = errors.length ? undefined : { date: date!, startMin: start!, durationMin: duration, title, categoryKey: cat?.key ?? 'personal', fixed: truthy(get(r, 'fixed')), priority: Math.min(5, Math.max(1, num(get(r, 'priority'), 3))), notes: get(r, 'notes') ?? '' };
    return { row: i + 2, value, errors: [...new Set(errors)], duplicate: false, overlap: false };
  });
  const existing = Object.values(data.activities).filter((b) => b.status !== 'cancelled');
  const seen = new Set<string>();
  for (const r of results) {
    if (!r.value) continue;
    const v = r.value;
    const key = `${v.date}|${v.startMin}|${v.title.toLowerCase()}`;
    if (seen.has(key) || existing.some((b) => b.date === v.date && b.startMin === v.startMin && b.title.toLowerCase() === v.title.toLowerCase())) r.duplicate = true;
    seen.add(key);
    const end = v.startMin + v.durationMin;
    r.overlap = existing.some((b) => b.date === v.date && b.startMin < end && v.startMin < b.startMin + b.durationMin)
      || results.some((o) => o !== r && o.value && o.value.date === v.date && o.value.startMin < end && v.startMin < o.value.startMin + o.value.durationMin);
  }
  return results;
}

export function validateTasks(rows: string[][], map: Record<string, number>, data: Collections): RowResult<Partial<Task>>[] {
  const get = (r: string[], k: string) => (map[k] != null ? r[map[k]] : undefined);
  const seen = new Set<string>();
  return rows.map((r, i) => {
    const errors: string[] = [];
    const title = (get(r, 'title') ?? '').trim();
    if (!title) errors.push('err_missing_title');
    const dueRaw = get(r, 'due');
    const due = dueRaw && dueRaw.trim() ? normDate(dueRaw) : undefined;
    if (dueRaw && dueRaw.trim() && !due) errors.push('err_date');
    const est = num(get(r, 'estimate'), 30);
    if (est < 0) errors.push('err_negative');
    const key = `${title.toLowerCase()}|${due ?? ''}`;
    const duplicate = seen.has(key) || Object.values(data.tasks).some((t) => t.title.toLowerCase() === title.toLowerCase() && (t.dueDate ?? '') === (due ?? ''));
    seen.add(key);
    return { row: i + 2, errors, duplicate, overlap: false, value: errors.length ? undefined : {
      title, dueDate: due ?? undefined, priority: Math.min(5, Math.max(1, num(get(r, 'priority'), 3))), estimateMin: est,
      tags: (get(r, 'tags') ?? '').split(/[|,،]/).map((x) => x.trim()).filter(Boolean), notes: get(r, 'notes') ?? '' } };
  });
}

export interface StudyDraft { subject: string; unit: string; lesson: string; hours: number; due?: DateKey; }
export function validateStudy(rows: string[][], map: Record<string, number>, data: Collections): RowResult<StudyDraft>[] {
  const get = (r: string[], k: string) => (map[k] != null ? r[map[k]] : undefined);
  return rows.map((r, i) => {
    const errors: string[] = [];
    const subject = (get(r, 'subject') ?? '').trim(), lesson = (get(r, 'lesson') ?? '').trim();
    if (!subject || !lesson) errors.push('err_missing_title');
    const dueRaw = get(r, 'due'); const due = dueRaw && dueRaw.trim() ? normDate(dueRaw) : undefined;
    if (dueRaw && dueRaw.trim() && !due) errors.push('err_date');
    const hours = num(get(r, 'hours'), 1);
    if (hours < 0) errors.push('err_negative');
    const duplicate = Object.values(data.lessons).some((l: StudyLesson) => l.title.toLowerCase() === lesson.toLowerCase() && data.subjects[l.subjectId]?.title.toLowerCase() === subject.toLowerCase());
    return { row: i + 2, errors, duplicate, overlap: false, value: errors.length ? undefined : { subject, unit: (get(r, 'unit') ?? '').trim() || subject, lesson, hours, due: due ?? undefined } };
  });
}

export interface ExerciseDraft { plan: string; days: number[]; exercise: string; sets: number; reps: number; rest: number; }
const DAY_NAMES: Record<string, number> = { sun: 0, sunday: 0, 'الأحد': 0, mon: 1, monday: 1, 'الاثنين': 1, tue: 2, tuesday: 2, 'الثلاثاء': 2, wed: 3, wednesday: 3, 'الأربعاء': 3, thu: 4, thursday: 4, 'الخميس': 4, fri: 5, friday: 5, 'الجمعة': 5, sat: 6, saturday: 6, 'السبت': 6 };
export function validateExercises(rows: string[][], map: Record<string, number>, data: Collections): RowResult<ExerciseDraft>[] {
  const get = (r: string[], k: string) => (map[k] != null ? r[map[k]] : undefined);
  return rows.map((r, i) => {
    const errors: string[] = [];
    const plan = (get(r, 'plan') ?? '').trim(), exercise = (get(r, 'exercise') ?? '').trim();
    if (!plan || !exercise) errors.push('err_missing_title');
    const days = (get(r, 'days') ?? '').split(/[|,،\s]+/).map((d) => DAY_NAMES[d.trim().toLowerCase()]).filter((d) => d != null);
    const sets = num(get(r, 'sets'), 3), reps = num(get(r, 'reps'), 10), rest = num(get(r, 'rest'), 60);
    if (sets <= 0 || reps <= 0 || rest < 0) errors.push('err_negative');
    const duplicate = Object.values(data.workoutPlans).some((p: WorkoutPlan) => p.name.toLowerCase() === plan.toLowerCase() && p.exercises.some((e) => data.exercises[e.exerciseId]?.name.toLowerCase() === exercise.toLowerCase()));
    return { row: i + 2, errors, duplicate, overlap: false, value: errors.length ? undefined : { plan, days, exercise, sets, reps, rest } };
  });
}

export function validateHabits(rows: string[][], map: Record<string, number>, data: Collections): RowResult<Partial<Habit>>[] {
  const get = (r: string[], k: string) => (map[k] != null ? r[map[k]] : undefined);
  return rows.map((r, i) => {
    const errors: string[] = [];
    const name = (get(r, 'name') ?? '').trim();
    if (!name) errors.push('err_missing_title');
    const kindRaw = (get(r, 'kind') ?? 'check').trim().toLowerCase();
    const kind = (['check', 'numeric', 'timed', 'avoid'].includes(kindRaw) ? kindRaw : 'check') as Habit['kind'];
    const target = num(get(r, 'target'), kind === 'avoid' ? 0 : 1);
    if (target < 0) errors.push('err_negative');
    const duplicate = Object.values(data.habits).some((h) => h.name.toLowerCase() === name.toLowerCase());
    return { row: i + 2, errors, duplicate, overlap: false, value: errors.length ? undefined : { name, kind, target, unit: get(r, 'unit') ?? '' } };
  });
}

export function activitiesToRows(blocks: ActivityBlock[], catName: (id: string) => string, fmt: (m: number) => string): string[][] {
  return [['date', 'start', 'end', 'duration', 'title', 'category', 'fixed', 'priority', 'status', 'notes'],
    ...blocks.sort((a, b) => a.date.localeCompare(b.date) || a.startMin - b.startMin).map((b) => [b.date, fmt(b.startMin), fmt(b.startMin + b.durationMin), String(b.durationMin), b.title, catName(b.categoryId), b.fixed ? 'yes' : 'no', String(b.priority), b.status, b.notes])];
}

export const sampleHeaders: Record<ImportTarget, string[]> = {
  activities: ['date', 'start', 'end', 'title', 'category', 'fixed', 'priority', 'notes'],
  tasks: ['title', 'due', 'priority', 'estimate', 'tags', 'notes'],
  study: ['subject', 'unit', 'lesson', 'hours', 'due'],
  exercises: ['plan', 'days', 'exercise', 'sets', 'reps', 'rest'],
  habits: ['name', 'kind', 'target', 'unit'],
};
export const defaultImportDate = () => todayKey();
