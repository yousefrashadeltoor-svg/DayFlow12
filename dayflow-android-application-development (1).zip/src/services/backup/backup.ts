/**
 * Versioned JSON backups with optional AES-GCM encryption (PBKDF2-SHA256, 250k iterations),
 * preview/diff, conflict detection and merge-or-replace restore. Uses WebCrypto only (offline).
 */
import { ALL_COLLECTIONS, type CollectionName, type Collections } from '@/models/types';
import { APP_SCHEMA_VERSION } from '@/services/database/db';

export const BACKUP_FORMAT = 'dayflow-backup';
export const BACKUP_SCHEMA = 1;

export interface BackupFile {
  format: typeof BACKUP_FORMAT;
  backupSchema: number;
  appSchema: number;
  appVersion: string;
  createdAt: number;
  collections: Partial<Record<CollectionName, unknown[]>>;
}
interface EncryptedFile { format: 'dayflow-backup-encrypted'; backupSchema: number; kdf: 'PBKDF2-SHA256'; iterations: number; salt: string; iv: string; data: string; }

const EXCLUDED: CollectionName[] = ['state'];

const b64 = (buf: ArrayBuffer | Uint8Array) => { const a = buf instanceof Uint8Array ? buf : new Uint8Array(buf); let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode(...a.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s: string) => { const bin = atob(s); const a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return a; };

async function deriveKey(password: string, salt: Uint8Array, iterations: number) {
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: salt as BufferSource, iterations, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

export function buildBackup(data: Collections): BackupFile {
  const collections: BackupFile['collections'] = {};
  for (const c of ALL_COLLECTIONS) if (!EXCLUDED.includes(c)) collections[c] = Object.values(data[c]);
  return { format: BACKUP_FORMAT, backupSchema: BACKUP_SCHEMA, appSchema: APP_SCHEMA_VERSION, appVersion: '1.0.0', createdAt: Date.now(), collections };
}
export const countRecords = (b: BackupFile) => Object.values(b.collections).reduce((a, arr) => a + (arr?.length ?? 0), 0);

export async function serializeBackup(b: BackupFile, password?: string): Promise<string> {
  const json = JSON.stringify(b);
  if (!password) return json;
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const iterations = 250_000;
  const key = await deriveKey(password, salt, iterations);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(json));
  const enc: EncryptedFile = { format: 'dayflow-backup-encrypted', backupSchema: BACKUP_SCHEMA, kdf: 'PBKDF2-SHA256', iterations, salt: b64(salt), iv: b64(iv), data: b64(ct) };
  return JSON.stringify(enc);
}

export type ParseResult = { ok: true; backup: BackupFile } | { ok: false; error: 'invalid' | 'needs_password' | 'wrong_password' | 'newer_schema' };

export function isEncrypted(text: string): boolean {
  try { return JSON.parse(text)?.format === 'dayflow-backup-encrypted'; } catch { return false; }
}

export async function parseBackup(text: string, password?: string): Promise<ParseResult> {
  let obj: unknown;
  try { obj = JSON.parse(text); } catch { return { ok: false, error: 'invalid' }; }
  if (!obj || typeof obj !== 'object') return { ok: false, error: 'invalid' };
  const o = obj as Record<string, unknown>;
  if (o.format === 'dayflow-backup-encrypted') {
    if (!password) return { ok: false, error: 'needs_password' };
    try {
      const key = await deriveKey(password, unb64(String(o.salt)), Number(o.iterations) || 250_000);
      const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(String(o.iv)) as BufferSource }, key, unb64(String(o.data)) as BufferSource);
      return parseBackup(new TextDecoder().decode(pt));
    } catch { return { ok: false, error: 'wrong_password' }; }
  }
  if (o.format !== BACKUP_FORMAT || typeof o.collections !== 'object' || !o.collections) return { ok: false, error: 'invalid' };
  if (Number(o.backupSchema) > BACKUP_SCHEMA) return { ok: false, error: 'newer_schema' };
  // Structural validation of every record: id + timestamps, known collections only.
  const clean: BackupFile['collections'] = {};
  for (const [col, arr] of Object.entries(o.collections as Record<string, unknown>)) {
    if (!ALL_COLLECTIONS.includes(col as CollectionName) || EXCLUDED.includes(col as CollectionName) || !Array.isArray(arr)) continue;
    clean[col as CollectionName] = arr.filter((r) => r && typeof r === 'object' && typeof (r as { id?: unknown }).id === 'string' && (r as { id: string }).id.length > 0)
      .map((r) => ({ createdAt: Date.now(), updatedAt: Date.now(), ...(r as object) }));
  }
  return { ok: true, backup: { ...(o as unknown as BackupFile), collections: clean } };
}

export interface BackupDiff { collection: CollectionName; incoming: number; added: number; conflicts: number; identical: number; }

export function diffBackup(current: Collections, b: BackupFile): BackupDiff[] {
  const out: BackupDiff[] = [];
  for (const [col, arr] of Object.entries(b.collections) as [CollectionName, { id: string; updatedAt: number }[]][]) {
    const cur = current[col] as Record<string, { updatedAt: number }>;
    let added = 0, conflicts = 0, identical = 0;
    for (const r of arr) {
      const ex = cur[r.id];
      if (!ex) added++;
      else if (JSON.stringify(ex) === JSON.stringify(r)) identical++;
      else conflicts++;
    }
    if (arr.length) out.push({ collection: col, incoming: arr.length, added, conflicts, identical });
  }
  return out;
}

/**
 * merge: new records added; for conflicts the more recently updated version wins (deterministic).
 * replace: every current record not in the backup is deleted, then all backup records are written.
 */
export function planRestore(current: Collections, b: BackupFile, mode: 'merge' | 'replace'): { puts: Partial<Record<CollectionName, { id: string }[]>>; dels: Partial<Record<CollectionName, string[]>> } {
  const puts: Partial<Record<CollectionName, { id: string }[]>> = {};
  const dels: Partial<Record<CollectionName, string[]>> = {};
  for (const col of ALL_COLLECTIONS) {
    if (EXCLUDED.includes(col)) continue;
    const incoming = (b.collections[col] ?? []) as { id: string; updatedAt: number }[];
    const cur = current[col] as Record<string, { updatedAt: number }>;
    if (mode === 'replace') {
      const keep = new Set(incoming.map((r) => r.id));
      const toDel = Object.keys(cur).filter((id) => !keep.has(id));
      if (toDel.length) dels[col] = toDel;
      if (incoming.length) puts[col] = incoming;
    } else {
      const chosen = incoming.filter((r) => !cur[r.id] || (r.updatedAt ?? 0) > (cur[r.id].updatedAt ?? 0));
      if (chosen.length) puts[col] = chosen;
    }
  }
  return { puts, dels };
}
