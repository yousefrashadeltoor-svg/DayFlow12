import { Capacitor, registerPlugin, type PluginListenerHandle } from '@capacitor/core';
import type { NotificationAction } from '@/models/types';

export type PermState = 'granted' | 'denied' | 'prompt' | 'disabled' | 'unsupported';

export interface AlarmPayload {
  kind: 'block' | 'task' | 'water' | 'sleep' | 'habit' | 'meal' | 'prayer' | 'review' | 'reminder' | 'occasion';
  title: string;
  body: string;
  blockId?: string;
  category?: string;
  localDate?: string;
  localMinute?: number;
  triggerAt?: number;
  absolute?: boolean;
  soundMode: 'custom' | 'tts' | 'tone' | 'system' | 'none';
  soundUri?: string;
  startMs?: number;
  endMs?: number;
  colorHex?: string;
  note?: string;
  nextLabel?: string;
  catName?: string;
  emoji?: string;
  official?: boolean;
  ttsText?: string;
  ttsLang?: string;
  vibrate: boolean;
  silent: boolean;
  volume: number;
  gradual: boolean;
  audioRepeat: number;
  repeatIntervalMin: number;
  maxRepeats: number;
  actions: NotificationAction[];
}
export interface DesiredAlarm { alarmKey: string; payload: AlarmPayload; }

export interface Capabilities {
  platform: 'android' | 'web';
  sdkInt?: number; release?: string; manufacturer?: string; model?: string;
  notificationPermission: PermState;
  exactAlarmRequiresPermission?: boolean;
  exactAlarmAllowed?: boolean;
  ignoringBatteryOptimizations?: boolean;
  powerSaveMode?: boolean;
  nativeDatabase: boolean;
  widgets: boolean;
  tts: boolean;
  customAudio: boolean;
  dbVersion?: number;
  lastAudioFallback?: string | null;
  fullScreenIntentAllowed?: boolean;
  alarmClockApi?: boolean;
}
export interface AlarmStatusEntry { alarmKey: string; kind: string; triggerAt: number; title: string; exact: boolean; state: string; blockId?: string; }
export interface AlarmStatus {
  pendingCount: number; next: AlarmStatusEntry | null; upcoming: AlarmStatusEntry[]; missedCount: number; deliveredCount: number;
  lastScheduleAt: number | null; lastSyncAt: number | null; lastRestoreAt: number | null; lastRestoreReason: string | null; lastRestoreCount: number;
  exactAllowed: boolean; recentActions: { alarmKey: string; blockId: string; action: string; result: string; handledAt: number }[];
}
export interface ImportedFile { name: string; size: number; mimeType: string; text?: string; base64?: string; path?: string; }

interface DayflowNativePlugin {
  initialize(): Promise<Capabilities>;
  getPlatformCapabilities(): Promise<Capabilities>;
  checkNotificationPermission(): Promise<{ state: PermState }>;
  requestNotificationPermission(): Promise<{ state: PermState; openedSettings?: boolean }>;
  checkExactAlarmPermission(): Promise<{ allowed: boolean; requiresPermission: boolean }>;
  requestExactAlarmPermission(): Promise<{ allowed: boolean; openedSettings?: boolean }>;
  scheduleBlockAlarm(o: DesiredAlarm): Promise<{ alarmKey: string; triggerAt: number; exact: boolean }>;
  scheduleReminder(o: DesiredAlarm): Promise<{ alarmKey: string; triggerAt: number; exact: boolean }>;
  cancelAlarm(o: { alarmKey: string }): Promise<{ cancelled: boolean }>;
  cancelBlockAlarms(o: { blockId: string }): Promise<{ cancelled: number }>;
  rescheduleUpcomingAlarms(o: { alarms: DesiredAlarm[] }): Promise<{ results: { alarmKey: string; ok: boolean; exact?: boolean; error?: string; triggerAt?: number }[]; cancelled: number; failures: number; exactAllowed: boolean; notificationPermission: PermState }>;
  getScheduledAlarmStatus(): Promise<AlarmStatus>;
  playCustomAlarmAudio(o: { path: string; volume?: number; startMs?: number; endMs?: number }): Promise<{ playing: boolean }>;
  pickRingtone(o: { type: 'ringtone' | 'alarm' | 'notification'; existingUri?: string }): Promise<{ uri: string | null; name: string; isDefault: boolean }>;
  pickMusic(): Promise<{ path: string; name: string; size: number; mimeType: string; durationMs: number }>;
  getAudioInfo(o: { path: string }): Promise<{ durationMs: number }>;
  configurePrayer(cfg: Record<string, unknown>): Promise<{ scheduled: number }>;
  canUseFullScreenIntent(): Promise<{ allowed: boolean }>;
  openFullScreenIntentSettings(): Promise<{ openedSettings: boolean }>;
  stopAlarmRinging(): Promise<{ stopped: boolean }>;
  stopAlarmAudio(): Promise<{ stopped: boolean }>;
  speakText(o: { text: string; lang: string }): Promise<{ spoken: boolean }>;
  createNotification(o: { id?: number; title: string; body?: string; silent?: boolean }): Promise<{ id: number; posted: boolean }>;
  updateNotification(o: { id: number; title: string; body?: string; silent?: boolean }): Promise<{ id: number; posted: boolean }>;
  registerNotificationActions(o: { language: string }): Promise<{ actions: string[] }>;
  handleNotificationAction(o: { action: NotificationAction; alarmKey?: string; blockId?: string }): Promise<{ result: string }>;
  getBatteryOptimizationStatus(): Promise<{ ignoring: boolean; powerSaveMode: boolean; manufacturer: string }>;
  requestBatterySettings(): Promise<{ openedSettings: boolean }>;
  openNotificationSettings(): Promise<{ openedSettings: boolean }>;
  getDeviceTimeZone(): Promise<{ timeZone: string; offsetMinutes: number }>;
  importNativeFile(o: { mode: 'text' | 'binary' | 'audio' | 'attachment'; mimeTypes?: string[] }): Promise<ImportedFile>;
  exportBackup(o: { fileName: string; content: string; mimeType: string; base64?: boolean }): Promise<{ uri: string; bytes: number }>;
  deleteAppFile(o: { path: string }): Promise<{ deleted: boolean }>;
  updateWidget(): Promise<{ installedWidgets: number }>;
  dbLoadAll(): Promise<{ collections: Record<string, unknown[]> }>;
  dbGetAll(o: { collection: string }): Promise<{ records: unknown[] }>;
  dbBatch(o: { ops: DbOp[] }): Promise<{ applied: number }>;
  setNativePreferences(o: { language?: string; theme?: string; clock24?: string; widgetLayout?: string; accent?: string; hijriAdjust?: string }): Promise<void>;
  consumeLaunchTarget(): Promise<{ blockId: string | null; screen: string | null }>;
  getAudioDiagnostics(): Promise<{ lastFallbackUsed: string | null }>;
  addListener(event: 'dataChanged' | 'openBlock' | 'openScreen', cb: (e: { at?: number; blockId?: string; screen?: string }) => void): Promise<PluginListenerHandle>;
}

export type DbOp = { op: 'put'; collection: string; record: unknown } | { op: 'delete'; collection: string; id: string } | { op: 'clear'; collection: string };

/** The real plugin. On the web there is intentionally no implementation: callers must check isNative. */
export const DayflowNative = registerPlugin<DayflowNativePlugin>('DayflowNative');

export const isNative = (): boolean => Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';

export class NativeUnavailableError extends Error {
  code = 'UNSUPPORTED';
  constructor() { super('This capability requires the Android app'); }
}

export function errorCode(e: unknown): string {
  if (e && typeof e === 'object' && 'code' in e) return String((e as { code: unknown }).code);
  return 'UNKNOWN';
}
export function errorMessage(e: unknown): string {
  if (e instanceof Error) return e.message;
  if (e && typeof e === 'object' && 'message' in e) return String((e as { message: unknown }).message);
  return String(e);
}

/** Web capability report — honest: no native alarms, widgets or notifications. */
export function webCapabilities(): Capabilities {
  return {
    platform: 'web',
    notificationPermission: 'unsupported',
    nativeDatabase: false,
    widgets: false,
    tts: typeof window !== 'undefined' && 'speechSynthesis' in window,
    customAudio: true,
  };
}

export async function getCapabilities(): Promise<Capabilities> {
  if (!isNative()) return webCapabilities();
  return DayflowNative.getPlatformCapabilities();
}

/** Haptic feedback via the Vibration API (works in the Android WebView). */
export function haptic(enabled: boolean, pattern: number | number[] = 10) {
  if (!enabled) return;
  try { navigator.vibrate?.(pattern); } catch { /* not available */ }
}

/** Speech: native TTS on Android, Web Speech API in the browser preview. Rejects honestly when unavailable. */
export async function speak(text: string, lang: string): Promise<void> {
  if (isNative()) { await DayflowNative.speakText({ text, lang }); return; }
  if (!('speechSynthesis' in window)) throw new NativeUnavailableError();
  await new Promise<void>((resolve, reject) => {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang === 'ar' ? 'ar-SA' : 'en-US';
    const voices = window.speechSynthesis.getVoices();
    if (voices.length && !voices.some((v) => v.lang.toLowerCase().startsWith(lang))) { reject(Object.assign(new Error('TTS_LANGUAGE_UNAVAILABLE'), { code: 'TTS_LANGUAGE_UNAVAILABLE' })); return; }
    u.onend = () => resolve();
    u.onerror = (ev) => reject(Object.assign(new Error(ev.error), { code: 'TTS_FAILED' }));
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  });
}

/** File picking: Android document picker natively, <input type=file> in the browser. */
export async function pickFile(mode: 'text' | 'binary' | 'audio' | 'attachment', accept: string, mimeTypes?: string[]): Promise<ImportedFile & { blobUrl?: string }> {
  if (isNative()) return DayflowNative.importNativeFile({ mode, mimeTypes });
  return new Promise((resolve, reject) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.onchange = async () => {
      const f = input.files?.[0];
      if (!f) { reject(Object.assign(new Error('User cancelled'), { code: 'CANCELLED' })); return; }
      if (f.size > 25 * 1024 * 1024) { reject(Object.assign(new Error('File is too large'), { code: 'INVALID_ARGUMENT' })); return; }
      try {
        if (mode === 'text') resolve({ name: f.name, size: f.size, mimeType: f.type, text: await f.text() });
        else {
          const buf = new Uint8Array(await f.arrayBuffer());
          let bin = '';
          for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
          const base64 = btoa(bin);
          resolve({ name: f.name, size: f.size, mimeType: f.type, base64, path: mode === 'binary' ? undefined : `data:${f.type || 'application/octet-stream'};base64,${base64}` });
        }
      } catch (e) { reject(e); }
    };
    input.click();
  });
}

/** Saves a file: Android "Create document" dialog natively, browser download otherwise. */
export async function saveFile(fileName: string, content: string, mimeType: string, base64 = false): Promise<void> {
  if (isNative()) { await DayflowNative.exportBackup({ fileName, content, mimeType, base64 }); return; }
  let blob: Blob;
  if (base64) {
    const bin = atob(content); const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    blob = new Blob([arr], { type: mimeType });
  } else blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = fileName; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

let webAudio: HTMLAudioElement | null = null;
export async function previewSound(path: string, volume: number, startMs?: number, endMs?: number): Promise<void> {
  if (isNative()) { await DayflowNative.playCustomAlarmAudio({ path, volume, startMs, endMs }); return; }
  webAudio?.pause();
  const a = new Audio(path);
  webAudio = a;
  a.volume = Math.max(0, Math.min(1, volume));
  if (startMs) a.currentTime = startMs / 1000;
  if (endMs) a.ontimeupdate = () => { if (a.currentTime * 1000 >= endMs) a.pause(); };
  await a.play();
}
export async function stopSound(): Promise<void> {
  if (isNative()) { await DayflowNative.stopAlarmAudio(); return; }
  webAudio?.pause(); webAudio = null;
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
}
