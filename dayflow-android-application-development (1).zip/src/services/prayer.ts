/**
 * Astronomical prayer-time calculation (PrayTimes.org algorithm) — fully offline.
 * Default: Egyptian General Authority of Survey (Fajr 19.5°, Isha 17.5°), Asr by the majority (Shafi'i/Maliki/Hanbali) shadow factor.
 * Uses the device's real UTC offset for the date, so Egypt's summer time is handled automatically.
 * The Android side (PrayerEngine.kt) implements the exact same formulas so alarms/widgets work without the web layer.
 */
import type { DateKey, PrayerKey, PrayerLog, Settings } from '@/models/types';
import { addDays, epochOf, parseDateKey, rangeKeys, todayKey } from '@/utils/date';

type Method = Settings['prayer']['method'];
const METHODS: Record<Method, { fajr: number; isha: number | { minutes: number }; maghrib?: number }> = {
  mwl: { fajr: 18, isha: 17 }, isna: { fajr: 15, isha: 15 }, egypt: { fajr: 19.5, isha: 17.5 }, makkah: { fajr: 18.5, isha: { minutes: 90 } },
  karachi: { fajr: 18, isha: 18 }, tehran: { fajr: 17.7, isha: 14, maghrib: 4.5 }, gulf: { fajr: 19.5, isha: { minutes: 90 } },
  kuwait: { fajr: 18, isha: 17.5 }, qatar: { fajr: 18, isha: { minutes: 90 } },
};
const dtr = (d: number) => (d * Math.PI) / 180;
const rtd = (r: number) => (r * 180) / Math.PI;
const sin = (d: number) => Math.sin(dtr(d));
const cos = (d: number) => Math.cos(dtr(d));
const tan = (d: number) => Math.tan(dtr(d));
const arcsin = (x: number) => rtd(Math.asin(x));
const arccos = (x: number) => rtd(Math.acos(x));
const arctan2 = (y: number, x: number) => rtd(Math.atan2(y, x));
const arccot = (x: number) => rtd(Math.atan(1 / x));
const fix = (a: number, b: number) => { a = a - b * Math.floor(a / b); return a < 0 ? a + b : a; };

function julian(y: number, m: number, d: number) {
  if (m <= 2) { y -= 1; m += 12; }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
}
function sunPosition(jd: number) {
  const D = jd - 2451545.0;
  const g = fix(357.529 + 0.98560028 * D, 360);
  const q = fix(280.459 + 0.98564736 * D, 360);
  const L = fix(q + 1.915 * sin(g) + 0.02 * sin(2 * g), 360);
  const e = 23.439 - 0.00000036 * D;
  const RA = arctan2(cos(e) * sin(L), cos(L)) / 15;
  return { decl: arcsin(sin(e) * sin(L)), eqt: q / 15 - fix(RA, 24) };
}

export interface PrayerTimes { fajr: number; sunrise: number; dhuhr: number; asr: number; maghrib: number; isha: number; }
export const PRAYER_KEYS: PrayerKey[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

export function computePrayerTimes(date: DateKey, lat: number, lng: number, method: Method, asr: 'standard' | 'hanafi', adjustments: Record<string, number> = {}): PrayerTimes | null {
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  const d = parseDateKey(date);
  const jd = julian(d.getFullYear(), d.getMonth() + 1, d.getDate()) - lng / (15 * 24);
  const tz = -new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12).getTimezoneOffset() / 60;
  const cfg = METHODS[method] ?? METHODS.egypt;
  const midDay = (t: number) => fix(12 - sunPosition(jd + t).eqt, 24);
  const sunAngleTime = (angle: number, t: number, ccw: boolean) => {
    const decl = sunPosition(jd + t).decl;
    const T = arccos((-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat))) / 15;
    return midDay(t) + (ccw ? -T : T);
  };
  const asrTime = (factor: number, t: number) => {
    const decl = sunPosition(jd + t).decl;
    return sunAngleTime(-arccot(factor + tan(Math.abs(lat - decl))), t, false);
  };
  let times = { fajr: 5, sunrise: 6, dhuhr: 12, asr: 13, sunset: 18, maghrib: 18, isha: 18 };
  for (let iter = 0; iter < 2; iter++) {
    const p = Object.fromEntries(Object.entries(times).map(([k, v]) => [k, v / 24])) as typeof times;
    times = {
      fajr: sunAngleTime(cfg.fajr, p.fajr, true), sunrise: sunAngleTime(0.833, p.sunrise, true), dhuhr: midDay(p.dhuhr),
      asr: asrTime(asr === 'hanafi' ? 2 : 1, p.asr), sunset: sunAngleTime(0.833, p.sunset, false),
      maghrib: cfg.maghrib ? sunAngleTime(cfg.maghrib, p.maghrib, false) : sunAngleTime(0.833, p.maghrib, false),
      isha: typeof cfg.isha === 'number' ? sunAngleTime(cfg.isha, p.isha, false) : 0,
    };
    if (typeof cfg.isha !== 'number') times.isha = times.maghrib + cfg.isha.minutes / 60;
  }
  const toMin = (h: number, adj = 0) => fix((h + tz - lng / 15) * 60 + adj, 1440);
  const out = {
    fajr: toMin(times.fajr, adjustments.fajr ?? 0), sunrise: toMin(times.sunrise), dhuhr: toMin(times.dhuhr, (adjustments.dhuhr ?? 0) + 1),
    asr: toMin(times.asr, adjustments.asr ?? 0), maghrib: toMin(times.maghrib, adjustments.maghrib ?? 0), isha: toMin(times.isha, adjustments.isha ?? 0),
  };
  return Object.values(out).some((v) => !Number.isFinite(v)) ? null : out;
}

/** All 27 Egyptian governorates (capital city coordinates) plus common cities/resorts. */
export interface Place { key: string; ar: string; en: string; lat: number; lng: number; governorate?: boolean }
export const EGYPT_PLACES: Place[] = [
  { key: 'cairo', ar: 'القاهرة', en: 'Cairo', lat: 30.0444, lng: 31.2357, governorate: true },
  { key: 'giza', ar: 'الجيزة', en: 'Giza', lat: 30.0131, lng: 31.2089, governorate: true },
  { key: 'alexandria', ar: 'الإسكندرية', en: 'Alexandria', lat: 31.2001, lng: 29.9187, governorate: true },
  { key: 'qalyubia', ar: 'القليوبية (بنها)', en: 'Qalyubia (Banha)', lat: 30.466, lng: 31.1848, governorate: true },
  { key: 'sharqia', ar: 'الشرقية (الزقازيق)', en: 'Sharqia (Zagazig)', lat: 30.5877, lng: 31.502, governorate: true },
  { key: 'dakahlia', ar: 'الدقهلية (المنصورة)', en: 'Dakahlia (Mansoura)', lat: 31.0409, lng: 31.3785, governorate: true },
  { key: 'gharbia', ar: 'الغربية (طنطا)', en: 'Gharbia (Tanta)', lat: 30.7865, lng: 31.0004, governorate: true },
  { key: 'monufia', ar: 'المنوفية (شبين الكوم)', en: 'Monufia (Shebin El Kom)', lat: 30.5972, lng: 30.9876, governorate: true },
  { key: 'beheira', ar: 'البحيرة (دمنهور)', en: 'Beheira (Damanhur)', lat: 31.0341, lng: 30.4682, governorate: true },
  { key: 'kafr_elsheikh', ar: 'كفر الشيخ', en: 'Kafr El Sheikh', lat: 31.1107, lng: 30.9388, governorate: true },
  { key: 'damietta', ar: 'دمياط', en: 'Damietta', lat: 31.4165, lng: 31.8133, governorate: true },
  { key: 'port_said', ar: 'بورسعيد', en: 'Port Said', lat: 31.2653, lng: 32.3019, governorate: true },
  { key: 'ismailia', ar: 'الإسماعيلية', en: 'Ismailia', lat: 30.5965, lng: 32.2715, governorate: true },
  { key: 'suez', ar: 'السويس', en: 'Suez', lat: 29.9668, lng: 32.5498, governorate: true },
  { key: 'north_sinai', ar: 'شمال سيناء (العريش)', en: 'North Sinai (Arish)', lat: 31.1316, lng: 33.7984, governorate: true },
  { key: 'south_sinai', ar: 'جنوب سيناء (الطور)', en: 'South Sinai (El Tor)', lat: 28.241, lng: 33.6222, governorate: true },
  { key: 'fayoum', ar: 'الفيوم', en: 'Fayoum', lat: 29.3084, lng: 30.8428, governorate: true },
  { key: 'beni_suef', ar: 'بني سويف', en: 'Beni Suef', lat: 29.0661, lng: 31.0994, governorate: true },
  { key: 'minya', ar: 'المنيا', en: 'Minya', lat: 28.1099, lng: 30.7503, governorate: true },
  { key: 'assiut', ar: 'أسيوط', en: 'Assiut', lat: 27.1809, lng: 31.1837, governorate: true },
  { key: 'sohag', ar: 'سوهاج', en: 'Sohag', lat: 26.5591, lng: 31.6948, governorate: true },
  { key: 'qena', ar: 'قنا', en: 'Qena', lat: 26.1551, lng: 32.716, governorate: true },
  { key: 'luxor', ar: 'الأقصر', en: 'Luxor', lat: 25.6872, lng: 32.6396, governorate: true },
  { key: 'aswan', ar: 'أسوان', en: 'Aswan', lat: 24.0889, lng: 32.8998, governorate: true },
  { key: 'red_sea', ar: 'البحر الأحمر (الغردقة)', en: 'Red Sea (Hurghada)', lat: 27.2579, lng: 33.8116, governorate: true },
  { key: 'new_valley', ar: 'الوادي الجديد (الخارجة)', en: 'New Valley (Kharga)', lat: 25.439, lng: 30.5586, governorate: true },
  { key: 'matrouh', ar: 'مطروح (مرسى مطروح)', en: 'Matrouh', lat: 31.3543, lng: 27.2373, governorate: true },
  { key: 'sharm', ar: 'شرم الشيخ', en: 'Sharm El-Sheikh', lat: 27.9158, lng: 34.33 },
  { key: 'dahab', ar: 'دهب', en: 'Dahab', lat: 28.5091, lng: 34.5136 },
  { key: 'marsa_alam', ar: 'مرسى علم', en: 'Marsa Alam', lat: 25.0676, lng: 34.8789 },
  { key: 'october6', ar: 'السادس من أكتوبر', en: '6th of October City', lat: 29.9285, lng: 30.9188 },
  { key: 'new_cairo', ar: 'القاهرة الجديدة', en: 'New Cairo', lat: 30.0074, lng: 31.4913 },
  { key: 'tenth', ar: 'العاشر من رمضان', en: '10th of Ramadan City', lat: 30.2917, lng: 31.7417 },
  { key: 'alamein', ar: 'العلمين', en: 'El Alamein', lat: 30.83, lng: 28.954 },
  { key: 'siwa', ar: 'سيوة', en: 'Siwa', lat: 29.2032, lng: 25.5195 },
  { key: 'mahalla', ar: 'المحلة الكبرى', en: 'El Mahalla El Kubra', lat: 30.97, lng: 31.1669 },
  { key: 'edfu', ar: 'إدفو', en: 'Edfu', lat: 24.9779, lng: 32.8742 },
];
export const placeOf = (key: string) => EGYPT_PLACES.find((p) => p.key === key) ?? EGYPT_PLACES[0];

export function timesFor(date: DateKey, cfg: Settings['prayer']): PrayerTimes | null {
  const pl = cfg.lat != null && cfg.lng != null ? { lat: cfg.lat, lng: cfg.lng } : placeOf(cfg.governorate);
  return computePrayerTimes(date, pl.lat, pl.lng, cfg.method, cfg.asr, cfg.adjustments);
}

export interface NextPrayer { key: PrayerKey; at: number; prevAt: number; prevKey: PrayerKey; progress: number; isTomorrow: boolean; remainingMs: number; }
/** Next prayer, with progress (0..100) between the previous prayer and the next one. */
export function nextPrayer(now: number, cfg: Settings['prayer']): NextPrayer | null {
  const today = todayKey(); const nd = new Date(now);
  const key = `${nd.getFullYear()}-${String(nd.getMonth() + 1).padStart(2, '0')}-${String(nd.getDate()).padStart(2, '0')}`;
  void today;
  const seq: { k: PrayerKey; at: number }[] = [];
  for (const d of [addDays(key, -1), key, addDays(key, 1)]) {
    const t = timesFor(d, cfg); if (!t) return null;
    for (const k of PRAYER_KEYS) seq.push({ k, at: epochOf(d, t[k]) });
  }
  const i = seq.findIndex((x) => x.at > now);
  if (i <= 0) return null;
  const next = seq[i], prev = seq[i - 1];
  return { key: next.k, at: next.at, prevAt: prev.at, prevKey: prev.k, progress: Math.max(0, Math.min(100, ((now - prev.at) / (next.at - prev.at)) * 100)), isTomorrow: new Date(next.at).getDate() !== nd.getDate(), remainingMs: next.at - now };
}

export interface PrayerStats { today: number; weekDone: number; weekTotal: number; weekRate: number; streak: number; byDay: { date: DateKey; done: number }[]; perPrayer: Record<PrayerKey, number> }
export function prayerStats(logs: PrayerLog[], days = 7): PrayerStats {
  const t = todayKey();
  const map = new Map<string, Set<PrayerKey>>();
  for (const l of logs) (map.get(l.date) ?? map.set(l.date, new Set()).get(l.date)!).add(l.prayer);
  const byDay = rangeKeys(addDays(t, -(days - 1)), days).map((d) => ({ date: d, done: map.get(d)?.size ?? 0 }));
  const weekDone = byDay.reduce((a, d) => a + d.done, 0);
  let streak = 0;
  for (let i = 0; i < 365; i++) { const d = addDays(t, -i); const n = map.get(d)?.size ?? 0; if (n >= 5) streak++; else if (i === 0) continue; else break; }
  const perPrayer = { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 } as Record<PrayerKey, number>;
  for (const l of logs) if (l.date >= byDay[0].date) perPrayer[l.prayer]++;
  return { today: map.get(t)?.size ?? 0, weekDone, weekTotal: days * 5, weekRate: Math.round((weekDone / (days * 5)) * 100), streak, byDay, perPrayer };
}
/** Qibla bearing (degrees from true north) towards the Kaaba. */
export function qiblaBearing(lat: number, lng: number): number {
  const kl = dtr(21.4225), kg = dtr(39.8262), l = dtr(lat), g = dtr(lng);
  return (rtd(Math.atan2(Math.sin(kg - g), Math.cos(l) * Math.tan(kl) - Math.sin(l) * Math.cos(kg - g))) + 360) % 360;
}
