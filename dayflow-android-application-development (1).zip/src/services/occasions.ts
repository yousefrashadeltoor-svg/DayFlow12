/**
 * Occasion catalogue: Gregorian, Hijri (Umm al-Qura via Intl + user adjustment), Orthodox/Coptic (Julian Easter) and Hebrew (Intl).
 * Religion handling: occasions of Christianity / Judaism are shown ONLY in the calendar, flagged with a red "!" and the religion name,
 * and are never materialised for notifications or widgets. Official-holiday flags follow the Egyptian public holiday list.
 */
import type { DateKey, OccasionRecord, SpecialDate } from '@/models/types';
import { addDays, diffDays, parseDateKey, toDateKey } from '@/utils/date';

export type Religion = 'muslim' | 'christian' | 'jewish' | 'national' | 'social' | 'heritage';
export interface OccasionDef {
  key: string; ar: string; en: string; emoji: string; religion: Religion; official: boolean;
  /** extra note about the holiday status, Arabic (Egyptian) */
  officialAr?: string; officialEn?: string;
  image: string; detailsAr: string; detailsEn: string;
}
export interface Occasion {
  id: string; date: DateKey; key: string; title: string; titleEn: string; emoji: string; religion: Religion;
  flagged: boolean; religionLabelAr?: string; religionLabelEn?: string;
  official: boolean; officialAr: string; officialEn: string; image: string; detailsAr: string; detailsEn: string;
  source: 'builtin' | 'user'; note?: string; notify: boolean; notifyMin: number; userId?: string;
}

export const HIJRI_MONTHS_AR = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];
export const HIJRI_MONTHS_EN = ['Muharram', 'Safar', 'Rabi I', 'Rabi II', 'Jumada I', 'Jumada II', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhu al-Qi'dah", 'Dhu al-Hijjah'];

// ---------------------------------------------------------------- calendars
const hijriFmt = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric' });
const hebrewFmt = new Intl.DateTimeFormat('en-u-ca-hebrew-nu-latn', { day: 'numeric', month: 'long' });
const hijriCache = new Map<string, { y: number; m: number; d: number }>();

export function hijriOf(key: DateKey, adjust = 0): { y: number; m: number; d: number } {
  const ck = `${key}|${adjust}`;
  const hit = hijriCache.get(ck);
  if (hit) return hit;
  const dt = parseDateKey(addDays(key, adjust));
  dt.setHours(12);
  const parts = hijriFmt.formatToParts(dt);
  const num = (t: string) => Number(parts.find((p) => p.type === t)?.value ?? 0);
  const out = { y: num('year') || num('relatedYear'), m: num('month'), d: num('day') };
  hijriCache.set(ck, out);
  return out;
}
export function hijriLabel(key: DateKey, adjust: number, lang: 'ar' | 'en'): string {
  const h = hijriOf(key, adjust);
  const n = (x: number) => (lang === 'ar' ? new Intl.NumberFormat('ar-EG', { useGrouping: false }).format(x) : String(x));
  return `${n(h.d)} ${(lang === 'ar' ? HIJRI_MONTHS_AR : HIJRI_MONTHS_EN)[h.m - 1] ?? ''} ${n(h.y)}`;
}
function hebrewOf(key: DateKey): { m: string; d: number } {
  const dt = parseDateKey(key); dt.setHours(12);
  const parts = hebrewFmt.formatToParts(dt);
  return { m: parts.find((p) => p.type === 'month')?.value ?? '', d: Number(parts.find((p) => p.type === 'day')?.value ?? 0) };
}
/** Orthodox (Coptic) Easter Sunday as a Gregorian date key (Julian computus + 13 days, valid 1900–2099). */
export function orthodoxEaster(year: number): DateKey {
  const a = year % 4, b = year % 7, c = year % 19;
  const d = (19 * c + 15) % 30;
  const e = (2 * a + 4 * b - d + 34) % 7;
  const month = Math.floor((d + e + 114) / 31);
  const day = ((d + e + 114) % 31) + 1;
  return addDays(toDateKey(new Date(year, month - 1, day)), 13);
}
const isLeap = (y: number) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;

// ---------------------------------------------------------------- catalogue
const D = (key: string, ar: string, en: string, emoji: string, religion: Religion, official: boolean, image: string, detailsAr: string, detailsEn: string, officialAr?: string, officialEn?: string): OccasionDef =>
  ({ key, ar, en, emoji, religion, official, image, detailsAr, detailsEn, officialAr, officialEn });

export const CATALOGUE: Record<string, OccasionDef> = {
  new_year: D('new_year', 'رأس السنة الميلادية', 'New Year’s Day', 'fireworks', 'social', false, 'fireworks1',
    'أول يوم في السنة الميلادية. الناس بتسهر وتتفرج على الألعاب النارية وتحط أهداف السنة الجديدة. فرصة كويسة تكتب أهدافك وتظبط خطتك في التطبيق.',
    'The first day of the Gregorian year — a good moment to set goals and plan your year.', 'مش إجازة رسمية للكل — بتبقى إجازة للبنوك وبعض الشركات بس', 'Not a general public holiday — banks and some companies only'),
  jan25: D('jan25', 'ثورة 25 يناير وعيد الشرطة', 'January 25 Revolution & Police Day', 'military_helmet', 'national', true, 'flag2',
    'يوم وطني بيجمع ذكرى ثورة 25 يناير 2011 وعيد الشرطة المصرية (معركة الإسماعيلية سنة 1952). إجازة رسمية في كل الجهات.',
    'A national day marking the 2011 revolution and Egypt’s Police Day.'),
  isra: D('isra', 'ذكرى الإسراء والمعراج', 'Isra and Mi’raj', 'night_with_stars', 'muslim', false, 'mosque1',
    'ليلة 27 رجب، بيفتكر فيها المسلمين رحلة النبي ﷺ من مكة للمسجد الأقصى وبعدها العروج للسماء، وفيها فُرضت الصلوات الخمس. مش إجازة رسمية لكن مناسبة دينية بيحتفل بيها الناس.',
    'The night journey of the Prophet ﷺ; observed, not an official holiday.', 'مناسبة دينية — مش إجازة رسمية', 'Observance — not an official holiday'),
  shaban15: D('shaban15', 'ليلة النصف من شعبان', 'Mid-Sha’ban Night', 'full_moon', 'muslim', false, 'night2',
    'ليلة 15 شعبان، قبل رمضان بنحو أسبوعين. كتير من الناس بيحيوها بالدعاء والذكر وبتبقى بداية استعداد حلو لشهر رمضان.',
    'The night of the 15th of Sha’ban, two weeks before Ramadan.', 'مناسبة دينية — مش إجازة رسمية', 'Observance — not an official holiday'),
  ramadan_start: D('ramadan_start', 'أول يوم رمضان', 'First day of Ramadan', 'red_paper_lantern', 'muslim', false, 'ramadan1',
    'رمضان هو الشهر التاسع في التقويم الهجري، والصيام فيه من الفجر لحد المغرب. الأجواء في مصر مميزة: الفوانيس والزينة والمسحراتي ولمّة الفطار والسحور. التاريخ بيتحدد برؤية الهلال فممكن يتغير يوم، وتقدر تظبطه من الإعدادات.',
    'The start of the holy month of fasting. The date follows moon sighting and may shift by a day.', 'مش إجازة رسمية (الشغل بيتأخر ساعتين في بعض الجهات)', 'Not a holiday (working hours are shortened in some places)'),
  qadr: D('qadr', 'ليلة القدر (27 رمضان)', 'Laylat al-Qadr (27 Ramadan)', 'glowing_star', 'muslim', false, 'mosque2',
    'ليلة القدر خير من ألف شهر، وبيتحراها المسلمين في الليالي الوتر من العشر الأواخر من رمضان، وأشهر ليلة فيهم 27 رمضان. ليلة للدعاء والصلاة وقراءة القرآن.',
    'The Night of Decree, sought in the last ten nights of Ramadan.', 'مناسبة دينية — مش إجازة رسمية', 'Observance — not an official holiday'),
  eid_fitr: D('eid_fitr', 'عيد الفطر المبارك', 'Eid al-Fitr', 'party_popper', 'muslim', true, 'eid1',
    'العيد الصغير، بيجي بعد انتهاء رمضان في أول 3 أيام من شوال. صلاة العيد والعيدية وكحك العيد ولمّة العيلة والخروج. إجازة رسمية 3 أيام (وممكن الحكومة تضيف أيام).',
    'Celebrates the end of Ramadan — three days of official holiday.'),
  arafat: D('arafat', 'يوم عرفة (وقفة عيد الأضحى)', 'Day of Arafah', 'kaaba', 'muslim', true, 'kaaba1',
    'اليوم التاسع من ذي الحجة، وهو أعظم أيام الحج لما الحجاج بيقفوا على جبل عرفات. صيامه للي مش حاج سُنّة. إجازة رسمية في مصر.',
    'The 9th of Dhu al-Hijjah — the climax of Hajj; an official holiday in Egypt.'),
  eid_adha: D('eid_adha', 'عيد الأضحى المبارك', 'Eid al-Adha', 'ewe', 'muslim', true, 'kaaba2',
    'العيد الكبير، بيبدأ يوم 10 ذي الحجة وبيستمر لحد 13 ذي الحجة. فيه الأضحية وتوزيع اللحمة على الأهل والجيران والفقراء ولمّة العيلة. إجازة رسمية عدة أيام.',
    'The Feast of Sacrifice, 10–13 Dhu al-Hijjah — official holiday.'),
  hijri_new_year: D('hijri_new_year', 'رأس السنة الهجرية', 'Islamic New Year', 'crescent_moon', 'muslim', true, 'oldcairo1',
    'أول يوم في شهر محرم، بداية السنة الهجرية. بتفتكر هجرة النبي ﷺ من مكة للمدينة. إجازة رسمية في مصر.',
    '1 Muharram — the Hijri new year; an official holiday in Egypt.'),
  ashura: D('ashura', 'يوم عاشوراء', 'Day of Ashura', 'sunrise', 'muslim', false, 'sunrise1',
    'اليوم العاشر من محرم، بيُستحب صيامه (ومعاه التاسع أو الحادي عشر). في مصر كمان بيتعمل فيه أكلة عاشوراء المشهورة. مش إجازة رسمية.',
    '10 Muharram — fasting is recommended; not an official holiday.', 'مناسبة دينية — مش إجازة رسمية', 'Observance — not an official holiday'),
  mawlid: D('mawlid', 'المولد النبوي الشريف', 'Mawlid al-Nabi', 'sparkles', 'muslim', true, 'oldcairo2',
    'ذكرى مولد النبي محمد ﷺ يوم 12 ربيع الأول. في مصر بتتعمل احتفالات وموالد وبتتوزع حلاوة المولد (الحمصية والسمسمية والفولية). إجازة رسمية.',
    'The Prophet’s birthday, 12 Rabi’ al-Awwal — an official holiday in Egypt.'),
  apr25: D('apr25', 'عيد تحرير سيناء', 'Sinai Liberation Day', 'desert', 'national', true, 'sinai1',
    'يوم 25 أبريل 1982 رجعت آخر حتة من سيناء لمصر بعد انسحاب إسرائيل. يوم وطني وإجازة رسمية.',
    'April 25, 1982 — the return of Sinai to Egypt; an official holiday.'),
  may1: D('may1', 'عيد العمال', 'Labour Day', 'hammer_and_wrench', 'social', true, 'labour1',
    'يوم 1 مايو، احتفال بالعمال وحقوقهم في مصر وفي العالم كله. إجازة رسمية.', 'International Workers’ Day — an official holiday.'),
  jun30: D('jun30', 'ثورة 30 يونيو', 'June 30 Revolution', 'star', 'national', true, 'cairo1',
    'ذكرى خروج ملايين المصريين يوم 30 يونيو 2013. يوم وطني وإجازة رسمية.', 'A national day — official holiday.'),
  jul23: D('jul23', 'ثورة 23 يوليو', 'July 23 Revolution', 'sailboat', 'national', true, 'cairo2',
    'ذكرى ثورة 23 يوليو 1952 اللي أنهت الحكم الملكي وأعلنت الجمهورية. إجازة رسمية.', 'The 1952 revolution — an official holiday.'),
  nile: D('nile', 'وفاء النيل', 'Wafaa El-Nil (Nile Flood)', 'water_wave', 'heritage', false, 'nile1',
    'احتفال مصري قديم (15 أغسطس) بفيضان النيل، من أيام الفراعنة لحد النهارده. تراث جميل مش إجازة رسمية.', 'An ancient Egyptian celebration of the Nile flood.', 'مناسبة تراثية — مش إجازة رسمية', 'Heritage — not an official holiday'),
  oct6: D('oct6', 'عيد القوات المسلحة (نصر أكتوبر)', 'Armed Forces Day (October War)', 'military_helmet', 'national', true, 'flag1',
    'ذكرى عبور 6 أكتوبر 1973 وانتصار الجيش المصري. أكبر مناسبة وطنية في مصر وإجازة رسمية.', 'Commemorates the October 1973 crossing — an official holiday.'),
  oct24: D('oct24', 'العيد القومي للسويس', 'Suez National Day', 'sailboat', 'national', false, 'sinai2',
    'يوم 24 أكتوبر 1973 قاومت السويس وصدّت الحصار. إجازة رسمية في محافظة السويس بس.', 'Suez governorate holiday.', 'إجازة رسمية في محافظة السويس بس', 'Official holiday in Suez governorate only'),
  dec23: D('dec23', 'عيد النصر (بورسعيد)', 'Port Said Victory Day', 'sailboat', 'national', false, 'alex1',
    'يوم 23 ديسمبر 1956 انتصار بورسعيد في العدوان الثلاثي. إجازة رسمية في بورسعيد بس.', 'Port Said governorate holiday.', 'إجازة رسمية في محافظة بورسعيد بس', 'Official holiday in Port Said governorate only'),
  mothers_day: D('mothers_day', 'عيد الأم', 'Mother’s Day', 'bouquet', 'social', false, 'mother1',
    'يوم 21 مارس، المصريين بيحتفلوا فيه بالأمهات وبيهادوهم ورد وهدايا. بدأ الاحتفال بيه في مصر سنة 1956. مش إجازة رسمية.', 'Celebrated on March 21 in Egypt.', 'مش إجازة رسمية', 'Not a public holiday'),
  orphans_day: D('orphans_day', 'يوم اليتيم', 'Orphan’s Day', 'red_heart', 'social', false, 'mother2',
    'أول جمعة في أبريل من كل سنة، يوم نفتكر فيه الأيتام ونطمّن عليهم وندعمهم. مش إجازة رسمية.', 'First Friday of April.', 'مش إجازة رسمية', 'Not a public holiday'),
  sham: D('sham', 'شم النسيم', 'Sham El-Nessim', 'egg', 'heritage', true, 'eggs1',
    'عيد مصري قديم عمره آلاف السنين بيحتفل بالربيع. اليوم بيبقى الاثنين اللي بعد عيد القيامة الأرثوذكسي. المصريين كلهم بيخرجوا الحدايق والنيل ويأكلوا البيض الملون والفسيخ والرنجة والبصل الأخضر والخس. إجازة رسمية.',
    'An ancient Egyptian spring festival, the Monday after Orthodox Easter — official holiday.'),
  // ---- Christian (flagged: calendar only)
  coptic_xmas: D('coptic_xmas', 'عيد الميلاد المجيد (قبطي)', 'Coptic Christmas', 'church', 'christian', true, 'church1',
    'مناسبة مسيحية: عيد ميلاد المسيح بحسب التقويم القبطي يوم 7 يناير. إجازة رسمية في مصر لكل المواطنين. (مش بتظهر في الإشعارات والويدجت.)',
    'A Christian occasion (7 January). An official holiday in Egypt.'),
  epiphany: D('epiphany', 'عيد الغطاس', 'Epiphany (Coptic)', 'church', 'christian', false, 'church1',
    'مناسبة مسيحية يوم 19 يناير. مش إجازة رسمية.', 'A Christian occasion — not an official holiday.', 'مش إجازة رسمية', 'Not an official holiday'),
  palm_sunday: D('palm_sunday', 'أحد الشعانين', 'Palm Sunday', 'church', 'christian', false, 'church1', 'مناسبة مسيحية قبل عيد القيامة بأسبوع. مش إجازة رسمية.', 'A Christian occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  good_friday: D('good_friday', 'الجمعة العظيمة', 'Good Friday', 'church', 'christian', false, 'church1', 'مناسبة مسيحية قبل عيد القيامة بيومين. مش إجازة رسمية.', 'A Christian occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  coptic_easter: D('coptic_easter', 'عيد القيامة المجيد', 'Coptic Easter', 'church', 'christian', false, 'church1', 'مناسبة مسيحية، دايمًا يوم أحد. اليوم اللي بعده بيبقى شم النسيم.', 'A Christian occasion (always Sunday).', 'يوم أحد — الإجازة بتبقى يوم شم النسيم', 'Falls on Sunday — the holiday is Sham El-Nessim the next day'),
  annunciation: D('annunciation', 'عيد البشارة', 'Annunciation', 'church', 'christian', false, 'church1', 'مناسبة مسيحية يوم 7 أبريل. مش إجازة رسمية.', 'A Christian occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  nayrouz: D('nayrouz', 'عيد النيروز (رأس السنة القبطية)', 'Nayrouz (Coptic New Year)', 'church', 'christian', false, 'church1', 'أول يوم في السنة القبطية (11 أو 12 سبتمبر). مناسبة قبطية مش إجازة رسمية.', 'Coptic New Year.', 'مش إجازة رسمية', 'Not an official holiday'),
  cross_feast: D('cross_feast', 'عيد الصليب', 'Feast of the Cross', 'church', 'christian', false, 'church1', 'مناسبة مسيحية يوم 27 سبتمبر (28 في بعض السنين). مش إجازة رسمية.', 'A Christian occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  western_xmas: D('western_xmas', 'عيد الميلاد (الغربي)', 'Christmas (Western)', 'christmas_tree', 'christian', false, 'winter2', 'مناسبة مسيحية يوم 25 ديسمبر. مش إجازة رسمية في مصر (إجازة اختيارية في بعض الشركات).', 'A Christian occasion — not an official holiday in Egypt.', 'مش إجازة رسمية', 'Not an official holiday'),
  // ---- Jewish (flagged: calendar only)
  rosh_hashanah: D('rosh_hashanah', 'رأس السنة العبرية', 'Rosh Hashanah', 'menorah', 'jewish', false, 'menorah1', 'مناسبة يهودية. مش إجازة رسمية في مصر.', 'A Jewish occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  yom_kippur: D('yom_kippur', 'يوم الغفران', 'Yom Kippur', 'menorah', 'jewish', false, 'menorah1', 'مناسبة يهودية. مش إجازة رسمية في مصر.', 'A Jewish occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  sukkot: D('sukkot', 'عيد المظال', 'Sukkot', 'menorah', 'jewish', false, 'menorah1', 'مناسبة يهودية. مش إجازة رسمية في مصر.', 'A Jewish occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  hanukkah: D('hanukkah', 'عيد الأنوار (حانوكا)', 'Hanukkah', 'menorah', 'jewish', false, 'menorah1', 'مناسبة يهودية بتبدأ 25 كسلو. مش إجازة رسمية في مصر.', 'A Jewish occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  purim: D('purim', 'عيد المساخر (بوريم)', 'Purim', 'menorah', 'jewish', false, 'menorah1', 'مناسبة يهودية. مش إجازة رسمية في مصر.', 'A Jewish occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
  passover: D('passover', 'عيد الفصح اليهودي', 'Passover', 'menorah', 'jewish', false, 'menorah1', 'مناسبة يهودية. مش إجازة رسمية في مصر.', 'A Jewish occasion.', 'مش إجازة رسمية', 'Not an official holiday'),
};

const RELIGION_LABEL: Record<Religion, [string, string]> = {
  muslim: ['إسلامي', 'Islamic'], christian: ['مسيحي', 'Christian'], jewish: ['يهودي', 'Jewish'], national: ['وطني', 'National'], social: ['اجتماعي', 'Social'], heritage: ['تراثي', 'Heritage'],
};
export const religionLabel = (r: Religion, lang: 'ar' | 'en') => RELIGION_LABEL[r][lang === 'ar' ? 0 : 1];

const GREG_FIXED: [number, number, string][] = [
  [1, 1, 'new_year'], [1, 7, 'coptic_xmas'], [1, 19, 'epiphany'], [1, 25, 'jan25'], [3, 21, 'mothers_day'], [4, 7, 'annunciation'], [4, 25, 'apr25'], [5, 1, 'may1'],
  [6, 30, 'jun30'], [7, 23, 'jul23'], [8, 15, 'nile'], [10, 6, 'oct6'], [10, 24, 'oct24'], [12, 23, 'dec23'], [12, 25, 'western_xmas'],
];
const HIJRI_FIXED: [number, number, string][] = [
  [1, 1, 'hijri_new_year'], [1, 10, 'ashura'], [3, 12, 'mawlid'], [7, 27, 'isra'], [8, 15, 'shaban15'], [9, 1, 'ramadan_start'], [9, 27, 'qadr'],
  [10, 1, 'eid_fitr'], [10, 2, 'eid_fitr'], [10, 3, 'eid_fitr'], [12, 9, 'arafat'], [12, 10, 'eid_adha'], [12, 11, 'eid_adha'], [12, 12, 'eid_adha'], [12, 13, 'eid_adha'],
];
const HEBREW_FIXED: [string[], number, string][] = [
  [['Tishri'], 1, 'rosh_hashanah'], [['Tishri'], 10, 'yom_kippur'], [['Tishri'], 15, 'sukkot'], [['Kislev'], 25, 'hanukkah'], [['Adar', 'Adar II'], 14, 'purim'], [['Nisan'], 15, 'passover'],
];

export interface OccasionOptions { hijriAdjust: number; showOtherReligions: boolean; user: SpecialDate[] }

function toOccasion(def: OccasionDef, date: DateKey): Occasion {
  const flagged = def.religion === 'christian' || def.religion === 'jewish';
  return {
    id: `occ:${date}:${def.key}`, date, key: def.key, title: def.ar, titleEn: def.en, emoji: def.emoji, religion: def.religion, flagged,
    religionLabelAr: flagged ? RELIGION_LABEL[def.religion][0] : undefined, religionLabelEn: flagged ? RELIGION_LABEL[def.religion][1] : undefined,
    official: def.official, officialAr: def.officialAr ?? (def.official ? 'إجازة رسمية' : 'مش إجازة رسمية'), officialEn: def.officialEn ?? (def.official ? 'Official holiday' : 'Not an official holiday'),
    image: def.image, detailsAr: def.detailsAr, detailsEn: def.detailsEn, source: 'builtin', notify: !flagged, notifyMin: 8 * 60,
  };
}

export function occasionsOn(date: DateKey, o: OccasionOptions): Occasion[] {
  const out: Occasion[] = [];
  const d = parseDateKey(date);
  const m = d.getMonth() + 1, day = d.getDate(), y = d.getFullYear();
  for (const [gm, gd, key] of GREG_FIXED) if (gm === m && gd === day) out.push(toOccasion(CATALOGUE[key], date));
  // Coptic new year / Feast of the Cross shift by a day before Gregorian leap years
  const shift = isLeap(y + 1) ? 1 : 0;
  if (m === 9 && day === 11 + shift) out.push(toOccasion(CATALOGUE.nayrouz, date));
  if (m === 9 && day === 27 + shift) out.push(toOccasion(CATALOGUE.cross_feast, date));
  const h = hijriOf(date, o.hijriAdjust);
  for (const [hm, hd, key] of HIJRI_FIXED) if (hm === h.m && hd === h.d) out.push(toOccasion(CATALOGUE[key], date));
  const easter = orthodoxEaster(y);
  const k = diffDays(easter, date);
  if (k === -7) out.push(toOccasion(CATALOGUE.palm_sunday, date));
  if (k === -2) out.push(toOccasion(CATALOGUE.good_friday, date));
  if (k === 0) out.push(toOccasion(CATALOGUE.coptic_easter, date));
  if (k === 1) out.push(toOccasion(CATALOGUE.sham, date));
  if (m === 4 && d.getDay() === 5 && day <= 7) out.push(toOccasion(CATALOGUE.orphans_day, date));
  if (o.showOtherReligions) {
    const hb = hebrewOf(date);
    for (const [months, hd, key] of HEBREW_FIXED) if (months.includes(hb.m) && hb.d === hd) out.push(toOccasion(CATALOGUE[key], date));
  }
  // de-duplicate multi-day Islamic occasions into a single labelled day number
  for (const occ of out) {
    if (occ.key === 'eid_fitr' || occ.key === 'eid_adha') {
      const hd = h.d - (occ.key === 'eid_fitr' ? 0 : 9);
      occ.title = `${occ.title} · ${hd === 1 ? 'اليوم الأول' : hd === 2 ? 'اليوم التاني' : hd === 3 ? 'اليوم التالت' : 'اليوم الرابع'}`;
      occ.titleEn = `${occ.titleEn} · day ${hd}`;
    }
  }
  for (const u of o.user) {
    const match = u.yearly ? u.date.slice(5) === date.slice(5) : u.date === date;
    if (!match) continue;
    out.push({
      id: `occ:${date}:u:${u.id}`, date, key: `u:${u.id}`, title: u.label, titleEn: u.label, emoji: u.emoji ?? 'sparkles', religion: 'social', flagged: false,
      official: !!u.official, officialAr: u.official ? 'إجازة رسمية' : 'مناسبة شخصية', officialEn: u.official ? 'Official holiday' : 'Personal occasion',
      image: 'journal2', detailsAr: u.note || 'مناسبة ضفتها بنفسك.', detailsEn: u.note || 'An occasion you added.', source: 'user', note: u.note, notify: u.notify !== false, notifyMin: u.notifyMin ?? 8 * 60, userId: u.id,
    });
  }
  return o.showOtherReligions ? out : out.filter((x) => !x.flagged);
}

/** Records for native consumption: user occasions + built-in occasions that are NOT flagged (Christian/Jewish never reach notifications/widgets). */
export function materializeOccasions(from: DateKey, days: number, o: OccasionOptions): OccasionRecord[] {
  const out: OccasionRecord[] = [];
  const now = Date.now();
  for (let i = 0; i < days; i++) {
    const date = addDays(from, i);
    for (const x of occasionsOn(date, { ...o, showOtherReligions: false })) {
      out.push({ id: x.id, date, key: x.key, title: x.title, titleEn: x.titleEn, emoji: x.emoji, official: x.official, kind: x.religion, image: x.image,
        notify: x.notify, notifyMin: x.notifyMin, source: x.source, note: x.note ?? '', createdAt: now, updatedAt: now });
    }
  }
  return out;
}

export function isRamadan(date: DateKey, adjust: number) { return hijriOf(date, adjust).m === 9; }
export function isEid(date: DateKey, adjust: number) { const h = hijriOf(date, adjust); return (h.m === 10 && h.d <= 3) || (h.m === 12 && h.d >= 10 && h.d <= 13); }
export function isHajjSeason(date: DateKey, adjust: number) { const h = hijriOf(date, adjust); return h.m === 12 && h.d <= 9; }
