/**
 * Theme engine. Every theme is a complete design system: palette (light + dark), typography, corner radii,
 * card construction, navigation style, header alignment, overview layout and timeline style.
 * CSS is generated once and injected, scoped by [data-theme] so the theme picker can render live previews.
 */
export type NavStyle = 'bar' | 'float' | 'dock';
export type CardStyle = 'elevated' | 'flat' | 'glass' | 'outline' | 'clay' | 'neon';
export type HeaderStyle = 'large' | 'center' | 'compact';
export type OverviewStyle = 'ring' | 'hero' | 'compact';
export type TimelineStyle = 'cards' | 'lines';

interface Palette { bg: string; surface: string; surface2: string; line: string; ink: string; ink2: string; ink3: string; accent: string; accentInk: string; page?: string; shadow?: string; float?: string; cardBg?: string; cardBorder?: string; blur?: string }
export interface ThemeDef {
  id: string; ar: string; en: string; descAr: string; descEn: string;
  font: string; nav: NavStyle; cards: CardStyle; header: HeaderStyle; overview: OverviewStyle; timeline: TimelineStyle;
  radius: { card: number; ctl: number; ctlS: number; sheet: number };
  forceDark?: boolean; swatch: [string, string, string];
  light: Palette; dark: Palette;
}

const P = (bg: string, surface: string, surface2: string, line: string, ink: string, ink2: string, ink3: string, accent: string, accentInk = '#fff', extra: Partial<Palette> = {}): Palette =>
  ({ bg, surface, surface2, line, ink, ink2, ink3, accent, accentInk, ...extra });

const SANS_LATIN = '"Inter"';
export const THEMES: ThemeDef[] = [
  {
    id: 'dayflow', ar: 'ديفلو الأصلي', en: 'Dayflow Classic', descAr: 'دافي وهادي وبسيط، زي ما بدأنا.', descEn: 'Warm, calm and clean.',
    font: `${SANS_LATIN}, "IBM Plex Sans Arabic", system-ui, sans-serif`, nav: 'bar', cards: 'elevated', header: 'large', overview: 'ring', timeline: 'cards',
    radius: { card: 22, ctl: 16, ctlS: 12, sheet: 28 }, swatch: ['#f7f5f0', '#5b5bd6', '#ffffff'],
    light: P('#f7f5f0', '#ffffff', '#f1eee8', 'rgba(28,27,34,.08)', '#1c1b22', '#5f5c69', '#9a97a3', '#5b5bd6'),
    dark: P('#121115', '#1c1b21', '#26252c', 'rgba(255,255,255,.08)', '#f4f3f7', '#b4b1bd', '#75727e', '#7c7cf0'),
  },
  {
    id: 'gemini', ar: 'جيميناي', en: 'Gemini Gradient', descAr: 'تدرجات ألوان ناعمة ومريحة وحواف دايرية كبيرة وانسيابية.', descEn: 'Soft flowing gradients, big rounded shapes.',
    font: '"Readex Pro", "Inter", system-ui, sans-serif', nav: 'float', cards: 'elevated', header: 'large', overview: 'hero', timeline: 'cards',
    radius: { card: 30, ctl: 20, ctlS: 14, sheet: 34 }, swatch: ['#8ab4ff', '#c58bff', '#ff9ec7'],
    light: P('#f5f6fd', 'rgba(255,255,255,.86)', '#ecefff', 'rgba(80,90,160,.12)', '#1b1d33', '#575b7d', '#9a9dbb', '#5b6cff', '#fff', {
      page: 'radial-gradient(900px 520px at 8% -8%, #d7e4ff 0%, transparent 62%), radial-gradient(800px 480px at 105% 2%, #ecd9ff 0%, transparent 58%), radial-gradient(900px 600px at 55% 112%, #ffdfeb 0%, transparent 62%), #f6f7fd',
      shadow: '0 1px 2px rgba(60,70,150,.05), 0 14px 36px -16px rgba(91,108,255,.28)', float: '0 18px 50px -14px rgba(91,108,255,.4)' }),
    dark: P('#0d0f1f', 'rgba(26,29,52,.82)', '#232743', 'rgba(150,160,255,.14)', '#eef0ff', '#aab0d6', '#6f7599', '#8c9bff', '#0b0d1e', {
      page: 'radial-gradient(900px 520px at 8% -8%, #1d2a63 0%, transparent 62%), radial-gradient(800px 480px at 105% 2%, #3a1f63 0%, transparent 58%), radial-gradient(900px 600px at 55% 112%, #4a1d45 0%, transparent 62%), #0d0f1f',
      shadow: '0 14px 36px -16px rgba(0,0,0,.7)', float: '0 18px 50px -14px rgba(0,0,0,.8)' }),
  },
  {
    id: 'oneui', ar: 'زجاج One UI', en: 'One UI Glass', descAr: 'زجاج بلوري شفاف وضبابي، عناوين كبيرة وبار تنقل عايم.', descEn: 'Frosted glass surfaces with a floating dock.',
    font: '"Tajawal", "Inter", system-ui, sans-serif', nav: 'dock', cards: 'glass', header: 'large', overview: 'ring', timeline: 'cards',
    radius: { card: 30, ctl: 22, ctlS: 16, sheet: 36 }, swatch: ['#cfe3ff', '#3e91ff', '#ffd9e6'],
    light: P('#e9f0fb', 'rgba(255,255,255,.58)', 'rgba(255,255,255,.5)', 'rgba(255,255,255,.7)', '#111827', '#4b5563', '#8b93a1', '#2f80ff', '#fff', {
      page: 'radial-gradient(700px 500px at 0% 0%, #bcd6ff 0%, transparent 60%), radial-gradient(700px 520px at 100% 10%, #ffd7ea 0%, transparent 58%), radial-gradient(800px 600px at 40% 105%, #c9f0ff 0%, transparent 60%), #eaf0fb',
      shadow: '0 8px 32px rgba(31,60,120,.12)', float: '0 16px 44px rgba(31,60,120,.2)', cardBg: 'rgba(255,255,255,.58)', cardBorder: 'rgba(255,255,255,.75)', blur: 'blur(28px) saturate(170%)' }),
    dark: P('#0b1220', 'rgba(30,41,59,.52)', 'rgba(255,255,255,.07)', 'rgba(255,255,255,.12)', '#f1f5f9', '#b5c0d0', '#7a8699', '#58a6ff', '#04101f', {
      page: 'radial-gradient(700px 500px at 0% 0%, #12306b 0%, transparent 60%), radial-gradient(700px 520px at 100% 10%, #4b1f5c 0%, transparent 58%), radial-gradient(800px 600px at 40% 105%, #0b4a58 0%, transparent 60%), #0b1220',
      shadow: '0 8px 32px rgba(0,0,0,.45)', float: '0 16px 44px rgba(0,0,0,.6)', cardBg: 'rgba(30,41,59,.52)', cardBorder: 'rgba(255,255,255,.12)', blur: 'blur(28px) saturate(160%)' }),
  },
  {
    id: 'clay', ar: 'نعومة (Soft UI)', en: 'Soft Clay', descAr: 'أزرار وبطاقات بارزة وناعمة زي الصلصال، ألوان باستيل مريحة.', descEn: 'Soft embossed neumorphic surfaces.',
    font: '"Cairo", "Inter", system-ui, sans-serif', nav: 'float', cards: 'clay', header: 'large', overview: 'ring', timeline: 'cards',
    radius: { card: 28, ctl: 20, ctlS: 14, sheet: 32 }, swatch: ['#e6e9f0', '#7c83fd', '#ffffff'],
    light: P('#e6e9f0', '#e6e9f0', '#dde1ea', 'rgba(0,0,0,.04)', '#2b2f3a', '#62697a', '#9aa1b2', '#6d75f5', '#fff', { shadow: '9px 9px 20px #c3c8d4, -9px -9px 20px #ffffff', float: '12px 12px 28px #bfc4d1, -10px -10px 24px #ffffff', cardBorder: 'transparent' }),
    dark: P('#22252d', '#22252d', '#2a2e37', 'rgba(255,255,255,.04)', '#eceef4', '#a3a9b8', '#6d7384', '#8f96ff', '#10121a', { shadow: '8px 8px 18px #181a20, -8px -8px 18px #2c3039', float: '12px 12px 28px #14161b, -8px -8px 22px #2e323c', cardBorder: 'transparent' }),
  },
  {
    id: 'amoled', ar: 'ليل أسود (AMOLED)', en: 'AMOLED Night', descAr: 'أسود حقيقي يوفر البطارية، حدود رفيعة ولون نيون هادي.', descEn: 'True black, thin outlines, mint neon.',
    font: '"Almarai", "Inter", system-ui, sans-serif', nav: 'bar', cards: 'outline', header: 'compact', overview: 'compact', timeline: 'lines',
    radius: { card: 14, ctl: 12, ctlS: 8, sheet: 22 }, forceDark: true, swatch: ['#000000', '#00e5a8', '#1a1a1f'],
    light: P('#000000', '#0b0b0d', '#151518', 'rgba(255,255,255,.14)', '#ffffff', '#b8b8c0', '#76767e', '#00e5a8', '#00150f'),
    dark: P('#000000', '#0b0b0d', '#151518', 'rgba(255,255,255,.14)', '#ffffff', '#b8b8c0', '#76767e', '#00e5a8', '#00150f', { shadow: 'none', cardBorder: 'rgba(255,255,255,.14)' }),
  },
  {
    id: 'paper', ar: 'ورق ودفتر', en: 'Paper Notebook', descAr: 'إحساس الدفتر الورق: ألوان دافية وخط أنيق وعناوين في النص.', descEn: 'Warm paper tones with elegant serif-like type.',
    font: '"El Messiri", "Inter", Georgia, serif', nav: 'bar', cards: 'flat', header: 'center', overview: 'compact', timeline: 'lines',
    radius: { card: 8, ctl: 8, ctlS: 6, sheet: 14 }, swatch: ['#f3ead8', '#a4552b', '#fbf6ea'],
    light: P('#f3ead8', '#fbf6ea', '#eadfc6', 'rgba(110,80,40,.22)', '#3b2f22', '#6d5a45', '#a08c73', '#a4552b', '#fff', { shadow: '0 1px 0 rgba(110,80,40,.12), 0 6px 14px -8px rgba(110,80,40,.25)', cardBorder: 'rgba(110,80,40,.22)' }),
    dark: P('#1f1a14', '#2a231b', '#352c22', 'rgba(255,230,190,.14)', '#f2e6d0', '#c4b196', '#8a7a64', '#e08a55', '#1b0f06', { shadow: 'none', cardBorder: 'rgba(255,230,190,.14)' }),
  },
  {
    id: 'ocean', ar: 'محيط', en: 'Ocean', descAr: 'تدرجات الأزرق والتركواز، منعش وهادي للعين.', descEn: 'Cool teal and aqua gradients.',
    font: '"Cairo", "Inter", system-ui, sans-serif', nav: 'float', cards: 'elevated', header: 'large', overview: 'hero', timeline: 'cards',
    radius: { card: 24, ctl: 18, ctlS: 12, sheet: 30 }, swatch: ['#d6f3f6', '#0ea5b7', '#0b3d5c'],
    light: P('#eaf7f8', '#ffffff', '#dcf0f3', 'rgba(8,80,100,.1)', '#0b2a3a', '#46687a', '#8aa7b4', '#0e9db0', '#fff', { page: 'linear-gradient(180deg,#d9f2f6 0%,#eaf7f8 38%,#f4fbfb 100%)', shadow: '0 1px 2px rgba(8,80,100,.05), 0 14px 32px -16px rgba(14,157,176,.35)' }),
    dark: P('#06222c', '#0b3340', '#10424f', 'rgba(150,230,240,.14)', '#e4f8fb', '#9cc5cf', '#5f8794', '#32c6d8', '#032027', { page: 'linear-gradient(180deg,#073440 0%,#06222c 45%,#041a22 100%)', shadow: '0 14px 32px -16px rgba(0,0,0,.7)' }),
  },
  {
    id: 'sunset', ar: 'غروب', en: 'Sunset', descAr: 'ألوان الغروب الدافية: برتقالي ووردي وبنفسجي.', descEn: 'Warm orange, pink and violet.',
    font: '"Readex Pro", "Inter", system-ui, sans-serif', nav: 'dock', cards: 'elevated', header: 'large', overview: 'hero', timeline: 'cards',
    radius: { card: 26, ctl: 18, ctlS: 12, sheet: 32 }, swatch: ['#ffd9b8', '#f0643c', '#c24d8f'],
    light: P('#fff3ea', '#ffffff', '#ffe6d6', 'rgba(150,60,30,.12)', '#34190f', '#7a4a38', '#b58a78', '#e8582f', '#fff', { page: 'linear-gradient(170deg,#ffe3cc 0%,#ffeee4 35%,#fff6f0 70%,#ffeaf1 100%)', shadow: '0 1px 2px rgba(150,60,30,.06), 0 14px 32px -16px rgba(232,88,47,.35)' }),
    dark: P('#1d0f13', '#2b161b', '#381d24', 'rgba(255,190,160,.14)', '#ffece4', '#d6aa9b', '#8f6d62', '#ff7a4f', '#2a0e05', { page: 'linear-gradient(170deg,#3a1520 0%,#2a1018 40%,#1d0f13 100%)', shadow: '0 14px 32px -16px rgba(0,0,0,.7)' }),
  },
  {
    id: 'forest', ar: 'غابة', en: 'Forest', descAr: 'أخضر طبيعي مريح للعين، حواف دايرية وإحساس هادي.', descEn: 'Calm natural greens.',
    font: '"Tajawal", "Inter", system-ui, sans-serif', nav: 'bar', cards: 'flat', header: 'large', overview: 'ring', timeline: 'cards',
    radius: { card: 20, ctl: 14, ctlS: 10, sheet: 26 }, swatch: ['#eef5ec', '#2f8f5b', '#c9e4cf'],
    light: P('#eef5ec', '#fbfefb', '#e0eedd', 'rgba(30,90,50,.14)', '#15281c', '#4b6a56', '#8aa593', '#2c8a56', '#fff', { shadow: '0 1px 0 rgba(30,90,50,.08)', cardBorder: 'rgba(30,90,50,.12)' }),
    dark: P('#0e1a13', '#15271b', '#1c3425', 'rgba(170,240,190,.12)', '#e6f6ea', '#a2c4ad', '#668573', '#4fcf86', '#03180c', { shadow: 'none', cardBorder: 'rgba(170,240,190,.12)' }),
  },
  {
    id: 'ramadan', ar: 'رمضان كريم', en: 'Ramadan', descAr: 'كحلي وذهبي بزخارف رمضانية، وخط مزخرف.', descEn: 'Midnight blue and gold.',
    font: '"El Messiri", "Inter", system-ui, serif', nav: 'float', cards: 'outline', header: 'center', overview: 'hero', timeline: 'cards',
    radius: { card: 20, ctl: 14, ctlS: 10, sheet: 28 }, forceDark: true, swatch: ['#0f1b3d', '#f2c14e', '#172552'],
    light: P('#0f1b3d', '#172552', '#1f306a', 'rgba(242,193,78,.28)', '#fdf3d6', '#d8c995', '#9a8f66', '#f2c14e', '#1b1400'),
    dark: P('#0f1b3d', '#172552', '#1f306a', 'rgba(242,193,78,.28)', '#fdf3d6', '#d8c995', '#9a8f66', '#f2c14e', '#1b1400', {
      page: 'radial-gradient(600px 400px at 85% -5%, rgba(242,193,78,.18) 0%, transparent 60%), radial-gradient(500px 360px at 0% 30%, rgba(94,114,235,.22) 0%, transparent 60%), #0f1b3d',
      shadow: '0 12px 30px -14px rgba(0,0,0,.7)', cardBorder: 'rgba(242,193,78,.3)' }),
  },
  {
    id: 'techno', ar: 'تقني (Terminal)', en: 'Terminal', descAr: 'شكل المبرمجين: خط أحادي المسافة ولون أخضر فسفوري.', descEn: 'Monospace, phosphor green.',
    font: 'ui-monospace, "SFMono-Regular", Menlo, Consolas, "Tajawal", monospace', nav: 'bar', cards: 'neon', header: 'compact', overview: 'compact', timeline: 'lines',
    radius: { card: 4, ctl: 4, ctlS: 3, sheet: 8 }, forceDark: true, swatch: ['#06100a', '#39ff88', '#0d1f14'],
    light: P('#06100a', '#0b1a10', '#102618', 'rgba(57,255,136,.28)', '#d8ffe6', '#8fd1a6', '#4f8a64', '#39ff88', '#02130a'),
    dark: P('#06100a', '#0b1a10', '#102618', 'rgba(57,255,136,.28)', '#d8ffe6', '#8fd1a6', '#4f8a64', '#39ff88', '#02130a', { shadow: '0 0 0 1px rgba(57,255,136,.15), 0 0 18px -6px rgba(57,255,136,.35)', cardBorder: 'rgba(57,255,136,.3)' }),
  },
  {
    id: 'rose', ar: 'باستيل وردي', en: 'Pastel Rose', descAr: 'ألوان باستيل وردية ناعمة ومريحة جدًا.', descEn: 'Gentle pastel pinks.',
    font: '"Cairo", "Inter", system-ui, sans-serif', nav: 'float', cards: 'flat', header: 'large', overview: 'ring', timeline: 'cards',
    radius: { card: 28, ctl: 20, ctlS: 14, sheet: 32 }, swatch: ['#fff0f4', '#e85d8a', '#ffd6e3'],
    light: P('#fff0f4', '#ffffff', '#ffe3ec', 'rgba(190,60,100,.12)', '#3a1624', '#86485f', '#c294a4', '#e04d7d', '#fff', { page: 'linear-gradient(180deg,#ffe3ec 0%,#fff0f4 40%,#fff7f9 100%)', shadow: '0 10px 28px -18px rgba(224,77,125,.45)' }),
    dark: P('#1f0f16', '#2d1822', '#3a202d', 'rgba(255,170,200,.14)', '#ffe9f0', '#d6a2b7', '#8f6678', '#ff7aa5', '#2a0716', { shadow: '0 10px 28px -18px rgba(0,0,0,.7)' }),
  },
  {
    id: 'mono', ar: 'مينيمال', en: 'Minimal Mono', descAr: 'أبيض وأسود بخطوط رفيعة وبدون زحمة.', descEn: 'Hairline black & white.',
    font: `${SANS_LATIN}, "IBM Plex Sans Arabic", system-ui, sans-serif`, nav: 'bar', cards: 'outline', header: 'compact', overview: 'compact', timeline: 'lines',
    radius: { card: 4, ctl: 4, ctlS: 3, sheet: 10 }, swatch: ['#ffffff', '#111111', '#e5e5e5'],
    light: P('#ffffff', '#ffffff', '#f4f4f5', 'rgba(0,0,0,.16)', '#0a0a0a', '#52525b', '#a1a1aa', '#111111', '#ffffff', { shadow: 'none', cardBorder: 'rgba(0,0,0,.16)' }),
    dark: P('#0a0a0a', '#0a0a0a', '#171717', 'rgba(255,255,255,.18)', '#fafafa', '#a1a1aa', '#71717a', '#fafafa', '#0a0a0a', { shadow: 'none', cardBorder: 'rgba(255,255,255,.18)' }),
  },
];

export const getTheme = (id: string): ThemeDef => THEMES.find((t) => t.id === id) ?? THEMES[0];

function vars(t: ThemeDef, p: Palette): string {
  const cardBg = p.cardBg ?? (t.cards === 'outline' || t.cards === 'neon' ? 'transparent' : p.surface);
  return [
    `--bg:${p.bg}`, `--surface:${p.surface}`, `--surface-2:${p.surface2}`, `--line:${p.line}`, `--ink:${p.ink}`, `--ink-2:${p.ink2}`, `--ink-3:${p.ink3}`,
    `--accent:${p.accent}`, `--accent-ink:${p.accentInk}`, `--accent-soft:color-mix(in srgb, ${p.accent} 15%, transparent)`,
    `--elevated:color-mix(in srgb, ${p.bg} 78%, transparent)`,
    `--page-bg:${p.page ?? p.bg}`, `--shadow-card:${p.shadow ?? 'none'}`, `--shadow-float:${p.float ?? p.shadow ?? 'none'}`,
    `--card-bg:${cardBg}`, `--card-border:${p.cardBorder ?? p.line}`, `--card-blur:${p.blur ?? 'none'}`,
    `--r-card:${t.radius.card}px`, `--r-ctl:${t.radius.ctl}px`, `--r-ctl-s:${t.radius.ctlS}px`, `--r-sheet:${t.radius.sheet}px`, `--font-sans:${t.font}`,
  ].join(';');
}

export function themeCss(): string {
  return THEMES.map((t) => {
    const sel = `[data-theme="${t.id}"]`;
    const dark = `.dark${sel},.dark ${sel},${sel}.dark`;
    return `${sel}{${vars(t, t.light)}}\n${dark}{${vars(t, t.dark)}}`;
  }).join('\n');
}

let injected = false;
export function ensureThemeStyles() {
  if (injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.id = 'df-themes';
  el.textContent = themeCss();
  document.head.appendChild(el);
  injected = true;
}
ensureThemeStyles();

/** Applies structural attributes to <html>. Returns whether dark mode must be forced. */
export function applyThemeAttributes(root: HTMLElement, id: string) {
  const t = getTheme(id);
  root.dataset.theme = t.id; root.dataset.nav = t.nav; root.dataset.cards = t.cards; root.dataset.header = t.header; root.dataset.overview = t.overview; root.dataset.timeline = t.timeline;
  return t;
}
