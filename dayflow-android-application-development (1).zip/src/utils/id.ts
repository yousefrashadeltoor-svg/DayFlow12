/** Collision-resistant, sortable id (time prefix + crypto random). */
export function uid(prefix = ''): string {
  const t = Date.now().toString(36);
  const r = new Uint8Array(8);
  (globalThis.crypto ?? (globalThis as unknown as { msCrypto: Crypto }).msCrypto).getRandomValues(r);
  const rand = Array.from(r, (b) => b.toString(36).padStart(2, '0')).join('').slice(0, 12);
  return `${prefix}${t}${rand}`;
}
