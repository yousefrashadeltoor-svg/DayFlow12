/** Storage / history helpers that never throw (sandboxed iframes and some WebViews deny these APIs). */
export const safeSession = {
  get(k: string): string | null { try { return sessionStorage.getItem(k); } catch { return null; } },
  set(k: string, v: string) { try { sessionStorage.setItem(k, v); } catch { /* denied */ } },
};
export function safePush(state: unknown) { try { history.pushState(state, ''); return true; } catch { return false; } }
export function safeBack() { try { history.back(); return true; } catch { return false; } }
