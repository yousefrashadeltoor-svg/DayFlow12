import type { DateKey, Lang } from '@/models/types';

export const pad = (n: number) => String(n).padStart(2, '0');

export function toDateKey(d: Date): DateKey {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export function todayKey(): DateKey { return toDateKey(new Date()); }

export function parseDateKey(k: DateKey): Date {
  const [y, m, d] = k.split('-').map(Number);
  return new Date(y, m - 1, d);
}
export function isValidDateKey(k: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(k)) return false;
  const d = parseDateKey(k);
  return toDateKey(d) === k;
}
export function addDays(k: DateKey, n: number): DateKey {
  const d = parseDateKey(k);
  d.setDate(d.getDate() + n);
  return toDateKey(d);
}
export function diffDays(a: DateKey, b: DateKey): number {
  // b - a in whole days, DST safe (uses UTC noon)
  const pa = parseDateKey(a), pb = parseDateKey(b);
  const ua = Date.UTC(pa.getFullYear(), pa.getMonth(), pa.getDate());
  const ub = Date.UTC(pb.getFullYear(), pb.getMonth(), pb.getDate());
  return Math.round((ub - ua) / 86400000);
}
export function weekday(k: DateKey): number { return parseDateKey(k).getDay(); }
export function startOfWeek(k: DateKey, weekStart: number): DateKey {
  const wd = weekday(k);
  const delta = (wd - weekStart + 7) % 7;
  return addDays(k, -delta);
}
export function rangeKeys(start: DateKey, days: number): DateKey[] {
  return Array.from({ length: days }, (_, i) => addDays(start, i));
}
export function monthGrid(k: DateKey, weekStart: number): DateKey[] {
  const d = parseDateKey(k);
  const first = toDateKey(new Date(d.getFullYear(), d.getMonth(), 1));
  const start = startOfWeek(first, weekStart);
  return rangeKeys(start, 42);
}
export function nowMinutes(d = new Date()): number { return d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60; }

/** epoch ms for local date + minute offset (handles minutes beyond 1440 for cross-midnight blocks) */
export function epochOf(k: DateKey, minute: number): number {
  const d = parseDateKey(k);
  d.setMinutes(Math.round(minute));
  return d.getTime();
}
export function minuteOfEpoch(ms: number): number { const d = new Date(ms); return d.getHours() * 60 + d.getMinutes(); }

export function localeOf(lang: Lang) { return lang === 'ar' ? 'ar-EG' : 'en-US'; }

export function fmtNumber(n: number, lang: Lang, digits = 0): string {
  return new Intl.NumberFormat(localeOf(lang), { maximumFractionDigits: digits, minimumFractionDigits: 0 }).format(n);
}

export function fmtTime(minute: number, lang: Lang, clock24: boolean): string {
  const m = ((Math.round(minute) % 1440) + 1440) % 1440;
  const d = new Date(2000, 0, 1, Math.floor(m / 60), m % 60);
  return new Intl.DateTimeFormat(localeOf(lang), { hour: 'numeric', minute: '2-digit', hour12: !clock24 }).format(d);
}
export function fmtClock(ms: number, lang: Lang, clock24: boolean): string {
  return new Intl.DateTimeFormat(localeOf(lang), { hour: 'numeric', minute: '2-digit', hour12: !clock24 }).format(new Date(ms));
}
export function fmtDate(k: DateKey, lang: Lang, opts: Intl.DateTimeFormatOptions = { weekday: 'long', day: 'numeric', month: 'long' }): string {
  return new Intl.DateTimeFormat(localeOf(lang), opts).format(parseDateKey(k));
}
export function fmtDateTime(ms: number, lang: Lang, clock24: boolean): string {
  return new Intl.DateTimeFormat(localeOf(lang), { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', hour12: !clock24 }).format(new Date(ms));
}
export function weekdayName(wd: number, lang: Lang, style: 'long' | 'short' | 'narrow' = 'short'): string {
  const base = new Date(2023, 0, 1 + wd); // 2023-01-01 is Sunday
  return new Intl.DateTimeFormat(localeOf(lang), { weekday: style }).format(base);
}
export function fmtDuration(min: number, lang: Lang): string {
  const m = Math.max(0, Math.round(min));
  const h = Math.floor(m / 60), r = m % 60;
  const n = (x: number) => fmtNumber(x, lang);
  if (lang === 'ar') {
    if (h && r) return `${n(h)} س ${n(r)} د`;
    if (h) return `${n(h)} س`;
    return `${n(r)} د`;
  }
  if (h && r) return `${h}h ${r}m`;
  if (h) return `${h}h`;
  return `${r}m`;
}
export function fmtCountdown(ms: number, lang: Lang): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600), m = Math.floor((total % 3600) / 60), s = total % 60;
  const str = h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
  return lang === 'ar' ? str.replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[Number(d)]) : str;
}
/** "HH:MM" or "H:MM AM/PM" -> minutes, or null if invalid */
export function parseTime(s: string): number | null {
  const t = s.trim().toLowerCase().replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
  const m = t.match(/^(\d{1,2})[:.](\d{2})\s*(am|pm|ص|م)?$/);
  if (!m) return null;
  let h = Number(m[1]); const mi = Number(m[2]);
  if (mi > 59) return null;
  const suf = m[3];
  if (suf) {
    if (h < 1 || h > 12) return null;
    const pm = suf === 'pm' || suf === 'م';
    if (h === 12) h = pm ? 12 : 0; else if (pm) h += 12;
  } else if (h > 24 || (h === 24 && mi > 0)) return null;
  return h * 60 + mi;
}
export function minToInput(min: number): string { const m = ((Math.round(min) % 1440) + 1440) % 1440; return `${pad(Math.floor(m / 60))}:${pad(m % 60)}`; }
export function inputToMin(v: string): number { const [h, m] = v.split(':').map(Number); return (h || 0) * 60 + (m || 0); }
