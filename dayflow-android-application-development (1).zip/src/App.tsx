import { lazy, Suspense, useEffect, useState } from 'react';
import { House, CalendarDays, Timer, ChartNoAxesColumn, Ellipsis, Plus, Bell, Sparkles } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { useUI, type Screen, type Tab } from '@/stores/uiStore';
import { Button, Dialog, Toasts, useHaptic, useT } from '@/components/common/ui';
import { TodayScreen } from '@/features/today/TodayScreen';
import { ActivityEditor } from '@/features/activities/ActivityEditor';
import { BlockDetailSheet, CatchUpSheet, WhatIfSheet } from '@/features/planning/ScheduleTools';
import { CommandPalette, MoreScreen } from '@/features/more/MoreScreen';
import { DecorLayer, StaticDecor } from '@/features/decor/Decor';
import { Welcome } from '@/features/onboarding/Welcome';
import { DayflowNative, isNative } from '@/services/native/dayflowNative';
import { todayKey } from '@/utils/date';
import { cn } from '@/utils/cn';
import { safeSession } from '@/utils/safe';
import '@/services/reminders/reminderSync';

const L = <T extends React.ComponentType<{ onBack: () => void }>>(f: () => Promise<{ default: T }>) => lazy(f);
const PlanScreen = lazy(() => import('@/features/planning/PlanScreen').then((m) => ({ default: m.PlanScreen })));
const FocusScreen = lazy(() => import('@/features/focus/FocusScreen').then((m) => ({ default: m.FocusScreen })));
const AssistantScreen = lazy(() => import('@/features/assistant/AssistantScreen').then((m) => ({ default: m.AssistantScreen })));
const ProgressScreen = lazy(() => import('@/features/analytics/ProgressScreen').then((m) => ({ default: m.ProgressScreen })));
const SCREENS: Record<Screen, React.ComponentType<{ onBack: () => void }>> = {
  tasks: L(() => import('@/features/tasks/TasksScreen').then((m) => ({ default: m.TasksScreen }))),
  projects: L(() => import('@/features/tasks/TasksScreen').then((m) => ({ default: m.ProjectsScreen }))),
  study: L(() => import('@/features/study/StudyScreen').then((m) => ({ default: m.StudyScreen }))),
  workouts: L(() => import('@/features/workouts/FitnessHabits').then((m) => ({ default: m.WorkoutsScreen }))),
  habits: L(() => import('@/features/workouts/FitnessHabits').then((m) => ({ default: m.HabitsScreen }))),
  wellness: L(() => import('@/features/wellness/Personal').then((m) => ({ default: m.WellnessScreen }))),
  goals: L(() => import('@/features/wellness/Personal').then((m) => ({ default: m.GoalsScreen }))),
  notes: L(() => import('@/features/wellness/Personal').then((m) => ({ default: m.NotesScreen }))),
  notifications: L(() => import('@/features/notifications/System').then((m) => ({ default: m.NotificationCenter }))),
  reliability: L(() => import('@/features/notifications/System').then((m) => ({ default: m.ReliabilityCenter }))),
  backup: L(() => import('@/features/notifications/System').then((m) => ({ default: m.BackupScreen }))),
  settings: L(() => import('@/features/settings/SettingsHub').then((m) => ({ default: m.SettingsHub }))),
  set_look: L(() => import('@/features/settings/SettingsHub').then((m) => ({ default: m.SetLook }))),
  set_plan: L(() => import('@/features/settings/SettingsHub').then((m) => ({ default: m.SetPlan }))),
  set_alerts: L(() => import('@/features/settings/SettingsHub').then((m) => ({ default: m.SetAlerts }))),
  set_sound: L(() => import('@/features/settings/SettingsHub').then((m) => ({ default: m.SetSound }))),
  set_study: L(() => import('@/features/settings/SettingsHub').then((m) => ({ default: m.SetStudy }))),
  set_data: L(() => import('@/features/settings/SettingsHub').then((m) => ({ default: m.SetData }))),
  rules: L(() => import('@/features/settings/SettingsScreens').then((m) => ({ default: m.RulesScreen }))),
  templates: L(() => import('@/features/settings/SettingsScreens').then((m) => ({ default: m.TemplatesScreen }))),
  history: L(() => import('@/features/settings/SettingsScreens').then((m) => ({ default: m.HistoryScreen }))),
  about: L(() => import('@/features/settings/SettingsScreens').then((m) => ({ default: m.AboutScreen }))),
  prayer: L(() => import('@/features/prayer/PrayerScreen').then((m) => ({ default: m.PrayerScreen }))),
  alarms: L(() => import('@/features/alarms/AlarmsScreen').then((m) => ({ default: m.AlarmsScreen }))),
  calendar: L(() => import('@/features/calendar/CalendarScreen').then((m) => ({ default: m.CalendarScreen }))),
  journal: L(() => import('@/features/journal/JournalScreen').then((m) => ({ default: m.JournalScreen }))),
  ai_providers: L(() => import('@/features/assistant/Providers').then((m) => ({ default: m.ProvidersScreen }))),
  decor: L(() => import('@/features/decor/DecorGallery').then((m) => ({ default: m.DecorGallery }))),
  themes: L(() => import('@/features/themes/ThemeScreen').then((m) => ({ default: m.ThemeScreen }))),
};

function Loading() {
  return <div className="mx-auto max-w-2xl space-y-3 p-4 pt-16"><div className="skeleton h-8 w-40 rounded-xl" /><div className="skeleton h-32 rounded-3xl" /><div className="skeleton h-20 rounded-3xl" /></div>;
}

function BottomNav() {
  const { t } = useT();
  const h = useHaptic();
  const tab = useUI((s) => s.tab);
  const setTab = useUI((s) => s.setTab);
  const openEditor = useUI((s) => s.openEditor);
  const items: [Tab, React.ReactNode, string][] = [
    ['today', <House size={21} />, t('nav_today')], ['plan', <CalendarDays size={21} />, t('nav_plan')], ['focus', <Timer size={21} />, t('nav_focus')],
    ['assistant', <Sparkles size={21} />, t('nav_assistant')], ['progress', <ChartNoAxesColumn size={21} />, t('nav_progress')], ['more', <Ellipsis size={21} />, t('nav_more')],
  ];
  const btn = ([id, icon, label]: (typeof items)[number]) => (
    <button key={id} onClick={() => { h(6); setTab(id); }} aria-current={tab === id ? 'page' : undefined} aria-label={label}
      className={cn('nav-item press flex flex-1 flex-col items-center gap-0.5 py-1.5 text-[10px] font-bold transition-colors', tab === id ? 'text-accent' : 'text-ink-3')}>
      <span className="nav-pill">{icon}</span><span className="nav-label">{label}</span>
    </button>
  );
  return (
    <nav className="app-nav safe-bottom">
      <div className="mx-auto flex max-w-2xl items-end px-2 pt-1">
        {items.slice(0, 3).map(btn)}
        <div className="flex flex-1 justify-center">
          <button aria-label={t('create')} onClick={() => { h(14); openEditor({ date: todayKey() }); }} className="press -mt-5 grid h-14 w-14 place-items-center rounded-[20px] bg-accent text-accent-ink shadow-float"><Plus size={26} strokeWidth={2.4} /></button>
        </div>
        {items.slice(3).map(btn)}
      </div>
    </nav>
  );
}

/** Asks for POST_NOTIFICATIONS in context (only on Android, only once activities with reminders exist). */
function PermissionPrompt() {
  const { t } = useT();
  const caps = useApp((s) => s.caps);
  const activities = useApp((s) => s.data.activities);
  const hasReminders = Object.values(activities).some((b) => b.reminder?.enabled && b.applied !== false && b.date >= todayKey());
  const onboarded = useApp((s) => s.data.settings.app.onboarded);
  const [dismissed, setDismissed] = useState(() => safeSession.get('df-perm') === '1');
  const open = isNative() && onboarded && hasReminders && !dismissed && caps?.notificationPermission === 'prompt';
  const close = () => { safeSession.set('df-perm', '1'); setDismissed(true); };
  return (
    <Dialog open={!!open} title={<span className="flex items-center gap-2"><Bell size={18} className="text-accent" />{t('perm_notif_title')}</span>} body={t('perm_notif_body')} onClose={close}
      actions={[{ label: t('perm_allow'), variant: 'primary', onClick: async () => { await DayflowNative.requestNotificationPermission().catch(() => undefined); await useApp.getState().refreshCaps(); close(); } }, { label: t('perm_later'), onClick: close }]} />
  );
}

export default function App() {
  const ready = useApp((s) => s.ready);
  const fatal = useApp((s) => s.fatal);
  const tab = useUI((s) => s.tab);
  const stack = useUI((s) => s.stack);
  const pop = useUI((s) => s.pop);
  const engine = useApp((s) => s.engine);
  const { t } = useT();
  useEffect(() => {
    useApp.getState().init().then(async () => {
      try { const { refreshProviderModels } = await import('@/services/ai/agent'); const { providerById } = await import('@/services/ai/providers');
        const p = providerById('openrouter')!; const cfg = useApp.getState().data.settings.app.ai.providers.openrouter;
        if (!cfg?.modelsFetchedAt || Date.now() - cfg.modelsFetchedAt > 6 * 3600e3) refreshProviderModels(p, true).catch(() => undefined);
      } catch { /* offline is fine */ }
    });
  }, []);
  useEffect(() => {
    const open = (e: Event) => { const screen = (e as CustomEvent).detail as Screen; if (screen in SCREENS) { useUI.getState().setTab('more'); useUI.getState().push(screen); } };
    window.addEventListener('dayflow:openScreen', open);
    return () => window.removeEventListener('dayflow:openScreen', open);
  }, []);
  useEffect(() => { window.scrollTo({ top: 0 }); }, [tab, stack.length]);

  if (fatal) return <div className="grid min-h-full place-items-center p-6 text-center"><div><h1 className="text-xl font-bold">DAYFLOW</h1><p className="mt-2 text-sm text-danger">{fatal}</p><Button className="mt-4" onClick={() => location.reload()}>↻</Button></div></div>;
  if (!ready) return <Loading />;

  const top = stack[stack.length - 1];
  const Sub = top ? SCREENS[top] : null;
  return (
    <div className="relative min-h-full">
      <div className="bg-layer" aria-hidden />
      <Suspense fallback={<Loading />}>
        <div key={top ?? tab} className="anim-page">
          {Sub ? <Sub onBack={pop} /> : (
            <>
              {tab === 'today' && <TodayScreen />}
              {tab === 'plan' && <PlanScreen />}
              {tab === 'focus' && <FocusScreen />}
              {tab === 'assistant' && <AssistantScreen />}
              {tab === 'progress' && <ProgressScreen />}
              {tab === 'more' && <MoreScreen />}
            </>
          )}
        </div>
      </Suspense>
      {engine === 'memory' && <div className="fixed inset-x-0 top-0 z-[75] bg-warning px-3 py-1.5 text-center text-[12px] font-bold text-white safe-top">{t('memory_mode')}</div>}
      <DecorLayer />
      <StaticDecor />
      <BottomNav />
      <ActivityEditor />
      <BlockDetailSheet />
      <CatchUpSheet />
      <WhatIfSheet />
      <CommandPalette />
      <PermissionPrompt />
      <Welcome />
      <Toasts />
    </div>
  );
}
