import { useEffect, useState } from 'react';
import { RefreshCw, ShieldCheck, ShieldAlert, Bell, AlarmClock, BatteryWarning, RotateCcw, Volume2, Upload, Download, Lock, FileSpreadsheet, Search } from 'lucide-react';
import { useApp, instantiate } from '@/stores/appStore';
import { Badge, Button, Card, Chip, Field, Input, Page, ScreenHeader, SectionTitle, Segmented, Select, Sheet, Toggle, useConfirm, useSettings, useT } from '@/components/common/ui';
import { DayflowNative, isNative, errorMessage, errorCode, pickFile, saveFile, type AlarmStatus, type Capabilities } from '@/services/native/dayflowNative';
import { syncReminders } from '@/services/reminders/reminderSync';
import { fmtDateTime, fmtNumber, todayKey } from '@/utils/date';
import { buildBackup, countRecords, diffBackup, isEncrypted, parseBackup, planRestore, serializeBackup, type BackupFile, type BackupDiff } from '@/services/backup/backup';
import { autoMap, parseCSV, parseXLSX, TARGET_FIELDS, toCSV, toXLSXBase64, validateActivities, validateExercises, validateHabits, validateStudy, validateTasks, activitiesToRows, type ImportTarget, type RowResult } from '@/services/import/csv';
import { coreFrom } from '@/services/defaults';
import { uid } from '@/utils/id';
import { minToInput } from '@/utils/date';
import type { TKey } from '@/services/localization/i18n';
import type { Collections } from '@/models/types';

export function NotificationCenter({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const report = useApp((st) => st.syncReport);
  const [status, setStatus] = useState<AlarmStatus | null>(null);
  const [tab, setTab] = useState<'upcoming' | 'delivered' | 'actions'>('upcoming');
  const [q, setQ] = useState('');
  const refresh = async () => { if (isNative()) setStatus(await DayflowNative.getScheduledAlarmStatus().catch(() => null)); };
  useEffect(() => { refresh(); }, []);
  const sync = async () => { const r = await syncReminders(useApp.getState()); if (r.ok) useApp.getState().toast('success', t('synced', { n: r.scheduled })); else if (r.error !== 'UNSUPPORTED') useApp.getState().toast('error', t('sync_failed', { n: r.failures })); refresh(); };
  const match = (x: string) => !q || x.toLowerCase().includes(q.toLowerCase());
  return (
    <div>
      <ScreenHeader title={t('m_notifications')} onBack={onBack} actions={<Button size="sm" variant="tinted" icon={<RefreshCw size={14} />} onClick={sync}>{t('sync_now')}</Button>} />
      <Page>
        {!isNative() && <p className="mb-3 rounded-2xl bg-warning/12 p-3 text-sm text-warning">{t('web_no_native')}</p>}
        {report && <Card className="mb-3 p-3 text-sm"><div className="flex flex-wrap gap-1.5"><Badge tone={report.ok ? 'success' : report.error === 'UNSUPPORTED' ? 'neutral' : 'danger'}>{report.ok ? t('synced', { n: report.scheduled }) : report.error === 'UNSUPPORTED' ? t('unsupported') : t('sync_failed', { n: report.failures })}</Badge>{report.exactAllowed === false && <Badge tone="warning">{t('inexact')}</Badge>}<Badge>{fmtDateTime(report.at, lang, s.clock24)}</Badge></div>{report.error && report.error !== 'UNSUPPORTED' && <p className="mt-1 text-xs text-danger">{report.error}</p>}</Card>}
        <div className="mb-3 flex items-center gap-2 rounded-xl bg-surface-2 px-3"><Search size={16} className="text-ink-3" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('search')} className="h-10 flex-1 bg-transparent outline-none" /></div>
        <Segmented value={tab} onChange={setTab} size="sm" options={[{ value: 'upcoming', label: t('rc_upcoming') }, { value: 'delivered', label: t('rc_delivered') }, { value: 'actions', label: t('rc_actions') }]} />
        {tab === 'upcoming' && <Card className="mt-3 divide-y divide-line">{(isNative() ? status?.upcoming ?? [] : (report?.planned ?? []).map((p) => ({ ...p, exact: false, state: 'planned' }))).filter((a) => match(a.title)).map((a) => (
          <div key={a.alarmKey} className="flex items-center gap-3 p-3"><Bell size={16} className="text-accent" /><div className="min-w-0 flex-1"><div className="truncate text-sm font-medium">{a.title}</div><div className="text-xs text-ink-3">{fmtDateTime(a.triggerAt, lang, s.clock24)} · {a.kind}</div></div>
            {isNative() ? <Badge tone={a.exact ? 'success' : 'warning'}>{a.exact ? t('exact') : t('inexact')}</Badge> : <Badge>{t('pending')}</Badge>}</div>
        ))}{!(isNative() ? status?.upcoming.length : report?.planned.length) && <p className="p-3 text-sm text-ink-3">{t('empty_generic')}</p>}</Card>}
        {tab === 'delivered' && <Card className="mt-3 p-3 text-sm">{isNative() && status ? <><div className="flex justify-between"><span>{t('rc_delivered')}</span><b>{fmtNumber(status.deliveredCount, lang)}</b></div><div className="flex justify-between"><span>{t('rc_missed')}</span><b className="text-warning">{fmtNumber(status.missedCount, lang)}</b></div></> : t('native_only')}</Card>}
        {tab === 'actions' && <Card className="mt-3 divide-y divide-line">{isNative() && status ? status.recentActions.filter((a) => match(a.action)).map((a, i) => (
          <div key={i} className="flex items-center justify-between p-3 text-sm"><span>{a.action} · <span className="text-ink-3">{useApp.getState().data.activities[a.blockId]?.title ?? a.alarmKey}</span></span><span className="flex gap-1"><Badge tone={a.result === 'ok' || a.result === 'delivered' ? 'success' : a.result.startsWith('blocked') || a.result.startsWith('error') ? 'danger' : 'neutral'}>{a.result}</Badge></span></div>
        )) : <p className="p-3 text-sm text-ink-3">{t('native_only')}</p>}</Card>}
      </Page>
    </div>
  );
}

export function ReliabilityCenter({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const [caps, setCaps] = useState<Capabilities | null>(null);
  const [status, setStatus] = useState<AlarmStatus | null>(null);
  const refresh = async () => {
    if (!isNative()) return;
    setCaps(await DayflowNative.getPlatformCapabilities().catch(() => null));
    setStatus(await DayflowNative.getScheduledAlarmStatus().catch(() => null));
  };
  useEffect(() => { refresh(); const f = () => document.visibilityState === 'visible' && refresh(); document.addEventListener('visibilitychange', f); return () => document.removeEventListener('visibilitychange', f); }, []);
  if (!isNative()) return (<div><ScreenHeader title={t('rel_title')} onBack={onBack} /><Page><p className="rounded-2xl bg-warning/12 p-4 text-sm text-warning">{t('web_no_native')}</p></Page></div>);
  const notifOk = caps?.notificationPermission === 'granted';
  const exactOk = !!caps?.exactAlarmAllowed;
  const batteryOk = !!caps?.ignoringBatteryOptimizations;
  const allOk = notifOk && exactOk;
  const Row = ({ ok, icon, title, why, action, value }: { ok: boolean | null; icon: React.ReactNode; title: string; why?: string; action?: React.ReactNode; value?: React.ReactNode }) => (
    <div className="flex items-start gap-3 p-4"><span className={ok == null ? 'text-ink-3' : ok ? 'text-success' : 'text-warning'}>{icon}</span><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-2"><span className="font-medium">{title}</span>{value}</div>{why && !ok && <p className="mt-1 text-xs text-ink-2">{why}</p>}{action && !ok && <div className="mt-2">{action}</div>}</div></div>
  );
  return (
    <div>
      <ScreenHeader title={t('rel_title')} onBack={onBack} actions={<Button size="sm" variant="ghost" icon={<RefreshCw size={14} />} onClick={refresh} />} />
      <Page>
        <Card className={`mb-3 flex items-center gap-3 p-4 ${allOk ? 'bg-success/8' : 'bg-warning/10'}`}>{allOk ? <ShieldCheck className="text-success" /> : <ShieldAlert className="text-warning" />}<p className="text-sm font-medium">{allOk ? t('rel_all_good') : t('rel_not_guaranteed')}</p></Card>
        <Card className="divide-y divide-line">
          <Row ok={notifOk} icon={<Bell size={20} />} title={t('rel_notif')} why={t('rel_notif_why')} value={<Badge tone={notifOk ? 'success' : 'warning'}>{t(notifOk ? 'granted' : caps?.notificationPermission === 'denied' ? 'denied' : 'permission_required')}</Badge>}
            action={<Button size="sm" onClick={async () => { await DayflowNative.requestNotificationPermission().catch(() => undefined); refresh(); }}>{t('rel_request')}</Button>} />
          <Row ok={exactOk} icon={<AlarmClock size={20} />} title={t('rel_exact')} why={t('rel_exact_why')} value={<Badge tone={exactOk ? 'success' : 'warning'}>{t(exactOk ? 'granted' : 'permission_required')}</Badge>}
            action={<Button size="sm" onClick={() => DayflowNative.requestExactAlarmPermission()}>{t('rel_open_settings')}</Button>} />
          <Row ok={!!caps?.fullScreenIntentAllowed} icon={<AlarmClock size={20} />} title={t('rel_fullscreen')} why={t('rel_fullscreen_why')} value={<Badge tone={caps?.fullScreenIntentAllowed ? 'success' : 'warning'}>{caps?.fullScreenIntentAllowed ? t('granted') : t('permission_required')}</Badge>}
            action={<Button size="sm" onClick={() => DayflowNative.openFullScreenIntentSettings()}>{t('rel_open_settings')}</Button>} />
          <Row ok={batteryOk} icon={<BatteryWarning size={20} />} title={t('rel_battery')} why={`${t('rel_battery_why')} ${t('manufacturer_tip', { m: caps?.manufacturer ?? '' })}`} value={<Badge tone={batteryOk ? 'success' : 'warning'}>{batteryOk ? t('enabled') : t('permission_required')}{caps?.powerSaveMode ? ' · ⚡' : ''}</Badge>}
            action={<Button size="sm" variant="secondary" onClick={() => DayflowNative.requestBatterySettings()}>{t('rel_open_settings')}</Button>} />
          <Row ok={null} icon={<AlarmClock size={20} />} title={t('rel_pending')} value={<b className="num">{fmtNumber(status?.pendingCount ?? 0, lang)}</b>} />
          <Row ok={null} icon={<Bell size={20} />} title={t('rel_next')} value={<span className="text-sm text-ink-2">{status?.next ? `${status.next.title} · ${fmtDateTime(status.next.triggerAt, lang, s.clock24)}` : t('rel_never')}</span>} />
          <Row ok={null} icon={<RefreshCw size={20} />} title={t('rel_last')} value={<span className="text-sm text-ink-2">{status?.lastSyncAt ? fmtDateTime(status.lastSyncAt, lang, s.clock24) : t('rel_never')}</span>} />
          <Row ok={null} icon={<RotateCcw size={20} />} title={t('rel_reboot')} value={<span className="text-sm text-ink-2">{status?.lastRestoreAt ? `${t('rel_restored', { n: status.lastRestoreCount, r: status.lastRestoreReason ?? '' })} · ${fmtDateTime(status.lastRestoreAt, lang, s.clock24)}` : t('rel_never')}</span>} />
          <Row ok={null} icon={<Volume2 size={20} />} title={t('rel_audio')} value={<span className="text-sm text-ink-2">{caps?.lastAudioFallback ?? t('rel_never')}</span>} />
        </Card>
        <Button variant="secondary" className="mt-4 w-full" onClick={async () => { try { await DayflowNative.createNotification({ id: 4242, title: t('app_name'), body: t('rel_test') }); useApp.getState().toast('success', t('rel_test_sent')); } catch (e) { useApp.getState().toast('error', `${errorCode(e)}: ${errorMessage(e)}`); } }}>{t('rel_test')}</Button>
        <p className="mt-3 text-center text-xs text-ink-3">Android {caps?.release} (SDK {caps?.sdkInt}) · {caps?.manufacturer} {caps?.model}</p>
      </Page>
    </div>
  );
}

// ======================================================================== backup & import

export function BackupScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [encrypt, setEncrypt] = useState(false); const [pw, setPw] = useState('');
  const [restore, setRestore] = useState<{ backup?: BackupFile; text: string; needsPw: boolean; diff?: BackupDiff[]; name: string } | null>(null);
  const [rpw, setRpw] = useState('');
  const [imp, setImp] = useState<{ rows: string[][]; headers: string[]; name: string; format: string } | null>(null);
  const { ask, node } = useConfirm();

  const create = async () => {
    try {
      const b = buildBackup(data);
      const text = await serializeBackup(b, encrypt ? pw : undefined);
      const name = `dayflow-backup-${todayKey()}${encrypt ? '.enc' : ''}.json`;
      await saveFile(name, text, 'application/json');
      const n = Date.now();
      await useApp.getState().put('backups', { id: uid('bk'), kind: 'export', format: 'json', records: countRecords(b), encrypted: encrypt, fileName: name, createdAt: n, updatedAt: n });
      useApp.getState().toast('success', t('backup_created', { n: countRecords(b) }));
    } catch (e) { if (errorCode(e) !== 'CANCELLED') useApp.getState().toast('error', errorMessage(e)); }
  };
  const openRestore = async () => {
    try {
      const f = await pickFile('text', '.json,application/json', ['application/json', 'text/plain', 'application/octet-stream']);
      const text = f.text ?? '';
      if (isEncrypted(text)) { setRestore({ text, needsPw: true, name: f.name }); return; }
      const r = await parseBackup(text);
      if (!r.ok) { useApp.getState().toast('error', t('invalid_backup')); return; }
      setRestore({ text, needsPw: false, backup: r.backup, diff: diffBackup(useApp.getState().data, r.backup), name: f.name });
    } catch (e) { if (errorCode(e) !== 'CANCELLED') useApp.getState().toast('error', errorMessage(e)); }
  };
  const unlock = async () => {
    if (!restore) return;
    const r = await parseBackup(restore.text, rpw);
    if (!r.ok) { useApp.getState().toast('error', r.error === 'wrong_password' ? t('wrong_password') : t('invalid_backup')); return; }
    setRestore({ ...restore, needsPw: false, backup: r.backup, diff: diffBackup(useApp.getState().data, r.backup) });
  };
  const doRestore = async (mode: 'merge' | 'replace') => {
    if (!restore?.backup) return;
    if (mode === 'replace' && !(await ask(t('replace'), t('replace_warning'), t('replace')))) return;
    const { puts, dels } = planRestore(useApp.getState().data, restore.backup, mode);
    const n = Date.now();
    const ok = await useApp.getState().commit({ ...(puts as object), backups: [{ id: uid('bk'), kind: 'restore', format: 'json', records: countRecords(restore.backup), encrypted: restore.needsPw, fileName: restore.name, createdAt: n, updatedAt: n }] }, dels as never);
    if (ok) { useApp.getState().toast('success', t('restore_done', { n: countRecords(restore.backup) })); setRestore(null); await useApp.getState().ensureDays(todayKey(), 7); }
  };
  const openImport = async () => {
    try {
      const f = await pickFile('binary', '.csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ['text/csv', 'text/comma-separated-values', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/octet-stream', 'text/plain']);
      const isX = /\.xlsx$/i.test(f.name);
      let rows: string[][];
      if (isX) rows = await parseXLSX(f.base64!);
      else { const bin = atob(f.base64!); const bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i); rows = parseCSV(new TextDecoder('utf-8').decode(bytes)); }
      if (rows.length < 2) { useApp.getState().toast('error', t('invalid_rows')); return; }
      setImp({ headers: rows[0], rows: rows.slice(1), name: f.name, format: isX ? 'xlsx' : 'csv' });
    } catch (e) { if (errorCode(e) !== 'CANCELLED') useApp.getState().toast('error', errorMessage(e)); }
  };
  const exportActs = async (fmt: 'csv' | 'xlsx') => {
    const rows = activitiesToRows(Object.values(data.activities), (id) => data.categories[id]?.key ?? id, minToInput);
    try {
      if (fmt === 'csv') await saveFile(`dayflow-activities-${todayKey()}.csv`, toCSV(rows), 'text/csv');
      else await saveFile(`dayflow-activities-${todayKey()}.xlsx`, await toXLSXBase64(rows), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', true);
    } catch (e) { if (errorCode(e) !== 'CANCELLED') useApp.getState().toast('error', errorMessage(e)); }
  };

  return (
    <div>
      <ScreenHeader title={t('backup_title')} onBack={onBack} />
      <Page>
        {node}
        <Card className="space-y-3 p-4">
          <h3 className="flex items-center gap-2 font-semibold"><Download size={18} />{t('create_backup')}</h3>
          <Toggle checked={encrypt} onChange={setEncrypt} label={<span className="flex items-center gap-1.5"><Lock size={14} />{t('encrypt')}</span>} description="AES-256-GCM · PBKDF2" />
          {encrypt && <Field label={t('password')}><Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></Field>}
          <Button className="w-full" disabled={encrypt && pw.length < 6} onClick={create}>{t('create_backup')}</Button>
        </Card>
        <Card className="mt-3 space-y-3 p-4">
          <h3 className="flex items-center gap-2 font-semibold"><Upload size={18} />{t('restore_backup')}</h3>
          <Button variant="secondary" className="w-full" onClick={openRestore}>{t('choose_file')}</Button>
        </Card>
        <Card className="mt-3 space-y-3 p-4">
          <h3 className="flex items-center gap-2 font-semibold"><FileSpreadsheet size={18} />{t('csv_import')}</h3>
          <p className="text-xs text-ink-3">{t('xlsx_note')}</p>
          <Button variant="secondary" className="w-full" onClick={openImport}>{t('choose_file')}</Button>
          <div className="flex gap-2"><Button variant="ghost" className="flex-1" onClick={() => exportActs('csv')}>{t('export_csv')}</Button><Button variant="ghost" className="flex-1" onClick={() => exportActs('xlsx')}>XLSX</Button></div>
        </Card>
        <SectionTitle>{t('backup_history')}</SectionTitle>
        <Card className="divide-y divide-line">{Object.values(data.backups).sort((a, b) => b.createdAt - a.createdAt).slice(0, 20).map((b) => <div key={b.id} className="flex items-center justify-between p-3 text-sm"><span className="truncate">{b.fileName}</span><span className="flex shrink-0 gap-1"><Badge>{b.kind}</Badge><Badge>{fmtNumber(b.records, lang)}</Badge>{b.encrypted && <Badge tone="accent"><Lock size={10} /></Badge>}<Badge>{fmtDateTime(b.createdAt, lang, s.clock24)}</Badge></span></div>)}{!Object.keys(data.backups).length && <p className="p-3 text-sm text-ink-3">{t('empty_generic')}</p>}</Card>
      </Page>

      <Sheet open={!!restore} onClose={() => setRestore(null)} title={t('backup_preview')} tall footer={restore?.backup && <div className="flex gap-2"><Button variant="danger" className="flex-1" onClick={() => doRestore('replace')}>{t('replace')}</Button><Button className="flex-[2]" onClick={() => doRestore('merge')}>{t('merge')}</Button></div>}>
        {restore?.needsPw ? <div className="space-y-3"><Field label={t('password')}><Input type="password" value={rpw} onChange={(e) => setRpw(e.target.value)} /></Field><Button className="w-full" onClick={unlock}>{t('confirm')}</Button></div> : restore?.backup && (
          <>
            <p className="mb-3 text-sm text-ink-2">{restore.name} · {fmtDateTime(restore.backup.createdAt, lang, s.clock24)} · {fmtNumber(countRecords(restore.backup), lang)} {t('records')}</p>
            <Card className="divide-y divide-line">{restore.diff?.map((d) => <div key={d.collection} className="flex items-center justify-between p-2.5 text-sm"><span>{d.collection}</span><span className="flex gap-1"><Badge>{fmtNumber(d.incoming, lang)}</Badge><Badge tone="success">+{fmtNumber(d.added, lang)}</Badge>{d.conflicts > 0 && <Badge tone="warning">{t('conflicts')} {fmtNumber(d.conflicts, lang)}</Badge>}</span></div>)}</Card>
          </>
        )}
      </Sheet>
      {imp && <ImportSheet imp={imp} onClose={() => setImp(null)} />}
    </div>
  );
}

function ImportSheet({ imp, onClose }: { imp: { rows: string[][]; headers: string[]; name: string; format: string }; onClose: () => void }) {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [target, setTarget] = useState<ImportTarget>('activities');
  const [map, setMap] = useState<Record<string, number>>(() => autoMap(imp.headers, 'activities'));
  const [skipDup, setSkipDup] = useState(true);
  useEffect(() => { setMap(autoMap(imp.headers, target)); }, [target, imp.headers]);
  const results: RowResult<unknown>[] = target === 'activities' ? validateActivities(imp.rows, map, data, todayKey()) : target === 'tasks' ? validateTasks(imp.rows, map, data) : target === 'study' ? validateStudy(imp.rows, map, data) : target === 'exercises' ? validateExercises(imp.rows, map, data) : validateHabits(imp.rows, map, data);
  const valid = results.filter((r) => r.value && (!skipDup || !r.duplicate));
  const missingRequired = TARGET_FIELDS[target].filter((f) => f.required && map[f.key] == null);
  const run = async () => {
    const n = Date.now();
    const st = useApp.getState();
    const puts: Partial<{ [K in keyof Collections]: unknown[] }> = {};
    if (target === 'activities') puts.activities = valid.map((r) => { const v = r.value as ReturnType<typeof validateActivities>[number]['value'] & object; return instantiate(coreFrom({ title: v.title, categoryId: `cat_${v.categoryKey}`, startMin: v.startMin, durationMin: v.durationMin, fixed: v.fixed, priority: v.priority, notes: v.notes }), v.date, { source: 'import' }); });
    if (target === 'tasks') puts.tasks = valid.map((r) => ({ id: uid('t'), description: '', status: 'todo', trackedMin: 0, checklist: [], subtasks: [], dependsOn: [], starred: false, someday: false, createdAt: n, updatedAt: n, ...(r.value as object) }));
    if (target === 'habits') puts.habits = valid.map((r) => ({ id: uid('h'), icon: 'star', color: 'var(--c-rest)', category: 'personal', kind: 'check', frequency: 'daily', weekdays: [0, 1, 2, 3, 4, 5, 6], timesPerWeek: 3, target: 1, unit: '', notes: '', archived: false, createdAt: n, updatedAt: n, ...(r.value as object) }));
    if (target === 'study') {
      const subjects = new Map(Object.values(data.subjects).map((x) => [x.title.toLowerCase(), x.id]));
      const units = new Map(Object.values(data.units).map((x) => [`${x.subjectId}|${x.title.toLowerCase()}`, x.id]));
      const S: unknown[] = [], U: unknown[] = [], L: unknown[] = [];
      const b = { description: '', difficulty: 3, priority: 3, status: 'not_started', resources: [], notes: '', createdAt: n, updatedAt: n };
      for (const r of valid) { const v = r.value as { subject: string; unit: string; lesson: string; hours: number; due?: string };
        let sid = subjects.get(v.subject.toLowerCase()); if (!sid) { sid = uid('sub'); subjects.set(v.subject.toLowerCase(), sid); S.push({ ...b, id: sid, title: v.subject, color: 'var(--c-study)', estimateHours: 0 }); }
        let unid = units.get(`${sid}|${v.unit.toLowerCase()}`); if (!unid) { unid = uid('u'); units.set(`${sid}|${v.unit.toLowerCase()}`, unid); U.push({ ...b, id: unid, subjectId: sid, title: v.unit, estimateHours: 0 }); }
        L.push({ ...b, id: uid('ls'), subjectId: sid, unitId: unid, title: v.lesson, estimateHours: v.hours, dueDate: v.due }); }
      puts.subjects = S; puts.units = U; puts.lessons = L;
    }
    if (target === 'exercises') {
      const exByName = new Map(Object.values(data.exercises).map((e) => [e.name.toLowerCase(), e.id]));
      const plans = new Map(Object.values(data.workoutPlans).map((p) => [p.name.toLowerCase(), { ...p, exercises: [...p.exercises] }]));
      const E: unknown[] = [];
      for (const r of valid) { const v = r.value as { plan: string; days: number[]; exercise: string; sets: number; reps: number; rest: number };
        let eid = exByName.get(v.exercise.toLowerCase()); if (!eid) { eid = uid('ex'); exByName.set(v.exercise.toLowerCase(), eid); E.push({ id: eid, name: v.exercise, category: 'strength', equipment: '', muscles: [], instructions: '', createdAt: n, updatedAt: n }); }
        let p = plans.get(v.plan.toLowerCase()); if (!p) { p = { id: uid('wp'), name: v.plan, weekdays: v.days, startMin: 18 * 60, exercises: [], notes: '', light: false, createdAt: n, updatedAt: n }; plans.set(v.plan.toLowerCase(), p); }
        p.weekdays = [...new Set([...p.weekdays, ...v.days])]; p.exercises.push({ id: uid(), exerciseId: eid, sets: v.sets, reps: v.reps, restSec: v.rest, note: '' }); }
      puts.exercises = E; puts.workoutPlans = [...plans.values()];
    }
    const ok = await st.commit({ ...(puts as object), backups: [{ id: uid('bk'), kind: 'import', format: imp.format, records: valid.length, encrypted: false, fileName: imp.name, createdAt: n, updatedAt: n }] });
    if (ok) { st.toast('success', t('imported', { n: valid.length })); onClose(); }
  };
  return (
    <Sheet open onClose={onClose} tall title={t('import_preview')} footer={<Button className="w-full" disabled={!valid.length || missingRequired.length > 0} onClick={run}>{t('import_n', { n: fmtNumber(valid.length, lang) })}</Button>}>
      <Field label={t('import_target')}><Select value={target} onChange={(v) => setTarget(v as ImportTarget)} options={(['activities', 'tasks', 'study', 'exercises', 'habits'] as const).map((k) => ({ value: k, label: t(`t_${k}` as TKey) }))} /></Field>
      <SectionTitle>{t('column_mapping')}</SectionTitle>
      <div className="space-y-2">{TARGET_FIELDS[target].map((f) => (
        <div key={f.key} className="flex items-center gap-2"><span className="w-24 text-sm">{f.key}{f.required ? ' *' : ''}</span><Select className="h-10 flex-1" value={map[f.key] != null ? String(map[f.key]) : ''} onChange={(v) => setMap({ ...map, [f.key]: v === '' ? (undefined as unknown as number) : Number(v) })} options={[{ value: '', label: t('ignore_column') }, ...imp.headers.map((h, i) => ({ value: String(i), label: h || `#${i + 1}` }))]} /></div>
      ))}</div>
      <div className="mt-4 flex flex-wrap gap-1.5"><Badge tone="success">{t('valid_rows')}: {fmtNumber(results.filter((r) => r.value).length, lang)}</Badge><Badge tone="danger">{t('invalid_rows')}: {fmtNumber(results.filter((r) => !r.value).length, lang)}</Badge><Badge tone="warning">{t('duplicates')}: {fmtNumber(results.filter((r) => r.duplicate).length, lang)}</Badge>{target === 'activities' && <Badge tone="info">{t('overlaps')}: {fmtNumber(results.filter((r) => r.overlap).length, lang)}</Badge>}</div>
      <Toggle checked={skipDup} onChange={setSkipDup} label={t('skip_duplicates')} />
      <Card className="mt-2 divide-y divide-line">{results.slice(0, 60).map((r) => (
        <div key={r.row} className="flex items-center justify-between gap-2 p-2 text-xs"><span className="num text-ink-3">#{r.row}</span><span className="min-w-0 flex-1 truncate">{imp.rows[r.row - 2]?.join(' · ')}</span>
          {r.errors.length ? r.errors.map((e) => <Chip key={e}>{t(e as TKey)}</Chip>) : r.duplicate ? <Badge tone="warning">{t('duplicates')}</Badge> : r.overlap ? <Badge tone="info">{t('overlaps')}</Badge> : <Badge tone="success">✓</Badge>}</div>
      ))}</Card>
    </Sheet>
  );
}
