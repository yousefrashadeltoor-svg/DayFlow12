import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, ExternalLink, KeyRound, Loader2, RefreshCw, Search, Wrench, XCircle, Star } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { Badge, Button, Card, Chip, Field, Input, Page, ScreenHeader, SectionTitle, Sheet, useSettings, useT } from '@/components/common/ui';
import { AiLogo } from './parts';
import { PROVIDERS, TIER_LABEL, TIER_ORDER, FACTS_CHECKED, isFreeModel, modelLogo, modelsOf, prettyModel, providerById, type ProviderDef } from '@/services/ai/providers';
export { isFreeModel, modelsOf };
import { listModels, resolveBase, AiError } from '@/services/ai/client';
import { getKeys, refreshProviderModels, setKey } from '@/services/ai/agent';
import { isNative } from '@/services/native/dayflowNative';
import type { AiProviderConfig, Settings } from '@/models/types';
import { cn } from '@/utils/cn';

const TIER_TONE = { free: 'success', trial: 'warning', paid: 'neutral', local: 'info' } as const;
export const L = (lang: string, ar: string, en: string) => (lang === 'ar' ? ar : en);

export function errorText(e: unknown, lang: string, p?: ProviderDef): string {
  const err = e as AiError; const ar = lang === 'ar';
  switch (err.code) {
    case 'auth': return err.message === 'no_endpoint' ? (ar ? 'المزوّد ده لسه مش متظبط: ضيف المفتاح من «المزوّدين».' : 'This provider is not set up yet: add its key in Providers.') : (ar ? `المفتاح غلط أو ملوش صلاحية (${err.status}).` : `Invalid key or no permission (${err.status}).`);
    case 'rate': return ar ? 'وصلت لحد الاستخدام المجاني دلوقتي. استنى شوية أو جرّب موديل/مزوّد تاني.' : 'Free usage limit reached. Wait a bit or try another model/provider.';
    case 'model': return ar ? 'الموديل ده مش موجود عند المزوّد. حدّث قايمة الموديلات واختار موديل تاني.' : 'Model not found. Refresh the model list and choose another.';
    case 'cors': return isNative() ? (ar ? 'مفيش اتصال بالإنترنت أو المزوّد مش بيرد.' : 'No internet connection or the provider is unreachable.') : (p && !p.cors ? (ar ? `${p.name} بيمنع الاتصال من المتصفح. هيشتغل عادي في تطبيق أندرويد.` : `${p.name} blocks browser calls. It works in the Android app.`) : (ar ? 'مفيش اتصال، أو المتصفح منع الطلب (CORS). في تطبيق أندرويد مفيش المشكلة دي.' : 'No connection, or the browser blocked the request (CORS). The Android app is not affected.'));
    case 'server': return ar ? `مشكلة عند المزوّد: ${err.message}` : `Provider error: ${err.message}`;
    case 'cancelled': return ar ? 'اتلغى.' : 'Cancelled.';
    default: return err.message || String(e);
  }
}

export const isReady = (s: Settings, p: ProviderDef) => (!p.needsKey || !!getKeys()[p.id]) && (!p.needsAccountId || !!s.ai.providers[p.id]?.accountId) && (p.id !== 'custom' || !!s.ai.providers[p.id]?.baseUrl);

async function patchProvider(s: Settings, id: string, patch: Partial<AiProviderConfig>) {
  const cur = s.ai.providers[id] ?? { enabled: true };
  await useApp.getState().updateSettings({ ai: { ...s.ai, providers: { ...s.ai.providers, [id]: { ...cur, ...patch } } } });
}

export function ProvidersScreen({ onBack }: { onBack: () => void }) {
  const { lang } = useT();
  const s = useSettings();
  const [open, setOpen] = useState<ProviderDef | null>(null);
  useApp((st) => st.data.state); // re-render when keys change
  return (
    <div>
      <ScreenHeader title={L(lang, 'مزوّدين الذكاء الاصطناعي', 'AI providers')} subtitle={L(lang, `${PROVIDERS.length} مزوّد — المجاني الأول`, `${PROVIDERS.length} providers — free first`)} onBack={onBack} />
      <Page>
        <div className="rounded-2xl border border-[#22a45d]/40 bg-[#22a45d]/10 p-3 text-[13px] leading-6">
          <b>{L(lang, 'ابدأ مجانًا:', 'Start free:')}</b> {L(lang, 'Groq وGoogle Gemini وOpenRouter بيدّوا استخدام مجاني متجدد من غير كارت. اعمل مفتاح من موقعهم (دقيقة واحدة) وحطّه هنا.', 'Groq, Google Gemini and OpenRouter give renewing free usage without a card. Create a key on their site (one minute) and paste it here.')}
          <div className="mt-1 text-[11.5px] text-ink-3">{L(lang, `معلومات الحدود المجانية اتراجعت ${FACTS_CHECKED} وبتتغيّر كتير — قايمة الموديلات الحقيقية بتتحمّل من المزوّد نفسه.`, `Free-tier facts checked ${FACTS_CHECKED} and change often — real model lists are loaded from each provider.`)}</div>
        </div>
        {TIER_ORDER.map((tier) => (
          <div key={tier}>
            <SectionTitle>{TIER_LABEL[tier][lang === 'ar' ? 0 : 1]}</SectionTitle>
            <div className="space-y-2">{PROVIDERS.filter((p) => p.tier === tier).sort((a, b) => a.rank - b.rank).map((p) => {
              const ready = isReady(s, p); const active = s.ai.providerId === p.id;
              return (
                <Card key={p.id} onClick={() => setOpen(p)} className={cn('flex items-start gap-3 p-3', active && 'ring-2 ring-accent')}>
                  <AiLogo name={p.logo} size={42} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5"><span className="text-[15px] font-bold">{p.name}</span><Badge tone={TIER_TONE[p.tier]}>{TIER_LABEL[p.tier][lang === 'ar' ? 0 : 1]}</Badge>{active && <Badge tone="accent"><Star size={10} />{L(lang, 'الحالي', 'Active')}</Badge>}</div>
                    <p className="mt-1 line-clamp-2 text-[12px] leading-5 text-ink-2">{lang === 'ar' ? p.freeAr : p.freeEn}</p>
                  </div>
                  {ready ? <CheckCircle2 size={20} className="mt-1 shrink-0 text-success" /> : <KeyRound size={18} className="mt-1 shrink-0 text-ink-3" />}
                </Card>
              );
            })}</div>
          </div>
        ))}
        <p className="mt-6 text-center text-[11px] leading-5 text-ink-3">{L(lang, 'المفاتيح بتتحفظ على جهازك بس، ومش بتتحط في النسخ الاحتياطية. الشعارات من LobeHub Icons (MIT).', 'Keys stay on your device and are never included in backups. Logos: LobeHub Icons (MIT).')}</p>
      </Page>
      {open && <ProviderSheet p={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

function ProviderSheet({ p, onClose }: { p: ProviderDef; onClose: () => void }) {
  const { lang } = useT();
  const s = useSettings();
  const cfg = s.ai.providers[p.id] ?? { enabled: true };
  const [key, setK] = useState(getKeys()[p.id] ?? '');
  const [baseUrl, setBase] = useState(cfg.baseUrl ?? '');
  const [account, setAccount] = useState(cfg.accountId ?? '');
  const [state, setState] = useState<{ kind: 'idle' | 'busy' | 'ok' | 'err'; msg?: string }>({ kind: 'idle' });
  const save = async () => { await setKey(p.id, key); await patchProvider(useApp.getState().data.settings.app, p.id, { enabled: true, baseUrl: baseUrl.trim() || undefined, accountId: account.trim() || undefined }); };
  const test = async () => {
    await save(); setState({ kind: 'busy' });
    try {
      const st = useApp.getState().data.settings.app;
      const models = await listModels({ provider: p, apiKey: key.trim(), baseUrl: resolveBase(p, baseUrl, account) });
      await patchProvider(st, p.id, { models: models.length ? models : undefined, modelsFetchedAt: Date.now() });
      const free = models.filter((m) => isFreeModel(p, m)).length;
      setState({ kind: 'ok', msg: L(lang, `اتصل ✓ — ${models.length} موديل${free ? `، منهم ${free} مجاني` : ''}`, `Connected ✓ — ${models.length} models${free ? `, ${free} free` : ''}`) });
    } catch (e) { setState({ kind: 'err', msg: errorText(e, lang, p) }); }
  };
  const activate = async () => {
    await save();
    const st = useApp.getState().data.settings.app;
    const list = modelsOf(st, p); const pick = list.find((m) => m.free && m.tools !== false) ?? list.find((m) => m.tools !== false) ?? list[0];
    await useApp.getState().updateSettings({ ai: { ...st.ai, providerId: p.id, modelId: pick?.id ?? st.ai.modelId } });
    onClose();
  };
  const openUrl = (u?: string) => { if (u) window.open(u, '_blank', 'noopener'); };
  return (
    <Sheet open onClose={onClose} tall title={<span className="flex items-center gap-2"><AiLogo name={p.logo} size={28} />{p.name}</span>}
      footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={async () => { await save(); onClose(); }}>{L(lang, 'احفظ', 'Save')}</Button><Button className="flex-[2]" onClick={activate} disabled={(p.needsKey && !key.trim()) || (p.needsAccountId && !account.trim())}>{L(lang, 'استخدمه', 'Use this provider')}</Button></div>}>
      <div className="space-y-4">
        <div className="rounded-2xl bg-surface-2 p-3 text-[13px] leading-6"><Badge tone={TIER_TONE[p.tier]}>{TIER_LABEL[p.tier][lang === 'ar' ? 0 : 1]}</Badge><p className="mt-1.5">{lang === 'ar' ? p.freeAr : p.freeEn}</p>
          {!p.cors && <p className="mt-1 text-[12px] text-warning">{L(lang, 'المزوّد ده مش بيقبل اتصال من المتصفح — هيشتغل في تطبيق أندرويد بس.', 'This provider does not accept browser calls — works in the Android app only.')}</p>}</div>
        {p.keyUrl && <Button variant="tinted" className="w-full" icon={<ExternalLink size={15} />} onClick={() => openUrl(p.keyUrl)}>{L(lang, 'اعمل مفتاح من الموقع', 'Get an API key')}</Button>}
        {p.needsKey && <Field label="API key"><Input type="password" value={key} onChange={(e) => setK(e.target.value)} placeholder="sk-… / gsk_… / AIza…" autoComplete="off" spellCheck={false} dir="ltr" /></Field>}
        {p.needsAccountId && <Field label="Cloudflare Account ID"><Input value={account} onChange={(e) => setAccount(e.target.value)} dir="ltr" /></Field>}
        <Field label={L(lang, 'العنوان (اختياري)', 'Base URL (optional)')} hint={p.baseUrl}><Input value={baseUrl} onChange={(e) => setBase(e.target.value)} placeholder={p.baseUrl || 'https://…/v1'} dir="ltr" /></Field>
        <Button variant="secondary" className="w-full" icon={state.kind === 'busy' ? <Loader2 size={15} className="animate-spin" /> : <RefreshCw size={15} />} disabled={state.kind === 'busy'} onClick={test}>{L(lang, 'اختبر الاتصال وحمّل الموديلات', 'Test & load models')}</Button>
        {state.msg && <div className={cn('flex items-start gap-2 rounded-xl p-3 text-[13px]', state.kind === 'ok' ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger')}>{state.kind === 'ok' ? <CheckCircle2 size={16} /> : <XCircle size={16} />}<span className="flex-1">{state.msg}</span></div>}
        <SectionTitle>{L(lang, 'الموديلات', 'Models')} · {modelsOf(s, p).length}</SectionTitle>
        <div className="space-y-1">{modelsOf(s, p).slice(0, 40).map((m) => (
          <div key={m.id} className="flex items-center gap-2 rounded-xl px-2 py-1.5 text-[13px]"><AiLogo name={modelLogo(m.id, p.logo)} size={24} /><span className="min-w-0 flex-1 truncate" dir="ltr">{m.name ?? m.id}</span>{m.free ? <Badge tone="success">{L(lang, 'مجاني', 'Free')}</Badge> : <Badge>{L(lang, 'مدفوع', 'Paid')}</Badge>}</div>
        ))}</div>
        {p.docsUrl && <button onClick={() => openUrl(p.docsUrl)} className="text-[12px] font-semibold text-accent">{L(lang, 'الحدود والتفاصيل الرسمية ←', 'Official limits →')}</button>}
      </div>
    </Sheet>
  );
}

/** Model picker across every configured provider. */
export function ModelPicker({ open, onClose, onPick }: { open: boolean; onClose: () => void; onPick: (providerId: string, modelId: string) => void }) {
  const { lang } = useT();
  const s = useSettings();
  const [q, setQ] = useState(''); const [freeOnly, setFreeOnly] = useState(s.ai.freeOnly); const [toolsOnly, setToolsOnly] = useState(false); const [all, setAll] = useState(false);
  const [refreshingId, setRefreshingId] = useState<string | null>(null);
  useEffect(() => {
    if (!open) return;
    const cur = useApp.getState().data.settings.app;
    for (const p of PROVIDERS) {
      const cfg = cur.ai.providers[p.id];
      const stale = !cfg?.modelsFetchedAt || Date.now() - cfg.modelsFetchedAt > 6 * 3600e3;
      const can = p.id === 'openrouter' || !!getKeys()[p.id];
      if (stale && can && (p.cors || isNative())) refreshProviderModels(p, true).catch(() => undefined);
    }
  }, [open]);
  const refresh = async (p: ProviderDef) => {
    setRefreshingId(p.id);
    try { const n = await refreshProviderModels(p); useApp.getState().toast(n > 0 ? 'success' : 'error', n > 0 ? L(lang, `${n} موديل اتحدّثوا`, `${n} models updated`) : L(lang, 'محتاج مفتاح الأول', 'Add a key first')); }
    catch (e) { useApp.getState().toast('error', errorText(e, lang, p)); }
    finally { setRefreshingId(null); }
  };
  const groups = useMemo(() => PROVIDERS.filter((p) => all || isReady(s, p)).sort((a, b) => TIER_ORDER.indexOf(a.tier) - TIER_ORDER.indexOf(b.tier) || a.rank - b.rank).map((p) => ({
    p, ready: isReady(s, p),
    models: modelsOf(s, p).filter((m) => (!freeOnly || m.free) && (!toolsOnly || m.tools !== false) && (!q || `${m.id} ${m.name ?? ''} ${p.name}`.toLowerCase().includes(q.toLowerCase())))
      .sort((a, b) => Number(a.bad) - Number(b.bad) || Number(b.free) - Number(a.free) || Number(b.tools !== false) - Number(a.tools !== false) || a.id.localeCompare(b.id)),
  })).filter((g) => g.models.length), [s, q, freeOnly, toolsOnly, all]);
  return (
    <Sheet open={open} onClose={onClose} tall title={L(lang, 'اختار الموديل', 'Choose a model')}>
      <div className="flex items-center gap-2 rounded-xl bg-surface-2 px-3"><Search size={16} className="text-ink-3" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={L(lang, 'دوّر على موديل…', 'Search models…')} className="h-11 flex-1 bg-transparent outline-none" /></div>
      <div className="-mx-1 mt-3 flex flex-wrap gap-2 px-1">
        <Chip active={freeOnly} onClick={() => { setFreeOnly(!freeOnly); useApp.getState().updateSettings({ ai: { ...s.ai, freeOnly: !freeOnly } }); }}>{L(lang, 'المجاني بس', 'Free only')}</Chip>
        <Chip active={toolsOnly} onClick={() => setToolsOnly(!toolsOnly)}><Wrench size={12} />{L(lang, 'بيقدر ينفّذ أوامر', 'Can run actions')}</Chip>
        <Chip active={all} onClick={() => setAll(!all)}>{L(lang, 'كل المزوّدين', 'All providers')}</Chip>
      </div>
      {groups.length === 0 && <p className="mt-6 text-center text-sm text-ink-3">{L(lang, 'مفيش موديلات — ضيف مفتاح مزوّد الأول.', 'No models — add a provider key first.')}</p>}
      {groups.map(({ p, ready, models }) => (
        <div key={p.id} className="mt-4">
          <div className="mb-1.5 flex items-center gap-2 px-1"><AiLogo name={p.logo} size={22} /><span className="text-[13px] font-bold">{p.name}</span><Badge tone={TIER_TONE[p.tier]}>{TIER_LABEL[p.tier][lang === 'ar' ? 0 : 1]}</Badge>{!ready && <Badge tone="warning">{L(lang, 'محتاج مفتاح', 'needs key')}</Badge>}
            <button aria-label={L(lang, 'تحديث الموديلات', 'Refresh models')} onClick={() => refresh(p)} className="press ms-auto grid h-7 w-7 place-items-center rounded-full text-ink-3 hover:bg-surface-2">{refreshingId === p.id ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}</button></div>
          {!s.ai.providers[p.id]?.modelsFetchedAt && <div className="mb-1 px-1 text-[10.5px] text-warning">{L(lang, 'قايمة مقترحة لسه متحققناش منها — دوس تحديث ↻', 'Suggested list, not verified yet — tap refresh ↻')}</div>}
          <Card className="divide-y divide-line overflow-hidden">{models.slice(0, 120).map((m) => {
            const active = s.ai.providerId === p.id && s.ai.modelId === m.id;
            return (
              <button key={m.id} disabled={!ready} onClick={() => onPick(p.id, m.id)} className={cn('press flex w-full items-center gap-3 px-3 py-2.5 text-start disabled:opacity-40', active && 'bg-accent-soft')}>
                <span className="relative"><AiLogo name={modelLogo(m.id, p.logo)} size={34} /><span className="absolute -bottom-1 -end-1"><AiLogo name={p.logo} size={16} /></span></span>
                <span className="min-w-0 flex-1"><span className="block truncate text-[14px] font-semibold">{m.name && !m.name.includes('/') ? m.name : prettyModel(m.id)}</span><span className="block truncate text-[11px] text-ink-3" dir="ltr">{m.id}</span></span>
                <span className="flex shrink-0 flex-col items-end gap-1">{m.bad ? <Badge tone="danger">{L(lang, 'مش متاح', 'unavailable')}</Badge> : m.free ? <Badge tone="success">{L(lang, 'مجاني', 'Free')}</Badge> : <Badge>{L(lang, 'مدفوع', 'Paid')}</Badge>}{m.tools === false ? <Badge tone="warning">{L(lang, 'شات بس', 'chat only')}</Badge> : m.context ? <span className="num text-[10px] text-ink-3">{Math.round(m.context / 1000)}K</span> : null}</span>
              </button>
            );
          })}</Card>
        </div>
      ))}
    </Sheet>
  );
}
export const providerName = (id: string) => providerById(id)?.name ?? id;
