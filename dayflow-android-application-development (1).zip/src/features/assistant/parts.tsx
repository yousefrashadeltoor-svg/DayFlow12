import { Fragment, type ReactNode } from 'react';
import { AlarmClock, Bell, CalendarDays, Check, CheckCircle2, Circle, Droplets, Flag, NotebookPen, Palette, Search, StickyNote, Target, Timer, Trash2, Trophy, Repeat } from 'lucide-react';
import type { AiCard } from '@/models/types';
import { useUI, type Screen, type Tab } from '@/stores/uiStore';
import { useSettings, useT, ProgressBar, ProgressRing, Badge } from '@/components/common/ui';
import { Orn } from '@/features/decor/Decor';
import { fmtDate, fmtNumber, fmtTime, inputToMin, weekdayName, fmtDuration } from '@/utils/date';
import { cn } from '@/utils/cn';

const logoMods = import.meta.glob('../../assets/ai-logos/*.svg', { eager: true, query: '?raw', import: 'default' }) as Record<string, string>;
const LOGOS = Object.fromEntries(Object.entries(logoMods).map(([k, v]) => [k.split('/').pop()!.replace('.svg', ''), v]));

/** Bundled provider / model-family logo. Mono logos use currentColor so they follow the theme. */
export function AiLogo({ name, size = 22, className = '', framed = true }: { name: string; size?: number; className?: string; framed?: boolean }) {
  const svg = LOGOS[name] ?? LOGOS.openai ?? '';
  const inner = <span aria-hidden className="inline-grid place-items-center text-ink [&_svg]:h-[1em] [&_svg]:w-[1em]" style={{ fontSize: framed ? size * 0.62 : size }} dangerouslySetInnerHTML={{ __html: svg }} />;
  if (!framed) return <span className={className}>{inner}</span>;
  return <span className={cn('inline-grid shrink-0 place-items-center rounded-[30%] border border-line bg-surface', className)} style={{ width: size, height: size }}>{inner}</span>;
}

// ---------------------------------------------------------------- markdown (safe: escapes HTML, no links/images)
function inline(text: string, key: string): ReactNode[] {
  const out: ReactNode[] = []; let i = 0; let k = 0;
  const re = /(`[^`]+`|\*\*[^*]+\*\*|\*[^*\n]+\*|__[^_]+__)/g; let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > i) out.push(text.slice(i, m.index));
    const t = m[0];
    if (t.startsWith('`')) out.push(<code key={`${key}c${k++}`} className="rounded-md bg-surface-2 px-1.5 py-0.5 font-mono text-[0.88em]">{t.slice(1, -1)}</code>);
    else if (t.startsWith('**') || t.startsWith('__')) out.push(<b key={`${key}b${k++}`}>{t.slice(2, -2)}</b>);
    else out.push(<i key={`${key}i${k++}`}>{t.slice(1, -1)}</i>);
    i = m.index + t.length;
  }
  if (i < text.length) out.push(text.slice(i));
  return out;
}
export function Markdown({ text }: { text: string }) {
  const blocks: ReactNode[] = []; const lines = text.replace(/\r/g, '').split('\n'); let i = 0; let n = 0;
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith('```')) { const code: string[] = []; i++; while (i < lines.length && !lines[i].startsWith('```')) code.push(lines[i++]); i++; blocks.push(<pre key={n++} dir="ltr" className="my-2 overflow-x-auto rounded-xl bg-surface-2 p-3 font-mono text-[12px] leading-5">{code.join('\n')}</pre>); continue; }
    if (/^\s*[-*•]\s+/.test(l)) { const items: string[] = []; while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*[-*•]\s+/, '')); blocks.push(<ul key={n++} className="my-1.5 list-disc space-y-1 ps-5">{items.map((x, j) => <li key={j}>{inline(x, `${n}-${j}`)}</li>)}</ul>); continue; }
    if (/^\s*\d+[.)]\s+/.test(l)) { const items: string[] = []; while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*\d+[.)]\s+/, '')); blocks.push(<ol key={n++} className="my-1.5 list-decimal space-y-1 ps-5">{items.map((x, j) => <li key={j}>{inline(x, `${n}-${j}`)}</li>)}</ol>); continue; }
    const h = l.match(/^(#{1,3})\s+(.*)$/);
    if (h) { blocks.push(<div key={n++} className={cn('mt-2 font-bold', h[1].length === 1 ? 'text-[17px]' : 'text-[15px]')}>{inline(h[2], `h${n}`)}</div>); i++; continue; }
    if (!l.trim()) { i++; continue; }
    const para: string[] = []; while (i < lines.length && lines[i].trim() && !/^(```|#{1,3}\s|\s*[-*•]\s|\s*\d+[.)]\s)/.test(lines[i])) para.push(lines[i++]);
    blocks.push(<p key={n++} className="my-1 leading-7">{para.map((x, j) => <Fragment key={j}>{j > 0 && <br />}{inline(x, `p${n}-${j}`)}</Fragment>)}</p>);
  }
  return <div className="text-[15px]">{blocks}</div>;
}

// ---------------------------------------------------------------- rich cards
function OpenBtn({ card }: { card: AiCard }) {
  const { lang } = useT();
  if (!card.open) return null;
  const go = () => {
    const ui = useUI.getState();
    if (card.open?.tab) ui.setTab(card.open.tab as Tab);
    else if (card.open?.screen) { ui.setTab('more'); ui.push(card.open.screen as Screen); }
    if (card.open?.blockId) setTimeout(() => ui.set({ detailFor: card.open!.blockId! }), 250);
  };
  return <button onClick={go} className="press text-[12px] font-bold text-accent">{lang === 'ar' ? 'افتح ←' : 'Open →'}</button>;
}
const Head = ({ icon, title, card, tone = 'var(--accent)' }: { icon: ReactNode; title: ReactNode; card: AiCard; tone?: string }) => (
  <div className="mb-2 flex items-center gap-2"><span className="grid h-7 w-7 place-items-center rounded-lg" style={{ background: `color-mix(in srgb, ${tone} 16%, transparent)`, color: tone }}>{icon}</span><span className="min-w-0 flex-1 truncate text-[13px] font-bold">{title}</span><OpenBtn card={card} /></div>
);

export function CardView({ card }: { card: AiCard }) {
  const { lang } = useT();
  const s = useSettings();
  const ar = lang === 'ar';
  const ft = (hhmm: string) => fmtTime(inputToMin(hhmm), lang, s.clock24);
  const d = card.data as Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
  const box = 'anim-pop mt-2 rounded-2xl border border-line bg-surface p-3';
  switch (card.type) {
    case 'activity': return (
      <div className={box} style={{ borderInlineStartWidth: 4, borderInlineStartColor: d.color }}>
        <Head icon={<CalendarDays size={15} />} title={ar ? 'نشاط في الخطة' : 'Plan activity'} card={card} tone={d.color} />
        <div className="text-[15px] font-bold">{d.title}</div>
        <div className="num mt-0.5 text-[13px] text-ink-2">{fmtDate(d.date, lang, { weekday: 'long', day: 'numeric', month: 'long' })} · {ft(d.start)} – {ft(d.end)} · {fmtDuration(d.duration, lang)}</div>
        {d.notes && <div className="mt-1.5 flex items-start gap-1 text-[12.5px] text-ink-2"><StickyNote size={12} className="mt-1" />{d.notes}</div>}
        <div className="mt-2 flex gap-1.5"><Badge tone={d.applied ? 'success' : 'warning'}>{d.applied ? (ar ? '✓ متطبّق — التنبيه شغّال' : '✓ Applied — reminder on') : (ar ? 'مسودة' : 'Draft')}</Badge></div>
      </div>);
    case 'schedule': return (
      <div className={box}>
        <Head icon={<CalendarDays size={15} />} title={`${ar ? 'جدول' : 'Schedule'} · ${fmtDate(d.date, lang, { weekday: 'long', day: 'numeric', month: 'short' })}`} card={card} />
        {d.blocks.length === 0 ? <div className="text-[13px] text-ink-3">{ar ? 'مفيش أنشطة' : 'No activities'}</div> : (
          <div className="relative space-y-1.5 ps-4">
            <span className="absolute bottom-1 top-1 w-px bg-line start-[5px]" />
            {d.blocks.slice(0, 12).map((b: any) => ( // eslint-disable-line @typescript-eslint/no-explicit-any
              <div key={b.id} className="relative flex items-center gap-2 text-[13px]">
                <span className="absolute h-2.5 w-2.5 rounded-full border-2 bg-surface -start-4" style={{ borderColor: b.status === 'completed' ? 'var(--success)' : b.color }} />
                <span className="num w-[86px] shrink-0 text-ink-3">{ft(b.start)}–{ft(b.end)}</span>
                <span className={cn('min-w-0 flex-1 truncate font-medium', b.status === 'completed' && 'text-ink-3 line-through')}>{b.title}</span>
                {!b.applied && <span className="text-[10px] font-bold text-warning">{ar ? 'مسودة' : 'draft'}</span>}
              </div>
            ))}
            {d.blocks.length > 12 && <div className="text-[11px] text-ink-3">+{d.blocks.length - 12}</div>}
          </div>
        )}
      </div>);
    case 'alarm': case 'alarms': {
      const list = card.type === 'alarm' ? [d] : (d as unknown as any[]); // eslint-disable-line @typescript-eslint/no-explicit-any
      return (
        <div className={box}>
          <Head icon={<AlarmClock size={15} />} title={ar ? (card.type === 'alarm' ? 'منبه' : 'المنبهات') : (card.type === 'alarm' ? 'Alarm' : 'Alarms')} card={card} tone="var(--danger)" />
          {list.length === 0 && <div className="text-[13px] text-ink-3">{ar ? 'مفيش منبهات' : 'No alarms'}</div>}
          {list.slice(0, 10).map((a: any) => ( // eslint-disable-line @typescript-eslint/no-explicit-any
            <div key={a.id} className="flex items-center gap-3 border-t border-line py-2 first:border-0 first:pt-0">
              <div className="min-w-0 flex-1"><div className="num text-[26px] font-extrabold leading-none">{ft(a.time)}</div><div className="mt-1 truncate text-[12.5px] text-ink-2">{a.label || (ar ? 'منبه' : 'Alarm')}</div></div>
              <div className="flex flex-wrap justify-end gap-0.5">{a.days?.length ? [6, 0, 1, 2, 3, 4, 5].map((x) => <span key={x} className={cn('grid h-5 w-5 place-items-center rounded-full text-[9px] font-bold', a.days.includes(x) ? 'bg-accent text-accent-ink' : 'bg-surface-2 text-ink-3')}>{weekdayName(x, lang, 'narrow')}</span>) : <Badge>{ar ? 'مرة واحدة' : 'Once'}</Badge>}</div>
              <span className={cn('h-5 w-9 rounded-full p-0.5', a.enabled ? 'bg-success' : 'bg-line')}><span className={cn('block h-4 w-4 rounded-full bg-white transition-all', a.enabled ? 'ms-4' : '')} /></span>
            </div>
          ))}
          {card.type === 'alarm' && d.next && <div className="mt-1 text-[12px] font-semibold text-accent">{ar ? 'هيرن ' : 'Rings '}{new Intl.DateTimeFormat(ar ? 'ar-EG' : 'en-US', { weekday: 'long', hour: 'numeric', minute: '2-digit', hour12: !s.clock24 }).format(new Date(d.next))}</div>}
        </div>);
    }
    case 'task': case 'tasks': {
      const list = card.type === 'task' ? [d] : (d as unknown as any[]); // eslint-disable-line @typescript-eslint/no-explicit-any
      return (
        <div className={box}>
          <Head icon={<CheckCircle2 size={15} />} title={ar ? 'المهام' : 'Tasks'} card={card} tone="var(--c-work)" />
          {list.length === 0 && <div className="text-[13px] text-ink-3">{ar ? 'مفيش مهام' : 'No tasks'}</div>}
          {list.slice(0, 10).map((t: any) => ( // eslint-disable-line @typescript-eslint/no-explicit-any
            <div key={t.id} className="flex items-center gap-2 py-1 text-[14px]">
              {t.status === 'done' ? <CheckCircle2 size={18} className="text-success" /> : <Circle size={18} className={t.priority >= 4 ? 'text-danger' : 'text-ink-3'} />}
              <span className={cn('min-w-0 flex-1 truncate', t.status === 'done' && 'text-ink-3 line-through')}>{t.title}</span>
              {t.due && <span className="num text-[11px] text-ink-3">{fmtDate(t.due, lang, { day: 'numeric', month: 'short' })}</span>}
              {t.priority >= 4 && <Flag size={12} className="text-danger" />}
            </div>
          ))}
          {card.type === 'task' && d.checklist?.length > 0 && <ul className="mt-1 space-y-0.5 ps-6 text-[12.5px] text-ink-2">{d.checklist.map((c: string, i: number) => <li key={i}>☐ {c}</li>)}</ul>}
        </div>);
    }
    case 'note': return (
      <div className={box}><Head icon={<StickyNote size={15} />} title={d.title || (ar ? 'ملاحظة' : 'Note')} card={card} tone="var(--c-meal)" />
        {d.body && <div className="line-clamp-6 whitespace-pre-wrap text-[13.5px] leading-6 text-ink-2">{d.body}</div>}
        {d.items?.length > 0 && <ul className="space-y-0.5 text-[13.5px]">{d.items.map((x: string, i: number) => <li key={i}>☐ {x}</li>)}</ul>}</div>);
    case 'journal': {
      const moods = ['loudly_crying_face', 'slightly_frowning_face', 'neutral_face', 'slightly_smiling_face', 'grinning_face_with_big_eyes'];
      return (
        <div className={box}><Head icon={<NotebookPen size={15} />} title={`${ar ? 'اليوميات' : 'Journal'} · ${fmtDate(d.date, lang, { day: 'numeric', month: 'long' })}`} card={card} tone="var(--c-sleep)" />
          <div className="flex gap-3">{d.mood > 0 && <Orn name={moods[d.mood - 1]} size={40} />}
            <div className="min-w-0 flex-1">{d.title && <div className="font-bold">{d.title}</div>}<div className="line-clamp-4 whitespace-pre-wrap text-[13.5px] leading-6 text-ink-2">{d.body}</div>
              {d.gratitude?.length > 0 && <div className="mt-1 text-[12px] text-ink-3">🙏 {d.gratitude.join(' · ')}</div>}</div></div></div>);
    }
    case 'occasion': return (
      <div className={box}><Head icon={<CalendarDays size={15} />} title={ar ? 'مناسبة في التقويم' : 'Calendar occasion'} card={card} tone="var(--success)" />
        <div className="flex items-center gap-3"><Orn name="party_popper" size={38} /><div><div className="font-bold">{d.title}</div><div className="text-[12.5px] text-ink-2">{fmtDate(d.date, lang, { weekday: 'long', day: 'numeric', month: 'long' })}{d.yearly ? (ar ? ' · كل سنة' : ' · yearly') : ''}</div>
          <div className="mt-0.5 text-[11.5px] text-ink-3"><Bell size={10} className="inline" /> {ar ? 'هيظهر في الإشعارات والويدجت' : 'Shown in notifications & widgets'}</div></div></div></div>);
    case 'water': return (
      <div className={box}><Head icon={<Droplets size={15} />} title={ar ? 'المية' : 'Water'} card={card} tone="var(--c-water)" />
        <div className="flex items-center gap-3"><ProgressRing value={(d.total / Math.max(1, d.target)) * 100} size={52} stroke={6} color="var(--c-water)"><Droplets size={16} className="text-water" /></ProgressRing>
          <div><div className="num text-[17px] font-bold">+{fmtNumber(d.added, lang)} {ar ? 'مل' : 'ml'}</div><div className="num text-[12.5px] text-ink-2">{fmtNumber(d.total, lang)} / {fmtNumber(d.target, lang)}</div></div></div></div>);
    case 'prayer': {
      const keys = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];
      const names: Record<string, [string, string]> = { fajr: ['الفجر', 'Fajr'], sunrise: ['الشروق', 'Sunrise'], dhuhr: ['الظهر', 'Dhuhr'], asr: ['العصر', 'Asr'], maghrib: ['المغرب', 'Maghrib'], isha: ['العشاء', 'Isha'] };
      return (
        <div className={box}><Head icon={<Orn name="mosque" size={16} />} title={ar ? 'الصلاة' : 'Prayer'} card={card} tone="var(--success)" />
          {d.recorded ? <div className="text-[14px]">✓ {names[d.recorded]?.[ar ? 0 : 1]} · {ar ? `صلّيت ${d.prayedToday} من ٥ النهاردة` : `${d.prayedToday}/5 today`}</div> : (
            <div className="grid grid-cols-3 gap-1.5">{keys.map((k) => (
              <div key={k} className={cn('rounded-xl px-2 py-1.5 text-center', d.next?.prayer === k ? 'bg-accent text-accent-ink' : 'bg-surface-2')}><div className="text-[11px] font-semibold opacity-80">{names[k][ar ? 0 : 1]}</div><div className="num text-[14px] font-bold">{ft(d.times[k])}</div></div>
            ))}</div>)}
          {d.next && <div className="mt-2"><ProgressBar value={d.next.progress} color="var(--success)" /><div className="mt-1 text-[11.5px] text-ink-3">{ar ? 'الجاية: ' : 'Next: '}{names[d.next.prayer]?.[ar ? 0 : 1]} · {new Intl.DateTimeFormat(ar ? 'ar-EG' : 'en-US', { hour: 'numeric', minute: '2-digit', hour12: !s.clock24 }).format(new Date(d.next.at))}</div></div>}
        </div>);
    }
    case 'stats': {
      const max = Math.max(1, ...d.days.map((x: { planned: number }) => x.planned));
      return (
        <div className={box}><Head icon={<Trophy size={15} />} title={ar ? 'الإحصائيات' : 'Statistics'} card={card} />
          <div className="flex items-center gap-3"><ProgressRing value={d.avgCompletion} size={64} stroke={7}><span className="num text-[14px] font-bold">{fmtNumber(d.avgCompletion, lang)}%</span></ProgressRing>
            <div className="grid flex-1 grid-cols-2 gap-1.5 text-[12px]"><span>{ar ? 'خلّصت' : 'Done'}: <b className="num">{fmtDuration(d.doneMin, lang)}</b></span><span>{ar ? 'مخطط' : 'Planned'}: <b className="num">{fmtDuration(d.plannedMin, lang)}</b></span><span>{ar ? 'مذاكرة' : 'Study'}: <b className="num">{fmtDuration(d.studyMin, lang)}</b></span><span>{ar ? 'تمرين' : 'Exercise'}: <b className="num">{fmtDuration(d.exerciseMin, lang)}</b></span></div></div>
          {d.days.length > 1 && <div className="mt-3 flex h-16 items-end gap-1" dir="ltr">{d.days.map((x: { date: string; pct: number; planned: number }) => <div key={x.date} title={`${x.date} ${x.pct}%`} className="relative flex-1 rounded-t-md bg-surface-2" style={{ height: `${Math.max(8, (x.planned / max) * 100)}%` }}><div className="absolute inset-x-0 bottom-0 rounded-t-md bg-accent" style={{ height: `${x.pct}%` }} /></div>)}</div>}
        </div>);
    }
    case 'habit': return <div className={box}><Head icon={<Repeat size={15} />} title={ar ? 'عادة' : 'Habit'} card={card} tone="var(--c-rest)" /><div className="font-bold">{d.name}</div><div className="text-[12.5px] text-ink-2">{d.logged != null ? `${ar ? 'سجّلت' : 'Logged'}: ${d.logged} ${d.unit ?? ''}` : `${d.frequency} · ${d.kind}${d.target ? ` · ${d.target} ${d.unit ?? ''}` : ''}`}</div></div>;
    case 'goal': return <div className={box}><Head icon={<Target size={15} />} title={ar ? 'هدف جديد' : 'New goal'} card={card} tone="var(--warning)" /><div className="font-bold">{d.title}</div>{d.targetDate && <div className="text-[12.5px] text-ink-2">{fmtDate(d.targetDate, lang)}</div>}</div>;
    case 'focus': return <div className={box}><Head icon={<Timer size={15} />} title={ar ? 'بدأت جلسة تركيز' : 'Focus session started'} card={card} /><div className="num text-[22px] font-extrabold">{d.minutes ? `${d.minutes} ${ar ? 'دقيقة' : 'min'}` : '∞'}</div><div className="text-[12.5px] text-ink-2">{d.mode}</div></div>;
    case 'settings': return <div className={box}><Head icon={<Palette size={15} />} title={ar ? 'اتغيّرت الإعدادات' : 'Settings changed'} card={card} /><div className="flex flex-wrap gap-1.5">{Object.entries(d).map(([k, v]) => <Badge key={k}>{k}: {typeof v === 'object' ? '…' : String(v)}</Badge>)}</div></div>;
    case 'search': return (
      <div className={box}><Head icon={<Search size={15} />} title={`${ar ? 'نتايج' : 'Results'}: ${d.query}`} card={card} />
        {d.results.length === 0 ? <div className="text-[13px] text-ink-3">{ar ? 'مفيش نتايج' : 'No results'}</div> : d.results.map((r: any, i: number) => <div key={i} className="flex items-center gap-2 py-0.5 text-[13px]"><Badge>{r.kind}</Badge><span className="min-w-0 flex-1 truncate">{r.title ?? r.label ?? r.name}</span><span className="num text-[11px] text-ink-3">{r.date ?? r.due ?? r.time ?? ''}</span></div>)} {/* eslint-disable-line @typescript-eslint/no-explicit-any */}
      </div>);
    case 'deleted': return <div className={cn(box, 'flex items-center gap-2 text-[13.5px]')}><Trash2 size={16} className="text-danger" /><span className="flex-1">{ar ? 'اتمسح' : 'Deleted'}: <b>{d.title}</b></span></div>;
    case 'overview': return null;
  }
  return <div className={box}><Check size={14} /></div>;
}
