import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowUp, Check, ChevronDown, Copy, History, Loader2, MessageSquarePlus, Pin, RotateCcw, Settings2, ShieldCheck, Sparkles, Square, Trash2, Undo2, X, AlertTriangle, Wrench } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { Badge, Button, Card, Segmented, Sheet, Toggle, useHaptic, useSettings, useT } from '@/components/common/ui';
import { Orn } from '@/features/decor/Decor';
import { AiLogo, CardView, Markdown } from './parts';
import { ModelPicker, errorText, isReady, modelsOf, L } from './Providers';
import { PROVIDERS, modelLogo, prettyModel, providerById } from '@/services/ai/providers';
import { canUndo, decide, newChat, regenerate, send, stop, undo, useAgent } from '@/services/ai/agent';
import type { AiChat, AiMessage, AiToolRun } from '@/models/types';
import { AiError } from '@/services/ai/client';
import { fmtDateTime } from '@/utils/date';
import { cn } from '@/utils/cn';

const TOOL_AR: Record<string, [string, string]> = {
  get_overview: ['بيشوف يومك', 'Reading your day'], search: ['بيدوّر', 'Searching'], get_stats: ['بيحسب الإحصائيات', 'Computing stats'], get_prayer_times: ['بيجيب مواقيت الصلاة', 'Prayer times'],
  list_tasks: ['بيجيب المهام', 'Listing tasks'], list_alarms: ['بيجيب المنبهات', 'Listing alarms'], create_activity: ['بيضيف نشاط', 'Adding activity'], update_activity: ['بيعدّل نشاط', 'Editing activity'],
  delete_activity: ['يمسح نشاط', 'Delete activity'], set_activity_status: ['بيغيّر حالة نشاط', 'Updating status'], apply_plan: ['بيطبّق الخطة', 'Applying plan'], plan_day: ['بيرتّب اليوم', 'Planning the day'],
  create_alarm: ['بيعمل منبه', 'Creating alarm'], update_alarm: ['بيعدّل منبه', 'Editing alarm'], delete_alarm: ['يمسح منبه', 'Delete alarm'], create_task: ['بيضيف مهمة', 'Adding task'],
  update_task: ['بيعدّل مهمة', 'Editing task'], delete_task: ['يمسح مهمة', 'Delete task'], create_note: ['بيكتب ملاحظة', 'Writing note'], write_journal: ['بيكتب في يومياتك', 'Writing journal'],
  add_occasion: ['بيضيف مناسبة', 'Adding occasion'], log_water: ['بيسجّل مية', 'Logging water'], mark_prayer: ['بيسجّل صلاة', 'Recording prayer'], create_habit: ['بيعمل عادة', 'Creating habit'],
  log_habit: ['بيسجّل عادة', 'Logging habit'], create_goal: ['بيعمل هدف', 'Creating goal'], start_focus: ['بيبدأ تركيز', 'Starting focus'], change_settings: ['بيغيّر الإعدادات', 'Changing settings'], open_screen: ['بيفتح شاشة', 'Opening screen'],
};
const SUGGESTIONS: [string, string, string][] = [
  ['alarm_clock', 'اعملي منبه الساعة ٦:٣٠ الصبح أيام الشغل واسمه «صحيان الشغل»', 'Set an alarm at 6:30 AM on workdays called “Work wake-up”'],
  ['spiral_calendar', 'رتّبلي يوم بكرة: مذاكرة ٣ ساعات الصبح، جيم الساعة ٦ المغرب، وقراءة نص ساعة قبل النوم', 'Plan tomorrow: 3 hours of study in the morning, gym at 6 PM, 30 min reading before bed'],
  ['notebook', 'اكتب في يومياتي إن النهاردة كان يوم حلو وخلّصت المشروع، ومزاجي كويس', 'Write in my journal that today was great and I finished the project; mood good'],
  ['check_mark_button', 'ضيف مهمة «تسليم المشروع» يوم الخميس الجاي وأولويتها عالية', 'Add a high-priority task “Submit project” for next Thursday'],
  ['mosque', 'امتى الصلاة الجاية؟ وسجّل إني صلّيت الظهر', 'When is the next prayer? And log that I prayed Dhuhr'],
  ['bar_chart', 'إيه إحصائياتي الأسبوع ده؟ وإيه اللي محتاج أحسّنه؟', 'Show my stats this week and what to improve'],
  ['artist_palette', 'غيّر الثيم لجيميناي وخلّي الزينة على رمضان', 'Switch to the Gemini theme and preview Ramadan decor'],
  ['party_popper', 'ضيف عيد ميلاد ماما يوم ١٥ مارس كل سنة', 'Add Mom’s birthday on March 15 every year'],
];

export function AssistantScreen() {
  const { lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const chats = useApp((st) => st.data.aiChats);
  const busyMap = useAgent((x) => x.busy);
  useApp((st) => st.data.state); // keys
  const sorted = useMemo(() => Object.values(chats).sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt), [chats]);
  const [activeId, setActiveId] = useState<string | null>(() => sorted[0]?.id ?? null);
  const chat = activeId ? chats[activeId] : undefined;
  const [text, setText] = useState('');
  const [sheet, setSheet] = useState<null | 'model' | 'history' | 'settings' | 'consent'>(s.ai.consent ? null : 'consent');
  const scroller = useRef<HTMLDivElement>(null);
  const ta = useRef<HTMLTextAreaElement>(null);
  const busy = chat ? busyMap[chat.id] : null;
  const provider = providerById(chat?.providerId ?? s.ai.providerId) ?? PROVIDERS[0];
  const ready = isReady(s, provider);
  const modelId = chat?.modelId || s.ai.modelId || modelsOf(s, provider)[0]?.id || '';
  const modelInfo = modelsOf(s, provider).find((m) => m.id === modelId);

  useEffect(() => { const el = scroller.current; if (!el) return; if (typeof el.scrollTo === 'function') el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' }); else el.scrollTop = el.scrollHeight; }, [chat?.messages.length, busy]);
  useEffect(() => { if (ta.current) { ta.current.style.height = 'auto'; ta.current.style.height = `${Math.min(160, ta.current.scrollHeight)}px`; } }, [text]);

  const ensureChat = async (): Promise<string> => {
    if (chat && chat.messages.length === 0) { if (chat.providerId !== s.ai.providerId || chat.modelId !== modelId) await useApp.getState().put('aiChats', { ...chat, providerId: s.ai.providerId, modelId }); return chat.id; }
    if (chat) return chat.id;
    const c: AiChat = { ...newChat(s), providerId: s.ai.providerId, modelId };
    await useApp.getState().put('aiChats', c); setActiveId(c.id); return c.id;
  };
  const submit = async (t = text) => {
    if (!t.trim() || busy) return;
    if (!s.ai.consent) { setSheet('consent'); return; }
    if (!ready || !modelId) { useUI.getState().setTab('more'); useUI.getState().push('ai_providers'); return; }
    h(10); setText('');
    const id = await ensureChat();
    await send(id, t);
  };
  const pickModel = async (pid: string, mid: string) => {
    await useApp.getState().updateSettings({ ai: { ...s.ai, providerId: pid, modelId: mid } });
    if (chat) await useApp.getState().put('aiChats', { ...chat, providerId: pid, modelId: mid });
    setSheet(null);
  };
  const startNew = () => { setActiveId(null); setText(''); setSheet(null); };

  return (
    <div className="flex h-[100dvh] flex-col">
      {/* header */}
      <header className="glass safe-top z-20 border-b border-line/60">
        <div className="mx-auto flex h-14 max-w-2xl items-center gap-1 px-2">
          <button onClick={() => setSheet('history')} aria-label={L(lang, 'المحادثات', 'Chats')} className="press grid h-10 w-10 place-items-center rounded-full text-ink-2 hover:bg-surface-2"><History size={20} /></button>
          <button onClick={() => setSheet('model')} className="press mx-auto flex min-w-0 max-w-[70%] items-center gap-2 rounded-full border border-line bg-surface px-2 py-1.5 shadow-sm">
            <span className="relative"><AiLogo name={modelLogo(modelId, provider.logo)} size={26} /><span className="absolute -bottom-1 -end-1"><AiLogo name={provider.logo} size={14} /></span></span>
            <span className="min-w-0 text-start"><span className="block truncate text-[13px] font-bold leading-4">{modelId ? (modelInfo?.name && !modelInfo.name.includes('/') ? modelInfo.name : prettyModel(modelId)) : L(lang, 'اختار موديل', 'Pick a model')}</span><span className="block truncate text-[10.5px] text-ink-3">{provider.name}{modelInfo?.free ? ` · ${L(lang, 'مجاني', 'free')}` : ''}</span></span>
            <ChevronDown size={14} className="shrink-0 text-ink-3" />
          </button>
          <button onClick={() => setSheet('settings')} aria-label={L(lang, 'إعدادات المساعد', 'Assistant settings')} className="press grid h-10 w-10 place-items-center rounded-full text-ink-2 hover:bg-surface-2"><Settings2 size={20} /></button>
          <button onClick={startNew} aria-label={L(lang, 'محادثة جديدة', 'New chat')} className="press grid h-10 w-10 place-items-center rounded-full text-ink-2 hover:bg-surface-2"><MessageSquarePlus size={20} /></button>
        </div>
      </header>

      {/* messages */}
      <div ref={scroller} className="flex-1 overflow-y-auto no-scrollbar">
        <div className="mx-auto max-w-2xl px-4 pb-4 pt-3">
          {!chat || chat.messages.length === 0 ? (
            <Welcome ready={ready} onPick={(t) => submit(t)} onSetup={() => { useUI.getState().setTab('more'); useUI.getState().push('ai_providers'); }} />
          ) : chat.messages.map((m, i) => <MessageView key={m.id} chat={chat} m={m} last={i === chat.messages.length - 1} busy={!!busy} />)}
          {busy && (
            <div className="anim-fade mt-3 flex items-center gap-2 text-[13px] text-ink-2">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-accent-soft text-accent"><Loader2 size={14} className="animate-spin" /></span>
              {busy === 'thinking' ? L(lang, 'بيفكّر…', 'Thinking…') : `${TOOL_AR[busy]?.[lang === 'ar' ? 0 : 1] ?? busy}…`}
            </div>
          )}
        </div>
      </div>

      {/* composer */}
      <div className="z-10 border-t border-line/60 bg-bg/90 backdrop-blur-xl" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 84px)' }}>
        <div className="mx-auto max-w-2xl px-3 pt-2.5">
          <div className="flex items-end gap-2 rounded-[24px] border border-line bg-surface p-1.5 shadow-sm focus-within:border-accent/50">
            <textarea ref={ta} rows={1} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); } }}
              placeholder={ready ? L(lang, 'اطلب أي حاجة… «اعملي منبه الساعة ٧ بكرة»', 'Ask anything… “set an alarm at 7 tomorrow”') : L(lang, 'ضيف مفتاح مزوّد الأول (فيه مجاني)', 'Add a provider key first (free options available)')}
              className="max-h-40 min-h-[40px] flex-1 resize-none bg-transparent px-3 py-2 text-[15px] leading-6 outline-none placeholder:text-ink-3" />
            {busy ? <button aria-label={L(lang, 'وقّف', 'Stop')} onClick={() => chat && stop(chat.id)} className="press grid h-10 w-10 shrink-0 place-items-center rounded-full bg-ink text-bg"><Square size={15} /></button>
              : <button aria-label={L(lang, 'ابعت', 'Send')} disabled={!text.trim()} onClick={() => submit()} className="press grid h-10 w-10 shrink-0 place-items-center rounded-full bg-accent text-accent-ink disabled:opacity-40"><ArrowUp size={19} /></button>}
          </div>
          <p className="mt-1.5 text-center text-[10.5px] text-ink-3">{L(lang, 'المساعد بينفّذ فعليًا في التطبيق، وتقدر تتراجع عن أي خطوة. بيحتاج إنترنت (الميزة الوحيدة في التطبيق اللي بتحتاجه).', 'The assistant really acts in the app and every step can be undone. Needs internet (the only feature that does).')}</p>
        </div>
      </div>

      <ModelPicker open={sheet === 'model'} onClose={() => setSheet(null)} onPick={pickModel} />
      <HistorySheet open={sheet === 'history'} onClose={() => setSheet(null)} chats={sorted} activeId={activeId} onOpen={(id) => { setActiveId(id); setSheet(null); }} onNew={startNew} />
      <SettingsSheet open={sheet === 'settings'} onClose={() => setSheet(null)} />
      <ConsentSheet open={sheet === 'consent'} onClose={() => setSheet(null)} />
    </div>
  );
}

function Welcome({ ready, onPick, onSetup }: { ready: boolean; onPick: (t: string) => void; onSetup: () => void }) {
  const { lang } = useT();
  const s = useSettings();
  const ar = lang === 'ar';
  return (
    <div className="anim-page">
      <div className="relative mt-2 overflow-hidden rounded-[28px] p-5 text-white shadow-float" style={{ background: 'linear-gradient(135deg, #4f46e5 0%, #7c3aed 45%, #db2777 100%)' }}>
        <div className="absolute -end-10 -top-10 h-40 w-40 rounded-full bg-white/15 blur-2xl" />
        <div className="flex items-center gap-3"><Orn name="sparkles" size={46} className="df-float" /><div><h1 className="text-[22px] font-extrabold">{ar ? `أهلًا${s.userName ? ` يا ${s.userName}` : ''} 👋` : `Hi${s.userName ? ` ${s.userName}` : ''} 👋`}</h1><p className="text-[13px] text-white/85">{L(lang, 'أنا مساعدك في مدير اليوم. قولّي عايز إيه وأنا أعمله في التطبيق.', 'I’m your Dayflow assistant. Tell me what you need and I’ll do it in the app.')}</p></div></div>
        <div className="mt-4 flex flex-wrap gap-1.5 text-[11.5px]">{(ar ? ['منبهات', 'خطة اليوم', 'مهام', 'يوميات', 'ملاحظات', 'صلاة', 'مناسبات', 'عادات', 'إحصائيات', 'ثيمات'] : ['Alarms', 'Day plans', 'Tasks', 'Journal', 'Notes', 'Prayer', 'Occasions', 'Habits', 'Stats', 'Themes']).map((x) => <span key={x} className="rounded-full bg-white/18 px-2.5 py-1 font-semibold backdrop-blur">{x}</span>)}</div>
      </div>
      {!ready && (
        <Card className="mt-3 p-4">
          <div className="mb-2 text-[15px] font-bold">{L(lang, 'خطوة واحدة: ضيف مفتاح مجاني', 'One step: add a free key')}</div>
          <p className="text-[13px] leading-6 text-ink-2">{L(lang, 'المساعد بيشتغل بموديلات من أي مزوّد. أسهل حاجة تبدأ بمفتاح مجاني من واحد من دول:', 'The assistant works with models from any provider. The easiest start is a free key from one of these:')}</p>
          <div className="mt-3 grid grid-cols-3 gap-2">{['groq', 'gemini', 'openrouter'].map((id) => { const p = providerById(id)!; return <button key={id} onClick={onSetup} className="press flex flex-col items-center gap-1.5 rounded-2xl border border-line bg-surface-2 p-3"><AiLogo name={p.logo} size={36} /><span className="text-[12px] font-bold">{p.name.split(' ')[0]}</span><Badge tone="success">{L(lang, 'مجاني', 'Free')}</Badge></button>; })}</div>
          <Button className="mt-3 w-full" onClick={onSetup}>{L(lang, `كل المزوّدين (${PROVIDERS.length})`, `All providers (${PROVIDERS.length})`)}</Button>
        </Card>
      )}
      <div className="mt-4 mb-2 px-1 text-[13px] font-semibold text-ink-3">{L(lang, 'جرّب تقول:', 'Try saying:')}</div>
      <div className="stagger grid grid-cols-1 gap-2">{SUGGESTIONS.map(([icon, a, e], i) => (
        <button key={i} style={{ ['--i' as string]: i }} onClick={() => onPick(ar ? a : e)} className="press card flex items-center gap-3 p-3 text-start"><Orn name={icon} size={30} /><span className="flex-1 text-[13.5px] leading-6">{ar ? a : e}</span></button>
      ))}</div>
    </div>
  );
}

function RunView({ chat, m, r }: { chat: AiChat; m: AiMessage; r: AiToolRun }) {
  const { lang } = useT();
  const label = TOOL_AR[r.name]?.[lang === 'ar' ? 0 : 1] ?? r.name;
  if (r.status === 'needs_confirm') return (
    <div className="anim-pop mt-2 rounded-2xl border border-warning/50 bg-warning/10 p-3">
      <div className="flex items-center gap-2 text-[13.5px] font-bold text-warning"><ShieldCheck size={16} />{L(lang, 'محتاج موافقتك', 'Needs your approval')}</div>
      <div className="mt-1 text-[13.5px]">{label}</div>
      <pre dir="ltr" className="mt-1.5 max-h-28 overflow-auto rounded-lg bg-surface p-2 text-[11px] text-ink-2">{JSON.stringify(r.args, null, 1)}</pre>
      <div className="mt-2 flex gap-2"><Button size="sm" className="flex-1" icon={<Check size={14} />} onClick={() => decide(chat.id, m.id, r.callId, true)}>{L(lang, 'نفّذ', 'Approve')}</Button><Button size="sm" variant="secondary" className="flex-1" icon={<X size={14} />} onClick={() => decide(chat.id, m.id, r.callId, false)}>{L(lang, 'إلغاء', 'Decline')}</Button></div>
    </div>
  );
  const icon = r.status === 'running' || r.status === 'pending' ? <Loader2 size={13} className="animate-spin" /> : r.status === 'done' ? <Check size={13} /> : r.status === 'cancelled' ? <X size={13} /> : <AlertTriangle size={13} />;
  const tone = r.status === 'done' ? 'text-success bg-success/10' : r.status === 'error' ? 'text-danger bg-danger/10' : 'text-ink-2 bg-surface-2';
  return (
    <div className="mt-2">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className={cn('inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[12px] font-semibold', tone)}>{icon}<Wrench size={11} className="opacity-60" />{label}{r.status === 'error' && r.error ? `: ${r.error.slice(0, 80)}` : ''}{r.undone ? ` · ${L(lang, 'اتلغى', 'undone')}` : ''}{r.status === 'cancelled' ? ` · ${L(lang, 'رفضته', 'declined')}` : ''}</span>
        {r.undoable && !r.undone && canUndo(r.callId) && <button onClick={() => undo(chat.id, m.id, r.callId).then((ok) => useApp.getState().toast(ok ? 'success' : 'error', ok ? L(lang, 'اتراجعت', 'Undone') : L(lang, 'مينفعش التراجع', 'Cannot undo')))} className="press inline-flex items-center gap-1 rounded-full border border-line px-2 py-0.5 text-[11.5px] font-semibold text-ink-2"><Undo2 size={11} />{L(lang, 'تراجع', 'Undo')}</button>}
      </div>
      {!r.undone && r.cards?.map((c, i) => <CardView key={i} card={c} />)}
    </div>
  );
}

function MessageView({ chat, m, last, busy }: { chat: AiChat; m: AiMessage; last: boolean; busy: boolean }) {
  const { lang } = useT();
  const s = useSettings();
  if (m.role === 'tool') return null;
  if (m.role === 'user') return (
    <div className="anim-pop mt-3 flex justify-end"><div className="max-w-[85%] whitespace-pre-wrap rounded-[22px] rounded-ee-md bg-accent px-4 py-2.5 text-[15px] leading-7 text-accent-ink shadow-sm">{m.content}</div></div>
  );
  if (m.role === 'error') {
    const [code, ...rest] = m.content.split('|');
    return (
      <div className="anim-pop mt-3 rounded-2xl border border-danger/30 bg-danger/8 p-3 text-[13.5px]">
        <div className="flex items-center gap-2 font-bold text-danger"><AlertTriangle size={16} />{L(lang, 'محصلش رد', 'No reply')}</div>
        <p className="mt-1 leading-6">{errorText(new AiError(rest.join('|'), code as never), lang, providerById(chat.providerId))}</p>
        {last && !busy && <div className="mt-2 flex gap-2"><Button size="sm" variant="secondary" icon={<RotateCcw size={13} />} onClick={() => regenerate(chat.id)}>{L(lang, 'حاول تاني', 'Retry')}</Button><Button size="sm" variant="ghost" onClick={() => { useUI.getState().setTab('more'); useUI.getState().push('ai_providers'); }}>{L(lang, 'المزوّدين', 'Providers')}</Button></div>}
      </div>
    );
  }
  const p = providerById(m.providerId ?? chat.providerId);
  return (
    <div className="anim-pop mt-4 flex gap-2.5">
      <span className="mt-0.5 shrink-0"><AiLogo name={modelLogo(m.modelId ?? chat.modelId, p?.logo ?? 'openai')} size={28} /></span>
      <div className="min-w-0 flex-1">
        {m.fallbackFrom && <div className="mb-1 inline-flex items-center gap-1 rounded-full bg-info/10 px-2 py-0.5 text-[11px] font-semibold text-info">↻ {L(lang, `النموذج الأصلي مكانش متاح — ردّ بـ ${prettyModel(m.modelId ?? '')}`, `original model unavailable — answered by ${prettyModel(m.modelId ?? '')}`)}</div>}
        {m.content && <Markdown text={m.content} />}
        {m.runs?.map((r) => <RunView key={r.callId} chat={chat} m={m} r={r} />)}
        {(m.content || !m.runs?.length) && (
          <div className="mt-1.5 flex items-center gap-1 text-ink-3">
            <button aria-label={L(lang, 'نسخ', 'Copy')} onClick={() => { navigator.clipboard?.writeText(m.content).then(() => useApp.getState().toast('success', L(lang, 'اتنسخ', 'Copied'))).catch(() => undefined); }} className="press grid h-7 w-7 place-items-center rounded-full hover:bg-surface-2"><Copy size={13} /></button>
            {last && !busy && <button aria-label={L(lang, 'إعادة', 'Regenerate')} onClick={() => regenerate(chat.id)} className="press grid h-7 w-7 place-items-center rounded-full hover:bg-surface-2"><RotateCcw size={13} /></button>}
            <span className="num text-[10.5px]">{m.ms ? `${(m.ms / 1000).toFixed(1)}s` : ''}{m.usage?.output ? ` · ${m.usage.output} tok` : ''} · {fmtDateTime(m.at, lang, s.clock24)}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function HistorySheet({ open, onClose, chats, activeId, onOpen, onNew }: { open: boolean; onClose: () => void; chats: AiChat[]; activeId: string | null; onOpen: (id: string) => void; onNew: () => void }) {
  const { lang } = useT(); const s = useSettings();
  return (
    <Sheet open={open} onClose={onClose} tall title={L(lang, 'المحادثات', 'Chats')} footer={<Button className="w-full" icon={<MessageSquarePlus size={16} />} onClick={onNew}>{L(lang, 'محادثة جديدة', 'New chat')}</Button>}>
      {chats.length === 0 && <p className="text-center text-sm text-ink-3">{L(lang, 'لسه مفيش محادثات', 'No chats yet')}</p>}
      <div className="space-y-2">{chats.map((c) => { const p = providerById(c.providerId); return (
        <Card key={c.id} className={cn('flex items-center gap-3 p-3', c.id === activeId && 'ring-2 ring-accent')}>
          <button className="flex min-w-0 flex-1 items-center gap-3 text-start" onClick={() => onOpen(c.id)}>
            <AiLogo name={modelLogo(c.modelId, p?.logo ?? 'openai')} size={32} />
            <span className="min-w-0"><span className="block truncate text-[14px] font-semibold">{c.title || L(lang, 'محادثة', 'Chat')}</span><span className="block truncate text-[11px] text-ink-3">{c.messages.filter((m) => m.role === 'user').length} {L(lang, 'رسالة', 'msgs')} · {fmtDateTime(c.updatedAt, lang, s.clock24)}</span></span>
          </button>
          <button aria-label="pin" onClick={() => useApp.getState().put('aiChats', { ...c, pinned: !c.pinned })} className={cn('press grid h-8 w-8 place-items-center rounded-full', c.pinned ? 'text-accent' : 'text-ink-3')}><Pin size={15} /></button>
          <button aria-label={L(lang, 'امسح', 'Delete')} onClick={() => { useApp.getState().remove('aiChats', [c.id]); if (c.id === activeId) onNew(); }} className="press grid h-8 w-8 place-items-center rounded-full text-ink-3"><Trash2 size={15} /></button>
        </Card>
      ); })}</div>
    </Sheet>
  );
}

function SettingsSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { lang } = useT(); const s = useSettings();
  const up = (p: Partial<typeof s.ai>) => useApp.getState().updateSettings({ ai: { ...s.ai, ...p } });
  return (
    <Sheet open={open} onClose={onClose} title={L(lang, 'إعدادات المساعد', 'Assistant settings')}>
      <div className="space-y-4">
        <div><div className="mb-2 text-[13px] font-medium text-ink-2">{L(lang, 'التنفيذ', 'Execution')}</div>
          <Segmented size="sm" value={s.ai.execution} onChange={(v) => up({ execution: v })} options={[{ value: 'auto', label: L(lang, 'تلقائي', 'Auto') }, { value: 'confirm_destructive', label: L(lang, 'أكّد المسح', 'Confirm deletes') }, { value: 'confirm_all', label: L(lang, 'أكّد كل حاجة', 'Confirm all') }]} />
          <p className="mt-1.5 text-xs text-ink-3">{L(lang, 'في كل الحالات تقدر تتراجع عن أي خطوة اتعملت.', 'Every executed step can always be undone.')}</p></div>
        <Card className="px-4"><Toggle checked={s.ai.shareContext} onChange={(v) => up({ shareContext: v })} label={L(lang, 'ابعت ملخص يومي مع كل طلب', 'Send a short summary of my day')} description={L(lang, 'بيخلّي الردود أذكى. لو قفلته، المساعد هيقرا اللي يحتاجه بالأدوات بس.', 'Smarter replies. When off, the assistant only reads what it needs through tools.')} /></Card>
        <div><div className="mb-1 flex justify-between text-[13px] font-medium text-ink-2"><span>{L(lang, 'الإبداع (Temperature)', 'Creativity (temperature)')}</span><span className="num">{s.ai.temperature.toFixed(1)}</span></div>
          <input type="range" min={0} max={10} value={Math.round(s.ai.temperature * 10)} onChange={(e) => up({ temperature: Number(e.target.value) / 10 })} className="w-full accent-[var(--accent)]" /></div>
        <Button variant="secondary" className="w-full" onClick={() => { onClose(); useUI.getState().setTab('more'); useUI.getState().push('ai_providers'); }}>{L(lang, `المزوّدين والمفاتيح (${PROVIDERS.length})`, `Providers & keys (${PROVIDERS.length})`)}</Button>
        <Button variant="ghost" className="w-full" onClick={() => up({ consent: false })}>{L(lang, 'سحب الموافقة على مشاركة البيانات', 'Withdraw data-sharing consent')}</Button>
      </div>
    </Sheet>
  );
}

function ConsentSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { lang } = useT(); const s = useSettings();
  return (
    <Sheet open={open} onClose={onClose} title={<span className="flex items-center gap-2"><Sparkles size={18} className="text-accent" />{L(lang, 'قبل ما تبدأ', 'Before you start')}</span>}>
      <div className="space-y-3 text-[14px] leading-7">
        <p>{L(lang, 'المساعد هو الميزة الوحيدة في مدير اليوم اللي بتستخدم الإنترنت. لما تبعت رسالة:', 'The assistant is the only Dayflow feature that uses the internet. When you send a message:')}</p>
        <ul className="list-disc space-y-1 ps-5 text-ink-2">
          <li>{L(lang, 'رسالتك بتروح للمزوّد اللي اخترته (Groq أو Google أو غيرهم) بمفتاحك إنت.', 'Your message goes to the provider you chose (Groq, Google…) using your own key.')}</li>
          <li>{L(lang, 'المساعد بيقرا البيانات اللي محتاجها عشان ينفّذ (زي جدول اليوم أو المنبهات) وبيبعتها للمزوّد. تقدر تقفل «الملخص اليومي» من الإعدادات.', 'To act, it reads the data it needs (e.g. today’s plan or alarms) and sends it to the provider. You can turn off the daily summary in settings.')}</li>
          <li>{L(lang, 'مفيش أي سيرفر تابع لنا في النص، والمفاتيح محفوظة على جهازك بس ومش بتدخل في النسخ الاحتياطي.', 'No server of ours sits in between; keys stay on your device and are excluded from backups.')}</li>
          <li>{L(lang, 'بعض الخطط المجانية (زي Gemini المجاني) بتستخدم المحتوى لتحسين خدماتها — اقرا شروط المزوّد.', 'Some free plans (e.g. free Gemini) use content to improve their services — check the provider’s terms.')}</li>
        </ul>
        <div className="flex gap-2 pt-2"><Button className="flex-[2]" onClick={async () => { await useApp.getState().updateSettings({ ai: { ...s.ai, consent: true } }); onClose(); }}>{L(lang, 'موافق، يلا نبدأ', 'I agree, let’s start')}</Button><Button variant="secondary" className="flex-1" onClick={() => { onClose(); useUI.getState().setTab('today'); }}>{L(lang, 'لأ', 'No')}</Button></div>
      </div>
    </Sheet>
  );
}
