import { useMemo, useState } from 'react';
import { ArrowRight, Check, CircleSlash, Clock, Pause, Play, Scissors, SkipForward, StickyNote, Wand2, Pencil, RotateCcw, Ban, AlarmClockPlus } from 'lucide-react';
import { useApp, blocksForDate, instantiate } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { Badge, Button, Field, Input, Segmented, Sheet, Stepper, TextArea, useSettings, useT, useHaptic } from '@/components/common/ui';
import { BlockIcon, effectiveStatus, statusKey, statusTone, toSched, catName } from '@/components/cards/blocks';
import { planCatchUp, simulate, type Proposal, type SchedItem, type WhatIf } from '@/services/scheduling/engine';
import { addDays, fmtDuration, fmtTime, inputToMin, minToInput, nowMinutes, todayKey } from '@/utils/date';
import { uid } from '@/utils/id';
import { coreFrom } from '@/services/defaults';

export function ProposalView({ proposal, items }: { proposal: Proposal; items: SchedItem[] }) {
  const { t, lang } = useT();
  const s = useSettings();
  const ft = (m: number) => fmtTime(m, lang, s.clock24);
  if (!proposal.changes.length) return <p className="rounded-2xl bg-success/10 p-4 text-sm font-medium text-success">{t('no_changes')}</p>;
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Badge tone={proposal.feasible ? 'success' : 'warning'}>{proposal.feasible ? t('feasible') : t('infeasible')}</Badge>
        {proposal.shortageMin > 0 && <Badge tone="danger">{t('shortage', { d: fmtDuration(proposal.shortageMin, lang) })}</Badge>}
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-x-2 px-1 text-[11px] font-semibold uppercase text-ink-3"><span>{t('original')}</span><span /><span>{t('proposed')}</span></div>
      {proposal.changes.map((c) => (
        <div key={c.id + c.kind} className="card p-3">
          <div className="mb-1.5 flex items-center justify-between gap-2"><span className="truncate text-[15px] font-semibold">{c.title}</span>
            <Badge tone={c.kind === 'unplaced' || c.kind === 'remove' ? 'danger' : c.kind === 'split' ? 'info' : 'accent'}>{c.kind === 'unplaced' ? t('unplaced') : c.kind === 'split' ? t('split') : c.kind === 'remove' ? t('deferred') : c.kind === 'add' ? t('new') : t('moved')}</Badge></div>
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 text-sm">
            <span className="num text-ink-2 line-through decoration-ink-3/50">{c.kind === 'add' ? '—' : `${ft(c.from.startMin)} · ${fmtDuration(c.from.durationMin, lang)}`}</span>
            <ArrowRight size={14} className="text-ink-3 rtl:rotate-180" />
            <span className="num font-semibold">{c.to.length ? c.to.map((p) => `${ft(p.startMin)}–${ft(p.startMin + p.durationMin)}`).join(' + ') : '—'}</span>
          </div>
        </div>
      ))}
      {proposal.conflictsAfter.length > 0 && <p className="text-xs text-warning">{t('conflicts_found', { n: proposal.conflictsAfter.length })}</p>}
      <p className="sr-only">{items.length}</p>
    </div>
  );
}

export function CatchUpSheet() {
  const id = useUI((s) => s.catchUpFor);
  const close = () => useUI.getState().set({ catchUpFor: null });
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const block = id ? data.activities[id] : undefined;
  const plan = useMemo(() => {
    if (!block) return null;
    const items = blocksForDate(data, block.date).map(toSched);
    return planCatchUp(items, { delayedId: block.id, nowMin: block.date === todayKey() ? nowMinutes() : block.startMin, dayEndMin: s.dayEndMin });
  }, [block, data, s.dayEndMin]);
  if (!block || !plan) return null;
  const unplacedBlocks = plan.proposal.unplaced.map((u) => data.activities[u]).filter(Boolean);
  const accept = async () => {
    const ok = await useApp.getState().applyProposal(block.date, plan.result, plan.proposal, t('catchup_reason', { x: block.title, d: fmtDuration(plan.delayMin, lang) }), 'catchup');
    if (ok && unplacedBlocks.length) {
      // Unplaced flexible items are moved to tomorrow only because the user accepted the proposal.
      const tomorrow = addDays(block.date, 1);
      await useApp.getState().commit({ activities: unplacedBlocks.map((b) => ({ ...b, date: tomorrow, detached: b.seriesId ? true : b.detached, updatedAt: Date.now() })) });
    }
    close();
  };
  return (
    <Sheet open onClose={close} title={t('catchup')} tall footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={close}>{t('reject')}</Button><Button className="flex-[2]" onClick={accept} disabled={!plan.proposal.changes.length}>{t('accept')}</Button></div>}>
      <p className="mb-1 text-sm text-ink-2">{t('catchup_desc')}</p>
      <p className="mb-4 text-[15px] font-semibold">{t('catchup_reason', { x: block.title, d: fmtDuration(plan.delayMin, lang) })}</p>
      <ProposalView proposal={plan.proposal} items={plan.result} />
      <div className="mt-5 card p-4 text-sm">
        <h4 className="mb-1 font-semibold">{t('expected_effect')}</h4>
        <p className="text-ink-2">{plan.proposal.changes.filter((c) => c.kind === 'move').length} {t('moved')} · {plan.proposal.changes.filter((c) => c.kind === 'split').length} {t('split')} · {unplacedBlocks.length} {t('deferred')}</p>
        {!plan.proposal.feasible && (
          <>
            <h4 className="mb-1 mt-3 font-semibold">{t('alternatives')}</h4>
            <ul className="list-inside list-disc space-y-0.5 text-ink-2">
              <li>{t('alt_split')}</li><li>{t('alt_reduce')}</li><li>{t('alt_move_low')}</li><li>{t('alt_extend_deadline')}</li><li>{t('alt_leave')}</li>
            </ul>
          </>
        )}
      </div>
    </Sheet>
  );
}

export function WhatIfSheet() {
  const id = useUI((s) => s.whatIfFor);
  const close = () => useUI.getState().set({ whatIfFor: null });
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const block = id ? data.activities[id] : undefined;
  const [kind, setKind] = useState<'delay' | 'extend' | 'move_tomorrow' | 'add'>('delay');
  const [minutes, setMinutes] = useState(60);
  const [newTitle, setNewTitle] = useState('');
  const [newStart, setNewStart] = useState(block ? block.startMin : 12 * 60);
  const [newDur, setNewDur] = useState(60);
  const sim = useMemo(() => {
    if (!block) return null;
    const items = blocksForDate(data, block.date).map(toSched);
    const change: WhatIf = kind === 'delay' ? { type: 'delay', id: block.id, minutes } : kind === 'extend' ? { type: 'extend', id: block.id, minutes } : kind === 'move_tomorrow' ? { type: 'move_tomorrow', id: block.id }
      : { type: 'add', item: { id: '__new', title: newTitle || t('whatif_add'), startMin: newStart, durationMin: newDur, fixed: true, status: 'planned', priority: 4 } };
    return simulate(items, change, { nowMin: block.date === todayKey() ? nowMinutes() : 0, dayEndMin: s.dayEndMin });
  }, [block, data, kind, minutes, newTitle, newStart, newDur, s.dayEndMin, t]);
  if (!block || !sim) return null;
  const apply = async () => {
    const st = useApp.getState();
    const reason = `${t('what_if')}: ${t(kind === 'delay' ? 'whatif_delay' : kind === 'extend' ? 'whatif_extend' : kind === 'move_tomorrow' ? 'whatif_tomorrow' : 'whatif_add')}`;
    if (kind === 'move_tomorrow') {
      await st.commit({ activities: [{ ...block, date: addDays(block.date, 1), detached: block.seriesId ? true : block.detached, updatedAt: Date.now() }] });
      const rest = sim.proposal.changes.filter((c) => c.id !== block.id && c.kind !== 'remove');
      if (rest.length) await st.applyProposal(block.date, sim.result, { ...sim.proposal, changes: rest }, reason, 'what_if');
      else st.toast('success', st.t('applied'));
    } else if (kind === 'add') {
      const nb = instantiate(coreFrom({ title: newTitle || t('whatif_add'), categoryId: 'cat_appointment', startMin: newStart, durationMin: newDur, fixed: true }), block.date);
      nb.id = uid('b');
      await st.commit({ activities: [nb] });
      await st.applyProposal(block.date, sim.result, { ...sim.proposal, changes: sim.proposal.changes.filter((c) => c.id !== '__new') }, reason, 'what_if');
    } else {
      await st.applyProposal(block.date, sim.result, sim.proposal, reason, 'what_if');
    }
    close();
  };
  return (
    <Sheet open onClose={close} title={t('what_if')} tall footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={close}>{t('reject')}</Button><Button className="flex-[2]" onClick={apply}>{t('apply')}</Button></div>}>
      <p className="mb-3 text-sm text-ink-2">{t('whatif_title')} · <b>{block.title}</b></p>
      <Segmented value={kind} onChange={setKind} size="sm" className="mb-4" options={[{ value: 'delay', label: t('whatif_delay') }, { value: 'extend', label: t('whatif_extend') }, { value: 'move_tomorrow', label: t('whatif_tomorrow') }, { value: 'add', label: t('whatif_add') }]} />
      {(kind === 'delay' || kind === 'extend') && <div className="mb-4 flex items-center justify-between"><span>{t('minutes')}</span><Stepper value={minutes} onChange={setMinutes} min={5} max={600} step={15} /></div>}
      {kind === 'add' && (
        <div className="mb-4 grid grid-cols-2 gap-3">
          <div className="col-span-2"><Field label={t('title')}><Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} /></Field></div>
          <Field label={t('start')}><Input type="time" value={minToInput(newStart)} onChange={(e) => setNewStart(inputToMin(e.target.value))} /></Field>
          <Field label={t('duration')}><Stepper value={newDur} onChange={setNewDur} min={5} max={600} step={15} /></Field>
        </div>
      )}
      <h4 className="mb-2 text-sm font-semibold text-ink-2">{t('preview')} · {fmtTime(block.startMin, lang, s.clock24)}</h4>
      <ProposalView proposal={sim.proposal} items={sim.result} />
    </Sheet>
  );
}

export function BlockDetailSheet() {
  const id = useUI((s) => s.detailFor);
  const close = () => useUI.getState().set({ detailFor: null });
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const block = useApp((st) => (id ? st.data.activities[id] : undefined));
  const cat = useApp((st) => (block ? st.data.categories[block.categoryId] : undefined));
  const [note, setNote] = useState('');
  const [percent, setPercent] = useState(50);
  if (!block) return null;
  const act = useApp.getState().blockAction;
  const isToday = block.date === todayKey();
  const eff = effectiveStatus(block, isToday, nowMinutes());
  const run = async (a: Parameters<typeof act>[1], extra?: Parameters<typeof act>[2]) => { h(12); const ok = await act(block.id, a, extra); if (ok) useApp.getState().toast('success', t('saved')); };
  const open = block.status === 'planned' || block.status === 'active' || block.status === 'paused';
  return (
    <Sheet open onClose={close} title={block.title}>
      <div className="mb-4 flex items-center gap-3">
        <BlockIcon block={block} size={48} />
        <div className="min-w-0 flex-1">
          <div className="num text-[15px] font-semibold">{fmtTime(block.startMin, lang, s.clock24)} – {fmtTime(block.startMin + block.durationMin, lang, s.clock24)} · {fmtDuration(block.durationMin, lang)}</div>
          <div className="mt-1 flex flex-wrap gap-1.5"><Badge tone={statusTone(eff)}>{t(statusKey(eff))}</Badge><Badge>{catName(cat, lang)}</Badge><Badge tone={block.fixed ? 'accent' : 'neutral'}>{block.fixed ? t('fixed') : t('flexible')}</Badge></div>
        </div>
      </div>
      {block.actualStart && <p className="mb-3 text-sm text-ink-2">{t('actual_start')}: {new Date(block.actualStart).toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', { hour: 'numeric', minute: '2-digit', hour12: !s.clock24 })}</p>}
      <div className="grid grid-cols-3 gap-2">
        {block.status === 'planned' && <ActionTile icon={<Play size={18} />} label={t('act_start')} onClick={() => run('start')} />}
        {block.status === 'active' && <ActionTile icon={<Pause size={18} />} label={t('act_pause')} onClick={() => run('pause')} />}
        {block.status === 'paused' && <ActionTile icon={<Play size={18} />} label={t('act_resume')} onClick={() => run('resume')} />}
        {open && <ActionTile icon={<Check size={18} />} label={t('act_complete')} tone="success" onClick={() => run('complete')} />}
        {open && <ActionTile icon={<SkipForward size={18} />} label={t('act_skip')} onClick={() => run('skip')} />}
        {open && !block.fixed && <ActionTile icon={<AlarmClockPlus size={18} />} label={`${t('act_snooze')} 10`} onClick={() => run('snooze', { minutes: 10 })} />}
        {open && <ActionTile icon={<Clock size={18} />} label={t('catchup')} onClick={() => { close(); useUI.getState().set({ catchUpFor: block.id }); }} />}
        <ActionTile icon={<Wand2 size={18} />} label={t('what_if')} onClick={() => { close(); useUI.getState().set({ whatIfFor: block.id }); }} />
        <ActionTile icon={<Pencil size={18} />} label={t('edit')} onClick={() => { close(); setTimeout(() => useUI.getState().openEditor({ blockId: block.id }), 30); }} />
        {!open && <ActionTile icon={<RotateCcw size={18} />} label={t('act_reset')} onClick={() => run('reset')} />}
        {open && <ActionTile icon={<Ban size={18} />} label={t('act_cancel_block')} tone="danger" onClick={() => run('cancel')} />}
      </div>
      {open && (block.status === 'active' || block.status === 'paused' || block.status === 'planned') && (
        <div className="mt-4 card p-3">
          <div className="mb-2 flex items-center justify-between text-sm"><span className="flex items-center gap-1.5"><Scissors size={15} />{t('act_partial')}</span><Stepper value={percent} onChange={setPercent} min={5} max={95} step={5} suffix="%" /></div>
          <Button variant="tinted" className="w-full" onClick={() => run('partial', { percent })}>{t('act_partial')}</Button>
        </div>
      )}
      <div className="mt-4 card p-3">
        <Field label={<span className="flex items-center gap-1.5"><StickyNote size={15} />{t('act_note')}</span>}><TextArea value={note} onChange={(e) => setNote(e.target.value)} /></Field>
        <Button variant="secondary" className="mt-2 w-full" disabled={!note.trim()} onClick={() => { run('note', { note: note.trim() }); setNote(''); }}>{t('save')}</Button>
        {block.notes && <p className="mt-3 whitespace-pre-wrap text-sm text-ink-2">{block.notes}</p>}
      </div>
      {block.events.length > 0 && (
        <div className="mt-4 text-xs text-ink-3">
          {block.events.slice(-6).reverse().map((e, i) => <div key={i} className="flex justify-between py-0.5"><span>{e.action} · {e.source}</span><span className="num">{new Date(e.at).toLocaleTimeString()}</span></div>)}
        </div>
      )}
      {block.status === 'cancelled' && <p className="mt-3 flex items-center gap-1 text-sm text-ink-3"><CircleSlash size={14} />{t('st_cancelled')}</p>}
    </Sheet>
  );
}

function ActionTile({ icon, label, onClick, tone }: { icon: React.ReactNode; label: string; onClick: () => void; tone?: 'success' | 'danger' }) {
  return (
    <button onClick={onClick} className={`press flex flex-col items-center gap-1.5 rounded-2xl px-2 py-3 text-[12px] font-semibold ${tone === 'success' ? 'bg-success/12 text-success' : tone === 'danger' ? 'bg-danger/10 text-danger' : 'bg-surface-2 text-ink'}`}>
      {icon}<span className="text-center leading-tight">{label}</span>
    </button>
  );
}
