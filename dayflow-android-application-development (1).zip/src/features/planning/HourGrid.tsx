import { useMemo, useRef, useState } from 'react';
import { GripHorizontal, Plus, StickyNote, FileEdit } from 'lucide-react';
import { useApp, blocksForDate, snapshot } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { useConfirm, useHaptic, useSettings, useT } from '@/components/common/ui';
import { effectiveStatus, statusKey, toSched } from '@/components/cards/blocks';
import { detectConflicts, layoutLanes } from '@/services/scheduling/engine';
import { fmtNumber, fmtTime, nowMinutes, todayKey, weekdayName } from '@/utils/date';
import { uid } from '@/utils/id';
import { cn } from '@/utils/cn';
import type { ActivityBlock, DateKey } from '@/models/types';

interface Drag { id: string; mode: 'move' | 'resize'; sx: number; sy: number; dx: number; dy: number; moved: boolean }
const MIN_H = 48; // px — every block keeps enough room for time + title + note

export function HourGrid({ days, onConflict, onPickDay }: { days: DateKey[]; onConflict: (d: DateKey, id: string) => void; onPickDay: (d: DateKey) => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const { ask, node } = useConfirm();
  const ppm = { compact: 0.85, comfortable: 1.15, spacious: 1.5 }[s.density];
  const startHour = Math.max(0, Math.floor(s.dayStartMin / 60) - 1);
  const [drag, setDrag] = useState<Drag | null>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const press = useRef<{ timer: number; x: number; y: number } | null>(null);
  const today = todayKey();
  const nowMin = nowMinutes();
  const top = (m: number) => (m - startHour * 60) * ppm;
  const ft = (m: number) => fmtTime(m, lang, s.clock24);

  const cols = useMemo(() => days.map((d) => {
    const blocks = blocksForDate(data, d).filter((b) => b.status !== 'cancelled');
    return { d, blocks, lanes: layoutLanes(blocks.map((b) => ({ id: b.id, start: b.startMin, end: b.startMin + b.durationMin })), MIN_H / ppm), conflicts: detectConflicts(blocks.map(toSched)) };
  }), [data, days, ppm]);

  const colW = () => Math.max(60, ((bodyRef.current?.clientWidth ?? 320) - 44) / days.length);
  const deltaOf = (d: Drag) => Math.round(d.dy / ppm / 5) * 5;

  const commit = async (b: ActivityBlock, d: Drag) => {
    const delta = deltaOf(d);
    const idx = Math.max(0, days.indexOf(b.date));
    const shift = days.length > 1 && d.mode === 'move' ? Math.round(d.dx / colW()) : 0;
    const newDate = days[Math.min(days.length - 1, Math.max(0, idx + shift))];
    const patch: Partial<ActivityBlock> = d.mode === 'resize'
      ? { durationMin: Math.max(5, Math.min(1440 - b.startMin, b.durationMin + delta)) }
      : { startMin: Math.max(0, Math.min(1435, b.startMin + delta)), date: newDate };
    if ((d.mode === 'resize' && patch.durationMin === b.durationMin) || (d.mode === 'move' && patch.startMin === b.startMin && newDate === b.date)) return;
    if (b.fixed && !(await ask(t('fixed_move_confirm'), b.title, t('confirm'), false))) return;
    const before = snapshot(b);
    if (!(await useApp.getState().updateActivity(b.id, patch))) return;
    const nb = useApp.getState().data.activities[b.id];
    const n = Date.now();
    await useApp.getState().put('scheduleChanges', { id: uid('sc'), date: nb.date, reason: b.title, kind: 'drag', before: [before], after: [snapshot(nb)], created: [], deleted: [], reverted: false, createdAt: n, updatedAt: n });
    h(16);
    const hits = detectConflicts(blocksForDate(useApp.getState().data, nb.date).map(toSched)).filter((c) => (c.a === b.id || c.b === b.id) && (c.type === 'overlap' || c.type === 'fixed_overlap'));
    if (hits.length) useApp.getState().toast('info', t('conflicts_found', { n: hits.length }), { label: t('resolve'), run: () => onConflict(nb.date, b.id) });
  };

  const addAt = (d: DateKey, clientY: number, host: HTMLElement) => {
    const r = host.getBoundingClientRect();
    const m = Math.max(0, Math.min(1425, Math.round(((clientY - r.top) / ppm + startHour * 60) / 15) * 15));
    h(20);
    ui.openEditor({ date: d, startMin: m });
  };
  const cancelPress = () => { if (press.current) { clearTimeout(press.current.timer); press.current = null; } };

  return (
    <div className="mt-3 card overflow-hidden" dir="ltr">
      {node}
      <div className="grid border-b border-line" style={{ gridTemplateColumns: `44px repeat(${days.length}, 1fr)` }}>
        <div />
        {cols.map(({ d, blocks }) => {
          const drafts = blocks.filter((b) => b.applied === false).length;
          return (
            <div key={d} className="flex items-center justify-center gap-1 py-1.5">
              <button onClick={() => onPickDay(d)} className={cn('min-w-0 text-center text-[11px] font-semibold', d === today ? 'text-accent' : 'text-ink-2')}>
                {weekdayName(new Date(d + 'T12:00').getDay(), lang)}<div className="num text-[15px] leading-4">{fmtNumber(Number(d.slice(8)), lang)}</div>
              </button>
              <button aria-label={t('add_activity')} onClick={() => ui.openEditor({ date: d })} className="press relative grid h-7 w-7 place-items-center rounded-full bg-accent-soft text-accent">
                <Plus size={15} />{drafts > 0 && <span className="absolute -end-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-warning ring-2 ring-[var(--surface)]" />}
              </button>
            </div>
          );
        })}
      </div>
      <div ref={bodyRef} className="relative max-h-[64vh] overflow-y-auto no-scrollbar">
        <div className="relative grid" style={{ gridTemplateColumns: `44px repeat(${days.length}, 1fr)`, height: (24 - startHour) * 60 * ppm }}>
          <div className="relative">
            {Array.from({ length: 24 - startHour }, (_, i) => <div key={i} className="num absolute end-1 -translate-y-1/2 text-[10px] text-ink-3" style={{ top: i * 60 * ppm }}>{i ? ft((startHour + i) * 60) : ''}</div>)}
          </div>
          {cols.map(({ d, blocks, lanes, conflicts }) => (
            <div key={d} className="relative border-s border-line"
              onPointerDown={(e) => { if (e.target !== e.currentTarget && !(e.target as HTMLElement).dataset.slot) return; const host = e.currentTarget as HTMLElement, y = e.clientY; press.current = { x: e.clientX, y, timer: window.setTimeout(() => { addAt(d, y, host); press.current = null; }, 480) }; }}
              onPointerMove={(e) => { if (press.current && (Math.abs(e.clientX - press.current.x) > 8 || Math.abs(e.clientY - press.current.y) > 8)) cancelPress(); }}
              onPointerUp={cancelPress} onPointerCancel={cancelPress} onPointerLeave={cancelPress}
              onDoubleClick={(e) => { if (e.target === e.currentTarget) addAt(d, e.clientY, e.currentTarget as HTMLElement); }}>
              {Array.from({ length: 24 - startHour }, (_, i) => <div key={i} data-slot="1" className="absolute inset-x-0 border-t border-line/60" style={{ top: i * 60 * ppm, height: 60 * ppm }} />)}
              {d === today && <div className="pointer-events-none absolute inset-x-0 z-20 h-[2px] bg-danger" style={{ top: top(nowMin) }}><span className="absolute -start-1 -top-1 h-2.5 w-2.5 rounded-full bg-danger" /></div>}
              {blocks.map((b) => {
                const lane = lanes[b.id] ?? { col: 0, cols: 1 };
                const dr = drag?.id === b.id ? drag : null;
                const delta = dr ? deltaOf(dr) : 0;
                const shift = dr && dr.mode === 'move' && days.length > 1 ? Math.round(dr.dx / colW()) : 0;
                const startShown = dr?.mode === 'move' ? Math.max(0, Math.min(1435, b.startMin + delta)) : b.startMin;
                const durShown = dr?.mode === 'resize' ? Math.max(5, b.durationMin + delta) : b.durationMin;
                const height = Math.max(MIN_H, durShown * ppm - 2);
                const eff = effectiveStatus(b, d === today, nowMin);
                const overlap = conflicts.some((c) => (c.a === b.id || c.b === b.id) && c.type !== 'buffer');
                const draft = b.applied === false;
                const narrow = lane.cols >= 3;
                const w = 100 / lane.cols;
                const noteTxt = b.notes?.trim() || b.description?.trim();
                return (
                  <div key={b.id} className={cn('absolute overflow-hidden rounded-xl border text-start transition-shadow', dr && 'z-40 shadow-float ring-2 ring-accent/60', !dr && 'z-10', ['completed', 'skipped'].includes(b.status) && 'opacity-60')}
                    style={{ top: top(startShown), height, left: `calc(${lane.col * w}% + 2px)`, width: `calc(${w}% - 4px)`, transform: dr ? `translateX(${shift * colW()}px) scale(1.02)` : undefined,
                      background: `color-mix(in srgb, ${b.color} ${draft ? 8 : 18}%, var(--surface))`, borderColor: overlap ? 'var(--warning)' : `color-mix(in srgb, ${b.color} 45%, transparent)`, borderStyle: draft ? 'dashed' : 'solid', borderInlineStartWidth: 4, borderInlineStartColor: b.color }}
                    dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                    {dr && (
                      <div className="pointer-events-none absolute -top-8 start-0 z-50 whitespace-nowrap rounded-lg bg-ink px-2 py-1 text-[11px] font-bold text-bg shadow-float">
                        {ft(startShown)} – {ft(startShown + durShown)}{dr.mode === 'move' && shift ? ` · ${weekdayName(new Date((days[Math.min(days.length - 1, Math.max(0, days.indexOf(b.date) + shift))]) + 'T12:00').getDay(), lang)}` : ''}
                      </div>
                    )}
                    {/* drag grip = time row */}
                    <div className="flex touch-none cursor-grab items-center gap-1 px-1.5 pt-1 active:cursor-grabbing"
                      onPointerDown={(e) => { e.stopPropagation(); cancelPress(); (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); h(8); setDrag({ id: b.id, mode: 'move', sx: e.clientX, sy: e.clientY, dx: 0, dy: 0, moved: false }); }}
                      onPointerMove={(e) => { if (drag?.id === b.id && drag.mode === 'move') setDrag({ ...drag, dx: e.clientX - drag.sx, dy: e.clientY - drag.sy, moved: drag.moved || Math.abs(e.clientY - drag.sy) > 4 || Math.abs(e.clientX - drag.sx) > 4 }); }}
                      onPointerUp={() => { const d0 = drag; setDrag(null); if (d0?.moved) commit(b, d0); else ui.set({ detailFor: b.id }); }} onPointerCancel={() => setDrag(null)}>
                      <GripHorizontal size={12} className="shrink-0 text-ink-3" />
                      <span className="num truncate text-[10.5px] font-extrabold" style={{ color: `color-mix(in srgb, ${b.color} 70%, var(--ink))` }}>{ft(startShown)}{narrow ? '' : ` – ${ft(startShown + durShown)}`}</span>
                      {draft && <FileEdit size={10} className="ms-auto shrink-0 text-warning" />}
                    </div>
                    <button className="block w-full px-1.5 pb-3 text-start" onClick={() => ui.set({ detailFor: b.id })}>
                      <div className={cn('font-semibold leading-tight', narrow ? 'line-clamp-2 text-[11px]' : 'truncate text-[12.5px]')}>{b.title}</div>
                      {noteTxt && height >= 46 && <div className={cn('mt-0.5 flex items-start gap-0.5 text-ink-2', narrow ? 'text-[9.5px]' : 'text-[10.5px]', height >= 78 ? 'line-clamp-2' : 'line-clamp-1')}><StickyNote size={9} className="mt-0.5 shrink-0" />{noteTxt}</div>}
                      {height >= 92 && <div className="mt-1 text-[10px] font-semibold text-ink-3">{t(statusKey(eff))}</div>}
                    </button>
                    {/* resize handle */}
                    <div className="absolute inset-x-0 bottom-0 flex h-3.5 touch-none cursor-ns-resize items-end justify-center"
                      onPointerDown={(e) => { e.stopPropagation(); cancelPress(); (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); h(8); setDrag({ id: b.id, mode: 'resize', sx: e.clientX, sy: e.clientY, dx: 0, dy: 0, moved: false }); }}
                      onPointerMove={(e) => { if (drag?.id === b.id && drag.mode === 'resize') setDrag({ ...drag, dy: e.clientY - drag.sy, moved: true }); }}
                      onPointerUp={() => { const d0 = drag; setDrag(null); if (d0?.moved) commit(b, d0); }} onPointerCancel={() => setDrag(null)}>
                      <span className="mb-0.5 h-1 w-8 rounded-full bg-ink/25" />
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
