import { useMemo, useState } from 'react';
import { Copy, LayoutTemplate, Plus, Save, ShieldAlert, Wand2, GripVertical } from 'lucide-react';
import { useApp, blocksForDate } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { Badge, Button, Card, EmptyState, Field, IconButton, Input, Page, ScreenHeader, SectionTitle, Segmented, Sheet, useSettings, useT } from '@/components/common/ui';
import { BlockIcon, effectiveStatus, statusKey, statusTone, toSched, catName } from '@/components/cards/blocks';
import { ProposalView } from './ScheduleTools';
import { HourGrid } from './HourGrid';
import { detectConflicts, repack, summarizeDay, type Proposal, type SchedItem } from '@/services/scheduling/engine';
import { evaluateRules, type RuleViolation } from '@/services/scheduling/rules';
import { addDays, fmtDate, fmtDuration, fmtNumber, fmtTime, monthGrid, nowMinutes, rangeKeys, startOfWeek, todayKey, weekdayName } from '@/utils/date';
import { instantiate } from '@/stores/appStore';
import { coreFrom } from '@/services/defaults';

import { cn } from '@/utils/cn';
import type { DateKey } from '@/models/types';

type View = 'day' | '3day' | 'week' | 'month' | 'agenda' | 'timeline';

export function PlanScreen() {
  const { t, lang } = useT();
  const s = useSettings();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const [view, setView] = useState<View>('day');
  const [date, setDate] = useState<DateKey>(ui.selectedDate ?? todayKey());
  const [sheet, setSheet] = useState<null | 'templates' | 'duplicate' | 'saveTpl'>(ui.selectedDate ? 'templates' : null);
  const [resolve, setResolve] = useState<{ date: DateKey; items: SchedItem[]; proposal: Proposal; reason: string } | null>(null);
  const step = view === 'month' ? 30 : view === 'week' ? 7 : view === '3day' ? 3 : 1;
  const move = (d: number) => setDate(view === 'month' ? shiftMonth(date, d) : addDays(date, d * step));
  useMemo(() => { useApp.getState().ensureDays(date, view === 'week' ? 7 : view === '3day' ? 3 : 1); }, [date, view]);

  const title = view === 'month' ? new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-US', { month: 'long', year: 'numeric' }).format(new Date(date + 'T12:00')) : fmtDate(date, lang, { weekday: 'short', day: 'numeric', month: 'short' });
  const days = view === 'week' ? rangeKeys(startOfWeek(date, s.weekStart), 7) : view === '3day' ? rangeKeys(date, 3) : [date];

  const openResolve = (d: DateKey, lockId?: string, reason?: string) => {
    const items = blocksForDate(useApp.getState().data, d).map(toSched);
    const { result, proposal } = repack(items, { fromMin: d === todayKey() ? nowMinutes() : 0, dayEndMin: s.dayEndMin, lockedIds: lockId ? [lockId] : [] });
    setResolve({ date: d, items: result, proposal, reason: reason ?? t('resolve') });
  };

  return (
    <div>
      <ScreenHeader title={t('nav_plan')} subtitle={title} actions={<>
        <IconButton label={t('templates')} onClick={() => setSheet('templates')}><LayoutTemplate size={20} /></IconButton>
        <IconButton label={t('add_activity')} onClick={() => ui.openEditor({ date })}><Plus size={22} /></IconButton>
      </>} />
      <Page>
        <Segmented value={view} onChange={setView} size="sm" options={[{ value: 'day', label: t('view_day') }, { value: '3day', label: t('view_3day') }, { value: 'week', label: t('view_week') }, { value: 'month', label: t('view_month') }, { value: 'agenda', label: t('view_agenda') }, { value: 'timeline', label: t('view_timeline') }]} />
        <div className="mt-3 flex items-center justify-between">
          <Button size="sm" variant="secondary" onClick={() => move(-1)}><span className="rtl:rotate-180">‹</span></Button>
          <button className="text-sm font-semibold text-accent" onClick={() => setDate(todayKey())}>{t('today')}</button>
          <Button size="sm" variant="secondary" onClick={() => move(1)}><span className="rtl:rotate-180">›</span></Button>
        </div>
        {(view === 'day' || view === '3day' || view === 'week') && (
          <>
            <ApplyBar days={days} />
            <p className="mt-2 text-center text-xs text-ink-3"><GripVertical size={12} className="inline" /> {t('drag_hint')}</p>
            <HourGrid days={days} onConflict={(d, id) => openResolve(d, id, t('resolve'))} onPickDay={(d) => { setDate(d); setView('day'); }} />
          </>
        )}
        {view === 'day' && <DayTools date={date} onDuplicate={() => setSheet('duplicate')} onSaveTpl={() => setSheet('saveTpl')} onResolve={() => openResolve(date)} />}
        {view === 'month' && <MonthView date={date} onPick={(d) => { setDate(d); setView('day'); }} />}
        {view === 'agenda' && <Agenda from={date} />}
        {view === 'timeline' && <TimelineBars from={date} onPick={(d) => { setDate(d); setView('day'); }} />}
      </Page>

      <TemplatesSheet open={sheet === 'templates'} date={date} onClose={() => { setSheet(null); ui.set({ selectedDate: null }); }} />
      <DuplicateSheet open={sheet === 'duplicate'} date={date} onClose={() => setSheet(null)} />
      <SaveTplSheet open={sheet === 'saveTpl'} date={date} onClose={() => setSheet(null)} />
      <Sheet open={!!resolve} onClose={() => setResolve(null)} title={t('resolve')} tall footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setResolve(null)}>{t('reject')}</Button><Button className="flex-[2]" disabled={!resolve?.proposal.changes.length} onClick={async () => { if (resolve) await useApp.getState().applyProposal(resolve.date, resolve.items, resolve.proposal, resolve.reason, 'drag'); setResolve(null); }}>{t('accept')}</Button></div>}>
        {resolve && <ProposalView proposal={resolve.proposal} items={resolve.items} />}
      </Sheet>
      {void data}
    </div>
  );
}

function shiftMonth(d: DateKey, n: number): DateKey { const x = new Date(d + 'T12:00'); x.setMonth(x.getMonth() + n, 1); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-01`; }

function DayTools({ date, onDuplicate, onSaveTpl, onResolve }: { date: DateKey; onDuplicate: () => void; onSaveTpl: () => void; onResolve: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const blocks = blocksForDate(data, date);
  const sum = summarizeDay(blocks, { isToday: date === todayKey(), isPast: date < todayKey(), nowMin: nowMinutes(), dayEndMin: s.dayEndMin });
  const conflicts = detectConflicts(blocks.map(toSched)).filter((c) => c.type === 'overlap' || c.type === 'fixed_overlap');
  const scheduledTaskIds = new Set(Object.values(data.activities).filter((b) => b.taskId && b.date >= todayKey()).map((b) => b.taskId!));
  const violations = evaluateRules(Object.values(data.rules), { date, blocks, categories: data.categories, settings: s, tasks: Object.values(data.tasks), scheduledTaskIds, fmtTime: (m) => fmtTime(m, lang, s.clock24), fmtDate: (d) => fmtDate(d, lang, { day: 'numeric', month: 'short' }) });

  const applySuggestion = async (v: RuleViolation) => {
    const sg = v.suggestion; if (!sg) return;
    const st = useApp.getState();
    if (sg.type === 'insert_break' && sg.atMin != null) {
      const b = instantiate(coreFrom({ title: t('qa_break'), categoryId: 'cat_rest', startMin: sg.atMin, durationMin: sg.minutes ?? 10, fixed: true }), date, { source: 'manual' });
      await st.commit({ activities: [b] });
      onResolve();
    } else if (sg.type === 'add_prep' && sg.blockId) {
      await st.updateActivity(sg.blockId, { prepMin: sg.minutes ?? 10 });
      onResolve();
    } else if (sg.type === 'move_later' && sg.blockId) ui.set({ whatIfFor: sg.blockId });
    else if (sg.type === 'schedule_task') { ui.setTab('more'); ui.push('tasks'); }
  };

  return (
    <>
      <div className="mt-3 grid grid-cols-3 gap-2">
        <Card className="p-3 text-center"><div className="num text-[17px] font-bold">{fmtDuration(sum.plannedMin, lang)}</div><div className="text-[11px] text-ink-3">{t('planned')}</div></Card>
        <Card className="p-3 text-center"><div className="num text-[17px] font-bold">{fmtDuration(sum.freeLeftMin, lang)}</div><div className="text-[11px] text-ink-3">{t('free_time_left')}</div></Card>
        <Card className="p-3 text-center"><div className={cn('num text-[17px] font-bold', conflicts.length && 'text-warning')}>{fmtNumber(conflicts.length, lang)}</div><div className="text-[11px] text-ink-3">{t('conflicts')}</div></Card>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" icon={<Copy size={14} />} onClick={onDuplicate}>{t('duplicate_day')}</Button>
        <Button size="sm" variant="secondary" icon={<Save size={14} />} onClick={onSaveTpl} disabled={!blocks.length}>{t('save_as_template')}</Button>
        {conflicts.length > 0 && <Button size="sm" variant="tinted" icon={<Wand2 size={14} />} onClick={onResolve}>{t('resolve')}</Button>}
      </div>
      <SectionTitle>{t('rule_violations')}</SectionTitle>
      {violations.length === 0 ? <p className="px-1 text-sm text-ink-3">{t('no_violations')}</p> : (
        <div className="space-y-2">{violations.map((v, i) => (
          <Card key={i} className="flex items-start gap-3 p-3">
            <ShieldAlert size={18} className={v.severity === 'warning' ? 'mt-0.5 text-warning' : 'mt-0.5 text-info'} />
            <div className="min-w-0 flex-1"><div className="text-[13px] font-semibold text-ink-2">{t(`ru_${v.ruleType}` as 'ru_no_overlap')}</div><div className="text-sm">{t(v.messageKey, v.params)}</div></div>
            {v.suggestion && v.suggestion.type !== 'raise_water' && <Button size="sm" variant="tinted" onClick={() => applySuggestion(v)}>{t(v.suggestion.type === 'insert_break' ? 'insert_break' : v.suggestion.type === 'add_prep' ? 'add_prep' : v.suggestion.type === 'move_later' ? 'move_later' : 'schedule_task')}</Button>}
          </Card>
        ))}</div>
      )}
    </>
  );
}

function MonthView({ date, onPick }: { date: DateKey; onPick: (d: DateKey) => void }) {
  const { lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const cells = monthGrid(date, s.weekStart);
  const month = date.slice(0, 7);
  const today = todayKey();
  return (
    <div className="mt-3 card p-3">
      <div className="mb-2 grid grid-cols-7 text-center text-[11px] font-semibold text-ink-3">{cells.slice(0, 7).map((d) => <span key={d}>{weekdayName(new Date(d + 'T12:00').getDay(), lang, 'narrow')}</span>)}</div>
      <div className="grid grid-cols-7 gap-1">
        {cells.map((d) => {
          const bl = blocksForDate(data, d).filter((b) => b.status !== 'cancelled');
          const done = bl.filter((b) => b.status === 'completed').length;
          const special = Object.values(data.specialDates).find((x) => x.date === d);
          return (
            <button key={d} onClick={() => onPick(d)} className={cn('press flex aspect-square flex-col items-center justify-center rounded-xl text-sm', d.slice(0, 7) !== month && 'opacity-35', d === today ? 'bg-accent text-accent-ink' : 'hover:bg-surface-2')}>
              <span className="num font-semibold">{fmtNumber(Number(d.slice(8)), lang)}</span>
              <span className="mt-0.5 flex gap-0.5">{bl.length > 0 && <span className={cn('h-1.5 w-1.5 rounded-full', d === today ? 'bg-accent-ink' : done === bl.length ? 'bg-success' : 'bg-accent')} />}{special && <span className="h-1.5 w-1.5 rounded-full bg-warning" />}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Agenda({ from }: { from: DateKey }) {
  const { t, lang } = useT();
  const s = useSettings();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const days = rangeKeys(from, 14).map((d) => [d, blocksForDate(data, d).filter((b) => b.status !== 'cancelled')] as const).filter(([, b]) => b.length);
  if (!days.length) return <EmptyState icon={<Plus size={26} />} title={t('no_activities')} action={<Button onClick={() => ui.openEditor({ date: from })}>{t('add_activity')}</Button>} />;
  return (
    <div className="mt-2">{days.map(([d, bl]) => (
      <div key={d}>
        <SectionTitle>{fmtDate(d, lang)}</SectionTitle>
        <div className="card divide-y divide-line">{bl.map((b) => {
          const eff = effectiveStatus(b, d === todayKey(), nowMinutes());
          return (
            <button key={b.id} onClick={() => ui.set({ detailFor: b.id })} className="press flex w-full items-center gap-3 px-3 py-2.5 text-start">
              <BlockIcon block={b} size={32} />
              <div className="min-w-0 flex-1"><div className="truncate text-[15px] font-medium">{b.title}</div><div className="num text-xs text-ink-3">{fmtTime(b.startMin, lang, s.clock24)} · {fmtDuration(b.durationMin, lang)} · {catName(data.categories[b.categoryId], lang)}</div></div>
              <Badge tone={statusTone(eff)}>{t(statusKey(eff))}</Badge>
            </button>
          );
        })}</div>
      </div>
    ))}</div>
  );
}

function TimelineBars({ from, onPick }: { from: DateKey; onPick: (d: DateKey) => void }) {
  const { lang } = useT();
  const data = useApp((st) => st.data);
  const days = rangeKeys(from, 7);
  return (
    <div className="mt-3 card space-y-3 p-4" dir="ltr">
      {days.map((d) => (
        <button key={d} onClick={() => onPick(d)} className="block w-full">
          <div className="mb-1 text-start text-xs font-semibold text-ink-2" dir={lang === 'ar' ? 'rtl' : 'ltr'}>{fmtDate(d, lang, { weekday: 'short', day: 'numeric' })}</div>
          <div className="relative h-6 overflow-hidden rounded-lg bg-surface-2">
            {blocksForDate(data, d).filter((b) => b.status !== 'cancelled').map((b) => (
              <div key={b.id} title={b.title} className="absolute top-0 h-full rounded-[5px] border-x border-surface" style={{ left: `${(b.startMin / 1440) * 100}%`, width: `${(b.durationMin / 1440) * 100}%`, background: b.color, opacity: b.status === 'completed' ? 1 : 0.55 }} />
            ))}
          </div>
        </button>
      ))}
      <div className="flex justify-between text-[10px] text-ink-3"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div>
    </div>
  );
}

function TemplatesSheet({ open, date, onClose }: { open: boolean; date: DateKey; onClose: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const ui = useUI();
  const templates = useApp((st) => st.data.templates);
  return (
    <Sheet open={open} onClose={onClose} title={`${t('apply_template')} · ${fmtDate(date, lang, { day: 'numeric', month: 'short' })}`}>
      <div className="space-y-2">{Object.values(templates).map((tpl) => (
        <Card key={tpl.id} className="flex items-center gap-3 p-3">
          <div className="min-w-0 flex-1"><div className="font-semibold">{tpl.name}</div><div className="truncate text-xs text-ink-3">{fmtNumber(tpl.blocks.length, lang)} {t('blocks')} · {tpl.blocks.slice(0, 3).map((b) => `${fmtTime(b.startMin, lang, s.clock24)} ${b.title}`).join(' · ')}</div></div>
          <Button size="sm" onClick={async () => { const n = await useApp.getState().applyTemplate(tpl.id, date); if (n) useApp.getState().toast('success', t('template_applied', { n })); onClose(); }}>{t('apply')}</Button>
        </Card>
      ))}</div>
      <Button variant="ghost" className="mt-3 w-full" onClick={() => { onClose(); ui.setTab('more'); ui.push('templates'); }}>{t('m_templates')}</Button>
    </Sheet>
  );
}
function DuplicateSheet({ open, date, onClose }: { open: boolean; date: DateKey; onClose: () => void }) {
  const { t } = useT();
  const [to, setTo] = useState(addDays(date, 1));
  return (
    <Sheet open={open} onClose={onClose} title={t('duplicate_day')} footer={<Button className="w-full" onClick={async () => { const n = await useApp.getState().duplicateDay(date, to); if (n) useApp.getState().toast('success', t('template_applied', { n })); onClose(); }}>{t('duplicate_to')}</Button>}>
      <Field label={t('duplicate_to')}><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
    </Sheet>
  );
}
function SaveTplSheet({ open, date, onClose }: { open: boolean; date: DateKey; onClose: () => void }) {
  const { t } = useT();
  const [name, setName] = useState('');
  return (
    <Sheet open={open} onClose={onClose} title={t('save_as_template')} footer={<Button className="w-full" disabled={!name.trim()} onClick={async () => { await useApp.getState().saveDayAsTemplate(date, name.trim()); useApp.getState().toast('success', t('saved')); setName(''); onClose(); }}>{t('save')}</Button>}>
      <Field label={t('name')}><Input value={name} onChange={(e) => setName(e.target.value)} autoFocus /></Field>
    </Sheet>
  );
}


function ApplyBar({ days }: { days: DateKey[] }) {
  const { t } = useT();
  const data = useApp((st) => st.data);
  const drafts = days.map((d) => ({ d, n: blocksForDate(data, d).filter((b) => b.applied === false && b.status !== 'cancelled').length })).filter((x) => x.n > 0);
  const total = drafts.reduce((a, x) => a + x.n, 0);
  const hasPlan = days.some((d) => blocksForDate(data, d).some((b) => b.status !== 'cancelled'));
  if (!hasPlan) return null;
  if (!total) return <div className="mt-3 flex items-center gap-2 rounded-2xl bg-success/10 px-3 py-2 text-sm font-semibold text-success">✓ {t('plan_all_applied')}</div>;
  return (
    <div className="mt-3 flex items-center gap-3 rounded-2xl border border-warning/40 bg-warning/10 p-3">
      <div className="min-w-0 flex-1"><div className="text-sm font-bold text-warning">{t('plan_drafts', { n: total })}</div><div className="text-xs text-ink-2">{t('plan_drafts_hint')}</div></div>
      <Button size="sm" onClick={async () => { for (const x of drafts) await useApp.getState().applyDayPlan(x.d); }}>{t('apply_plan')}</Button>
    </div>
  );
}
