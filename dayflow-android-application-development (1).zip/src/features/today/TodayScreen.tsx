import { useEffect, useMemo, useRef, useState } from 'react';
import { Bell, Search, Settings2, Plus, Timer, Droplets, Dumbbell, CheckSquare, StickyNote, CircleCheck, Coffee, Hourglass, Play, Pause, Check, SkipForward, AlarmClockPlus, ChevronDown, ChevronUp, Crosshair, ArrowDownToLine, Clock, AlertTriangle, CalendarDays, Sparkles, Battery } from 'lucide-react';
import { useApp, blocksForDate, instantiate } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { Badge, Button, Card, Chip, EmptyState, Field, IconButton, Input, ProgressRing, SectionTitle, Segmented, Sheet, Stepper, useHaptic, useNow, useSettings, useT } from '@/components/common/ui';
import { BlockIcon, effectiveStatus, statusKey, statusTone, toSched, catName } from '@/components/cards/blocks';
import { detectConflicts, freeSlots, summarizeDay } from '@/services/scheduling/engine';
import { addDays, fmtDate, fmtDuration, fmtNumber, fmtTime, nowMinutes, startOfWeek, rangeKeys, todayKey, weekdayName, fmtCountdown } from '@/utils/date';
import { coreFrom } from '@/services/defaults';
import { uid } from '@/utils/id';
import { cn } from '@/utils/cn';
import { HangingOrnaments, Orn, SeasonHero, useSeason } from '@/features/decor/Decor';
import { PrayerCard } from '@/features/prayer/PrayerScreen';
import { hijriLabel, occasionsOn } from '@/services/occasions';
import { getTheme } from '@/services/themes';
import { ASCII_ART } from '@/services/brand';
import { CalendarDays as CalIcon, FileEdit as DraftIcon } from 'lucide-react';
import type { ActivityBlock } from '@/models/types';

export function TodayScreen() {
  const { t, lang } = useT();
  const s = useSettings();
  const now = useNow(15000);
  const h = useHaptic();
  const data = useApp((st) => st.data);
  const ui = useUI();
  const [date, setDate] = useState(todayKey());
  const [filter, setFilter] = useState<string | null>(null);
  const [collapsed, setCollapsed] = useState(s.dashboard.collapseCompleted);
  const [sheet, setSheet] = useState<null | 'record' | 'task' | 'free' | 'break' | 'rate'>(null);
  const nowLineRef = useRef<HTMLDivElement>(null);
  const today = todayKey();
  const season = useSeason();
  const todayOcc = useMemo(() => occasionsOn(date, { hijriAdjust: s.hijriAdjust, showOtherReligions: false, user: Object.values(data.specialDates) }), [date, s.hijriAdjust, data.specialDates]);
  const drafts = useMemo(() => blocksForDate(data, date).filter((b) => b.applied === false && b.status !== 'cancelled').length, [data, date]);
  const isToday = date === today;
  const nowMin = nowMinutes(new Date(now));

  useEffect(() => { useApp.getState().ensureDays(date, 1); }, [date]);
  useEffect(() => {
    const open = (e: Event) => { const id = (e as CustomEvent).detail as string; const b = useApp.getState().data.activities[id]; if (b) { setDate(b.date); useUI.getState().set({ detailFor: id }); } };
    window.addEventListener('dayflow:openBlock', open);
    return () => window.removeEventListener('dayflow:openBlock', open);
  }, []);

  const blocks = useMemo(() => blocksForDate(data, date), [data, date]);
  const summary = useMemo(() => summarizeDay(blocks.filter((b) => b.applied !== false), { isToday, isPast: date < today, nowMin, dayEndMin: s.dayEndMin, now }), [blocks, isToday, date, today, nowMin, s.dayEndMin, now]);
  const conflicts = useMemo(() => detectConflicts(blocks.map(toSched), 1440).filter((c) => c.type === 'overlap' || c.type === 'fixed_overlap'), [blocks]);
  const current = isToday ? blocks.find((b) => b.status === 'active' || b.status === 'paused') ?? blocks.find((b) => b.status === 'planned' && b.startMin <= nowMin && b.startMin + b.durationMin > nowMin) : undefined;
  const next = isToday ? blocks.find((b) => b.status === 'planned' && b.startMin > nowMin && b.id !== current?.id) : undefined;
  const visible = blocks.filter((b) => (!filter || b.categoryId === filter) && (!collapsed || !['completed', 'skipped', 'cancelled'].includes(b.status)));
  const waterToday = Object.values(data.waterLogs).filter((w) => w.date === today).reduce((a, w) => a + w.ml, 0);
  const lastRating = Object.values(data.ratings).filter((r) => r.date === today).sort((a, b) => b.at - a.at)[0];

  const hour = new Date(now).getHours();
  const greet = t(hour < 5 ? 'greet_night' : hour < 12 ? 'greet_morning' : hour < 18 ? 'greet_afternoon' : 'greet_evening');
  const ft = (m: number) => fmtTime(m, lang, s.clock24);
  const dens = { compact: 'py-2', comfortable: 'py-3', spacious: 'py-4' }[s.density];
  const cats = [...new Set(blocks.map((b) => b.categoryId))];

  const logWater = async (ml: number) => {
    h(10);
    const ok = await useApp.getState().put('waterLogs', { id: uid('w'), date: today, ml, at: Date.now(), createdAt: Date.now(), updatedAt: Date.now() });
    if (ok) useApp.getState().toast('success', t('water_logged', { x: fmtNumber(ml, lang) }));
  };
  const scrollNow = () => nowLineRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  const jumpNext = () => { if (next) document.getElementById(`blk-${next.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }); };

  const weekDays = rangeKeys(startOfWeek(date, s.weekStart), 7);

  return (
    <div className="pb-32">
      <header className="safe-top mx-auto max-w-2xl px-4 pt-3">
        <SeasonHero className="anim-page">
          <HangingOrnaments names={season.hanging} avoidStart />
          <pre className="ascii-mark" dir="ltr" aria-label="Day Flow">{ASCII_ART}</pre>
          <div className={cn('relative px-5 pb-5', season.hanging.length && s.decor !== 'off' ? 'pt-[74px]' : 'pt-9')}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-[12.5px] font-semibold text-white/90 text-shadow">{fmtDate(today, lang)} · {hijriLabel(today, s.hijriAdjust, lang)}</p>
                <h1 className="mt-1 truncate text-[27px] font-extrabold leading-tight text-shadow">{greet}{s.userName ? `${lang === 'ar' ? '، ' : ', '}${s.userName}` : ''}</h1>
                <p className="mt-0.5 text-sm font-semibold text-white/90 text-shadow">{lang === 'ar' ? season.greetingAr : season.greetingEn}</p>
                <div className="num mt-1.5 text-[34px] font-extrabold leading-none text-shadow">{new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-US', { hour: 'numeric', minute: '2-digit', hour12: !s.clock24 }).format(now)}</div>
              </div>
              <div className="flex shrink-0 flex-col gap-1.5">
                <HeroBtn label={t('search')} onClick={() => ui.set({ commandOpen: true })}><Search size={18} /></HeroBtn>
                <HeroBtn label={t('m_calendar')} onClick={() => { ui.setTab('more'); ui.push('calendar'); }}><CalIcon size={18} /></HeroBtn>
                <HeroBtn label={t('m_notifications')} onClick={() => { ui.setTab('more'); ui.push('notifications'); }}><Bell size={18} /></HeroBtn>
                <HeroBtn label={t('m_settings')} onClick={() => { ui.setTab('more'); ui.push('settings'); }}><Settings2 size={18} /></HeroBtn>
              </div>
            </div>
            {todayOcc.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">{todayOcc.slice(0, 2).map((o) => (
                <button key={o.id} onClick={() => { ui.setTab('more'); ui.push('calendar'); }} className="press flex items-center gap-1.5 rounded-full bg-white/20 py-1 pe-3 ps-1.5 text-[12.5px] font-bold backdrop-blur"><Orn name={o.emoji} size={20} />{lang === 'ar' ? o.title : o.titleEn}{o.official && <span className="rounded-full bg-[#22a45d] px-1.5 py-0.5 text-[10px]">{t('official_short')}</span>}</button>
              ))}</div>
            )}
          </div>
        </SeasonHero>
        {/* week strip / day navigation */}
        <div className="mt-3 flex items-center gap-1">
          <IconButton label={t('back')} onClick={() => setDate(addDays(date, -7))} className="h-8 w-8"><span className="rtl:rotate-180">‹</span></IconButton>
          <div className="grid flex-1 grid-cols-7 gap-1">
            {weekDays.map((d) => {
              const sel = d === date, isT = d === today;
              const cnt = blocksForDate(data, d).filter((b) => b.status !== 'cancelled').length;
              const occ = occasionsOn(d, { hijriAdjust: s.hijriAdjust, showOtherReligions: false, user: [] }).length + Object.values(data.specialDates).filter((x) => x.date === d).length;
              return (
                <button key={d} onClick={() => { h(6); setDate(d); }} className={cn('press flex flex-col items-center rounded-2xl py-1.5 transition-colors', sel ? 'bg-ink text-bg' : 'text-ink-2')}>
                  <span className="text-[10px] font-semibold uppercase">{weekdayName(new Date(d + 'T12:00').getDay(), lang, 'narrow')}</span>
                  <span className={cn('num text-[15px] font-bold', isT && !sel && 'text-accent')}>{fmtNumber(Number(d.slice(8)), lang)}</span>
                  <span className="mt-0.5 flex h-1.5 gap-0.5">{cnt > 0 && <span className={cn('h-1 w-1 rounded-full', sel ? 'bg-bg' : 'bg-accent')} />}{occ > 0 && <span className="h-1 w-1 rounded-full bg-success" />}</span>
                </button>
              );
            })}
          </div>
          <IconButton label={t('next_up')} onClick={() => setDate(addDays(date, 7))} className="h-8 w-8"><span className="rtl:rotate-180">›</span></IconButton>
        </div>
        {!isToday && <button onClick={() => setDate(today)} className="mt-2 text-sm font-semibold text-accent">{t('today')} · {fmtDate(date, lang)}</button>}
      </header>

      <main className="mx-auto max-w-2xl px-4">
        {/* drafts banner */}
        {drafts > 0 && (
          <div className="anim-pop mt-4 flex items-center gap-3 rounded-2xl border border-warning/40 bg-warning/10 p-3">
            <DraftIcon size={20} className="shrink-0 text-warning" />
            <div className="min-w-0 flex-1"><div className="text-sm font-bold text-warning">{t('plan_drafts', { n: drafts })}</div><div className="text-xs text-ink-2">{t('plan_drafts_hint')}</div></div>
            <Button size="sm" onClick={() => useApp.getState().applyDayPlan(date)}>{t('apply_plan')}</Button>
          </div>
        )}
        {/* overview */}
        {s.dashboard.overview && (() => {
          const ov = getTheme(s.themeId).overview;
          if (ov === 'hero') return (
            <div className="anim-page relative mt-4 overflow-hidden p-5 text-accent-ink shadow-float" style={{ borderRadius: 'var(--r-card)', background: 'linear-gradient(135deg, var(--accent), color-mix(in srgb, var(--accent) 55%, #ff7ad9))' }}>
              <div className="flex items-end justify-between"><div><div className="text-[12px] font-bold opacity-85">{t('day_progress')}</div><div className="num text-[46px] font-extrabold leading-none">{fmtNumber(summary.completionPct, lang)}%</div></div>
                <div className="text-end text-[12px] font-semibold opacity-90"><div>{t('planned')}: {fmtDuration(summary.plannedMin, lang)}</div><div>{t('completed')}: {fmtDuration(summary.creditedMin, lang)}</div><div>{t('remaining')}: {fmtDuration(summary.remainingMin, lang)}</div></div></div>
              <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-white/30"><div className="h-full rounded-full bg-current transition-all duration-700" style={{ width: `${summary.completionPct}%` }} /></div>
              <div className="mt-3 grid grid-cols-4 gap-2 text-center text-[11px] font-bold"><span className="rounded-xl bg-white/20 py-1.5"><b className="num block text-base">{fmtNumber(summary.completed, lang)}</b>{t('blocks_done')}</span><span className="rounded-xl bg-white/20 py-1.5"><b className="num block text-base">{fmtNumber(summary.pending, lang)}</b>{t('blocks_pending')}</span><span className="rounded-xl bg-white/20 py-1.5"><b className="num block text-base">{fmtNumber(summary.missed + summary.overdue, lang)}</b>{t('blocks_missed')}</span><button onClick={() => setSheet('free')} className="rounded-xl bg-white/20 py-1.5"><b className="num block text-base">{fmtDuration(summary.freeLeftMin, lang)}</b>{t('free_time_left')}</button></div>
            </div>
          );
          if (ov === 'compact') return (
            <Card className="anim-page mt-4 flex items-center gap-3 p-3">
              <span className="num text-2xl font-extrabold text-accent">{fmtNumber(summary.completionPct, lang)}%</span>
              <div className="min-w-0 flex-1"><div className="h-2 overflow-hidden rounded-full bg-line"><div className="h-full rounded-full bg-accent transition-all duration-700" style={{ width: `${summary.completionPct}%` }} /></div><div className="mt-1 flex justify-between text-[11px] text-ink-3"><span>{fmtNumber(summary.completed, lang)}/{fmtNumber(summary.total, lang)} · {fmtDuration(summary.creditedMin, lang)}</span><button onClick={() => setSheet('free')} className="font-bold text-accent">{fmtDuration(summary.freeLeftMin, lang)} {t('free_time_left')}</button></div></div>
            </Card>
          );
          return (
            <Card className="anim-page mt-4 p-4">
              <div className="flex items-center gap-4">
                <ProgressRing value={summary.completionPct} size={84} stroke={9}><div className="text-center"><div className="num text-xl font-bold">{fmtNumber(summary.completionPct, lang)}%</div></div></ProgressRing>
                <div className="grid flex-1 grid-cols-2 gap-x-3 gap-y-2 text-sm"><Stat label={t('planned')} value={fmtDuration(summary.plannedMin, lang)} /><Stat label={t('completed')} value={fmtDuration(summary.creditedMin, lang)} /><Stat label={t('remaining')} value={fmtDuration(summary.remainingMin, lang)} /><Stat label={t('tracked')} value={fmtDuration(summary.trackedMin, lang)} /></div>
              </div>
              <div className="mt-4 grid grid-cols-4 gap-2 text-center">
                <Pill tone="success" n={summary.completed} label={t('blocks_done')} lang={lang} /><Pill tone="neutral" n={summary.pending} label={t('blocks_pending')} lang={lang} /><Pill tone="danger" n={summary.missed + summary.overdue} label={t('blocks_missed')} lang={lang} />
                <button onClick={() => setSheet('free')} className="press rounded-xl bg-accent-soft py-2 text-accent"><div className="num text-[15px] font-bold">{fmtDuration(summary.freeLeftMin, lang)}</div><div className="text-[10px] font-semibold">{t('free_time_left')}</div></button>
              </div>
              <p className="mt-3 text-[11px] leading-relaxed text-ink-3">{t('completion_note')}</p>
            </Card>
          );
        })()}
        {s.dashboard.prayer && isToday && <PrayerCard onOpen={() => { ui.setTab('more'); ui.push('prayer'); }} />}
        {s.dashboard.tasks && isToday && (() => {
          const due = Object.values(data.tasks).filter((x) => x.status !== 'done' && x.status !== 'cancelled' && x.dueDate != null && x.dueDate <= today).sort((a, b) => (a.dueDate ?? '').localeCompare(b.dueDate ?? '') || b.priority - a.priority).slice(0, 4);
          return due.length ? (
            <Card className="mt-3 p-3"><div className="mb-1 flex items-center justify-between"><span className="text-[13px] font-bold text-ink-2">{t('today_tasks')}</span><button className="text-xs font-bold text-accent" onClick={() => { ui.setTab('more'); ui.push('tasks'); }}>{t('all')}</button></div>
              {due.map((x) => <div key={x.id} className="flex items-center gap-2.5 py-1.5"><button aria-label={t('done')} onClick={() => useApp.getState().put('tasks', { ...x, status: 'done', completedAt: Date.now() })} className="grid h-6 w-6 place-items-center rounded-full border-2 border-ink-3" /><span className="min-w-0 flex-1 truncate text-[15px]">{x.title}</span>{x.dueDate! < today && <Badge tone="danger">{t('overdue')}</Badge>}</div>)}</Card>
          ) : null;
        })()}

        {/* current activity */}
        {isToday && (current ? <CurrentCard block={current} now={now} /> : (
          <Card className="mt-4 flex items-center gap-3 p-4">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-surface-2 text-ink-2"><Hourglass size={20} /></span>
            <div className="min-w-0 flex-1"><div className="text-[15px] font-semibold">{t('no_current')}</div>{next && <div className="text-sm text-ink-2">{t('free_until', { t: ft(next.startMin) })}</div>}</div>
            <Button size="sm" variant="tinted" onClick={() => ui.openEditor({ date, startMin: Math.ceil(nowMin / 5) * 5 })} icon={<Plus size={15} />}>{t('add')}</Button>
          </Card>
        ))}
        {next && (
          <button onClick={() => ui.set({ detailFor: next.id })} className="press mt-2 flex w-full items-center gap-3 rounded-2xl px-2 py-2 text-start">
            <span className="text-[12px] font-semibold uppercase text-ink-3">{t('next_up')}</span>
            <span className="flex-1 truncate text-sm font-semibold">{next.title}</span>
            <span className="num text-sm text-ink-2">{ft(next.startMin)} · {t('starts_in', { d: fmtDuration(next.startMin - nowMin, lang) })}</span>
          </button>
        )}

        {/* quick actions */}
        {s.dashboard.quickActions && (
          <>
            <SectionTitle>{t('quick_actions')}</SectionTitle>
            <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 no-scrollbar">
              <QA icon={<Plus size={20} />} label={t('add_activity')} onClick={() => ui.openEditor({ date })} />
              <QA icon={<Timer size={20} />} label={t('qa_focus')} onClick={() => ui.setTab('focus')} />
              <QA icon={<Droplets size={20} />} label={`${t('qa_water')} ${s.water.cupSizes[1] ?? 250}`} onClick={() => logWater(s.water.cupSizes[1] ?? 250)} />
              <QA icon={<Dumbbell size={20} />} label={t('qa_workout')} onClick={() => { ui.setTab('more'); ui.push('workouts'); }} />
              <QA icon={<CheckSquare size={20} />} label={t('qa_task')} onClick={() => setSheet('task')} />
              <QA icon={<StickyNote size={20} />} label={t('qa_note')} onClick={() => { ui.setTab('more'); ui.push('notes'); }} />
              <QA icon={<CircleCheck size={20} />} label={t('qa_record')} onClick={() => setSheet('record')} />
              <QA icon={<Coffee size={20} />} label={t('qa_break')} onClick={() => setSheet('break')} />
              <QA icon={<Battery size={20} />} label={t('energy_label')} onClick={() => setSheet('rate')} />
            </div>
          </>
        )}

        {s.dashboard.water && isToday && (
          <Card className="mt-3 flex items-center gap-3 p-3">
            <ProgressRing value={(waterToday / Math.max(1, s.water.targetMl)) * 100} size={44} stroke={5} color="var(--c-water)"><Droplets size={16} className="text-water" /></ProgressRing>
            <div className="flex-1"><div className="num text-[15px] font-semibold">{fmtNumber(waterToday, lang)} / {fmtNumber(s.water.targetMl, lang)} {t('ml')}</div><div className="text-xs text-ink-3">{t('water')}</div></div>
            <div className="flex gap-1">{s.water.cupSizes.slice(0, 3).map((c) => <Button key={c} size="sm" variant="secondary" onClick={() => logWater(c)}>+{fmtNumber(c, lang)}</Button>)}</div>
          </Card>
        )}
        {lastRating == null && isToday && hour >= 9 && (
          <button onClick={() => setSheet('rate')} className="press mt-3 flex w-full items-center gap-2 rounded-2xl border border-dashed border-line px-4 py-3 text-sm text-ink-2"><Sparkles size={16} className="text-accent" />{t('rate_energy')}</button>
        )}

        {/* timeline */}
        <SectionTitle action={
          <div className="flex items-center gap-1">
            {isToday && <Button size="sm" variant="ghost" onClick={scrollNow} icon={<Crosshair size={14} />}>{t('jump_now')}</Button>}
            {next && <Button size="sm" variant="ghost" onClick={jumpNext} icon={<ArrowDownToLine size={14} />}>{t('jump_next')}</Button>}
            <IconButton label={collapsed ? t('show_completed') : t('collapse_completed')} className="h-8 w-8" onClick={() => setCollapsed(!collapsed)}>{collapsed ? <ChevronDown size={16} /> : <ChevronUp size={16} />}</IconButton>
          </div>
        }>{t('timeline')}</SectionTitle>
        {conflicts.length > 0 && <div className="mb-2 flex items-center gap-2 rounded-xl bg-warning/12 px-3 py-2 text-sm text-warning"><AlertTriangle size={15} />{t('conflicts_found', { n: conflicts.length })}</div>}
        {cats.length > 1 && (
          <div className="-mx-4 mb-2 flex gap-2 overflow-x-auto px-4 no-scrollbar">
            <Chip active={!filter} onClick={() => setFilter(null)}>{t('all')}</Chip>
            {cats.map((c) => <Chip key={c} active={filter === c} color={data.categories[c]?.color} onClick={() => setFilter(filter === c ? null : c)}>{catName(data.categories[c], lang)}</Chip>)}
          </div>
        )}
        <div className="mb-3 flex justify-end"><Segmented size="sm" className="w-auto" value={s.density} onChange={(v) => useApp.getState().updateSettings({ density: v })} options={[{ value: 'compact', label: t('compact') }, { value: 'comfortable', label: t('comfortable') }, { value: 'spacious', label: t('spacious') }]} /></div>

        {blocks.length === 0 ? (
          <EmptyState icon={<CalendarDays size={28} />} title={t('empty_day_title')} body={t('empty_day_body')}
            action={<div className="flex flex-wrap justify-center gap-2"><Button onClick={() => ui.openEditor({ date })} icon={<Plus size={16} />}>{t('add_activity')}</Button><Button variant="secondary" onClick={() => { ui.setTab('plan'); ui.set({ selectedDate: date }); }}>{t('apply_template')}</Button></div>} />
        ) : (
          <ol className="relative">
            <div className="absolute bottom-3 top-3 w-px bg-line start-[67px]" aria-hidden />
            {visible.map((b, i) => {
              const eff = effectiveStatus(b, isToday, nowMin);
              const showNow = isToday && nowMin >= b.startMin && (i === visible.length - 1 || nowMin < visible[i + 1].startMin);
              const isCur = current?.id === b.id;
              const conflict = conflicts.some((c) => c.a === b.id || c.b === b.id);
              return (
                <li key={b.id} id={`blk-${b.id}`}>
                  {isToday && i === 0 && nowMin < b.startMin && <NowLine refEl={nowLineRef} label={ft(nowMin)} />}
                  <button onClick={() => ui.set({ detailFor: b.id })} onContextMenu={(e) => { e.preventDefault(); h(20); ui.openEditor({ blockId: b.id }); }}
                    className={cn('press relative flex w-full items-start gap-3 text-start', dens)}>
                    <div className="num w-[52px] shrink-0 pt-1 text-end text-[12px] font-semibold text-ink-2">{ft(b.startMin)}<div className="text-[10px] font-normal text-ink-3">{fmtDuration(b.durationMin, lang)}</div></div>
                    <span className={cn('relative z-10 mt-1.5 h-[13px] w-[13px] shrink-0 rounded-full border-[2.5px] bg-bg', isCur && 'pulse-dot')} style={{ borderColor: eff === 'completed' ? 'var(--success)' : eff === 'missed' || eff === 'delayed' ? 'var(--warning)' : b.color }} />
                    <div style={{ ['--tl-color' as string]: b.color }} className={cn('card tl-card min-w-0 flex-1 p-3', b.applied === false && 'border-dashed', isCur && 'ring-2 ring-accent/50', ['completed', 'skipped', 'cancelled'].includes(b.status) && 'opacity-60')}>
                      <div className="flex items-center gap-2.5">
                        <BlockIcon block={b} size={34} />
                        <div className="min-w-0 flex-1">
                          <div className={cn('truncate text-[15px] font-semibold', b.status === 'cancelled' && 'line-through')}>{b.title}</div>
                          <div className="num text-xs text-ink-3">{ft(b.startMin)}–{ft(b.startMin + b.durationMin)} · {catName(data.categories[b.categoryId], lang)}</div>
                        </div>
                        <Badge tone={statusTone(eff)}>{t(statusKey(eff))}</Badge>
                      </div>
                      <div className="mt-2 flex flex-wrap items-center gap-1.5">
                        {b.applied === false && <Badge tone="warning"><DraftIcon size={10} />{t('draft')}</Badge>}
                        <Badge tone={b.fixed ? 'accent' : 'neutral'}>{b.fixed ? t('fixed') : t('flexible')}</Badge>
                        {b.reminder.enabled && <Badge><Bell size={10} />{b.reminder.offsets.length}</Badge>}
                        {b.taskId && data.tasks[b.taskId] && <Badge tone="info"><CheckSquare size={10} />{data.tasks[b.taskId].title}</Badge>}
                        {b.lessonId && data.lessons[b.lessonId] && <Badge tone="info">{data.lessons[b.lessonId].title}</Badge>}
                        {conflict && <Badge tone="warning"><AlertTriangle size={10} /></Badge>}
                        {eff === 'delayed' && <span role="button" tabIndex={0} onClick={(e) => { e.stopPropagation(); ui.set({ catchUpFor: b.id }); }} onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); ui.set({ catchUpFor: b.id }); } }} className="cursor-pointer rounded-full bg-warning/15 px-2 py-0.5 text-[11px] font-bold text-warning">{t('catchup')}</span>}
                      </div>
                    </div>
                  </button>
                  {showNow && <NowLine refEl={nowLineRef} label={ft(nowMin)} />}
                </li>
              );
            })}
          </ol>
        )}
      </main>

      <RecordSheet open={sheet === 'record'} onClose={() => setSheet(null)} />
      <QuickTaskSheet open={sheet === 'task'} onClose={() => setSheet(null)} />
      <BreakSheet open={sheet === 'break'} onClose={() => setSheet(null)} />
      <RateSheet open={sheet === 'rate'} onClose={() => setSheet(null)} />
      <Sheet open={sheet === 'free'} onClose={() => setSheet(null)} title={t('free_slots')}>
        {(() => {
          const from = isToday ? Math.ceil(nowMin) : s.dayStartMin;
          const gaps = freeSlots(blocks.map(toSched), from, s.dayEndMin, 10);
          return gaps.length ? <ul className="space-y-2">{gaps.map(([a, z]) => (
            <li key={a} className="card flex items-center justify-between p-3"><span className="num font-semibold">{ft(a)} – {ft(z)}</span><span className="flex items-center gap-2"><Badge tone="accent">{fmtDuration(z - a, lang)}</Badge><Button size="sm" variant="tinted" onClick={() => { setSheet(null); ui.openEditor({ date, startMin: a }); }}><Plus size={14} /></Button></span></li>
          ))}</ul> : <p className="text-sm text-ink-2">{t('no_free_slots')}</p>;
        })()}
      </Sheet>
    </div>
  );
}

function NowLine({ refEl, label }: { refEl: React.RefObject<HTMLDivElement | null>; label: string }) {
  return (
    <div ref={refEl} className="relative my-1 flex items-center gap-2" aria-label={label}>
      <span className="num w-[52px] text-end text-[11px] font-bold text-danger">{label}</span>
      <span className="z-10 h-2.5 w-2.5 rounded-full bg-danger ms-[3px]" />
      <span className="h-[2px] flex-1 rounded bg-danger/70" />
    </div>
  );
}

function CurrentCard({ block, now }: { block: ActivityBlock; now: number }) {
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const [tick, setTick] = useState(Date.now());
  useEffect(() => { const id = setInterval(() => setTick(Date.now()), 1000); return () => clearInterval(id); }, []);
  void now;
  const act = (a: Parameters<ReturnType<typeof useApp.getState>['blockAction']>[1], extra?: { minutes?: number }) => { h(14); useApp.getState().blockAction(block.id, a, extra); };
  const nowMin = nowMinutes(new Date(tick));
  const end = block.startMin + block.durationMin;
  const leftMs = (end - nowMin) * 60000;
  const progress = block.status === 'active' && block.actualStart
    ? Math.min(100, ((tick - block.actualStart - block.pausedTotalMs) / (block.durationMin * 60000)) * 100)
    : Math.min(100, Math.max(0, ((nowMin - block.startMin) / block.durationMin) * 100));
  const ft = (m: number) => fmtTime(m, lang, s.clock24);
  const linked = block.taskId ? data.tasks[block.taskId]?.title : block.lessonId ? data.lessons[block.lessonId]?.title : block.workoutPlanId ? data.workoutPlans[block.workoutPlanId]?.name : null;
  return (
    <div className="relative mt-4 overflow-hidden rounded-[26px] p-5 text-white shadow-float anim-pop" style={{ background: `linear-gradient(135deg, color-mix(in srgb, ${block.color} 88%, #000) 0%, color-mix(in srgb, ${block.color} 60%, #1c1b22) 100%)` }}>
      <div className="absolute -end-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" aria-hidden />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[12px] font-semibold uppercase tracking-wider text-white/75">{t('current_activity')} · {catName(data.categories[block.categoryId], lang)}</p>
          <h2 className="mt-1 truncate text-[24px] font-bold leading-tight">{block.title}</h2>
          <p className="num mt-1 text-sm text-white/80">{ft(block.startMin)} – {ft(end)}{block.actualStart ? ` · ${t('actual_start')} ${new Date(block.actualStart).toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', { hour: 'numeric', minute: '2-digit', hour12: !s.clock24 })}` : ''}</p>
          {linked && <p className="mt-1 truncate text-sm text-white/80">↳ {linked}</p>}
        </div>
        <button onClick={() => ui.set({ detailFor: block.id })} className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/15"><BlockIcon block={{ ...block, color: '#fff' }} size={44} /></button>
      </div>
      <div className="mt-4">
        <div className="h-2 overflow-hidden rounded-full bg-white/20"><div className="h-full rounded-full bg-white transition-all" style={{ width: `${progress}%` }} /></div>
        <div className="mt-2 flex justify-between text-sm font-semibold"><span className="num">{leftMs >= 0 ? t('time_left', { d: fmtCountdown(leftMs, lang) }) : t('overdue_by', { d: fmtDuration(-leftMs / 60000, lang) })}</span><span className="num">{fmtNumber(Math.round(progress), lang)}%</span></div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {block.status === 'planned' && <CBtn icon={<Play size={16} />} label={t('act_start')} onClick={() => act('start')} primary />}
        {block.status === 'active' && <CBtn icon={<Pause size={16} />} label={t('act_pause')} onClick={() => act('pause')} />}
        {block.status === 'paused' && <CBtn icon={<Play size={16} />} label={t('act_resume')} onClick={() => act('resume')} primary />}
        <CBtn icon={<Check size={16} />} label={t('act_complete')} onClick={() => act('complete')} primary={block.status !== 'planned'} />
        <CBtn icon={<SkipForward size={16} />} label={t('act_skip')} onClick={() => act('skip')} />
        {!block.fixed && block.status === 'planned' && <CBtn icon={<AlarmClockPlus size={16} />} label={`${t('act_snooze')} 10`} onClick={() => act('snooze', { minutes: 10 })} />}
        <CBtn icon={<Clock size={16} />} label={t('more_options')} onClick={() => ui.set({ detailFor: block.id })} />
      </div>
    </div>
  );
}
const CBtn = ({ icon, label, onClick, primary }: { icon: React.ReactNode; label: string; onClick: () => void; primary?: boolean }) => (
  <button onClick={onClick} className={cn('press inline-flex h-10 items-center gap-1.5 rounded-xl px-3.5 text-[13px] font-bold', primary ? 'bg-white text-[#1c1b22]' : 'bg-white/15 text-white')}>{icon}{label}</button>
);
const Stat = ({ label, value }: { label: string; value: string }) => <div><div className="text-[11px] font-medium text-ink-3">{label}</div><div className="num text-[15px] font-semibold">{value}</div></div>;
const Pill = ({ n, label, tone, lang }: { n: number; label: string; tone: 'success' | 'neutral' | 'danger'; lang: 'ar' | 'en' }) => (
  <div className={cn('rounded-xl py-2', tone === 'success' ? 'bg-success/10 text-success' : tone === 'danger' ? 'bg-danger/10 text-danger' : 'bg-surface-2 text-ink')}><div className="num text-[17px] font-bold">{fmtNumber(n, lang)}</div><div className="text-[10px] font-semibold">{label}</div></div>
);
const QA = ({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) => (
  <button onClick={onClick} className="press card flex w-[92px] shrink-0 flex-col items-center gap-2 px-2 py-3"><span className="grid h-10 w-10 place-items-center rounded-2xl bg-accent-soft text-accent">{icon}</span><span className="text-center text-[11px] font-semibold leading-tight">{label}</span></button>
);

function RecordSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [title, setTitle] = useState(''); const [cat, setCat] = useState('cat_personal'); const [mins, setMins] = useState(30);
  const save = async () => {
    if (!title.trim()) return;
    const now = Date.now(); const nm = Math.floor(nowMinutes());
    const start = Math.max(0, nm - mins);
    const b = instantiate(coreFrom({ title: title.trim(), categoryId: cat, startMin: start, durationMin: Math.max(1, nm - start) }), todayKey(), { status: 'completed', actualStart: now - mins * 60000, actualEnd: now, completionPercent: 100, source: 'manual', events: [{ at: now, action: 'RECORDED', source: 'app' }] });
    b.reminder.enabled = false;
    if (await useApp.getState().commit({ activities: [b] })) { useApp.getState().toast('success', t('saved')); setTitle(''); onClose(); }
  };
  return (
    <Sheet open={open} onClose={onClose} title={t('qa_record')} footer={<Button className="w-full" onClick={save} disabled={!title.trim()}>{t('save')}</Button>}>
      <div className="space-y-4">
        <Field label={t('title')}><Input value={title} onChange={(e) => setTitle(e.target.value)} autoFocus /></Field>
        <div className="flex flex-wrap gap-2">{Object.values(data.categories).map((c) => <Chip key={c.id} active={cat === c.id} color={c.color} onClick={() => setCat(c.id)}>{catName(c, lang)}</Chip>)}</div>
        <div className="flex items-center justify-between"><span>{t('duration')}</span><Stepper value={mins} onChange={setMins} min={1} max={600} step={5} suffix={t('min_short')} /></div>
      </div>
    </Sheet>
  );
}
function QuickTaskSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t } = useT();
  const [title, setTitle] = useState(''); const [due, setDue] = useState('');
  const save = async () => {
    if (!title.trim()) return;
    const n = Date.now();
    if (await useApp.getState().put('tasks', { id: uid('t'), title: title.trim(), description: '', dueDate: due || undefined, priority: 3, status: 'todo', estimateMin: 30, trackedMin: 0, tags: [], checklist: [], subtasks: [], notes: '', dependsOn: [], starred: false, someday: false, createdAt: n, updatedAt: n })) {
      useApp.getState().toast('success', t('saved')); setTitle(''); setDue(''); onClose();
    }
  };
  return (
    <Sheet open={open} onClose={onClose} title={t('new_task')} footer={<Button className="w-full" onClick={save} disabled={!title.trim()}>{t('save')}</Button>}>
      <div className="space-y-4"><Field label={t('title')}><Input value={title} onChange={(e) => setTitle(e.target.value)} autoFocus onKeyDown={(e) => e.key === 'Enter' && save()} /></Field><Field label={t('due_date')}><Input type="date" value={due} onChange={(e) => setDue(e.target.value)} /></Field></div>
    </Sheet>
  );
}
function BreakSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t } = useT();
  const [mins, setMins] = useState(10);
  const start = async () => {
    const nm = Math.floor(nowMinutes());
    const b = instantiate(coreFrom({ title: t('qa_break'), categoryId: 'cat_rest', startMin: nm, durationMin: mins }), todayKey(), { status: 'active', actualStart: Date.now(), events: [{ at: Date.now(), action: 'START', source: 'app' }] });
    b.reminder = { ...b.reminder, enabled: true, offsets: [], atEnd: true };
    if (await useApp.getState().commit({ activities: [b] })) { useApp.getState().toast('success', t('saved')); onClose(); }
  };
  return (
    <Sheet open={open} onClose={onClose} title={t('qa_break')} footer={<Button className="w-full" onClick={start}>{t('act_start')}</Button>}>
      <div className="flex items-center justify-between"><span>{t('duration')}</span><Stepper value={mins} onChange={setMins} min={1} max={120} step={5} suffix={t('min_short')} /></div>
    </Sheet>
  );
}
function RateSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t } = useT();
  const [energy, setEnergy] = useState(3); const [focus, setFocus] = useState(3);
  const save = async () => {
    const n = Date.now();
    if (await useApp.getState().put('ratings', { id: uid('r'), date: todayKey(), at: n, hour: new Date().getHours(), energy, focus, note: '', createdAt: n, updatedAt: n })) { useApp.getState().toast('success', t('rating_saved')); onClose(); }
  };
  const Scale = ({ v, set }: { v: number; set: (n: number) => void }) => <div className="flex gap-2">{[1, 2, 3, 4, 5].map((n) => <button key={n} onClick={() => set(n)} className={cn('press h-11 flex-1 rounded-xl text-[15px] font-bold', v === n ? 'bg-accent text-accent-ink' : 'bg-surface-2')}>{n}</button>)}</div>;
  return (
    <Sheet open={open} onClose={onClose} title={t('rate_energy')} footer={<Button className="w-full" onClick={save}>{t('save')}</Button>}>
      <div className="space-y-4"><Field label={t('energy_label')}><Scale v={energy} set={setEnergy} /></Field><Field label={t('focus_label')}><Scale v={focus} set={setFocus} /></Field></div>
    </Sheet>
  );
}

const HeroBtn = ({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) => (
  <button aria-label={label} title={label} onClick={onClick} className="press grid h-10 w-10 place-items-center rounded-full bg-white/20 text-white backdrop-blur">{children}</button>
);
