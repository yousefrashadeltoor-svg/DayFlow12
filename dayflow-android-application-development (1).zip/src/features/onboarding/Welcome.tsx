import { useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { Button, Chip, Input, Select, Toggle, useSettings, useT } from '@/components/common/ui';
import { Orn } from '@/features/decor/Decor';
import { ThemePreview } from '@/features/themes/ThemeScreen';
import { THEMES } from '@/services/themes';
import { EGYPT_PLACES, placeOf } from '@/services/prayer';
import { ensureNotificationPermission } from '@/features/alarms/AlarmsScreen';
import { DayflowNative, isNative } from '@/services/native/dayflowNative';
import { todayKey } from '@/utils/date';
import { photoUrl } from '@/services/decor';
import { cn } from '@/utils/cn';
import type { TKey } from '@/services/localization/i18n';
import type { Settings } from '@/models/types';
import { BRAND, SIGNATURE } from '@/services/brand';

const SLIDES: { img: string[]; title: TKey; body: TKey; photo: string }[] = [
  { img: ['sparkles', 'calendar', 'rocket'], title: 'wl1_t', body: 'wl1_b', photo: 'sunrise2' },
  { img: ['spiral_calendar', 'check_mark_button', 'bullseye'], title: 'wl2_t', body: 'wl2_b', photo: 'journal2' },
  { img: ['alarm_clock', 'bell', 'hourglass_not_done'], title: 'wl3_t', body: 'wl3_b', photo: 'night1' },
  { img: ['mosque', 'prayer_beads', 'crescent_moon'], title: 'wl4_t', body: 'wl4_b', photo: 'mosque1' },
  { img: ['calendar', 'party_popper', 'memo'], title: 'wl5_t', body: 'wl5_b', photo: 'cairo2' },
  { img: ['notebook', 'slightly_smiling_face', 'pencil'], title: 'wl6_t', body: 'wl6_b', photo: 'journal1' },
  { img: ['artist_palette', 'sparkles', 'snowflake'], title: 'wl7_t', body: 'wl7_b', photo: 'autumn2' },
  { img: ['trophy', 'rocket', 'hundred_points'], title: 'wl8_t', body: 'wl8_b', photo: 'pyramids1' },
];

/** First-run guide and re-playable tour. 'first' persists choices and marks the app as onboarded. */
export function Welcome() {
  const { t, lang } = useT();
  const s = useSettings();
  const tourOpen = useUI((u) => u.tourOpen);
  const first = !s.onboarded;
  const [i, setI] = useState(0);
  const [name, setName] = useState(s.userName);
  const [template, setTemplate] = useState(true);
  const finishing = useRef(false);
  if (!first && !tourOpen) return null;
  const sl = SLIDES[i];
  const last = i === SLIDES.length - 1;
  const rtl = lang === 'ar';
  const Next = rtl ? ArrowLeft : ArrowRight, Prev = rtl ? ArrowRight : ArrowLeft;
  const up = (p: Partial<Settings>) => useApp.getState().updateSettings(p);
  const finish = async () => {
    if (finishing.current) return;
    finishing.current = true;
    const st = useApp.getState();
    if (first) {
      await st.updateSettings({ onboarded: true, userName: name.trim() });
      if (template) { const n = await st.applyTemplate('tpl_normal', todayKey()); await st.applyDayPlan(todayKey()); if (n) st.toast('success', t('template_applied', { n })); }
    } else if (name.trim() !== s.userName) await st.updateSettings({ userName: name.trim() });
    useUI.getState().set({ tourOpen: false });
  };
  const close = () => (first ? finish() : useUI.getState().set({ tourOpen: false }));
  return (
    <div className="fixed inset-0 z-[80] flex flex-col overflow-hidden bg-bg anim-fade">
      <img key={sl.photo} src={photoUrl(sl.photo)} alt="" className="anim-fade absolute inset-x-0 top-0 h-[44%] w-full object-cover" />
      <div className="absolute inset-x-0 top-0 h-[44%] bg-gradient-to-b from-black/30 via-black/10 to-[var(--bg)]" />
      <div className="relative z-10 flex items-center justify-between px-4 pt-[calc(env(safe-area-inset-top)+12px)]">
        <div className="flex gap-1.5">{SLIDES.map((_, k) => <span key={k} className={cn('h-1.5 rounded-full transition-all', k === i ? 'w-6 bg-white' : 'w-1.5 bg-white/50')} />)}</div>
        <button onClick={close} className="rounded-full bg-black/30 px-3 py-1 text-[13px] font-bold text-white backdrop-blur">{t('skip')}</button>
      </div>
      <div key={i} className="anim-page relative z-10 flex flex-1 flex-col overflow-y-auto px-6 pb-4 pt-[18%] no-scrollbar">
        <div className="mx-auto flex items-end justify-center gap-1">{sl.img.map((n, k) => <Orn key={n} name={n} size={k === 1 ? 92 : 64} className={cn('drop-shadow-2xl', k % 2 === 0 ? 'df-float' : '')} style={{ animationDelay: `${k * 0.4}s` }} />)}</div>
        <div className="mt-4 text-center text-[15px] font-bold tracking-wide text-accent" style={{ fontFamily: '"El Messiri", Georgia, serif' }}>{BRAND}</div>
        <h1 className="mt-1 text-center text-[27px] font-extrabold leading-tight tracking-tight">{t(sl.title)}</h1>
        <p className="mx-auto mt-3 max-w-md text-center text-[15.5px] leading-8 text-ink-2">{t(sl.body)}</p>

        <div className="mx-auto mt-5 w-full max-w-md space-y-3">
          {i === 0 && <>
            <div className="flex gap-2"><Button variant={s.language === 'ar' ? 'primary' : 'secondary'} className="flex-1" onClick={() => up({ language: 'ar' })}>العربية</Button><Button variant={s.language === 'en' ? 'primary' : 'secondary'} className="flex-1" onClick={() => up({ language: 'en' })}>English</Button></div>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t('ob_name')} maxLength={40} /></>}
          {i === 1 && <div className="card px-4"><Toggle checked={s.autoApplyPlan} onChange={(v) => up({ autoApplyPlan: v })} label={t('auto_apply')} description={t('wl2_toggle')} help="auto_apply" /></div>}
          {i === 2 && isNative() && <Button className="w-full" size="lg" variant="tinted" onClick={async () => { const ok = await ensureNotificationPermission(); useApp.getState().refreshCaps(); useApp.getState().toast(ok ? 'success' : 'error', ok ? t('granted') : t('perm_notif_needed')); }}>{t('perm_allow')} · {t('rel_notif')}</Button>}
          {i === 2 && isNative() && <Button className="w-full" variant="secondary" onClick={() => DayflowNative.requestExactAlarmPermission().catch(() => undefined)}>{t('rel_exact')}</Button>}
          {i === 3 && <>
            <Select value={s.prayer.governorate} onChange={(v) => { const pl = placeOf(v); up({ prayer: { ...s.prayer, governorate: v, city: v, lat: pl.lat, lng: pl.lng } }); }} options={EGYPT_PLACES.map((p) => ({ value: p.key, label: lang === 'ar' ? p.ar : p.en }))} />
            <div className="card px-4"><Toggle checked={s.prayer.enabled} onChange={async (v) => { up({ prayer: { ...s.prayer, enabled: v } }); if (v) await ensureNotificationPermission(); }} label={t('prayer_enable')} description={t('prayer_enable_desc')} /></div></>}
          {i === 6 && <>
            <div className="-mx-6 flex gap-3 overflow-x-auto px-6 pb-2 no-scrollbar">{THEMES.slice(0, 6).map((th) => (
              <button key={th.id} onClick={() => up({ themeId: th.id })} className={cn('press shrink-0 rounded-3xl p-1', s.themeId === th.id && 'ring-2 ring-accent')}><ThemePreview theme={th} dark={s.theme === 'dark'} scale={0.42} /><div className="mt-1 text-center text-[11px] font-bold">{lang === 'ar' ? th.ar : th.en}</div></button>
            ))}</div>
            <div className="flex gap-2">{(['off', 'light', 'full'] as const).map((d) => <Chip key={d} active={s.decor === d} onClick={() => up({ decor: d })}>{t(`decor_${d}` as TKey)}</Chip>)}</div></>}
          {last && <div className="card px-4"><Toggle checked={template} onChange={setTemplate} label={t('ob_start_template')} description={t('wl8_toggle')} /></div>}
        </div>
      </div>
      <div className="signature relative z-10 pb-1 text-center" aria-label={SIGNATURE}>{SIGNATURE}</div>
      <div className="relative z-10 flex items-center gap-3 px-6 pb-[calc(env(safe-area-inset-bottom)+14px)] pt-1">
        {i > 0 ? <Button variant="secondary" size="lg" aria-label={t('back')} onClick={() => setI(i - 1)} icon={<Prev size={18} />} /> : <span className="w-12" />}
        <Button size="lg" className="flex-1" onClick={() => (last ? finish() : setI(i + 1))} icon={last ? <Check size={18} /> : undefined}>{last ? t('wl_start') : t('next')}{!last && <Next size={18} />}</Button>
      </div>
    </div>
  );
}
