import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, Download, Flame, Search, Star, Trash2, Sparkles } from 'lucide-react';
import { useApp, blocksForDate, emptyJournal } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { Badge, Button, Card, Chip, Field, HelpTip, Input, Page, ScreenHeader, SectionTitle, Segmented, Stepper, TextArea, Toggle, useConfirm, useSettings, useT } from '@/components/common/ui';
import { Orn } from '@/features/decor/Decor';
import { photoUrl } from '@/services/decor';
import type { DateKey, JournalEntry } from '@/models/types';
import { saveFile } from '@/services/native/dayflowNative';
import { addDays, fmtDate, fmtDuration, fmtNumber, fmtTime, inputToMin, minToInput, rangeKeys, todayKey } from '@/utils/date';
import { hijriLabel } from '@/services/occasions';
import { cn } from '@/utils/cn';

const MOODS = ['loudly_crying_face', 'slightly_frowning_face', 'neutral_face', 'slightly_smiling_face', 'grinning_face_with_big_eyes'];
const MOOD_COLOR = ['#ef4444', '#f59e0b', '#94a3b8', '#34d399', '#16a34a'];
const PROMPTS_AR = [
  'إيه أحلى حاجة حصلت النهاردة، حتى لو صغيرة؟', 'إيه الحاجة اللي ضايقتك النهاردة وإزاي تتعامل معاها بكرة؟', 'مين الشخص اللي عايز تشكره النهاردة وليه؟',
  'لو رجع اليوم من الأول، إيه الحاجة الواحدة اللي هتعملها مختلف؟', 'إيه الحاجة اللي اتعلمتها النهاردة؟', 'إيه هدفك الأهم بكرة؟',
  'وصف يومك في ٣ كلمات.', 'إيه الحاجة اللي بتحسسك بالراحة؟', 'إيه الحاجة اللي كنت مأجلها وعملتها؟', 'اكتب جواب لنفسك بعد سنة.',
  'إيه الحاجة اللي اتغيرت فيك الشهر ده؟', 'إيه الحاجة اللي مستني تحصل قريب؟',
];
const PROMPTS_EN = ['What was the best part of today, even a small one?', 'What bothered you today and how will you handle it tomorrow?', 'Who would you like to thank today and why?', 'If you could replay today, what one thing would you change?', 'What did you learn today?', 'What is your most important goal tomorrow?', 'Describe your day in three words.', 'What makes you feel at ease?', 'What did you finally do that you had postponed?', 'Write a letter to yourself one year from now.', 'What has changed in you this month?', 'What are you looking forward to?'];

const hasContent = (e: JournalEntry) => e.mood > 0 || e.energy > 0 || e.title.trim() || e.body.trim() || e.gratitude.some((g) => g.trim()) || e.highlight.trim() || e.lesson.trim() || e.tags.length;
const words = (e: JournalEntry) => `${e.title} ${e.body} ${e.highlight} ${e.lesson} ${e.gratitude.join(' ')}`.trim().split(/\s+/).filter(Boolean).length;

export function JournalScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const [tab, setTab] = useState<'write' | 'all' | 'stats'>('write');
  const [date, setDate] = useState<DateKey>(ui.selectedDate ?? todayKey());
  const entries = useMemo(() => Object.values(data.journal).filter(hasContent).sort((a, b) => b.date.localeCompare(a.date)), [data.journal]);
  return (
    <div>
      <ScreenHeader title={t('m_journal')} subtitle={t('journal_sub')} onBack={onBack} />
      <Page>
        <Segmented value={tab} onChange={setTab} size="sm" options={[{ value: 'write', label: t('journal_write') }, { value: 'all', label: `${t('journal_all')} (${fmtNumber(entries.length, lang)})` }, { value: 'stats', label: t('journal_stats') }]} />
        {tab === 'write' && <Writer key={date} date={date} setDate={setDate} />}
        {tab === 'all' && <All entries={entries} open={(d) => { setDate(d); setTab('write'); }} />}
        {tab === 'stats' && <Stats entries={entries} />}
      </Page>
    </div>
  );
}

function Writer({ date, setDate }: { date: DateKey; setDate: (d: DateKey) => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const { ask, node } = useConfirm();
  const stored = data.journal[date];
  const [e, setE] = useState<JournalEntry>(() => stored ?? emptyJournal(date));
  const [saved, setSaved] = useState(true);
  const first = useRef(true);
  const today = todayKey();
  const up = <K extends keyof JournalEntry>(k: K, v: JournalEntry[K]) => { setE((p) => ({ ...p, [k]: v })); setSaved(false); };

  // keep plan snapshots written by "apply plan" in sync without clobbering typed text
  useEffect(() => { if (stored && stored.plans.length !== e.plans.length) setE((p) => ({ ...p, plans: stored.plans })); }, [stored?.plans.length]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (first.current) { first.current = false; return; }
    const id = setTimeout(async () => {
      if (!hasContent(e) && !e.plans.length) { if (stored) await useApp.getState().remove('journal', [date], false); setSaved(true); return; }
      if (await useApp.getState().put('journal', e)) setSaved(true);
    }, 700);
    return () => clearTimeout(id);
  }, [e]); // eslint-disable-line react-hooks/exhaustive-deps

  const summary = useMemo(() => {
    const blocks = blocksForDate(data, date).filter((b) => b.applied !== false && b.status !== 'cancelled');
    const done = blocks.filter((b) => b.status === 'completed' || b.status === 'partial');
    return {
      blocks: blocks.length, done,
      focus: Object.values(data.focusSessions).filter((f) => f.date === date && f.phase === 'work').reduce((a, f) => a + f.actualMin, 0),
      water: Object.values(data.waterLogs).filter((w) => w.date === date).reduce((a, w) => a + w.ml, 0),
      habits: Object.values(data.habitLogs).filter((l) => l.date === date && !l.skipped && l.value > 0).length,
      prayers: Object.values(data.prayerLogs).filter((p) => p.date === date).length,
      tasks: Object.values(data.tasks).filter((x) => x.completedAt && new Date(x.completedAt).toDateString() === new Date(date + 'T12:00').toDateString()).length,
    };
  }, [data, date]);
  const prompt = (lang === 'ar' ? PROMPTS_AR : PROMPTS_EN)[Math.floor(new Date(date + 'T12:00').getTime() / 86400000) % PROMPTS_AR.length];
  const exportText = async () => {
    const txt = `${fmtDate(date, lang)} · ${hijriLabel(date, s.hijriAdjust, lang)}\n${e.title}\n\n${e.body}\n\n${e.gratitude.filter(Boolean).map((g) => `• ${g}`).join('\n')}\n\n${t('journal_highlight')}: ${e.highlight}\n${t('journal_lesson')}: ${e.lesson}\n${e.tags.map((x) => `#${x}`).join(' ')}`;
    await saveFile(`dayflow-journal-${date}.txt`, txt, 'text/plain').catch(() => undefined);
  };

  return (
    <div className="anim-page">
      {node}
      <div className="mt-3 flex items-center justify-between">
        <Button size="sm" variant="secondary" aria-label={t('back')} onClick={() => setDate(addDays(date, -1))}>{lang === 'ar' ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}</Button>
        <div className="text-center"><div className="text-[15px] font-bold">{fmtDate(date, lang)}</div><div className="text-xs text-ink-3">{hijriLabel(date, s.hijriAdjust, lang)}{date === today ? ` · ${t('today')}` : ''}</div></div>
        <Button size="sm" variant="secondary" aria-label={t('next_up')} disabled={date >= today} onClick={() => setDate(addDays(date, 1))}>{lang === 'ar' ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}</Button>
      </div>

      <div className="relative mt-3 overflow-hidden rounded-3xl text-white">
        <img src={photoUrl('journal1')} alt="" className="absolute inset-0 h-full w-full object-cover" /><div className="absolute inset-0 bg-gradient-to-b from-black/35 to-black/70" />
        <div className="relative p-4">
          <div className="text-sm font-bold text-shadow">{t('journal_mood_q')}</div>
          <div className="mt-3 flex justify-between gap-1">
            {MOODS.map((m, i) => (
              <button key={m} aria-label={t(`mood_${i + 1}` as 'mood_1')} onClick={() => up('mood', e.mood === i + 1 ? 0 : i + 1)} className={cn('press flex flex-1 flex-col items-center gap-1 rounded-2xl py-2 transition-all', e.mood === i + 1 ? 'scale-105 bg-white/30 ring-2 ring-white' : 'bg-white/10')}>
                <Orn name={m} size={e.mood === i + 1 ? 44 : 36} /><span className="text-[10px] font-bold">{t(`mood_${i + 1}` as 'mood_1')}</span>
              </button>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between gap-2"><span className="text-sm font-semibold text-shadow">{t('energy_label')}</span><div className="flex gap-1.5">{[1, 2, 3, 4, 5].map((n) => <button key={n} onClick={() => up('energy', e.energy === n ? 0 : n)} className={cn('press h-9 w-9 rounded-full text-sm font-bold', e.energy >= n ? 'bg-white text-black' : 'bg-white/20')}>{n}</button>)}</div></div>
        </div>
      </div>

      <Card className="mt-3 p-3">
        <div className="flex items-start gap-2"><Sparkles size={18} className="mt-0.5 shrink-0 text-accent" /><div className="min-w-0 flex-1"><div className="flex items-center gap-1.5 text-[11px] font-bold uppercase text-ink-3">{t('journal_prompt')}<HelpTip id="journal_prompt" /></div><p className="text-[15px] font-semibold leading-7">{prompt}</p></div>
          <Button size="sm" variant="tinted" onClick={() => up('body', `${e.body}${e.body ? '\n\n' : ''}${prompt}\n`)}>{t('journal_use')}</Button></div>
      </Card>

      <div className="mt-3 space-y-3">
        <Field label={t('title')}><Input value={e.title} onChange={(x) => up('title', x.target.value)} placeholder={t('journal_title_ph')} maxLength={120} /></Field>
        <Field label={t('journal_body')}><TextArea className="min-h-[200px] text-[16px] leading-8" value={e.body} onChange={(x) => up('body', x.target.value)} placeholder={t('journal_body_ph')} /></Field>
        <Field label={t('journal_gratitude')}>{e.gratitude.map((g, i) => <Input key={i} className="mb-2" value={g} placeholder={`${fmtNumber(i + 1, lang)}.`} onChange={(x) => up('gratitude', e.gratitude.map((y, j) => (j === i ? x.target.value : y)))} />)}</Field>
        <Field label={t('journal_highlight')}><Input value={e.highlight} onChange={(x) => up('highlight', x.target.value)} /></Field>
        <Field label={t('journal_lesson')}><Input value={e.lesson} onChange={(x) => up('lesson', x.target.value)} /></Field>
        <Field label={t('tags')}><Input value={e.tags.join(', ')} onChange={(x) => up('tags', x.target.value.split(/[,،]/).map((v) => v.trim().replace(/^#/, '')).filter(Boolean))} /></Field>
      </div>

      <SectionTitle>{t('journal_day_summary')}</SectionTitle>
      <Card className="p-4">
        <div className="grid grid-cols-3 gap-2 text-center">
          <Sum n={`${fmtNumber(summary.done.length, lang)}/${fmtNumber(summary.blocks, lang)}`} l={t('timeline')} />
          <Sum n={fmtDuration(summary.focus, lang)} l={t('nav_focus')} />
          <Sum n={`${fmtNumber(summary.water, lang)}`} l={t('water')} />
          <Sum n={fmtNumber(summary.habits, lang)} l={t('m_habits')} />
          <Sum n={`${fmtNumber(summary.prayers, lang)}/٥`.replace('٥', lang === 'ar' ? '٥' : '5')} l={t('m_prayer')} />
          <Sum n={fmtNumber(summary.tasks, lang)} l={t('m_tasks')} />
        </div>
        {summary.done.length > 0 && <ul className="mt-3 space-y-1 border-t border-line pt-3 text-sm">{summary.done.map((b) => <li key={b.id} className="flex items-center gap-2"><Check size={14} className="text-success" /><span className="flex-1 truncate">{b.title}</span><span className="num text-xs text-ink-3">{fmtTime(b.startMin, lang, s.clock24)}</span></li>)}</ul>}
      </Card>
      {e.plans.length > 0 && <>
        <SectionTitle>{t('journal_plans')}</SectionTitle>
        <div className="space-y-2">{e.plans.map((p, i) => (
          <Card key={i} className="p-3"><div className="mb-1 text-sm font-bold">{p.title}</div>
            <ul className="space-y-0.5 text-xs text-ink-2">{p.blocks.map((b) => <li key={b.id} className="num">{fmtTime(b.startMin, lang, s.clock24)} – {fmtTime(b.startMin + b.durationMin, lang, s.clock24)} · {b.title}</li>)}</ul></Card>
        ))}</div>
      </>}

      <div className="mt-4 flex items-center gap-2">
        <Badge tone={saved ? 'success' : 'warning'}>{saved ? `✓ ${t('journal_saved')}` : t('journal_saving')}</Badge><span className="num text-xs text-ink-3">{fmtNumber(words(e), lang)} {t('journal_words')}</span>
        <span className="flex-1" />
        <Button size="sm" variant={e.favorite ? 'tinted' : 'secondary'} aria-label={t('favorites')} icon={<Star size={15} className={e.favorite ? 'fill-current' : ''} />} onClick={() => up('favorite', !e.favorite)} />
        <Button size="sm" variant="secondary" aria-label="export" icon={<Download size={15} />} onClick={exportText} />
        {stored && <Button size="sm" variant="danger" aria-label={t('delete')} icon={<Trash2 size={15} />} onClick={async () => { if (await ask(t('delete'), fmtDate(date, lang))) { await useApp.getState().remove('journal', [date]); setE(emptyJournal(date)); } }} />}
      </div>
    </div>
  );
}
const Sum = ({ n, l }: { n: string; l: string }) => <div className="rounded-2xl bg-surface-2 py-2.5"><div className="num text-[15px] font-bold">{n}</div><div className="text-[10px] font-semibold text-ink-3">{l}</div></div>;

function All({ entries, open }: { entries: JournalEntry[]; open: (d: DateKey) => void }) {
  const { t, lang } = useT();
  const [q, setQ] = useState(''); const [mood, setMood] = useState(0); const [fav, setFav] = useState(false);
  const list = entries.filter((e) => (!mood || e.mood === mood) && (!fav || e.favorite) && (!q || `${e.title} ${e.body} ${e.highlight} ${e.lesson} ${e.tags.join(' ')}`.toLowerCase().includes(q.toLowerCase())));
  return (
    <div className="anim-page">
      <div className="mt-3 flex items-center gap-2 rounded-xl bg-surface-2 px-3"><Search size={16} className="text-ink-3" /><input value={q} onChange={(x) => setQ(x.target.value)} placeholder={t('search')} className="h-11 flex-1 bg-transparent outline-none" /></div>
      <div className="-mx-4 mt-3 flex gap-2 overflow-x-auto px-4 no-scrollbar"><Chip active={!mood && !fav} onClick={() => { setMood(0); setFav(false); }}>{t('all')}</Chip><Chip active={fav} onClick={() => setFav(!fav)}><Star size={12} />{t('favorites')}</Chip>
        {MOODS.map((m, i) => <Chip key={m} active={mood === i + 1} onClick={() => setMood(mood === i + 1 ? 0 : i + 1)}><Orn name={m} size={16} /></Chip>)}</div>
      {list.length === 0 ? <p className="mt-6 text-center text-sm text-ink-3">{t('empty_generic')}</p> : (
        <div className="stagger mt-3 space-y-2">{list.map((e, i) => (
          <Card key={e.id} onClick={() => open(e.date)} className="flex gap-3 p-3" style={{ ['--i' as string]: Math.min(i, 8) }}>
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl" style={{ background: e.mood ? `${MOOD_COLOR[e.mood - 1]}22` : 'var(--surface-2)' }}>{e.mood ? <Orn name={MOODS[e.mood - 1]} size={32} /> : <Orn name="notebook" size={30} />}</div>
            <div className="min-w-0 flex-1"><div className="flex items-center gap-2"><span className="truncate text-[15px] font-bold">{e.title || fmtDate(e.date, lang, { weekday: 'long', day: 'numeric', month: 'long' })}</span>{e.favorite && <Star size={13} className="fill-warning text-warning" />}</div>
              <div className="text-xs text-ink-3">{fmtDate(e.date, lang, { day: 'numeric', month: 'short', year: 'numeric' })}</div>
              <p className="mt-1 line-clamp-2 text-[13px] leading-6 text-ink-2">{e.body || e.highlight || e.gratitude.filter(Boolean).join(' · ')}</p>
              {e.tags.length > 0 && <div className="mt-1 flex flex-wrap gap-1">{e.tags.slice(0, 4).map((x) => <Badge key={x}>#{x}</Badge>)}</div>}</div>
          </Card>
        ))}</div>
      )}
    </div>
  );
}

function Stats({ entries }: { entries: JournalEntry[] }) {
  const { t, lang } = useT();
  const s = useSettings();
  const today = todayKey();
  const set = new Set(entries.map((e) => e.date));
  let streak = 0; for (let i = set.has(today) ? 0 : 1; i < 400; i++) { if (set.has(addDays(today, -i))) streak++; else break; }
  const last30 = entries.filter((e) => e.date >= addDays(today, -29) && e.mood > 0);
  const avg = last30.length ? last30.reduce((a, e) => a + e.mood, 0) / last30.length : 0;
  const tags = new Map<string, number>(); for (const e of entries) for (const x of e.tags) tags.set(x, (tags.get(x) ?? 0) + 1);
  const days = rangeKeys(addDays(today, -34), 35);
  const byDate = new Map(entries.map((e) => [e.date, e]));
  const totalWords = entries.reduce((a, e) => a + words(e), 0);
  return (
    <div className="anim-page">
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Card className="p-3"><div className="flex items-center gap-1.5 text-[11px] text-ink-3"><Flame size={13} className="text-warning" />{t('journal_streak')}</div><div className="num text-2xl font-bold">{fmtNumber(streak, lang)} <span className="text-sm text-ink-3">{t('days')}</span></div></Card>
        <Card className="p-3"><div className="text-[11px] text-ink-3">{t('journal_total')}</div><div className="num text-2xl font-bold">{fmtNumber(entries.length, lang)}</div></Card>
        <Card className="p-3"><div className="text-[11px] text-ink-3">{t('journal_avg_mood')}</div><div className="flex items-center gap-2">{avg > 0 ? <><Orn name={MOODS[Math.round(avg) - 1]} size={30} /><span className="num text-2xl font-bold">{fmtNumber(Math.round(avg * 10) / 10, lang, 1)}</span></> : <span className="text-sm text-ink-3">—</span>}</div></Card>
        <Card className="p-3"><div className="text-[11px] text-ink-3">{t('journal_words')}</div><div className="num text-2xl font-bold">{fmtNumber(totalWords, lang)}</div></Card>
      </div>
      <SectionTitle>{t('journal_mood_map')}</SectionTitle>
      <Card className="p-3"><div className="grid grid-cols-7 gap-1.5">{days.map((d) => { const e = byDate.get(d); return <div key={d} title={d} className="grid aspect-square place-items-center rounded-lg text-[10px] font-bold text-white" style={{ background: e?.mood ? MOOD_COLOR[e.mood - 1] : e ? 'var(--ink-3)' : 'var(--surface-2)', opacity: e ? 1 : 0.7 }}>{e ? '' : ''}</div>; })}</div>
        <div className="mt-2 flex items-center justify-between text-[10px] text-ink-3"><span>{t('mood_1')}</span><span className="flex gap-1">{MOOD_COLOR.map((c) => <i key={c} className="h-2 w-5 rounded-full" style={{ background: c }} />)}</span><span>{t('mood_5')}</span></div></Card>
      <SectionTitle>{t('journal_top_tags')}</SectionTitle>
      <div className="flex flex-wrap gap-2">{[...tags.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k, n]) => <Chip key={k}>#{k} · {fmtNumber(n, lang)}</Chip>)}{!tags.size && <p className="text-sm text-ink-3">{t('empty_generic')}</p>}</div>
      <SectionTitle>{t('reminders')}</SectionTitle>
      <Card className="divide-y divide-line px-4">
        <Toggle checked={s.journal.reminderEnabled} onChange={(v) => useApp.getState().updateSettings({ journal: { ...s.journal, reminderEnabled: v } })} label={t('journal_reminder')} description={t('journal_reminder_hint')} />
        {s.journal.reminderEnabled && <div className="flex items-center justify-between py-3"><span>{t('time')}</span><Input type="time" className="w-32" value={minToInput(s.journal.reminderMin)} onChange={(e) => useApp.getState().updateSettings({ journal: { ...s.journal, reminderMin: inputToMin(e.target.value) } })} /></div>}
      </Card>
      {void Stepper}
    </div>
  );
}
