import { useState } from 'react';
import { Palette, SlidersHorizontal, Bell, Volume2, GraduationCap, Database, Sparkles, Play, Square, Trash2, Plus, Music, ChevronLeft } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { useUI, type Screen } from '@/stores/uiStore';
import { Badge, Button, Card, Chevron, Chip, Field, Group, HelpTip, Icon, ICONS, Input, ListRow, Page, ScreenHeader, SectionTitle, Segmented, Select, Sheet, SRow, Stepper, Toggle, useConfirm, useSettings, useT } from '@/components/common/ui';
import { SoundField } from '@/features/alarms/SoundPicker';
import { Orn } from '@/features/decor/Decor';
import { getTheme } from '@/services/themes';
import type { Accent, ActivityCategory, Settings } from '@/models/types';
import { DayflowNative, errorCode, isNative, pickFile, previewSound, speak, stopSound } from '@/services/native/dayflowNative';
import { getAdapter } from '@/services/database/db';
import { ALL_COLLECTIONS } from '@/models/types';
import { inputToMin, minToInput, weekdayName, fmtNumber } from '@/utils/date';
import { uid } from '@/utils/id';
import { cn } from '@/utils/cn';
import type { TKey } from '@/services/localization/i18n';

type P = { onBack: () => void };
const up = (p: Partial<Settings>) => useApp.getState().updateSettings(p);

const HUB: { id: Screen; icon: React.ReactNode; color: string; t: TKey; s: TKey }[] = [
  { id: 'set_look', icon: <Palette size={19} />, color: '#8b5cf6', t: 'set_look', s: 'set_look_sub' },
  { id: 'set_plan', icon: <SlidersHorizontal size={19} />, color: '#3b82f6', t: 'set_plan', s: 'set_plan_sub' },
  { id: 'set_alerts', icon: <Bell size={19} />, color: '#ef4444', t: 'set_alerts', s: 'set_alerts_sub' },
  { id: 'set_sound', icon: <Volume2 size={19} />, color: '#f59e0b', t: 'set_sound', s: 'set_sound_sub' },
  { id: 'set_study', icon: <GraduationCap size={19} />, color: '#10b981', t: 'set_study', s: 'set_study_sub' },
  { id: 'set_data', icon: <Database size={19} />, color: '#64748b', t: 'set_data', s: 'set_data_sub' },
];

export function SettingsHub({ onBack }: P) {
  const { t } = useT();
  const ui = useUI();
  const s = useSettings();
  const theme = getTheme(s.themeId);
  return (
    <div>
      <ScreenHeader title={t('m_settings')} subtitle={t('privacy_note')} onBack={onBack} />
      <Page>
        <Card onClick={() => ui.push('themes')} className="anim-page flex items-center gap-3 p-3">
          <div className="flex -space-x-2 rtl:space-x-reverse">{theme.swatch.map((c, i) => <span key={i} className="h-9 w-9 rounded-full border-2 border-[var(--surface)] shadow" style={{ background: c }} />)}</div>
          <div className="min-w-0 flex-1"><div className="text-[11px] font-bold uppercase text-ink-3">{t('theme')}</div><div className="truncate text-[16px] font-bold">{s.language === 'ar' ? theme.ar : theme.en}</div></div>
          <Badge tone="accent">{t('change')}</Badge>
        </Card>
        <div className="stagger mt-4"><Group>{HUB.map((r) => (
          <ListRow key={r.id} onClick={() => ui.push(r.id)} icon={<span className="grid h-9 w-9 place-items-center rounded-[11px] text-white" style={{ background: r.color }}>{r.icon}</span>} title={<span className="font-semibold">{t(r.t)}</span>} subtitle={t(r.s)} trailing={<Chevron className="text-ink-3" />} />
        ))}</Group></div>
        <SectionTitle>{t('more_title')}</SectionTitle>
        <Group>
          <ListRow onClick={() => ui.push('rules')} title={t('m_rules')} trailing={<Chevron className="text-ink-3" />} />
          <ListRow onClick={() => ui.push('templates')} title={t('m_templates')} trailing={<Chevron className="text-ink-3" />} />
          <ListRow onClick={() => ui.set({ tourOpen: true })} icon={<Orn name="rocket" size={22} />} title={t('tour_again')} trailing={<Chevron className="text-ink-3" />} />
          <ListRow onClick={() => ui.push('about')} title={t('m_about')} trailing={<Chevron className="text-ink-3" />} />
        </Group>
      </Page>
    </div>
  );
}

export function SetLook({ onBack }: P) {
  const { t, lang } = useT();
  const s = useSettings();
  const ui = useUI();
  const forced = getTheme(s.themeId).forceDark;
  return (
    <div>
      <ScreenHeader title={t('set_look')} onBack={onBack} />
      <Page>
        <SectionTitle>{t('language')}</SectionTitle>
        <Card className="p-3"><Segmented value={s.language} onChange={(v) => up({ language: v })} options={[{ value: 'ar', label: 'العربية (مصري)' }, { value: 'en', label: 'English' }]} /></Card>
        <SectionTitle>{t('theme')}</SectionTitle>
        <Group>
          <ListRow onClick={() => ui.push('themes')} icon={<Orn name="artist_palette" size={24} />} title={lang === 'ar' ? getTheme(s.themeId).ar : getTheme(s.themeId).en} subtitle={t('themes_open')} trailing={<Chevron className="text-ink-3" />} />
          <div className="p-3"><div className="mb-1.5 text-[13px] text-ink-2">{t('theme_mode')}</div><Segmented value={forced ? 'dark' : s.theme} onChange={(v) => !forced && up({ theme: v })} options={[{ value: 'system', label: t('th_system') }, { value: 'light', label: t('th_light') }, { value: 'dark', label: t('th_dark') }]} />{forced && <p className="mt-1 text-xs text-ink-3">{t('theme_forced_dark')}</p>}</div>
          <SRow label={t('accent')}><div className="flex flex-wrap justify-end gap-2"><button aria-label="auto" onClick={() => up({ accent: 'theme' as Accent })} className={cn('h-7 rounded-full border-2 px-2 text-[11px] font-bold', s.accent === ('theme' as Accent) ? 'border-ink' : 'border-line text-ink-3')}>{t('accent_auto')}</button>
            {(['indigo', 'teal', 'rose', 'amber', 'graphite', 'emerald'] as Accent[]).map((a) => <button key={a} aria-label={a} onClick={() => up({ accent: a })} data-accent={a} className={cn('h-7 w-7 rounded-full border-2', s.accent === a ? 'border-ink' : 'border-transparent')} style={{ background: { indigo: '#5b5bd6', teal: '#13897b', rose: '#cf4a6b', amber: '#c27a12', graphite: '#3c3b45', emerald: '#1f9a5c', theme: '#888' }[a] }} />)}</div></SRow>
        </Group>
        <SectionTitle>{t('decor_title')}</SectionTitle>
        <Group className="mb-2"><ListRow onClick={() => ui.push('decor')} icon={<Orn name="sparkles" size={24} />} title={t('decor_open')} subtitle={t('decor_open_sub')} trailing={<Chevron className="text-ink-3" />} /></Group>
        <Card className="p-3"><div className="mb-2 flex items-center gap-1.5 text-[13px] text-ink-2">{t('decor_level')}<HelpTip id="decor" /></div>
          <Segmented value={s.decor} onChange={(v) => up({ decor: v })} options={[{ value: 'off', label: t('decor_off') }, { value: 'light', label: t('decor_light') }, { value: 'full', label: t('decor_full') }]} /><p className="mt-2 text-xs text-ink-3">{t('decor_note')}</p></Card>
        <SectionTitle>{t('set_look')}</SectionTitle>
        <Group>
          <SRow label={t('font_scale')} help="font_scale"><Stepper value={Math.round(s.fontScale * 100)} onChange={(v) => up({ fontScale: v / 100 })} min={85} max={135} step={5} suffix="%" /></SRow>
          <SRow label={t('week_start')} help="week_start"><Select className="w-36" value={String(s.weekStart)} onChange={(v) => up({ weekStart: Number(v) as 0 | 1 | 6 })} options={[6, 0, 1].map((d) => ({ value: String(d), label: weekdayName(d, lang, 'long') }))} /></SRow>
          <SRow label={t('timeline_density')} help="density"><Segmented size="sm" className="w-44" value={s.density} onChange={(v) => up({ density: v })} options={[{ value: 'compact', label: t('compact') }, { value: 'comfortable', label: t('comfortable') }, { value: 'spacious', label: t('spacious') }]} /></SRow>
          <div className="px-4"><Toggle checked={s.clock24} onChange={(v) => up({ clock24: v })} label={t('clock_24')} /></div>
          <div className="px-4"><Toggle checked={s.haptics} onChange={(v) => up({ haptics: v })} label={t('haptics')} help="haptics" /></div>
          <div className="p-3"><div className="mb-1.5 flex items-center gap-1.5 text-[13px] text-ink-2">{t('reduce_motion')}<HelpTip id="reduce_motion" /></div><Segmented size="sm" value={s.reducedMotion} onChange={(v) => up({ reducedMotion: v })} options={[{ value: 'system', label: t('th_system') }, { value: 'on', label: t('enabled') }, { value: 'off', label: t('disabled') }]} /></div>
        </Group>
        <SectionTitle>{t('hijri_adjust')}</SectionTitle>
        <Group><SRow label={t('hijri_adjust')} help="hijri_adjust"><Stepper value={s.hijriAdjust} onChange={(v) => up({ hijriAdjust: v })} min={-2} max={2} suffix={t('days')} /></SRow>
          <div className="px-4"><Toggle checked={s.showOtherReligions} onChange={(v) => up({ showOtherReligions: v })} label={t('cal_others_toggle')} description={t('cal_others_toggle_sub')} help="other_religions" /></div></Group>
      </Page>
    </div>
  );
}

export function SetPlan({ onBack }: P) {
  const { t } = useT();
  const s = useSettings();
  return (
    <div>
      <ScreenHeader title={t('set_plan')} onBack={onBack} />
      <Page>
        <SectionTitle>{t('apply_plan')}</SectionTitle>
        <Card className="px-4"><Toggle checked={s.autoApplyPlan} onChange={(v) => up({ autoApplyPlan: v })} label={t('auto_apply')} description={t('auto_apply_sub')} help="auto_apply" /></Card>
        <p className="mt-2 flex items-center gap-1.5 px-1 text-xs text-ink-3"><HelpTip id="apply_plan" />{t('apply_plan_note')}</p>
        <SectionTitle>{t('scheduling')}</SectionTitle>
        <Group>
          <SRow label={t('default_duration')}><Stepper value={s.defaultDurationMin} onChange={(v) => up({ defaultDurationMin: v })} min={5} max={480} step={5} suffix={t('min_short')} /></SRow>
          <SRow label={t('default_buffer')} help="buffer"><Stepper value={s.defaultBufferMin} onChange={(v) => up({ defaultBufferMin: v })} min={0} max={60} step={5} suffix={t('min_short')} /></SRow>
          <SRow label={`${t('day_bounds')} · ${t('from')}`} help="day_bounds"><Input type="time" className="w-32" value={minToInput(s.dayStartMin)} onChange={(e) => up({ dayStartMin: inputToMin(e.target.value) })} /></SRow>
          <SRow label={`${t('day_bounds')} · ${t('to')}`}><Input type="time" className="w-32" value={minToInput(s.dayEndMin)} onChange={(e) => up({ dayEndMin: Math.max(s.dayStartMin + 60, inputToMin(e.target.value) || 1440) })} /></SRow>
          <SRow label={`${t('productive_hours')} · ${t('from')}`} help="productive_hours"><Input type="time" className="w-32" value={minToInput(s.productiveStartMin)} onChange={(e) => up({ productiveStartMin: inputToMin(e.target.value) })} /></SRow>
          <SRow label={`${t('productive_hours')} · ${t('to')}`}><Input type="time" className="w-32" value={minToInput(s.productiveEndMin)} onChange={(e) => up({ productiveEndMin: inputToMin(e.target.value) })} /></SRow>
        </Group>
        <SectionTitle>{t('dashboard_layout')}</SectionTitle>
        <Group className="px-4">
          {(['overview', 'quickActions', 'prayer', 'tasks', 'water', 'collapseCompleted'] as const).map((k) => <Toggle key={k} checked={s.dashboard[k]} onChange={(v) => up({ dashboard: { ...s.dashboard, [k]: v } })} label={t(({ overview: 'day_progress', quickActions: 'quick_actions', prayer: 'm_prayer', tasks: 'm_tasks', water: 'water', collapseCompleted: 'collapse_completed' } as const)[k])} />)}
          <div className="py-3"><div className="mb-1.5 flex items-center gap-1.5 text-[13px] text-ink-2">{t('widget_layout')}<HelpTip id="widgets" /></div><Segmented size="sm" value={s.widgetLayout} onChange={(v) => up({ widgetLayout: v })} options={[{ value: 'compact', label: t('compact') }, { value: 'medium', label: t('medium') }, { value: 'large', label: t('spacious') }]} /></div>
        </Group>
      </Page>
    </div>
  );
}

export function SetAlerts({ onBack }: P) {
  const { t, lang } = useT();
  const s = useSettings();
  const ui = useUI();
  return (
    <div>
      <ScreenHeader title={t('set_alerts')} onBack={onBack} />
      <Page>
        <Group className="mb-2"><ListRow onClick={() => ui.push('reliability')} icon={<Orn name="bell" size={24} />} title={t('m_reliability')} subtitle={t('rel_check_sub')} trailing={<Chevron className="text-ink-3" />} /></Group>
        <SectionTitle>{t('reminders')}</SectionTitle>
        <Group>
          <div className="p-3"><Field label={<span className="flex items-center gap-1.5">{t('default_reminder')}</span>}><Input value={s.defaultReminderOffsets.join(', ')} onChange={(e) => up({ defaultReminderOffsets: e.target.value.split(/[,،\s]+/).map(Number).filter((n) => Number.isFinite(n) && n >= 0 && n <= 1440).slice(0, 5) })} /></Field></div>
          <SRow label={t('reminder_horizon')} help="horizon"><Stepper value={s.reminderHorizonDays} onChange={(v) => up({ reminderHorizonDays: v })} min={1} max={14} suffix={t('days')} /></SRow>
          <SRow label={t('escalation_every')} help="escalation"><Stepper value={s.escalation.repeatIntervalMin} onChange={(v) => up({ escalation: { ...s.escalation, repeatIntervalMin: v } })} min={0} max={60} suffix={t('min_short')} /></SRow>
          <SRow label={t('max_repeats')}><Stepper value={s.escalation.maxRepeats} onChange={(v) => up({ escalation: { ...s.escalation, maxRepeats: v } })} min={0} max={10} /></SRow>
          <div className="p-3"><div className="mb-2 flex items-center gap-1.5 text-[13px] text-ink-2">{t('notif_buttons')}<HelpTip id="notif_actions" /></div>
            <div className="flex flex-wrap gap-2">{(['DONE', 'START', 'SNOOZE_5', 'SNOOZE_10', 'SNOOZE_15', 'SKIP', 'PARTIAL'] as const).map((a) => <Chip key={a} active={s.defaultActions.includes(a)} onClick={() => up({ defaultActions: s.defaultActions.includes(a) ? s.defaultActions.filter((x) => x !== a) : [...s.defaultActions, a].slice(-3) })}>{t(`act_${a.toLowerCase()}` as TKey)}</Chip>)}</div></div>
        </Group>
        <SectionTitle>{t('occasions')}</SectionTitle>
        <Card className="px-4"><Toggle checked={s.occasionNotify} onChange={(v) => up({ occasionNotify: v })} label={t('occasion_notify')} description={t('occasion_notify_sub')} help="occasion_notify" /></Card>
        <SectionTitle>{t('quiet_hours')}</SectionTitle>
        <Group>
          <div className="px-4"><Toggle checked={s.quietHours.enabled} onChange={(v) => up({ quietHours: { ...s.quietHours, enabled: v } })} label={t('quiet_hours')} help="quiet_hours" /></div>
          {s.quietHours.enabled && <>
            <SRow label={t('from')}><Input type="time" className="w-32" value={minToInput(s.quietHours.startMin)} onChange={(e) => up({ quietHours: { ...s.quietHours, startMin: inputToMin(e.target.value) } })} /></SRow>
            <SRow label={t('to')}><Input type="time" className="w-32" value={minToInput(s.quietHours.endMin)} onChange={(e) => up({ quietHours: { ...s.quietHours, endMin: inputToMin(e.target.value) } })} /></SRow>
            <div className="flex flex-wrap gap-1.5 p-3">{[0, 1, 2, 3, 4, 5, 6].map((d) => <Chip key={d} active={s.quietHours.days.includes(d)} onClick={() => up({ quietHours: { ...s.quietHours, days: s.quietHours.days.includes(d) ? s.quietHours.days.filter((x) => x !== d) : [...s.quietHours.days, d] } })}>{weekdayName(d, lang)}</Chip>)}</div>
            <div className="px-4"><Toggle checked={s.quietHours.allowCritical} onChange={(v) => up({ quietHours: { ...s.quietHours, allowCritical: v } })} label={t('allow_critical')} help="critical" /></div>
          </>}
        </Group>
      </Page>
    </div>
  );
}

export function SetSound({ onBack }: P) {
  const { t, lang } = useT();
  const s = useSettings();
  const sounds = useApp((st) => st.data.sounds);
  const { ask, node } = useConfirm();
  const defaultSpec = { kind: s.soundMode === 'tts' ? 'tts' : s.soundMode === 'none' ? 'silent' : s.defaultSoundId && sounds[s.defaultSoundId] ? 'file' : 'default', uri: s.defaultSoundId ? sounds[s.defaultSoundId]?.path : undefined, name: s.defaultSoundId ? sounds[s.defaultSoundId]?.name : undefined, startMs: s.defaultSoundId ? sounds[s.defaultSoundId]?.startMs : undefined, endMs: s.defaultSoundId ? sounds[s.defaultSoundId]?.endMs : undefined } as import('@/models/types').SoundSpec;
  const tryAudio = async (fn: () => Promise<void>) => { try { await fn(); } catch (e) { useApp.getState().toast('error', errorCode(e).startsWith('TTS') ? t('tts_unavailable') : String((e as Error).message ?? e)); } };
  return (
    <div>
      <ScreenHeader title={t('set_sound')} onBack={onBack} />
      <Page>
        {node}
        <SectionTitle>{t('default_sound')}</SectionTitle>
        <Card className="overflow-hidden"><SoundField value={defaultSpec} volume={s.volume} onChange={(v) => {
          if (v.kind === 'tts') up({ soundMode: 'tts', defaultSoundId: undefined }); else if (v.kind === 'silent') up({ soundMode: 'none', defaultSoundId: undefined });
          else if (v.kind === 'file') { const id = Object.values(sounds).find((x) => x.path === v.uri)?.id; up({ soundMode: 'custom', defaultSoundId: id }); } else up({ soundMode: 'tone', defaultSoundId: undefined });
        }} /></Card>
        <SectionTitle>{t('sound')}</SectionTitle>
        <Group>
          <SRow label={t('volume')}><Stepper value={Math.round(s.volume * 100)} onChange={(v) => up({ volume: v / 100 })} min={5} max={100} step={5} suffix="%" /></SRow>
          <SRow label={t('audio_repeat')}><Stepper value={s.audioRepeat} onChange={(v) => up({ audioRepeat: v })} min={1} max={10} /></SRow>
          <div className="px-4"><Toggle checked={s.gradualVolume} onChange={(v) => up({ gradualVolume: v })} label={t('gradual')} help="gradual" /><Toggle checked={s.vibrate} onChange={(v) => up({ vibrate: v })} label={t('vibrate')} /></div>
          <div className="flex gap-2 p-3"><Button variant="secondary" className="flex-1" icon={<Volume2 size={15} />} onClick={() => tryAudio(() => speak(lang === 'ar' ? 'حان وقت المذاكرة' : 'Time to study', lang))}>{t('test_tts')}</Button><Button variant="secondary" icon={<Square size={14} />} onClick={() => stopSound()}>{t('stop')}</Button></div>
        </Group>
        <SectionTitle action={<Button size="sm" variant="ghost" icon={<Plus size={14} />} onClick={async () => { try { const f = await pickFile('audio', 'audio/*'); const n = Date.now(); await useApp.getState().put('sounds', { id: uid('snd'), name: f.name, path: f.path ?? '', mimeType: f.mimeType, size: f.size, createdAt: n, updatedAt: n }); } catch (e) { if (errorCode(e) !== 'CANCELLED') useApp.getState().toast('error', String((e as Error).message)); } }}>{t('add')}</Button>}>{t('sounds_library')}</SectionTitle>
        <Group>{Object.values(sounds).map((snd) => (
          <ListRow key={snd.id} icon={<Music size={18} className="text-accent" />} title={snd.name} subtitle={snd.startMs != null ? `${Math.round((snd.startMs ?? 0) / 1000)}–${Math.round((snd.endMs ?? 0) / 1000)}s · ${fmtNumber(Math.round(snd.size / 1024), lang)} KB` : `${fmtNumber(Math.round(snd.size / 1024), lang)} KB`}
            trailing={<div className="flex gap-1"><Button size="sm" variant="ghost" aria-label={t('preview_sound')} onClick={() => tryAudio(() => previewSound(snd.path, s.volume, snd.startMs, snd.endMs))}><Play size={15} /></Button>
              <Button size="sm" variant="ghost" aria-label={t('delete')} onClick={async () => { if (await ask(t('delete'), snd.name)) { if (isNative()) DayflowNative.deleteAppFile({ path: snd.path }).catch(() => undefined); await useApp.getState().remove('sounds', [snd.id], false); } }}><Trash2 size={15} /></Button></div>} />
        ))}{!Object.keys(sounds).length && <p className="p-4 text-sm text-ink-3">{t('sounds_empty')}</p>}</Group>
      </Page>
    </div>
  );
}

export function SetStudy({ onBack }: P) {
  const { t } = useT();
  const s = useSettings();
  return (
    <div>
      <ScreenHeader title={t('set_study')} onBack={onBack} />
      <Page>
        <SectionTitle><span className="flex items-center gap-1.5">{t('focus_durations')}<HelpTip id="focus_modes" /></span></SectionTitle>
        <Group>{(['pomodoroWork', 'pomodoroShort', 'pomodoroLong', 'cyclesBeforeLong', 'extendedWork', 'extendedBreak', 'deepWork', 'deepBreak', 'countdown', 'customWork', 'customBreak'] as const).map((k) => <SRow key={k} label={t(`fd_${k}` as TKey)}><Stepper value={s.focus[k]} onChange={(v) => up({ focus: { ...s.focus, [k]: v } })} min={1} max={240} /></SRow>)}
          <div className="px-4"><Toggle checked={s.focus.autoStartBreaks} onChange={(v) => up({ focus: { ...s.focus, autoStartBreaks: v } })} label={t('fd_autoStartBreaks')} /></div></Group>
        <SectionTitle><span className="flex items-center gap-1.5">{t('srs_intervals')}<HelpTip id="srs" /></span></SectionTitle>
        <Card className="p-3"><Input value={s.srsIntervals.join(', ')} onChange={(e) => { const arr = e.target.value.split(/[,،\s]+/).map(Number).filter((n) => n > 0 && n <= 365); if (arr.length) up({ srsIntervals: arr }); }} /></Card>
        <SectionTitle>{t('burnout_thresholds')}</SectionTitle>
        <Group>
          <div className="px-4"><Toggle checked={s.burnout.enabled} onChange={(v) => up({ burnout: { ...s.burnout, enabled: v } })} label={t('burnout')} help="burnout" /></div>
          <SRow label={t('max_daily_work')}><Stepper value={s.burnout.maxDailyWorkMin} onChange={(v) => up({ burnout: { ...s.burnout, maxDailyWorkMin: v } })} min={60} max={1200} step={30} /></SRow>
          <SRow label={t('low_energy')}><Stepper value={s.burnout.lowEnergyThreshold} onChange={(v) => up({ burnout: { ...s.burnout, lowEnergyThreshold: v } })} min={1} max={5} step={0.5} /></SRow>
          <SRow label={t('lookback')}><Stepper value={s.burnout.lookbackDays} onChange={(v) => up({ burnout: { ...s.burnout, lookbackDays: v } })} min={3} max={30} /></SRow>
          <SRow label={t('insights_min')} help="insights_min"><Stepper value={s.insightsMinObservations} onChange={(v) => up({ insightsMinObservations: v })} min={5} max={100} /></SRow>
        </Group>
      </Page>
    </div>
  );
}

export function SetData({ onBack }: P) {
  const { t, lang } = useT();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const engine = useApp((st) => st.engine);
  const { node } = useConfirm();
  const [wipe, setWipe] = useState('');
  const [cat, setCat] = useState<ActivityCategory | null>(null);
  return (
    <div>
      <ScreenHeader title={t('set_data')} onBack={onBack} />
      <Page>
        {node}
        <Group>
          <ListRow onClick={() => ui.push('backup')} icon={<Orn name="ledger" size={24} />} title={t('m_backup')} subtitle={t('backup_sub')} trailing={<Chevron className="text-ink-3" />} />
          <ListRow onClick={() => ui.push('history')} icon={<Orn name="clipboard" size={24} />} title={t('m_history')} trailing={<Chevron className="text-ink-3" />} />
        </Group>
        <SectionTitle action={<Button size="sm" variant="ghost" icon={<Plus size={14} />} onClick={() => { const n = Date.now(); setCat({ id: uid('cat'), key: 'custom', nameAr: '', nameEn: '', icon: 'star', color: 'var(--c-custom)', builtin: false, productive: false, createdAt: n, updatedAt: n }); }}>{t('new_category')}</Button>}>{t('categories_mgmt')}</SectionTitle>
        <Group>{Object.values(data.categories).map((c) => <ListRow key={c.id} onClick={() => setCat(c)} icon={<span style={{ color: c.color }}><Icon name={c.icon} /></span>} title={lang === 'ar' ? c.nameAr : c.nameEn} trailing={c.productive ? <Badge tone="accent">{t('productive')}</Badge> : undefined} />)}</Group>
        <SectionTitle>{t('ai_coach')}</SectionTitle>
        <Card className="p-4"><Toggle checked={false} disabled onChange={() => undefined} label={t('ai_coach')} description={t('ai_coach_off')} /></Card>
        <SectionTitle>{t('db_info')}</SectionTitle>
        <Card className="space-y-2 p-4 text-sm">
          <div className="flex justify-between"><span>{t('storage_engine')}</span><b>{engine === 'sqlite' ? 'SQLite (Android)' : engine === 'memory' ? t('memory_engine') : 'IndexedDB'}</b></div>
          <div className="flex justify-between"><span>{t('schema_version')}</span><b>{Object.values(data.migrations).map((m) => m.version).sort().join(', ')}</b></div>
          <div className="flex justify-between"><span>{t('records')}</span><b className="num">{fmtNumber(ALL_COLLECTIONS.reduce((a, c) => a + Object.keys(data[c]).length, 0), lang)}</b></div>
          <p className="pt-2 text-xs text-ink-3">{t('privacy_note')} {t('offline_note')}</p>
        </Card>
        <SectionTitle>{t('wipe_all')}</SectionTitle>
        <Card className="space-y-2 p-4"><Field label={t('wipe_confirm')}><Input value={wipe} onChange={(e) => setWipe(e.target.value)} /></Field>
          <Button variant="danger" className="w-full" disabled={wipe !== 'DELETE'} onClick={async () => { await getAdapter().batch(ALL_COLLECTIONS.map((c) => ({ op: 'clear' as const, collection: c }))); location.reload(); }}>{t('wipe_all')}</Button></Card>
      </Page>
      {cat && (
        <Sheet open onClose={() => setCat(null)} title={t('new_category')} footer={<div className="flex gap-2">{!cat.builtin && data.categories[cat.id] && <Button variant="danger" onClick={async () => { await useApp.getState().remove('categories', [cat.id]); setCat(null); }}>{t('delete')}</Button>}<Button className="flex-1" disabled={!cat.nameAr.trim() && !cat.nameEn.trim()} onClick={async () => { await useApp.getState().put('categories', { ...cat, nameAr: cat.nameAr || cat.nameEn, nameEn: cat.nameEn || cat.nameAr }); setCat(null); }}>{t('save')}</Button></div>}>
          <div className="space-y-4">
            <Field label="العربية"><Input value={cat.nameAr} onChange={(e) => setCat({ ...cat, nameAr: e.target.value })} dir="rtl" /></Field>
            <Field label="English"><Input value={cat.nameEn} onChange={(e) => setCat({ ...cat, nameEn: e.target.value })} dir="ltr" /></Field>
            <Field label={t('icon')}><div className="flex flex-wrap gap-2">{Object.keys(ICONS).map((k) => <button key={k} onClick={() => setCat({ ...cat, icon: k })} className={cn('grid h-10 w-10 place-items-center rounded-xl', cat.icon === k ? 'bg-accent text-accent-ink' : 'bg-surface-2')}><Icon name={k} /></button>)}</div></Field>
            <Field label={t('color')}><div className="flex flex-wrap gap-2">{['study', 'exercise', 'rest', 'meal', 'sleep', 'water', 'work', 'custom'].map((c) => <button key={c} aria-label={c} onClick={() => setCat({ ...cat, color: `var(--c-${c})` })} className={cn('h-9 w-9 rounded-full border-2', cat.color === `var(--c-${c})` ? 'border-ink' : 'border-transparent')} style={{ background: `var(--c-${c})` }} />)}</div></Field>
            <Toggle checked={cat.productive} onChange={(v) => setCat({ ...cat, productive: v })} label={t('productive')} />
          </div>
        </Sheet>
      )}
      {void Sparkles}{void Play}{void ChevronLeft}{void Select}
    </div>
  );
}
