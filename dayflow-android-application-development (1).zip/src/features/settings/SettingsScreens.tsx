import { useState } from 'react';
import { Trash2, Plus, RotateCcw, Check } from 'lucide-react';
import { useApp, blocksForDate, instantiate } from '@/stores/appStore';
import { Badge, Button, Card, Chip, Field, Group, Input, ListRow, Page, ScreenHeader, SectionTitle, Select, Sheet, Stepper, Toggle, useSettings, useT } from '@/components/common/ui';
import type { DayTemplate, Routine } from '@/models/types';
import { fmtDate, fmtDateTime, fmtNumber, fmtTime, inputToMin, minToInput, todayKey, weekdayName } from '@/utils/date';
import { uid } from '@/utils/id';
import { coreFrom } from '@/services/defaults';


import { cn } from '@/utils/cn';
import type { TKey } from '@/services/localization/i18n';

const Row = ({ label, children }: { label: React.ReactNode; children: React.ReactNode }) => <div className="flex items-center justify-between gap-3 px-4 py-3"><span className="text-[15px]">{label}</span>{children}</div>;

export function RulesScreen({ onBack }: { onBack: () => void }) {
  const { t } = useT();
  const rules = useApp((s) => s.data.rules);
  return (
    <div>
      <ScreenHeader title={t('rules_title')} onBack={onBack} />
      <Page>
        <div className="space-y-2">{Object.values(rules).sort((a, b) => b.priority - a.priority).map((r) => (
          <Card key={r.id} className="p-4">
            <Toggle checked={r.enabled} onChange={(v) => useApp.getState().put('rules', { ...r, enabled: v })} label={t(`ru_${r.type}` as TKey)} description={`${t('priority')}: ${r.priority}`} />
            {r.enabled && Object.keys(r.params).length > 0 && <div className="mt-2 space-y-2 border-t border-line pt-2">{Object.entries(r.params).map(([k, v]) => <div key={k} className="flex items-center justify-between text-sm"><span className="text-ink-2">{k}</span><Stepper value={v} onChange={(nv) => useApp.getState().put('rules', { ...r, params: { ...r.params, [k]: nv } })} min={0} max={1000} step={k.toLowerCase().includes('min') && v >= 30 ? 5 : 1} /></div>)}</div>}
            <div className="mt-2 flex items-center justify-between"><span className="text-xs text-ink-3">{t('priority')}</span><Stepper value={r.priority} onChange={(v) => useApp.getState().put('rules', { ...r, priority: v })} min={1} max={10} /></div>
          </Card>
        ))}</div>
      </Page>
    </div>
  );
}

export function TemplatesScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [tpl, setTpl] = useState<DayTemplate | null>(null);
  const [rt, setRt] = useState<Routine | null>(null);
  const [special, setSpecial] = useState({ date: todayKey(), label: '', templateId: '' });
  const assign = async (wd: number, templateId: string) => {
    const ex = Object.values(data.weekdayAssignments).find((w) => w.weekday === wd);
    if (!templateId) { if (ex) await useApp.getState().remove('weekdayAssignments', [ex.id], false); return; }
    const n = Date.now();
    await useApp.getState().put('weekdayAssignments', { id: ex?.id ?? `wd_${wd}`, weekday: wd, templateId, createdAt: ex?.createdAt ?? n, updatedAt: n });
  };
  const runToday = async (r: Routine, start: number) => {
    let m = start;
    const blocks = r.steps.map((st) => { const b = instantiate(coreFrom({ title: `${r.name} · ${st.title}`, categoryId: r.categoryId, startMin: m, durationMin: st.durationMin }), todayKey(), { source: 'routine' }); m += st.durationMin; return b; });
    if (await useApp.getState().commit({ activities: blocks })) useApp.getState().toast('success', t('template_applied', { n: blocks.length }));
  };
  return (
    <div>
      <ScreenHeader title={t('m_templates')} onBack={onBack} />
      <Page>
        <SectionTitle>{t('weekday_assign')}</SectionTitle>
        <Group>{[0, 1, 2, 3, 4, 5, 6].map((wd) => <Row key={wd} label={weekdayName(wd, lang, 'long')}><Select className="w-44" value={Object.values(data.weekdayAssignments).find((w) => w.weekday === wd)?.templateId ?? ''} onChange={(v) => assign(wd, v)} options={[{ value: '', label: t('none') }, ...Object.values(data.templates).map((x) => ({ value: x.id, label: x.name }))]} /></Row>)}</Group>
        <SectionTitle action={<Button size="sm" variant="ghost" icon={<Plus size={14} />} onClick={() => { const n = Date.now(); setTpl({ id: uid('tpl'), name: '', kind: 'custom', blocks: [], builtin: false, createdAt: n, updatedAt: n }); }}>{t('new')}</Button>}>{t('templates')}</SectionTitle>
        <Group>{Object.values(data.templates).map((x) => <ListRow key={x.id} onClick={() => setTpl(x)} title={x.name} subtitle={`${fmtNumber(x.blocks.length, lang)} ${t('blocks')} · ${t(`tpl_${x.kind}` as TKey)}`} />)}</Group>
        <SectionTitle>{t('special_dates')}</SectionTitle>
        <Card className="space-y-2 p-3">
          <div className="grid grid-cols-2 gap-2"><Input type="date" value={special.date} onChange={(e) => setSpecial({ ...special, date: e.target.value })} /><Input value={special.label} placeholder={t('title')} onChange={(e) => setSpecial({ ...special, label: e.target.value })} /></div>
          <Select value={special.templateId} onChange={(v) => setSpecial({ ...special, templateId: v })} options={[{ value: '', label: t('none') }, ...Object.values(data.templates).map((x) => ({ value: x.id, label: x.name }))]} />
          <Button size="sm" className="w-full" disabled={!special.label.trim()} onClick={async () => { const n = Date.now(); await useApp.getState().put('specialDates', { id: uid('sd'), date: special.date, label: special.label.trim(), kind: special.templateId ? 'special' : 'holiday', templateId: special.templateId || undefined, createdAt: n, updatedAt: n }); setSpecial({ ...special, label: '' }); }}>{t('add')}</Button>
          {Object.values(data.specialDates).sort((a, b) => a.date.localeCompare(b.date)).map((d) => <div key={d.id} className="flex items-center justify-between text-sm"><span>{fmtDate(d.date, lang, { day: 'numeric', month: 'short' })} · {d.label}</span><button onClick={() => useApp.getState().remove('specialDates', [d.id])}><Trash2 size={14} /></button></div>)}
        </Card>
        <SectionTitle action={<Button size="sm" variant="ghost" icon={<Plus size={14} />} onClick={() => { const n = Date.now(); setRt({ id: uid('rt'), name: '', kind: 'custom', steps: [], categoryId: 'cat_routine', createdAt: n, updatedAt: n }); }}>{t('new')}</Button>}>{t('routines')}</SectionTitle>
        <div className="space-y-2">{Object.values(data.routines).map((r) => {
          const run = Object.values(data.routineRuns).find((x) => x.routineId === r.id && x.date === todayKey());
          const toggleStep = async (sid: string) => { const n = Date.now(); const done = run?.doneStepIds.includes(sid) ? run.doneStepIds.filter((x) => x !== sid) : [...(run?.doneStepIds ?? []), sid]; const req = r.steps.filter((x) => x.required).every((x) => done.includes(x.id)); await useApp.getState().put('routineRuns', { id: run?.id ?? uid('rr'), routineId: r.id, date: todayKey(), doneStepIds: done, completedAt: req ? n : undefined, createdAt: run?.createdAt ?? n, updatedAt: n }); };
          return (
            <Card key={r.id} className="p-4">
              <div className="flex items-center justify-between"><button className="font-semibold" onClick={() => setRt(r)}>{r.name}</button>{run?.completedAt && <Badge tone="success"><Check size={10} />{t('completed')}</Badge>}</div>
              {r.steps.map((st) => <label key={st.id} className="flex items-center gap-2 py-1 text-sm"><input type="checkbox" className="h-5 w-5 accent-[var(--accent)]" checked={!!run?.doneStepIds.includes(st.id)} onChange={() => toggleStep(st.id)} /><span className="flex-1">{st.title}{st.required ? '' : ` (${t('optional')})`}</span><span className="num text-ink-3">{st.durationMin}{t('min_short')}</span></label>)}
              <Button size="sm" variant="tinted" className="mt-2" onClick={() => runToday(r, Math.ceil((new Date().getHours() * 60 + new Date().getMinutes()) / 5) * 5)}>{t('schedule_routine')}</Button>
            </Card>
          );
        })}</div>
      </Page>
      {tpl && <TemplateSheet tpl={tpl} onClose={() => setTpl(null)} />}
      {rt && (
        <Sheet open onClose={() => setRt(null)} tall title={rt.name || t('routines')} footer={<div className="flex gap-2">{data.routines[rt.id] && <Button variant="danger" onClick={async () => { await useApp.getState().remove('routines', [rt.id]); setRt(null); }}>{t('delete')}</Button>}<Button className="flex-1" disabled={!rt.name.trim()} onClick={async () => { await useApp.getState().put('routines', rt); setRt(null); }}>{t('save')}</Button></div>}>
          <div className="space-y-3">
            <Field label={t('name')}><Input value={rt.name} onChange={(e) => setRt({ ...rt, name: e.target.value })} /></Field>
            <Select value={rt.kind} onChange={(v) => setRt({ ...rt, kind: v as Routine['kind'] })} options={(['morning', 'evening', 'pre_study', 'after_work', 'workout_prep', 'pre_sleep', 'custom'] as const).map((k) => ({ value: k, label: k === 'custom' ? t('tpl_custom') : t(`r_${k}` as TKey) }))} />
            {rt.steps.map((st, i) => <div key={st.id} className="flex items-center gap-2"><Input value={st.title} onChange={(e) => setRt({ ...rt, steps: rt.steps.map((x, j) => j === i ? { ...x, title: e.target.value } : x) })} /><Stepper value={st.durationMin} onChange={(v) => setRt({ ...rt, steps: rt.steps.map((x, j) => j === i ? { ...x, durationMin: v } : x) })} min={1} max={180} /><input type="checkbox" aria-label={t('required')} checked={st.required} onChange={() => setRt({ ...rt, steps: rt.steps.map((x, j) => j === i ? { ...x, required: !x.required } : x) })} /><button onClick={() => setRt({ ...rt, steps: rt.steps.filter((_, j) => j !== i) })}><Trash2 size={14} /></button></div>)}
            <Button variant="secondary" icon={<Plus size={14} />} onClick={() => setRt({ ...rt, steps: [...rt.steps, { id: uid(), title: '', durationMin: 5, required: true }] })}>{t('add_step')}</Button>
          </div>
        </Sheet>
      )}
      {void s}
    </div>
  );
}

function TemplateSheet({ tpl, onClose }: { tpl: DayTemplate; onClose: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [x, setX] = useState(tpl);
  return (
    <Sheet open onClose={onClose} tall title={x.name || t('templates')} footer={<div className="flex gap-2">{data.templates[x.id] && <Button variant="danger" onClick={async () => { await useApp.getState().remove('templates', [x.id]); onClose(); }}>{t('delete')}</Button>}<Button variant="secondary" onClick={async () => { const n = Date.now(); await useApp.getState().put('templates', { ...x, id: uid('tpl'), name: `${x.name} (2)`, builtin: false, createdAt: n, updatedAt: n }); onClose(); }}>{t('duplicate_day').split(' ')[0]}</Button><Button className="flex-1" disabled={!x.name.trim()} onClick={async () => { await useApp.getState().put('templates', x); onClose(); }}>{t('save')}</Button></div>}>
      <div className="space-y-3">
        <Field label={t('name')}><Input value={x.name} onChange={(e) => setX({ ...x, name: e.target.value })} /></Field>
        <Select value={x.kind} onChange={(v) => setX({ ...x, kind: v as DayTemplate['kind'] })} options={(['normal', 'school', 'exam', 'work', 'weekend', 'vacation', 'recovery', 'light', 'custom'] as const).map((k) => ({ value: k, label: t(`tpl_${k}` as TKey) }))} />
        {x.blocks.sort((a, b) => a.startMin - b.startMin).map((b, i) => (
          <Card key={i} className="space-y-2 p-3">
            <div className="flex gap-2"><Input value={b.title} onChange={(e) => setX({ ...x, blocks: x.blocks.map((y, j) => j === i ? { ...y, title: e.target.value } : y) })} /><button onClick={() => setX({ ...x, blocks: x.blocks.filter((_, j) => j !== i) })}><Trash2 size={15} /></button></div>
            <div className="flex flex-wrap items-center gap-2"><Input type="time" className="w-28" value={minToInput(b.startMin)} onChange={(e) => setX({ ...x, blocks: x.blocks.map((y, j) => j === i ? { ...y, startMin: inputToMin(e.target.value) } : y) })} /><Stepper value={b.durationMin} onChange={(v) => setX({ ...x, blocks: x.blocks.map((y, j) => j === i ? { ...y, durationMin: v } : y) })} min={5} max={720} step={5} />
              <Select className="h-10 w-32" value={b.categoryId} onChange={(v) => { const c = data.categories[v]; setX({ ...x, blocks: x.blocks.map((y, j) => j === i ? { ...y, categoryId: v, icon: c?.icon ?? y.icon, color: c?.color ?? y.color } : y) }); }} options={Object.values(data.categories).map((c) => ({ value: c.id, label: lang === 'ar' ? c.nameAr : c.nameEn }))} />
              <Chip active={b.fixed} onClick={() => setX({ ...x, blocks: x.blocks.map((y, j) => j === i ? { ...y, fixed: !y.fixed } : y) })}>{t('fixed')}</Chip></div>
          </Card>
        ))}
        <Button variant="secondary" icon={<Plus size={14} />} onClick={() => setX({ ...x, blocks: [...x.blocks, coreFrom({ title: '', categoryId: 'cat_personal', startMin: x.blocks.length ? Math.min(1380, Math.max(...x.blocks.map((b) => b.startMin + b.durationMin))) : 8 * 60, durationMin: s.defaultDurationMin })] })}>{t('add_activity')}</Button>
      </div>
    </Sheet>
  );
}

export function HistoryScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const changes = useApp((st) => st.data.scheduleChanges);
  const list = Object.values(changes).sort((a, b) => b.createdAt - a.createdAt);
  const last = list.find((c) => !c.reverted && c.kind !== 'template');
  return (
    <div>
      <ScreenHeader title={t('schedule_history')} onBack={onBack} actions={last && <Button size="sm" variant="tinted" icon={<RotateCcw size={14} />} onClick={() => useApp.getState().revertChange(last.id)}>{t('undo_last')}</Button>} />
      <Page>
        {!list.length && <p className="text-sm text-ink-3">{t('empty_generic')}</p>}
        <div className="space-y-2">{list.slice(0, 100).map((c) => (
          <Card key={c.id} className={cn('p-4', c.reverted && 'opacity-55')}>
            <div className="flex items-start justify-between gap-2"><div><div className="font-semibold">{c.reason}</div><div className="text-xs text-ink-3">{fmtDateTime(c.createdAt, lang, s.clock24)} · {c.kind}</div></div>{c.reverted ? <Badge>{t('reverted')}</Badge> : <Button size="sm" variant="secondary" onClick={() => useApp.getState().revertChange(c.id)}>{t('restore')}</Button>}</div>
            <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
              <div><div className="mb-1 font-semibold text-ink-3">{t('before')}</div>{c.before.map((b) => <div key={b.id} className="truncate">{fmtTime(b.startMin, lang, s.clock24)} {b.title}</div>)}</div>
              <div><div className="mb-1 font-semibold text-ink-3">{t('after')}</div>{c.after.map((b, i) => <div key={b.id + i} className="truncate">{fmtTime(b.startMin, lang, s.clock24)} {b.title}</div>)}</div>
            </div>
          </Card>
        ))}</div>
      </Page>
    </div>
  );
}

export function AboutScreen({ onBack }: { onBack: () => void }) {
  const { t } = useT();
  const caps = useApp((s) => s.caps);
  const rows: [TKey, string][] = [['storage_engine', caps?.nativeDatabase ? 'SQLite' : 'IndexedDB'], ['m_notifications', caps?.platform === 'android' ? t('available') : t('native_only')], ['widget_layout', caps?.widgets ? t('available') : t('native_only')], ['test_tts', caps?.tts ? t('available') : t('unsupported')]];
  return (
    <div>
      <ScreenHeader title={t('m_about')} onBack={onBack} />
      <Page>
        <Card className="p-6 text-center"><div className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-3xl bg-accent text-2xl font-bold text-accent-ink">D</div><h2 className="text-xl font-bold">{t('app_name')} · 𝐃α𝗒 𝐅ᥣⱺω</h2><p className="mt-1 text-sm text-ink-2">{t('tagline')}</p><p className="mt-3 text-xs text-ink-3">{t('about_body')}</p></Card>
        <SectionTitle>{t('available')}</SectionTitle>
        <Group>{rows.map(([k, v]) => <Row key={k} label={t(k)}><Badge>{v}</Badge></Row>)}</Group>
        <p className="mt-4 text-center text-xs text-ink-3">{t('privacy_note')}</p>
        <p className="mt-2 text-center text-[11px] leading-5 text-ink-3">Photos: Pexels contributors (free licence) · 3D icons: Microsoft Fluent Emoji (MIT) · Fonts: Inter, IBM Plex Sans Arabic, Cairo, Tajawal, Almarai, El Messiri, Readex Pro (OFL)</p>
        {void blocksForDate}
      </Page>
    </div>
  );
}
