import { useMemo, useState } from 'react';
import { Plus, ChevronDown, ChevronUp, Layers, GraduationCap, CalendarPlus, Trash2, BookOpen } from 'lucide-react';
import { useApp, blocksForDate, instantiate } from '@/stores/appStore';
import { Badge, Button, Card, Chip, EmptyState, Field, Input, Page, ProgressBar, ScreenHeader, SectionTitle, Segmented, Select, Sheet, Stepper, TextArea, useSettings, useT } from '@/components/common/ui';
import type { StudyLesson, StudyStatus, StudySubject, StudyUnit, Flashcard, Exam } from '@/models/types';
import { addDays, diffDays, fmtDate, fmtDuration, fmtNumber, inputToMin, minToInput, todayKey, nowMinutes } from '@/utils/date';
import { uid } from '@/utils/id';
import { nextReview } from '@/services/study/srs';
import { placeAcrossDays } from '@/services/scheduling/engine';
import { toSched } from '@/components/cards/blocks';
import { coreFrom } from '@/services/defaults';
import { cn } from '@/utils/cn';

const base = () => { const n = Date.now(); return { description: '', estimateHours: 1, difficulty: 3, priority: 3, status: 'not_started' as StudyStatus, resources: [] as string[], notes: '', createdAt: n, updatedAt: n }; };

export function StudyScreen({ onBack }: { onBack: () => void }) {
  const { t } = useT();
  const [tab, setTab] = useState<'dash' | 'subjects' | 'cards' | 'exams'>('dash');
  return (
    <div>
      <ScreenHeader title={t('m_study')} onBack={onBack} />
      <Page>
        <Segmented value={tab} onChange={setTab} size="sm" options={[{ value: 'dash', label: t('progress') }, { value: 'subjects', label: t('subjects') }, { value: 'cards', label: t('flashcards') }, { value: 'exams', label: t('exams') }]} />
        {tab === 'dash' && <Dashboard />}
        {tab === 'subjects' && <Subjects />}
        {tab === 'cards' && <Cards />}
        {tab === 'exams' && <Exams />}
      </Page>
    </div>
  );
}

function useStudyMetrics() {
  const data = useApp((s) => s.data);
  return useMemo(() => {
    const sessions = Object.values(data.studySessions);
    const actualBy = (pred: (x: (typeof sessions)[number]) => boolean) => sessions.filter(pred).reduce((a, x) => a + x.minutes, 0) / 60;
    const lessons = Object.values(data.lessons);
    const est = lessons.reduce((a, l) => a + l.estimateHours, 0);
    const doneEst = lessons.filter((l) => l.status === 'done').reduce((a, l) => a + l.estimateHours, 0);
    const from = addDays(todayKey(), -14);
    const recentMin = sessions.filter((x) => x.date >= from).reduce((a, x) => a + x.minutes, 0);
    const perDay = recentMin / 14;
    const remainingH = Math.max(0, est - doneEst);
    const etaDays = perDay > 0 ? Math.ceil((remainingH * 60) / perDay) : null;
    return { lessons, est, doneEst, actualBy, perDay, remainingH, etaDays };
  }, [data]);
}

function Dashboard() {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const m = useStudyMetrics();
  const today = todayKey();
  const outstanding = m.lessons.filter((l) => l.status !== 'done');
  const delayed = outstanding.filter((l) => l.dueDate && l.dueDate < today);
  const targets = [...outstanding.filter((l) => l.dueDate === today), ...blocksForDate(data, today).filter((b) => data.categories[b.categoryId]?.key === 'study' && b.status === 'planned').map((b) => ({ id: b.id, title: b.title } as StudyLesson))];
  const exams = Object.values(data.exams).filter((e) => e.date >= today).sort((a, b) => a.date.localeCompare(b.date));
  return (
    <>
      <Card className="mt-4 p-4">
        <div className="flex items-end justify-between"><div><div className="text-[11px] text-ink-3">{t('progress')}</div><div className="num text-3xl font-bold">{fmtNumber(m.est ? Math.round((m.doneEst / m.est) * 100) : 0, lang)}%</div></div>
          <div className="text-end text-sm"><div>{t('est_completion')}</div><div className="font-semibold">{m.etaDays == null ? t('not_enough_data', { n: 0, m: 1 }).slice(0, 30) : fmtDate(addDays(today, m.etaDays), lang, { day: 'numeric', month: 'short' })}</div></div></div>
        <ProgressBar className="mt-3" value={m.est ? (m.doneEst / m.est) * 100 : 0} color="var(--c-study)" />
        <p className="mt-2 text-xs text-ink-3">{fmtNumber(Math.round(m.doneEst * 10) / 10, lang, 1)} / {fmtNumber(m.est, lang, 1)} {t('hours')} · {fmtDuration(m.perDay, lang)}/{t('day')}</p>
      </Card>
      <SectionTitle>{t('subjects')}</SectionTitle>
      <Card className="divide-y divide-line">{Object.values(data.subjects).map((s) => {
        const ls = m.lessons.filter((l) => l.subjectId === s.id); const tot = ls.reduce((a, l) => a + l.estimateHours, 0); const dn = ls.filter((l) => l.status === 'done').reduce((a, l) => a + l.estimateHours, 0);
        return <div key={s.id} className="p-3"><div className="mb-1 flex justify-between text-sm"><span className="font-semibold">{s.title}</span><span className="num text-ink-2">{fmtNumber(Math.round(m.actualBy((x) => x.subjectId === s.id) * 10) / 10, lang, 1)} {t('actual_hours')}</span></div><ProgressBar value={tot ? (dn / tot) * 100 : 0} color={s.color} /></div>;
      })}{!Object.keys(data.subjects).length && <p className="p-3 text-sm text-ink-3">{t('empty_generic')}</p>}</Card>
      <SectionTitle>{t('todays_targets')}</SectionTitle>
      <Card className="p-3 text-sm">{targets.length ? targets.map((l) => <div key={l.id} className="py-1">• {l.title}</div>) : <span className="text-ink-3">{t('empty_generic')}</span>}</Card>
      <div className="mt-3 grid grid-cols-2 gap-2"><Card className="p-3"><div className="text-[11px] text-ink-3">{t('outstanding')}</div><div className="num text-xl font-bold">{fmtNumber(outstanding.length, lang)}</div></Card><Card className="p-3"><div className="text-[11px] text-ink-3">{t('delayed_content')}</div><div className="num text-xl font-bold text-warning">{fmtNumber(delayed.length, lang)}</div></Card></div>
      <SectionTitle>{t('exams')}</SectionTitle>
      <Card className="divide-y divide-line">{exams.length ? exams.map((e) => <div key={e.id} className="flex justify-between p-3 text-sm"><span>{e.name}</span><Badge tone={diffDays(today, e.date) <= 7 ? 'warning' : 'neutral'}>{t('days_left', { n: fmtNumber(diffDays(today, e.date), lang) })}</Badge></div>) : <p className="p-3 text-sm text-ink-3">{t('empty_generic')}</p>}</Card>
    </>
  );
}

function Subjects() {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [openS, setOpenS] = useState<string | null>(null);
  const [edit, setEdit] = useState<{ kind: 'subject' | 'unit' | 'lesson'; item: StudySubject | StudyUnit | StudyLesson } | null>(null);
  const [log, setLog] = useState<StudyLesson | null>(null);
  const cycle = (l: StudyLesson) => useApp.getState().put('lessons', { ...l, status: l.status === 'not_started' ? 'in_progress' : l.status === 'in_progress' ? 'done' : 'not_started' });
  return (
    <>
      <div className="mt-4 flex justify-end"><Button size="sm" icon={<Plus size={15} />} onClick={() => setEdit({ kind: 'subject', item: { id: uid('sub'), title: '', color: 'var(--c-study)', ...base() } })}>{t('new_subject')}</Button></div>
      {!Object.keys(data.subjects).length && <EmptyState icon={<GraduationCap size={28} />} title={t('empty_generic')} />}
      <div className="mt-3 space-y-2">{Object.values(data.subjects).map((s) => {
        const units = Object.values(data.units).filter((u) => u.subjectId === s.id);
        const open = openS === s.id;
        return (
          <Card key={s.id} className="overflow-hidden">
            <button onClick={() => setOpenS(open ? null : s.id)} className="flex w-full items-center gap-3 p-4 text-start"><span className="h-3 w-3 rounded-full" style={{ background: s.color }} /><span className="flex-1 text-[16px] font-semibold">{s.title}</span><Badge>{fmtNumber(units.length, lang)} {t('units')}</Badge>{open ? <ChevronUp size={16} /> : <ChevronDown size={16} />}</button>
            {open && (
              <div className="border-t border-line px-3 pb-3">
                <div className="flex gap-2 py-2"><Button size="sm" variant="secondary" onClick={() => setEdit({ kind: 'subject', item: s })}>{t('edit')}</Button><Button size="sm" variant="tinted" icon={<Plus size={14} />} onClick={() => setEdit({ kind: 'unit', item: { id: uid('u'), subjectId: s.id, title: '', ...base() } })}>{t('new_unit')}</Button></div>
                {units.map((u) => (
                  <div key={u.id} className="mt-2 rounded-2xl bg-surface-2/60 p-3">
                    <div className="flex items-center justify-between"><button className="text-sm font-semibold" onClick={() => setEdit({ kind: 'unit', item: u })}>{u.title}</button><Button size="sm" variant="ghost" icon={<Plus size={14} />} onClick={() => setEdit({ kind: 'lesson', item: { id: uid('ls'), subjectId: s.id, unitId: u.id, title: '', ...base() } })}>{t('new_lesson')}</Button></div>
                    {Object.values(data.lessons).filter((l) => l.unitId === u.id).map((l) => (
                      <div key={l.id} className="flex items-center gap-2 py-1.5">
                        <button onClick={() => cycle(l)} aria-label={t('status')} className={cn('h-5 w-5 rounded-full border-2', l.status === 'done' ? 'border-success bg-success' : l.status === 'in_progress' ? 'border-accent bg-accent-soft' : 'border-line')} />
                        <button className="min-w-0 flex-1 text-start text-sm" onClick={() => setEdit({ kind: 'lesson', item: l })}><span className={l.status === 'done' ? 'text-ink-3 line-through' : ''}>{l.title}</span>
                          <span className="ms-2 text-[11px] text-ink-3">{fmtNumber(l.estimateHours, lang, 1)}h · {fmtNumber(Math.round(Object.values(data.studySessions).filter((x) => x.lessonId === l.id).reduce((a, x) => a + x.minutes, 0) / 6) / 10, lang, 1)}h{l.dueDate ? ` · ${fmtDate(l.dueDate, lang, { day: 'numeric', month: 'short' })}` : ''}</span></button>
                        <Button size="sm" variant="ghost" onClick={() => setLog(l)} aria-label={t('log_study')}><BookOpen size={14} /></Button>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </Card>
        );
      })}</div>
      {edit && <StudyItemSheet kind={edit.kind} item={edit.item} onClose={() => setEdit(null)} />}
      {log && <LogSheet lesson={log} onClose={() => setLog(null)} />}
    </>
  );
}

function StudyItemSheet({ kind, item, onClose }: { kind: 'subject' | 'unit' | 'lesson'; item: StudySubject | StudyUnit | StudyLesson; onClose: () => void }) {
  const { t } = useT();
  const data = useApp((s) => s.data);
  const [x, setX] = useState(item);
  const col = kind === 'subject' ? 'subjects' : kind === 'unit' ? 'units' : 'lessons';
  const exists = !!(data[col] as Record<string, unknown>)[x.id];
  const save = async () => { if (!x.title.trim()) return; if (await useApp.getState().put(col, { ...x, title: x.title.trim() } as never)) onClose(); };
  const remove = async () => {
    const st = useApp.getState();
    if (kind === 'subject') await st.commit({}, { subjects: [x.id], units: Object.values(data.units).filter((u) => u.subjectId === x.id).map((u) => u.id), lessons: Object.values(data.lessons).filter((l) => l.subjectId === x.id).map((l) => l.id) });
    else if (kind === 'unit') await st.commit({}, { units: [x.id], lessons: Object.values(data.lessons).filter((l) => l.unitId === x.id).map((l) => l.id) });
    else await st.remove('lessons', [x.id]);
    onClose();
  };
  return (
    <Sheet open onClose={onClose} title={t(kind === 'subject' ? 'new_subject' : kind === 'unit' ? 'new_unit' : 'new_lesson')} footer={<div className="flex gap-2">{exists && <Button variant="danger" onClick={remove} icon={<Trash2 size={15} />} />}<Button className="flex-1" disabled={!x.title.trim()} onClick={save}>{t('save')}</Button></div>}>
      <div className="space-y-4">
        <Field label={t('title')}><Input value={x.title} onChange={(e) => setX({ ...x, title: e.target.value })} autoFocus /></Field>
        <Field label={t('description')}><TextArea value={x.description} onChange={(e) => setX({ ...x, description: e.target.value })} /></Field>
        <div className="flex items-center justify-between"><span>{t('est_hours')}</span><Stepper value={x.estimateHours} onChange={(v) => setX({ ...x, estimateHours: v })} min={0} max={500} step={0.5} /></div>
        <div className="flex items-center justify-between"><span>{t('difficulty')}</span><Stepper value={x.difficulty} onChange={(v) => setX({ ...x, difficulty: v })} min={1} max={5} /></div>
        <div className="flex items-center justify-between"><span>{t('priority')}</span><Stepper value={x.priority} onChange={(v) => setX({ ...x, priority: v })} min={1} max={5} /></div>
        <Field label={t('due_date')}><Input type="date" value={x.dueDate ?? ''} onChange={(e) => setX({ ...x, dueDate: e.target.value || undefined })} /></Field>
        <Field label={t('status')}><Segmented value={x.status} onChange={(v) => setX({ ...x, status: v })} size="sm" options={[{ value: 'not_started', label: t('ss_not_started') }, { value: 'in_progress', label: t('ss_in_progress') }, { value: 'done', label: t('ss_done') }]} /></Field>
        <Field label={t('exams')}><Select value={x.examId ?? ''} onChange={(v) => setX({ ...x, examId: v || undefined })} options={[{ value: '', label: t('none') }, ...Object.values(data.exams).map((e) => ({ value: e.id, label: e.name }))]} /></Field>
        <Field label={t('resources')}><TextArea value={x.resources.join('\n')} onChange={(e) => setX({ ...x, resources: e.target.value.split('\n').map((r) => r.trim()).filter(Boolean) })} /></Field>
        <Field label={t('notes')}><TextArea value={x.notes} onChange={(e) => setX({ ...x, notes: e.target.value })} /></Field>
      </div>
    </Sheet>
  );
}

function LogSheet({ lesson, onClose }: { lesson: StudyLesson; onClose: () => void }) {
  const { t } = useT(); const [mins, setMins] = useState(30); const [note, setNote] = useState('');
  return (
    <Sheet open onClose={onClose} title={t('log_study')} footer={<Button className="w-full" onClick={async () => { const n = Date.now(); await useApp.getState().put('studySessions', { id: uid('ss'), subjectId: lesson.subjectId, unitId: lesson.unitId, lessonId: lesson.id, date: todayKey(), minutes: mins, note, createdAt: n, updatedAt: n }); if (lesson.status === 'not_started') await useApp.getState().put('lessons', { ...lesson, status: 'in_progress' }); onClose(); }}>{t('save')}</Button>}>
      <p className="mb-3 font-semibold">{lesson.title}</p>
      <div className="flex items-center justify-between"><span>{t('duration')}</span><Stepper value={mins} onChange={setMins} min={1} max={600} step={5} /></div>
      <Field label={t('notes')}><TextArea className="mt-3" value={note} onChange={(e) => setNote(e.target.value)} /></Field>
    </Sheet>
  );
}

function Cards() {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const today = todayKey();
  const [deck, setDeck] = useState<string>(Object.keys(data.decks)[0] ?? '');
  const [deckName, setDeckName] = useState(''); const [q, setQ] = useState(''); const [a, setA] = useState(''); const [tags, setTags] = useState('');
  const [reviewing, setReviewing] = useState(false); const [show, setShow] = useState(false);
  const cards = Object.values(data.flashcards).filter((c) => !deck || c.deckId === deck);
  const due = cards.filter((c) => c.dueDate <= today).sort((x, y) => x.dueDate.localeCompare(y.dueDate));
  const current = due[0];
  const grade = async (g: 0 | 1 | 2 | 3) => {
    if (!current) return;
    const r = nextReview(current, g, today, s.srsIntervals);
    const n = Date.now();
    const updated: Flashcard = { ...current, step: r.step, ease: r.ease, dueDate: r.nextDue, lapses: r.lapses, reviews: current.reviews + 1, lastReviewed: n, difficulty: g === 0 ? Math.min(5, current.difficulty + 1) : g === 3 ? Math.max(1, current.difficulty - 1) : current.difficulty };
    await useApp.getState().commit({ flashcards: [updated], reviews: [{ id: uid('rv'), cardId: current.id, deckId: current.deckId, date: today, grade: g, prevStep: current.step, nextStep: r.step, nextDue: r.nextDue, createdAt: n, updatedAt: n }] });
    setShow(false);
  };
  return (
    <>
      <div className="mt-4 -mx-4 flex gap-2 overflow-x-auto px-4 no-scrollbar">
        <Chip active={!deck} onClick={() => setDeck('')}>{t('all')}</Chip>
        {Object.values(data.decks).map((d) => <Chip key={d.id} active={deck === d.id} onClick={() => setDeck(d.id)}>{d.name} · {fmtNumber(Object.values(data.flashcards).filter((c) => c.deckId === d.id && c.dueDate <= today).length, lang)}</Chip>)}
      </div>
      <div className="mt-3 flex gap-2"><Input value={deckName} onChange={(e) => setDeckName(e.target.value)} placeholder={t('new_deck')} /><Button variant="secondary" onClick={async () => { if (!deckName.trim()) return; const n = Date.now(); const id = uid('dk'); await useApp.getState().put('decks', { id, name: deckName.trim(), createdAt: n, updatedAt: n }); setDeck(id); setDeckName(''); }}><Plus size={16} /></Button></div>
      <Card className="mt-3 p-4 text-center">
        <Layers size={22} className="mx-auto text-accent" />
        <div className="num mt-1 text-3xl font-bold">{fmtNumber(due.length, lang)}</div><div className="text-sm text-ink-2">{t('due_cards')}</div>
        <Button className="mt-3" disabled={!due.length} onClick={() => { setReviewing(true); setShow(false); }}>{t('review')}</Button>
      </Card>
      {deck && (
        <Card className="mt-3 space-y-3 p-4">
          <h3 className="font-semibold">{t('new_card')}</h3>
          <Field label={t('question')}><TextArea value={q} onChange={(e) => setQ(e.target.value)} /></Field>
          <Field label={t('answer')}><TextArea value={a} onChange={(e) => setA(e.target.value)} /></Field>
          <Field label={t('tags')}><Input value={tags} onChange={(e) => setTags(e.target.value)} /></Field>
          <Button className="w-full" disabled={!q.trim() || !a.trim()} onClick={async () => { const n = Date.now(); await useApp.getState().put('flashcards', { id: uid('fc'), deckId: deck, question: q.trim(), answer: a.trim(), tags: tags.split(/[,،]/).map((x) => x.trim()).filter(Boolean), difficulty: 3, step: -1, ease: 2.5, dueDate: today, reviews: 0, lapses: 0, createdAt: n, updatedAt: n }); setQ(''); setA(''); }}>{t('add')}</Button>
        </Card>
      )}
      <SectionTitle>{t('flashcards')} · {fmtNumber(cards.length, lang)}</SectionTitle>
      <Card className="divide-y divide-line">{cards.slice(0, 50).map((c) => <div key={c.id} className="flex items-center justify-between gap-2 p-3 text-sm"><span className="truncate">{c.question}</span><span className="flex items-center gap-1"><Badge>{t('next_review')}: {fmtDate(c.dueDate, lang, { day: 'numeric', month: 'short' })}</Badge><button aria-label={t('delete')} onClick={() => useApp.getState().remove('flashcards', [c.id])}><Trash2 size={14} className="text-ink-3" /></button></span></div>)}</Card>
      <Sheet open={reviewing} onClose={() => setReviewing(false)} title={`${t('review')} · ${fmtNumber(due.length, lang)}`}>
        {current ? (
          <div className="text-center">
            <Card className="min-h-40 p-6 text-[19px] font-semibold leading-relaxed">{current.question}</Card>
            {show ? <>
              <Card className="mt-3 p-5 text-[17px] leading-relaxed">{current.answer}</Card>
              <div className="mt-4 grid grid-cols-4 gap-2">{([0, 1, 2, 3] as const).map((g) => <Button key={g} variant={g === 0 ? 'danger' : g === 3 ? 'primary' : 'secondary'} onClick={() => grade(g)}>{t((['g_again', 'g_hard', 'g_good', 'g_easy'] as const)[g])}</Button>)}</div>
            </> : <Button className="mt-4 w-full" onClick={() => setShow(true)}>{t('show_answer')}</Button>}
          </div>
        ) : <EmptyState icon={<Layers size={26} />} title={t('review_done')} />}
      </Sheet>
    </>
  );
}

function Exams() {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [edit, setEdit] = useState<Exam | null>(null);
  const today = todayKey();
  const create = () => { const n = Date.now(); setEdit({ id: uid('ex'), name: '', date: addDays(today, 14), timeMin: 9 * 60, location: '', topics: [], prepProgress: 0, studyMinutesPerDay: 90, createdAt: n, updatedAt: n }); };
  const plan = (e: Exam) => {
    const lessons = Object.values(data.lessons).filter((l) => (l.examId === e.id || (e.subjectId && l.subjectId === e.subjectId)) && l.status !== 'done');
    const neededMin = Math.round(lessons.reduce((a, l) => a + l.estimateHours, 0) * 60 * (1 - e.prepProgress / 100)) || Math.round(e.studyMinutesPerDay * Math.max(1, diffDays(today, e.date)) * (1 - e.prepProgress / 100));
    const days = Math.max(0, diffDays(today, e.date));
    const avail = Array.from({ length: days }, (_, i) => addDays(today, i)).map((d) => ({ date: d, items: blocksForDate(data, d).map(toSched), fromMin: d === today ? Math.ceil(nowMinutes() / 5) * 5 : s.dayStartMin }));
    const reqs = Array.from({ length: days }, (_, i) => ({ refId: `${e.id}:${i}`, title: e.name, durationMin: Math.min(e.studyMinutesPerDay, Math.ceil(neededMin / Math.max(1, days))), priority: 4, difficulty: 4, deadline: addDays(today, i), splitAllowed: true, minSplitMin: 25 }));
    const res = placeAcrossDays(reqs, avail.map((d, i) => ({ ...d, fromMin: d.fromMin + 0 * i })), { dayStartMin: s.dayStartMin, dayEndMin: s.dayEndMin, productiveStartMin: s.productiveStartMin, productiveEndMin: s.productiveEndMin, bufferMin: s.defaultBufferMin });
    const placed = res.placements.reduce((a, p) => a + p.durationMin, 0);
    return { neededMin, placed, placements: res.placements };
  };
  return (
    <>
      <div className="mt-4 flex justify-end"><Button size="sm" icon={<Plus size={15} />} onClick={create}>{t('new_exam')}</Button></div>
      <div className="mt-3 space-y-2">{Object.values(data.exams).sort((a, b) => a.date.localeCompare(b.date)).map((e) => {
        const p = plan(e);
        return (
          <Card key={e.id} className="p-4">
            <div className="flex items-start justify-between"><button className="text-start" onClick={() => setEdit(e)}><div className="text-[16px] font-semibold">{e.name}</div><div className="text-xs text-ink-3">{fmtDate(e.date, lang)} · {e.location}</div></button><Badge tone={diffDays(today, e.date) <= 7 ? 'warning' : 'accent'}>{t('days_left', { n: fmtNumber(Math.max(0, diffDays(today, e.date)), lang) })}</Badge></div>
            <div className="mt-3 text-sm"><div className="mb-1 flex justify-between"><span>{t('prep_progress')}</span><span className="num">{fmtNumber(e.prepProgress, lang)}%</span></div><ProgressBar value={e.prepProgress} /></div>
            <p className="mt-3 text-xs text-ink-2">{t('revision_plan')}: {t('revision_needed', { h: fmtNumber(Math.round(p.neededMin / 6) / 10, lang, 1), a: fmtNumber(Math.round(p.placed / 6) / 10, lang, 1) })}</p>
            <Button size="sm" variant="tinted" className="mt-2" icon={<CalendarPlus size={14} />} disabled={!p.placements.length || e.date < today} onClick={async () => {
              const blocks = p.placements.map((pl) => instantiate(coreFrom({ title: `${t('review')}: ${e.name}`, categoryId: 'cat_study', startMin: pl.startMin, durationMin: pl.durationMin, subjectId: e.subjectId, priority: 4, difficulty: 4, splitAllowed: true }), pl.date, { source: 'task' }));
              if (await useApp.getState().commit({ activities: blocks })) useApp.getState().toast('success', t('task_scheduled', { n: blocks.length }));
            }}>{t('create_revision')}</Button>
          </Card>
        );
      })}</div>
      {edit && (
        <Sheet open onClose={() => setEdit(null)} title={edit.name || t('new_exam')} footer={<div className="flex gap-2">{data.exams[edit.id] && <Button variant="danger" onClick={async () => { await useApp.getState().remove('exams', [edit.id]); setEdit(null); }}>{t('delete')}</Button>}<Button className="flex-1" disabled={!edit.name.trim()} onClick={async () => { await useApp.getState().put('exams', edit); setEdit(null); }}>{t('save')}</Button></div>}>
          <div className="space-y-4">
            <Field label={t('name')}><Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label={t('subjects')}><Select value={edit.subjectId ?? ''} onChange={(v) => setEdit({ ...edit, subjectId: v || undefined })} options={[{ value: '', label: t('none') }, ...Object.values(data.subjects).map((x) => ({ value: x.id, label: x.title }))]} /></Field>
            <div className="grid grid-cols-2 gap-3"><Field label={t('date')}><Input type="date" value={edit.date} onChange={(e) => setEdit({ ...edit, date: e.target.value })} /></Field><Field label={t('time')}><Input type="time" value={minToInput(edit.timeMin)} onChange={(e) => setEdit({ ...edit, timeMin: inputToMin(e.target.value) })} /></Field></div>
            <Field label={t('location')}><Input value={edit.location} onChange={(e) => setEdit({ ...edit, location: e.target.value })} /></Field>
            <Field label={t('topics')}><TextArea value={edit.topics.join('\n')} onChange={(e) => setEdit({ ...edit, topics: e.target.value.split('\n').filter(Boolean) })} /></Field>
            <div className="flex items-center justify-between"><span>{t('prep_progress')}</span><Stepper value={edit.prepProgress} onChange={(v) => setEdit({ ...edit, prepProgress: v })} min={0} max={100} step={5} suffix="%" /></div>
            <div className="flex items-center justify-between"><span>{t('study_time')} / {t('day')}</span><Stepper value={edit.studyMinutesPerDay} onChange={(v) => setEdit({ ...edit, studyMinutesPerDay: v })} min={15} max={600} step={15} /></div>
          </div>
        </Sheet>
      )}
    </>
  );
}
