import { useMemo, useState } from 'react';
import { Droplets, Plus, Moon, Utensils, Target, Star, Search, Trash2, X, NotebookPen } from 'lucide-react';
import { useApp, instantiate } from '@/stores/appStore';
import { Badge, Button, Card, Chip, EmptyState, Field, Input, Page, ProgressBar, ProgressRing, ScreenHeader, SectionTitle, Segmented, Select, Sheet, Stepper, TextArea, Toggle, useHaptic, useSettings, useT } from '@/components/common/ui';
import { BarChart } from '@/components/charts/Charts';
import type { Goal, PersonalNote, MealLog } from '@/models/types';
import { addDays, epochOf, fmtClock, fmtDate, fmtDuration, fmtNumber, inputToMin, minToInput, rangeKeys, todayKey, weekdayName } from '@/utils/date';
import { uid } from '@/utils/id';
import { coreFrom } from '@/services/defaults';
import { habitStats } from '@/services/analytics/stats';
import { cn } from '@/utils/cn';

export function WellnessScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const data = useApp((st) => st.data);
  const [tab, setTab] = useState<'water' | 'meals' | 'sleep'>('water');
  const [custom, setCustom] = useState(200);
  const [meal, setMeal] = useState<MealLog | null>(null);
  const today = todayKey();
  const week = rangeKeys(addDays(today, -6), 7);
  const water = Object.values(data.waterLogs);
  const todayWater = water.filter((w) => w.date === today);
  const total = todayWater.reduce((a, w) => a + w.ml, 0);
  const add = async (ml: number) => { h(10); const n = Date.now(); await useApp.getState().put('waterLogs', { id: uid('w'), date: today, ml, at: n, createdAt: n, updatedAt: n }); };
  const upd = (p: Partial<typeof s.water>) => useApp.getState().updateSettings({ water: { ...s.water, ...p } });
  const updSleep = (p: Partial<typeof s.sleep>) => useApp.getState().updateSettings({ sleep: { ...s.sleep, ...p } });
  const sleepLogs = Object.values(data.sleepLogs).sort((a, b) => a.date.localeCompare(b.date));
  const [bed, setBed] = useState(minToInput(s.sleep.bedtimeMin)); const [wake, setWake] = useState(minToInput(s.sleep.wakeMin)); const [quality, setQuality] = useState(3);
  const hasWorkout = Object.values(data.activities).some((b) => b.date === today && data.categories[b.categoryId]?.key === 'exercise' && b.status !== 'cancelled');
  const target = s.water.targetMl;

  return (
    <div>
      <ScreenHeader title={t('m_wellness')} onBack={onBack} />
      <Page>
        <Segmented value={tab} onChange={setTab} options={[{ value: 'water', label: t('water') }, { value: 'meals', label: t('meals') }, { value: 'sleep', label: t('sleep') }]} />
        {tab === 'water' && <>
          <Card className="mt-4 flex flex-col items-center p-6">
            <ProgressRing value={(total / Math.max(1, target)) * 100} size={170} stroke={12} color="var(--c-water)"><div className="text-center"><Droplets className="mx-auto text-water" size={22} /><div className="num text-2xl font-bold">{fmtNumber(total, lang)}</div><div className="text-xs text-ink-3">/ {fmtNumber(target, lang)} {t('ml')}</div></div></ProgressRing>
            {hasWorkout && s.water.workoutBonusMl > 0 && <p className="mt-2 text-xs text-info">{t('rv_water', { m: fmtNumber(s.water.workoutBonusMl, lang) })}</p>}
            <div className="mt-4 flex flex-wrap justify-center gap-2">{s.water.cupSizes.map((c) => <Button key={c} variant="secondary" onClick={() => add(c)}>+{fmtNumber(c, lang)}</Button>)}</div>
            <div className="mt-3 flex items-center gap-2"><Stepper value={custom} onChange={setCustom} min={10} max={2000} step={10} suffix={t('ml')} /><Button variant="tinted" onClick={() => add(custom)}>{t('add')}</Button></div>
          </Card>
          <SectionTitle>{t('history')}</SectionTitle>
          <Card className="p-4"><BarChart labels={week.map((d) => weekdayName(new Date(d + 'T12:00').getDay(), lang, 'narrow'))} series={[{ name: t('water'), color: 'var(--c-water)', values: week.map((d) => water.filter((w) => w.date === d).reduce((a, w) => a + w.ml, 0)) }]} /></Card>
          <Card className="mt-2 divide-y divide-line">{todayWater.sort((a, b) => b.at - a.at).map((w) => <div key={w.id} className="flex items-center justify-between p-3 text-sm"><span className="num">{fmtClock(w.at, lang, s.clock24)}</span><span className="flex items-center gap-2">{fmtNumber(w.ml, lang)} {t('ml')}<button aria-label={t('delete')} onClick={() => useApp.getState().remove('waterLogs', [w.id])}><X size={14} /></button></span></div>)}</Card>
          <SectionTitle>{t('m_settings')}</SectionTitle>
          <Card className="space-y-3 p-4">
            <div className="flex items-center justify-between"><span>{t('daily_target')}</span><Stepper value={s.water.targetMl} onChange={(v) => upd({ targetMl: v })} min={250} max={8000} step={250} /></div>
            <Field label={t('custom_amount')}><Input value={s.water.cupSizes.join(', ')} onChange={(e) => { const arr = e.target.value.split(/[,،\s]+/).map(Number).filter((n) => n > 0 && n <= 3000); if (arr.length) upd({ cupSizes: arr.slice(0, 6) }); }} /></Field>
            <div className="flex items-center justify-between"><span>{t('ru_water_on_active_days')}</span><Stepper value={s.water.workoutBonusMl} onChange={(v) => upd({ workoutBonusMl: v })} min={0} max={2000} step={100} /></div>
            <Toggle checked={s.water.reminderEnabled} onChange={(v) => upd({ reminderEnabled: v })} label={t('reminders')} />
            {s.water.reminderEnabled && <>
              <div className="flex items-center justify-between"><span>{t('repeat_every')}</span><Stepper value={s.water.intervalMin} onChange={(v) => upd({ intervalMin: v })} min={15} max={360} step={15} /></div>
              <div className="grid grid-cols-2 gap-3"><Field label={t('from')}><Input type="time" value={minToInput(s.water.wakeStartMin)} onChange={(e) => upd({ wakeStartMin: inputToMin(e.target.value) })} /></Field><Field label={t('to')}><Input type="time" value={minToInput(s.water.wakeEndMin)} onChange={(e) => upd({ wakeEndMin: inputToMin(e.target.value) })} /></Field></div>
            </>}
          </Card>
        </>}

        {tab === 'meals' && <>
          <div className="mt-4 flex justify-between"><p className="text-xs text-ink-3">{t('nutrition_optional')}</p><Button size="sm" icon={<Plus size={15} />} onClick={() => { const n = Date.now(); setMeal({ id: uid('ml'), date: today, name: '', notes: '', plannedMin: 13 * 60, createdAt: n, updatedAt: n }); }}>{t('new_meal')}</Button></div>
          <Card className="mt-3 divide-y divide-line">{Object.values(data.mealLogs).filter((m) => m.date === today).map((m) => (
            <button key={m.id} onClick={() => setMeal(m)} className="flex w-full items-center gap-3 p-3 text-start"><Utensils size={18} className="text-meal" /><div className="flex-1"><div className="font-medium">{m.name}</div><div className="num text-xs text-ink-3">{m.plannedMin != null ? minToInput(m.plannedMin) : ''}{m.actualAt ? ` · ✓ ${fmtClock(m.actualAt, lang, s.clock24)}` : ''}{m.kcal ? ` · ${m.kcal} ${t('kcal')}` : ''}</div></div>
              {!m.actualAt && <Button size="sm" variant="tinted" onClick={(e) => { e.stopPropagation(); useApp.getState().put('mealLogs', { ...m, actualAt: Date.now() }); }}>{t('done')}</Button>}</button>
          ))}{!Object.values(data.mealLogs).some((m) => m.date === today) && <p className="p-3 text-sm text-ink-3">{t('empty_generic')}</p>}</Card>
        </>}

        {tab === 'sleep' && <>
          <Card className="mt-4 space-y-3 p-4">
            <div className="grid grid-cols-2 gap-3"><Field label={t('bedtime')}><Input type="time" value={minToInput(s.sleep.bedtimeMin)} onChange={(e) => updSleep({ bedtimeMin: inputToMin(e.target.value) })} /></Field><Field label={t('wake_time')}><Input type="time" value={minToInput(s.sleep.wakeMin)} onChange={(e) => updSleep({ wakeMin: inputToMin(e.target.value) })} /></Field></div>
            <Toggle checked={s.sleep.prepReminderEnabled} onChange={(v) => updSleep({ prepReminderEnabled: v })} label={t('n_sleep_prep')} description={t('n_sleep_body', { m: s.sleep.prepReminderMin })} />
            {s.sleep.prepReminderEnabled && <div className="flex items-center justify-between"><span>{t('minutes')}</span><Stepper value={s.sleep.prepReminderMin} onChange={(v) => updSleep({ prepReminderMin: v })} min={5} max={180} step={5} /></div>}
            <Toggle checked={s.sleep.wakeReminder} onChange={(v) => updSleep({ wakeReminder: v })} label={t('n_wake')} />
            <Button variant="secondary" className="w-full" icon={<Moon size={15} />} onClick={async () => {
              const b = instantiate(coreFrom({ title: t('sleep'), categoryId: 'cat_sleep', startMin: s.sleep.bedtimeMin, durationMin: ((s.sleep.wakeMin - s.sleep.bedtimeMin + 1440) % 1440) || 480, fixed: true }), today, { source: 'manual' });
              b.reminder.enabled = false;
              if (await useApp.getState().commit({ activities: [b] })) useApp.getState().toast('success', t('saved'));
            }}>{t('create_sleep_blocks')}</Button>
          </Card>
          <SectionTitle>{t('log_sleep')}</SectionTitle>
          <Card className="space-y-3 p-4">
            <div className="grid grid-cols-2 gap-3"><Field label={t('slept')}><Input type="time" value={bed} onChange={(e) => setBed(e.target.value)} /></Field><Field label={t('woke')}><Input type="time" value={wake} onChange={(e) => setWake(e.target.value)} /></Field></div>
            <div className="flex items-center justify-between"><span>{t('quality')}</span><Stepper value={quality} onChange={setQuality} min={1} max={5} /></div>
            <Button className="w-full" onClick={async () => {
              const bm = inputToMin(bed), wm = inputToMin(wake);
              const bedAt = epochOf(bm > wm ? addDays(today, -1) : today, bm), wakeAt = epochOf(today, wm);
              const n = Date.now();
              await useApp.getState().put('sleepLogs', { id: today, date: today, bedAt, wakeAt, quality, note: '', createdAt: n, updatedAt: n });
              useApp.getState().toast('success', t('saved'));
            }}>{t('save')}</Button>
            <p className="text-xs text-ink-3">{t('sleep_disclaimer')}</p>
          </Card>
          <SectionTitle>{t('sleep_consistency')}</SectionTitle>
          <Card className="p-4">
            <BarChart labels={week.map((d) => weekdayName(new Date(d + 'T12:00').getDay(), lang, 'narrow'))} series={[{ name: t('sleep'), color: 'var(--c-sleep)', values: week.map((d) => { const l = sleepLogs.find((x) => x.date === d); return l ? Math.round((l.wakeAt - l.bedAt) / 60000) : 0; }) }]} />
            {(() => { const last = sleepLogs.filter((l) => l.date >= addDays(today, -6)); if (last.length < 2) return null; const beds = last.map((l) => { const m = new Date(l.bedAt).getHours() * 60 + new Date(l.bedAt).getMinutes(); return m < 720 ? m + 1440 : m; }); const avg = beds.reduce((a, b) => a + b, 0) / beds.length; const dev = Math.sqrt(beds.reduce((a, b) => a + (b - avg) ** 2, 0) / beds.length); const dur = last.reduce((a, l) => a + (l.wakeAt - l.bedAt) / 60000, 0) / last.length; return <p className="mt-2 text-sm text-ink-2">{t('average')}: {fmtDuration(dur, lang)} · ±{fmtDuration(dev, lang)}</p>; })()}
          </Card>
        </>}
      </Page>
      {meal && (
        <Sheet open onClose={() => setMeal(null)} title={meal.name || t('new_meal')} footer={<div className="flex gap-2">{data.mealLogs[meal.id] && <Button variant="danger" onClick={async () => { await useApp.getState().remove('mealLogs', [meal.id]); setMeal(null); }} icon={<Trash2 size={15} />} />}<Button className="flex-1" disabled={!meal.name.trim()} onClick={async () => { await useApp.getState().put('mealLogs', meal); setMeal(null); }}>{t('save')}</Button></div>}>
          <div className="space-y-4">
            <Field label={t('name')}><Input value={meal.name} onChange={(e) => setMeal({ ...meal, name: e.target.value })} autoFocus /></Field>
            <Field label={t('time')}><Input type="time" value={meal.plannedMin != null ? minToInput(meal.plannedMin) : ''} onChange={(e) => setMeal({ ...meal, plannedMin: e.target.value ? inputToMin(e.target.value) : undefined })} /></Field>
            <div className="grid grid-cols-2 gap-3">{(['kcal', 'protein', 'carbs', 'fat'] as const).map((k) => <Field key={k} label={`${k} (${t('optional')})`}><Input inputMode="numeric" value={meal[k] ?? ''} onChange={(e) => setMeal({ ...meal, [k]: e.target.value ? Number(e.target.value) || undefined : undefined })} /></Field>)}</div>
            <Field label={t('notes')}><TextArea value={meal.notes} onChange={(e) => setMeal({ ...meal, notes: e.target.value })} /></Field>
            <Button variant="secondary" className="w-full" disabled={!meal.name.trim() || meal.plannedMin == null} onClick={async () => { const b = instantiate(coreFrom({ title: meal.name, categoryId: 'cat_meal', startMin: meal.plannedMin!, durationMin: 30 }), meal.date); await useApp.getState().commit({ activities: [b], mealLogs: [meal] }); setMeal(null); }}>{t('add_activity')} + {t('reminders')}</Button>
          </div>
        </Sheet>
      )}
    </div>
  );
}

// ======================================================================== goals

export function GoalsScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [edit, setEdit] = useState<Goal | null>(null);
  const [ms, setMs] = useState('');
  const progressOf = (g: Goal): number => {
    if (g.metric === 'manual') return g.targetValue ? Math.min(100, Math.round((g.manualValue / g.targetValue) * 100)) : 0;
    if (g.metric === 'tasks') {
      const tasks = Object.values(data.tasks).filter((x) => x.goalId === g.id || (x.projectId && data.projects[x.projectId]?.goalId === g.id));
      const mss = Object.values(data.goalMilestones).filter((m) => m.goalId === g.id);
      const tot = tasks.length + mss.length; return tot ? Math.round(((tasks.filter((x) => x.status === 'done').length + mss.filter((m) => m.done).length) / tot) * 100) : 0;
    }
    if (g.metric === 'habits') { const rates = g.habitIds.map((id) => data.habits[id]).filter(Boolean).map((h) => habitStats(h, Object.values(data.habitLogs), s.weekStart).rate ?? 0); return rates.length ? Math.round(rates.reduce((a, b) => a + b, 0) / rates.length) : 0; }
    const ls = Object.values(data.lessons).filter((l) => g.subjectIds.includes(l.subjectId)); const tot = ls.reduce((a, l) => a + l.estimateHours, 0);
    return tot ? Math.round((ls.filter((l) => l.status === 'done').reduce((a, l) => a + l.estimateHours, 0) / tot) * 100) : 0;
  };
  const create = () => { const n = Date.now(); setEdit({ id: uid('g'), title: '', description: '', horizon: 'monthly', metric: 'tasks', targetValue: 100, manualValue: 0, unit: '', habitIds: [], subjectIds: [], reviews: [], archived: false, createdAt: n, updatedAt: n }); };
  return (
    <div>
      <ScreenHeader title={t('m_goals')} onBack={onBack} actions={<Button size="sm" icon={<Plus size={15} />} onClick={create}>{t('new_goal')}</Button>} />
      <Page>
        {!Object.keys(data.goals).length && <EmptyState icon={<Target size={28} />} title={t('empty_generic')} action={<Button onClick={create}>{t('new_goal')}</Button>} />}
        {(['short', 'monthly', 'long'] as const).map((hz) => { const gs = Object.values(data.goals).filter((g) => g.horizon === hz && !g.archived); return gs.length ? (
          <div key={hz}><SectionTitle>{t(`gh_${hz}` as 'gh_short')}</SectionTitle><div className="space-y-2">{gs.map((g) => { const p = progressOf(g); const linked = Object.values(data.tasks).filter((x) => x.goalId === g.id).length + Object.values(data.projects).filter((x) => x.goalId === g.id).length; return (
            <Card key={g.id} className="flex items-center gap-4 p-4" onClick={() => setEdit(g)}><ProgressRing value={p} size={54} stroke={6}><span className="num text-xs font-bold">{fmtNumber(p, lang)}%</span></ProgressRing><div className="min-w-0 flex-1"><div className="text-[16px] font-semibold">{g.title}</div><div className="text-xs text-ink-3">{t(`gm_${g.metric}` as 'gm_tasks')} · {t('linked_work')}: {fmtNumber(linked, lang)}{g.targetDate ? ` · ${fmtDate(g.targetDate, lang, { day: 'numeric', month: 'short' })}` : ''}</div></div></Card>
          ); })}</div></div>) : null; })}
      </Page>
      {edit && (
        <Sheet open onClose={() => setEdit(null)} tall title={edit.title || t('new_goal')} footer={<div className="flex gap-2">{data.goals[edit.id] && <Button variant="danger" onClick={async () => { await useApp.getState().remove('goals', [edit.id]); setEdit(null); }} icon={<Trash2 size={15} />} />}<Button className="flex-1" disabled={!edit.title.trim()} onClick={async () => { await useApp.getState().put('goals', edit); setEdit(null); }}>{t('save')}</Button></div>}>
          <div className="space-y-4">
            <Field label={t('title')}><Input value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} /></Field>
            <Field label={t('description')}><TextArea value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
            <Field label={t('horizon')}><Segmented value={edit.horizon} onChange={(v) => setEdit({ ...edit, horizon: v })} size="sm" options={[{ value: 'short', label: t('gh_short') }, { value: 'monthly', label: t('gh_monthly') }, { value: 'long', label: t('gh_long') }]} /></Field>
            <Field label={t('target_date')}><Input type="date" value={edit.targetDate ?? ''} onChange={(e) => setEdit({ ...edit, targetDate: e.target.value || undefined })} /></Field>
            <Field label={t('measure')}><Select value={edit.metric} onChange={(v) => setEdit({ ...edit, metric: v as Goal['metric'] })} options={(['tasks', 'manual', 'habits', 'study'] as const).map((m) => ({ value: m, label: t(`gm_${m}` as 'gm_tasks') }))} /></Field>
            {edit.metric === 'manual' && <div className="grid grid-cols-3 gap-2"><Field label={t('value')}><Stepper value={edit.manualValue} onChange={(v) => setEdit({ ...edit, manualValue: v })} max={1e6} /></Field><Field label={t('target')}><Input inputMode="numeric" value={edit.targetValue} onChange={(e) => setEdit({ ...edit, targetValue: Number(e.target.value) || 0 })} /></Field><Field label={t('unit')}><Input value={edit.unit} onChange={(e) => setEdit({ ...edit, unit: e.target.value })} /></Field></div>}
            {edit.metric === 'habits' && <div className="flex flex-wrap gap-2">{Object.values(data.habits).map((h) => <Chip key={h.id} active={edit.habitIds.includes(h.id)} onClick={() => setEdit({ ...edit, habitIds: edit.habitIds.includes(h.id) ? edit.habitIds.filter((x) => x !== h.id) : [...edit.habitIds, h.id] })}>{h.name}</Chip>)}</div>}
            {edit.metric === 'study' && <div className="flex flex-wrap gap-2">{Object.values(data.subjects).map((x) => <Chip key={x.id} active={edit.subjectIds.includes(x.id)} onClick={() => setEdit({ ...edit, subjectIds: edit.subjectIds.includes(x.id) ? edit.subjectIds.filter((y) => y !== x.id) : [...edit.subjectIds, x.id] })}>{x.title}</Chip>)}</div>}
            {data.goals[edit.id] && <>
              <SectionTitle>{t('milestones')}</SectionTitle>
              <Card className="divide-y divide-line">{Object.values(data.goalMilestones).filter((m) => m.goalId === edit.id).map((m) => <div key={m.id} className="flex items-center gap-2 p-2.5"><input type="checkbox" className="h-5 w-5 accent-[var(--accent)]" checked={m.done} onChange={() => useApp.getState().put('goalMilestones', { ...m, done: !m.done })} /><span className={cn('flex-1 text-sm', m.done && 'line-through text-ink-3')}>{m.title}</span></div>)}
                <div className="flex gap-2 p-2"><Input value={ms} onChange={(e) => setMs(e.target.value)} placeholder={t('add_item')} /><Button variant="secondary" onClick={async () => { if (ms.trim()) { const n = Date.now(); await useApp.getState().put('goalMilestones', { id: uid('gm'), goalId: edit.id, title: ms.trim(), done: false, createdAt: n, updatedAt: n }); setMs(''); } }}><Plus size={16} /></Button></div></Card>
              <SectionTitle>{t('related_tasks')}</SectionTitle>
              <Card className="p-3 text-sm">{Object.values(data.tasks).filter((x) => x.goalId === edit.id).map((x) => <div key={x.id} className="py-0.5">{x.status === 'done' ? '✓' : '○'} {x.title}</div>)}{Object.values(data.projects).filter((p) => p.goalId === edit.id).map((p) => <div key={p.id} className="py-0.5">▣ {p.title}</div>)}</Card>
              <SectionTitle>{t('history')}</SectionTitle>
              <Button size="sm" variant="secondary" onClick={() => setEdit({ ...edit, reviews: [...edit.reviews, { at: Date.now(), note: '', value: progressOf(edit) }] })}>{t('add_review')}</Button>
              {edit.reviews.map((r, i) => <div key={i} className="flex gap-2"><Badge>{fmtDate(new Date(r.at).toISOString().slice(0, 10), lang, { day: 'numeric', month: 'short' })} · {r.value}%</Badge><Input value={r.note} onChange={(e) => setEdit({ ...edit, reviews: edit.reviews.map((x, j) => j === i ? { ...x, note: e.target.value } : x) })} /></div>)}
              <ProgressBar value={progressOf(edit)} />
            </>}
          </div>
        </Sheet>
      )}
    </div>
  );
}

// ======================================================================== notes

function renderRich(md: string) {
  const esc = (s: string) => s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]!));
  return md.split('\n').map((line) => {
    let l = esc(line).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>');
    if (l.startsWith('# ')) return `<h3 class="text-lg font-bold mt-2">${l.slice(2)}</h3>`;
    if (l.startsWith('- ')) l = `• ${l.slice(2)}`;
    return `<p>${l || '&nbsp;'}</p>`;
  }).join('');
}

export function NotesScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const data = useApp((st) => st.data);
  const [q, setQ] = useState(''); const [kind, setKind] = useState<'all' | PersonalNote['kind'] | 'fav'>('all');
  const [edit, setEdit] = useState<PersonalNote | null>(null); const [preview, setPreview] = useState(false); const [item, setItem] = useState('');
  const notes = useMemo(() => Object.values(data.notes).filter((n) => (kind === 'all' || (kind === 'fav' ? n.favorite : n.kind === kind)) && (!q || `${n.title} ${n.body} ${n.tags.join(' ')}`.toLowerCase().includes(q.toLowerCase()))).sort((a, b) => b.updatedAt - a.updatedAt), [data.notes, q, kind]);
  const create = (k: PersonalNote['kind'] = 'quick') => { const n = Date.now(); setEdit({ id: uid('n'), title: k === 'journal' ? fmtDate(todayKey(), lang) : '', body: '', kind: k, checklist: [], tags: [], favorite: false, linkedNoteIds: [], date: todayKey(), createdAt: n, updatedAt: n }); setPreview(false); };
  return (
    <div>
      <ScreenHeader title={t('m_notes')} onBack={onBack} actions={<Button size="sm" icon={<Plus size={15} />} onClick={() => create()}>{t('new_note')}</Button>} />
      <Page>
        <div className="flex items-center gap-2 rounded-xl bg-surface-2 px-3"><Search size={16} className="text-ink-3" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('search')} className="h-11 flex-1 bg-transparent outline-none" /></div>
        <div className="-mx-4 mt-3 flex gap-2 overflow-x-auto px-4 no-scrollbar">
          <Chip active={kind === 'all'} onClick={() => setKind('all')}>{t('all')}</Chip><Chip active={kind === 'fav'} onClick={() => setKind('fav')}><Star size={12} />{t('favorites')}</Chip>
          {(['quick', 'rich', 'checklist', 'study', 'meeting', 'journal'] as const).map((k) => <Chip key={k} active={kind === k} onClick={() => setKind(k)}>{t(`nk_${k}` as 'nk_quick')}</Chip>)}
        </div>
        {!notes.length ? <EmptyState icon={<NotebookPen size={28} />} title={t('empty_generic')} action={<div className="flex gap-2"><Button onClick={() => create()}>{t('new_note')}</Button><Button variant="secondary" onClick={() => create('journal')}>{t('nk_journal')}</Button></div>} /> : (
          <div className="mt-3 grid grid-cols-2 gap-2">{notes.map((n) => (
            <Card key={n.id} className="p-3" onClick={() => { setEdit(n); setPreview(n.kind === 'rich'); }}>
              <div className="flex items-start justify-between gap-1"><span className="line-clamp-1 font-semibold">{n.title || '—'}</span>{n.favorite && <Star size={13} className="fill-warning text-warning" />}</div>
              <p className="mt-1 line-clamp-4 text-xs text-ink-2">{n.kind === 'checklist' ? n.checklist.map((c) => `${c.done ? '✓' : '○'} ${c.title}`).join('\n') : n.body}</p>
              <div className="mt-2"><Badge>{t(`nk_${n.kind}` as 'nk_quick')}</Badge></div>
            </Card>
          ))}</div>
        )}
      </Page>
      {edit && (
        <Sheet open onClose={() => setEdit(null)} tall title={t(`nk_${edit.kind}` as 'nk_quick')} footer={<div className="flex gap-2">{data.notes[edit.id] && <Button variant="danger" onClick={async () => { await useApp.getState().remove('notes', [edit.id]); setEdit(null); }} icon={<Trash2 size={15} />} />}<Button className="flex-1" disabled={!edit.title.trim() && !edit.body.trim() && !edit.checklist.length} onClick={async () => { await useApp.getState().put('notes', edit); setEdit(null); }}>{t('save')}</Button></div>}>
          <div className="space-y-3">
            <div className="flex gap-2"><Input value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} placeholder={t('title')} /><Button variant={edit.favorite ? 'tinted' : 'secondary'} onClick={() => setEdit({ ...edit, favorite: !edit.favorite })} aria-label={t('favorites')}><Star size={16} /></Button></div>
            <Select value={edit.kind} onChange={(v) => setEdit({ ...edit, kind: v as PersonalNote['kind'] })} options={(['quick', 'rich', 'checklist', 'study', 'meeting', 'journal'] as const).map((k) => ({ value: k, label: t(`nk_${k}` as 'nk_quick') }))} />
            {edit.kind === 'checklist' ? (<>
              {edit.checklist.map((c) => <div key={c.id} className="flex items-center gap-2"><input type="checkbox" className="h-5 w-5 accent-[var(--accent)]" checked={c.done} onChange={() => setEdit({ ...edit, checklist: edit.checklist.map((x) => x.id === c.id ? { ...x, done: !x.done } : x) })} /><span className={cn('flex-1 text-sm', c.done && 'line-through text-ink-3')}>{c.title}</span><button onClick={() => setEdit({ ...edit, checklist: edit.checklist.filter((x) => x.id !== c.id) })}><X size={14} /></button></div>)}
              <div className="flex gap-2"><Input value={item} onChange={(e) => setItem(e.target.value)} placeholder={t('add_item')} onKeyDown={(e) => { if (e.key === 'Enter' && item.trim()) { setEdit({ ...edit, checklist: [...edit.checklist, { id: uid(), title: item.trim(), done: false }] }); setItem(''); } }} /><Button variant="secondary" onClick={() => { if (item.trim()) { setEdit({ ...edit, checklist: [...edit.checklist, { id: uid(), title: item.trim(), done: false }] }); setItem(''); } }}><Plus size={16} /></Button></div>
            </>) : (<>
              {edit.kind === 'rich' && <Segmented size="sm" value={preview ? 'p' : 'e'} onChange={(v) => setPreview(v === 'p')} options={[{ value: 'e', label: t('edit') }, { value: 'p', label: t('preview') }]} />}
              {preview ? <div className="card min-h-40 p-4 text-[15px] leading-relaxed" dangerouslySetInnerHTML={{ __html: renderRich(edit.body) }} /> : <TextArea className="min-h-[220px]" value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} />}
              {edit.kind === 'rich' && <p className="text-xs text-ink-3">{t('rich_hint')}</p>}
            </>)}
            <Field label={t('tags')}><Input value={edit.tags.join(', ')} onChange={(e) => setEdit({ ...edit, tags: e.target.value.split(/[,،]/).map((x) => x.trim()).filter(Boolean) })} /></Field>
            <Field label={t('linked_project')}><Select value={edit.projectId ?? ''} onChange={(v) => setEdit({ ...edit, projectId: v || undefined })} options={[{ value: '', label: t('none') }, ...Object.values(data.projects).map((p) => ({ value: p.id, label: p.title }))]} /></Field>
            <Field label={t('linked_lesson')}><Select value={edit.lessonId ?? ''} onChange={(v) => setEdit({ ...edit, lessonId: v || undefined })} options={[{ value: '', label: t('none') }, ...Object.values(data.lessons).map((p) => ({ value: p.id, label: p.title }))]} /></Field>
            <Field label={t('timeline')}><Select value={edit.blockId ?? ''} onChange={(v) => setEdit({ ...edit, blockId: v || undefined })} options={[{ value: '', label: t('none') }, ...Object.values(data.activities).filter((b) => b.date >= addDays(todayKey(), -3) && b.date <= addDays(todayKey(), 3)).map((b) => ({ value: b.id, label: `${b.date.slice(5)} ${b.title}` }))]} /></Field>
            <Field label={t('linked_notes')}><div className="flex flex-wrap gap-2">{Object.values(data.notes).filter((n) => n.id !== edit.id).slice(0, 20).map((n) => <Chip key={n.id} active={edit.linkedNoteIds.includes(n.id)} onClick={() => setEdit({ ...edit, linkedNoteIds: edit.linkedNoteIds.includes(n.id) ? edit.linkedNoteIds.filter((x) => x !== n.id) : [...edit.linkedNoteIds, n.id] })}>{n.title || n.body.slice(0, 16)}</Chip>)}</div></Field>
          </div>
        </Sheet>
      )}
    </div>
  );
}
