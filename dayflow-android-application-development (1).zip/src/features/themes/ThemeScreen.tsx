import { Check, Moon, Sun } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { Badge, Page, ScreenHeader, Segmented, useSettings, useT } from '@/components/common/ui';
import { Orn, useSeason } from '@/features/decor/Decor';
import { THEMES, getTheme, type ThemeDef } from '@/services/themes';
import { cn } from '@/utils/cn';

/** A live miniature of the Home screen rendered with the theme's real tokens, classes and structure. */
export function ThemePreview({ theme, dark, scale = 0.56 }: { theme: ThemeDef; dark: boolean; scale?: number }) {
  const { lang } = useT();
  const ar = lang === 'ar';
  const W = 300, H = 560;
  const isDark = dark || !!theme.forceDark;
  const navItems = ['house', 'calendar', 'timer_clock', 'bar_chart', 'gear'];
  const overview = theme.overview;
  return (
    <div className="relative overflow-hidden" style={{ width: W * scale, height: H * scale, borderRadius: 26 * scale + 8 }}>
      <div data-theme={theme.id} data-nav={theme.nav} data-cards={theme.cards} data-header={theme.header} data-timeline={theme.timeline} className={isDark ? 'dark' : ''} dir={ar ? 'rtl' : 'ltr'}
        style={{ width: W, height: H, transform: `scale(${scale})`, transformOrigin: 'top left', background: 'var(--page-bg, var(--bg))', backgroundColor: 'var(--bg)', color: 'var(--ink)', fontFamily: 'var(--font-sans)', position: 'absolute', top: 0, left: 0, overflow: 'hidden' }}>
        <div style={{ padding: '18px 16px 0' }}>
          <div style={{ display: 'flex', justifyContent: theme.header === 'center' ? 'center' : 'space-between', textAlign: theme.header === 'center' ? 'center' : 'start' }}>
            <div><div style={{ fontSize: 11, color: 'var(--ink-3)', fontWeight: 600 }}>{ar ? 'الأربعاء ١٥ أكتوبر' : 'Wed, Oct 15'}</div>
              <div style={{ fontSize: theme.header === 'compact' ? 20 : 26, fontWeight: 800, letterSpacing: -0.5 }}>{ar ? 'صباح الخير' : 'Good morning'}</div></div>
          </div>
          {overview === 'hero' ? (
            <div style={{ marginTop: 14, borderRadius: 'var(--r-card)', padding: 16, background: 'linear-gradient(135deg, var(--accent), color-mix(in srgb, var(--accent) 55%, #ff7ad9))', color: 'var(--accent-ink)', boxShadow: 'var(--shadow-float)' }}>
              <div style={{ fontSize: 12, opacity: 0.85, fontWeight: 700 }}>{ar ? 'تقدّم اليوم' : 'Day progress'}</div>
              <div style={{ fontSize: 40, fontWeight: 800, lineHeight: 1.1 }}>68%</div>
              <div style={{ height: 8, borderRadius: 8, background: 'rgba(255,255,255,.3)', marginTop: 8 }}><div style={{ width: '68%', height: '100%', borderRadius: 8, background: 'currentColor', opacity: 0.9 }} /></div>
            </div>
          ) : overview === 'compact' ? (
            <div className="card" style={{ marginTop: 14, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--accent)' }}>68%</div><div style={{ flex: 1, height: 6, borderRadius: 6, background: 'var(--line)' }}><div style={{ width: '68%', height: '100%', borderRadius: 6, background: 'var(--accent)' }} /></div><div style={{ fontSize: 11, color: 'var(--ink-3)' }}>٥/٨</div>
            </div>
          ) : (
            <div className="card" style={{ marginTop: 14, padding: 14, display: 'flex', alignItems: 'center', gap: 14 }}>
              <svg width="64" height="64" viewBox="0 0 64 64" style={{ transform: 'rotate(-90deg)' }}><circle cx="32" cy="32" r="26" stroke="var(--line)" strokeWidth="7" fill="none" /><circle cx="32" cy="32" r="26" stroke="var(--accent)" strokeWidth="7" fill="none" strokeLinecap="round" strokeDasharray="163" strokeDashoffset="52" /></svg>
              <div style={{ flex: 1 }}><div style={{ fontSize: 22, fontWeight: 800 }}>68%</div><div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{ar ? '٥ من ٨ أنشطة' : '5 of 8 blocks'}</div></div>
            </div>
          )}
          <div style={{ marginTop: 10, borderRadius: 'var(--r-card)', padding: 14, color: 'var(--accent-ink)', background: 'linear-gradient(135deg, var(--accent), color-mix(in srgb, var(--accent) 60%, #000))' }}>
            <div style={{ fontSize: 10, opacity: 0.8, fontWeight: 700 }}>{ar ? 'النشاط الحالي' : 'CURRENT'}</div>
            <div style={{ fontSize: 17, fontWeight: 800 }}>{ar ? 'مذاكرة الفيزياء' : 'Physics study'}</div>
            <div style={{ marginTop: 8, height: 5, borderRadius: 5, background: 'rgba(255,255,255,.3)' }}><div style={{ width: '45%', height: '100%', borderRadius: 5, background: 'currentColor' }} /></div>
          </div>
          {[{ t: ar ? 'غدا' : 'Lunch', c: 'var(--c-meal)', time: '1:00' }, { t: ar ? 'تمرين' : 'Workout', c: 'var(--c-exercise)', time: '6:00' }, { t: ar ? 'قراءة' : 'Reading', c: 'var(--c-study)', time: '8:30' }].map((r, i) => (
            <div key={i} className="card tl-card" style={{ marginTop: 8, padding: '9px 12px', display: 'flex', alignItems: 'center', gap: 10, ['--tl-color' as string]: r.c }}>
              <span style={{ width: 10, height: 10, borderRadius: 10, background: r.c }} /><div style={{ flex: 1, fontSize: 13, fontWeight: 700 }}>{r.t}</div><div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{r.time}</div>
            </div>
          ))}
        </div>
        <div style={{ position: 'absolute', display: 'flex', alignItems: 'center', justifyContent: 'space-around', background: 'color-mix(in srgb, var(--bg) 78%, transparent)', backdropFilter: 'blur(14px)', border: '1px solid var(--card-border, var(--line))',
          ...(theme.nav === 'bar' ? { left: 0, right: 0, bottom: 0, height: 58, borderRadius: 0, borderWidth: '1px 0 0 0' } : theme.nav === 'float' ? { left: 12, right: 12, bottom: 12, height: 56, borderRadius: 28, boxShadow: 'var(--shadow-float)' } : { left: 40, right: 40, bottom: 12, height: 56, borderRadius: 30, boxShadow: 'var(--shadow-float)' }) }}>
          {navItems.map((n, i) => <div key={n} style={{ width: 38, height: 30, borderRadius: 20, display: 'grid', placeItems: 'center', background: i === 0 ? 'var(--accent-soft)' : 'transparent', opacity: i === 0 ? 1 : 0.55 }}><Orn name={n === 'house' ? 'sparkles' : n} size={20} /></div>)}
        </div>
      </div>
      <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-black/10" style={{ borderRadius: 26 * scale + 8 }} />
    </div>
  );
}

export function ThemeScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const season = useSeason();
  const sysDark = typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const dark = s.theme === 'dark' || (s.theme === 'system' && sysDark);
  const suggest = season.id === 'ramadan' && s.themeId !== 'ramadan';
  return (
    <div>
      <ScreenHeader title={t('themes_title')} subtitle={t('themes_sub')} onBack={onBack} />
      <Page>
        <Segmented value={s.theme} onChange={(v) => useApp.getState().updateSettings({ theme: v })} options={[{ value: 'system', label: t('th_system') }, { value: 'light', label: <span className="flex items-center justify-center gap-1"><Sun size={13} />{t('th_light')}</span> }, { value: 'dark', label: <span className="flex items-center justify-center gap-1"><Moon size={13} />{t('th_dark')}</span> }]} />
        {suggest && <button onClick={() => useApp.getState().updateSettings({ themeId: 'ramadan' })} className="press mt-3 flex w-full items-center gap-3 rounded-2xl border border-[#f2c14e]/50 bg-[#f2c14e]/10 p-3 text-start"><Orn name="red_paper_lantern" size={34} /><span className="flex-1 text-sm font-bold">{t('theme_suggest_ramadan')}</span><Badge tone="warning">{t('apply')}</Badge></button>}
        <div className="stagger mt-4 grid grid-cols-2 gap-3">
          {THEMES.map((th, i) => {
            const active = s.themeId === th.id;
            return (
              <button key={th.id} onClick={() => useApp.getState().updateSettings({ themeId: th.id })} style={{ ['--i' as string]: i % 8 }}
                className={cn('press card flex flex-col items-center gap-2 p-2.5 text-start transition-all', active && 'ring-2 ring-accent')}>
                <ThemePreview theme={th} dark={dark} />
                <div className="w-full px-1">
                  <div className="flex items-center gap-1.5"><span className="truncate text-[14px] font-bold">{lang === 'ar' ? th.ar : th.en}</span>{active && <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-accent text-accent-ink"><Check size={12} /></span>}</div>
                  <div className="mt-0.5 line-clamp-2 min-h-[2.2em] text-[11px] leading-snug text-ink-3">{lang === 'ar' ? th.descAr : th.descEn}</div>
                  <div className="mt-1.5 flex items-center gap-1">{th.swatch.map((c, j) => <span key={j} className="h-3.5 w-3.5 rounded-full border border-black/10" style={{ background: c }} />)}{th.forceDark && <Badge className="ms-auto">{t('theme_dark_only')}</Badge>}</div>
                </div>
              </button>
            );
          })}
        </div>
        <p className="mt-4 text-center text-xs text-ink-3">{t('themes_note')} · {getTheme(s.themeId).nav}</p>
      </Page>
    </div>
  );
}
