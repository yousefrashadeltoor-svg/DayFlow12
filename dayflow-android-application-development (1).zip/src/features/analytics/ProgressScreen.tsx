import { useMemo, useState } from 'react';
import { Download, Lightbulb, HeartPulse, FileText, ChevronLeft, ChevronRight } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { Badge, Button, Card, Chip, Page, ProgressBar, ScreenHeader, SectionTitle, Segmented, Select, useSettings, useT } from '@/components/common/ui';
import { BarChart, Donut, LineChart, Heatmap, Trend } from '@/components/charts/Charts';
import { catLabel } from '@/components/cards/blocks';
import { burnoutSignals, computeInsights, rangeStats, reschedules, statsToCsvRows, weeklyReport, habitStats, dayStat } from '@/services/analytics/stats';
import { addDays, fmtDate, fmtDuration, fmtNumber, fmtTime, startOfWeek, todayKey, weekdayName } from '@/utils/date';
import { toCSV } from '@/services/import/csv';
import { saveFile } from '@/services/native/dayflowNative';
import { uid } from '@/utils/id';
import { coreFrom } from '@/services/defaults';
import { instantiate } from '@/stores/appStore';

type Tab = 'daily' | 'weekly' | 'monthly' | 'insights' | 'report';

export function ProgressScreen() {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [tab, setTab] = useState<Tab>('daily');
  const [offset, setOffset] = useState(0);
  const [cat, setCat] = useState('');
  const [project, setProject] = useState('');
  const filter = { categoryId: cat || undefined, projectId: project || undefined };
  const today = todayKey();
  const days = tab === 'monthly' ? 30 : 7;
  const from = tab === 'weekly' || tab === 'report' ? addDays(startOfWeek(today, s.weekStart), offset * 7) : addDays(today, -(days - 1) + offset * days);
  const stats = useMemo(() => rangeStats(data, from, days, filter), [data, from, days, cat, project]); // eslint-disable-line react-hooks/exhaustive-deps
  const prev = useMemo(() => rangeStats(data, addDays(from, -days), days, filter), [data, from, days, cat, project]); // eslint-disable-line react-hooks/exhaustive-deps
  const dStat = useMemo(() => dayStat(data, addDays(today, offset), undefined, filter), [data, today, offset, cat, project]); // eslint-disable-line react-hooks/exhaustive-deps
  const labelCat = (id: string) => catLabel(data, id, lang);

  const sumBy = (arr: typeof stats, k: 'plannedMin' | 'creditedMin' | 'trackedMin' | 'studyMin' | 'exerciseMin' | 'completed' | 'missed') => arr.reduce((a, d) => a + d[k], 0);
  const catTotals = useMemo(() => {
    const m = new Map<string, number>();
    for (const d of stats) for (const [c, v] of Object.entries(d.byCategory)) m.set(c, (m.get(c) ?? 0) + v.credited);
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [stats]);
  const withPlan = stats.filter((d) => d.plannedMin > 0);
  const avgPct = withPlan.length ? Math.round(withPlan.reduce((a, d) => a + d.completionPct, 0) / withPlan.length) : 0;
  const prevPlan = prev.filter((d) => d.plannedMin > 0);
  const prevAvg = prevPlan.length ? Math.round(prevPlan.reduce((a, d) => a + d.completionPct, 0) / prevPlan.length) : 0;

  const exportCsv = async () => { await saveFile(`dayflow-stats-${from}.csv`, toCSV(statsToCsvRows(stats, labelCat)), 'text/csv'); };
  const exportJson = async () => { await saveFile(`dayflow-stats-${from}.json`, JSON.stringify({ from, days, filter, stats }, null, 2), 'application/json'); };

  return (
    <div>
      <ScreenHeader title={t('nav_progress')} subtitle={t('stats')} actions={<><Button size="sm" variant="ghost" icon={<Download size={15} />} onClick={exportCsv}>CSV</Button><Button size="sm" variant="ghost" onClick={exportJson}>JSON</Button></>} />
      <Page>
        <Segmented value={tab} onChange={(v) => { setTab(v); setOffset(0); }} size="sm" options={[{ value: 'daily', label: t('daily') }, { value: 'weekly', label: t('weekly') }, { value: 'monthly', label: t('monthly') }, { value: 'insights', label: t('insights') }, { value: 'report', label: t('report') }]} />
        {tab !== 'insights' && (
          <>
            <div className="mt-3 flex items-center justify-between">
              <Button size="sm" variant="secondary" onClick={() => setOffset(offset - 1)} aria-label={t('back')}><ChevronLeft size={16} className="rtl:rotate-180" /></Button>
              <span className="text-sm font-semibold">{tab === 'daily' ? fmtDate(addDays(today, offset), lang) : `${fmtDate(from, lang, { day: 'numeric', month: 'short' })} – ${fmtDate(addDays(from, days - 1), lang, { day: 'numeric', month: 'short' })}`}</span>
              <Button size="sm" variant="secondary" disabled={offset >= 0} onClick={() => setOffset(offset + 1)} aria-label={t('next_up')}><ChevronRight size={16} className="rtl:rotate-180" /></Button>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Select ariaLabel={t('category')} value={cat} onChange={setCat} options={[{ value: '', label: `${t('category')}: ${t('all')}` }, ...Object.values(data.categories).map((c) => ({ value: c.id, label: labelCat(c.id) }))]} />
              <Select ariaLabel={t('linked_project')} value={project} onChange={setProject} options={[{ value: '', label: `${t('m_projects')}: ${t('all')}` }, ...Object.values(data.projects).map((p) => ({ value: p.id, label: p.title }))]} />
            </div>
          </>
        )}

        {tab === 'daily' && (
          <>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <Kpi label={t('day_progress')} value={`${fmtNumber(dStat.completionPct, lang)}%`} />
              <Kpi label={t('productive_time')} value={fmtDuration(dStat.productiveMin, lang)} />
              <Kpi label={t('study_time')} value={fmtDuration(dStat.studyMin, lang)} />
              <Kpi label={t('exercise_time')} value={fmtDuration(dStat.exerciseMin, lang)} />
              <Kpi label={t('rest_time')} value={fmtDuration(dStat.restMin, lang)} />
              <Kpi label={t('unallocated')} value={fmtDuration(dStat.unallocatedMin, lang)} />
              <Kpi label={t('blocks_done')} value={fmtNumber(dStat.completed, lang)} />
              <Kpi label={t('blocks_missed')} value={fmtNumber(dStat.missed + dStat.overdue, lang)} />
            </div>
            <SectionTitle>{t('planned_vs_actual')}</SectionTitle>
            <Card className="p-4 space-y-3">
              {Object.entries(dStat.byCategory).map(([c, v]) => (
                <div key={c}><div className="mb-1 flex justify-between text-sm"><span>{labelCat(c)}</span><span className="num text-ink-2">{fmtDuration(v.credited, lang)} / {fmtDuration(v.planned, lang)}</span></div><ProgressBar value={(v.credited / Math.max(1, v.planned)) * 100} color={data.categories[c]?.color} /></div>
              ))}
              {!Object.keys(dStat.byCategory).length && <p className="text-sm text-ink-3">{t('no_activities')}</p>}
              <div className="flex justify-between border-t border-line pt-3 text-sm"><span>{t('tracked')}</span><span className="num font-semibold">{fmtDuration(dStat.trackedMin, lang)}</span></div>
            </Card>
          </>
        )}

        {(tab === 'weekly' || tab === 'monthly') && (
          <>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <Kpi label={t('average')} value={`${fmtNumber(avgPct, lang)}%`} extra={<Trend value={avgPct} prev={prevAvg} suffix="%" />} />
              <Kpi label={t('completed')} value={fmtDuration(sumBy(stats, 'creditedMin'), lang)} extra={<Trend value={Math.round(sumBy(stats, 'creditedMin') / 60)} prev={Math.round(sumBy(prev, 'creditedMin') / 60)} />} />
              <Kpi label={t('study_time')} value={fmtDuration(sumBy(stats, 'studyMin'), lang)} />
              <Kpi label={t('reschedule_freq')} value={fmtNumber(reschedules(data, from, addDays(from, days - 1)), lang)} />
            </div>
            <SectionTitle>{t('completion_trend')}</SectionTitle>
            <Card className="p-4"><LineChart points={stats.map((d) => (d.plannedMin ? d.completionPct : null))} labels={stats.map((d) => tab === 'weekly' ? weekdayName(new Date(d.date + 'T12:00').getDay(), lang, 'narrow') : String(Number(d.date.slice(8))))} /></Card>
            <SectionTitle>{t('planned_vs_actual')}</SectionTitle>
            <Card className="p-4">
              <BarChart stacked={false} labels={stats.map((d) => tab === 'weekly' ? weekdayName(new Date(d.date + 'T12:00').getDay(), lang, 'narrow') : (Number(d.date.slice(8)) % 5 === 0 ? String(Number(d.date.slice(8))) : ''))}
                series={[{ name: t('planned'), color: 'var(--line)', values: stats.map((d) => d.plannedMin) }, { name: t('completed'), color: 'var(--accent)', values: stats.map((d) => d.creditedMin) }]} />
            </Card>
            <SectionTitle>{t('category_distribution')}</SectionTitle>
            <Card className="p-4"><Donut parts={catTotals.map(([c, v]) => ({ name: labelCat(c), value: v, color: data.categories[c]?.color ?? 'var(--c-custom)' }))} label={fmtDuration(catTotals.reduce((a, [, v]) => a + v, 0), lang)} /></Card>
            <SectionTitle>{t('habit_consistency')}</SectionTitle>
            <Card className="divide-y divide-line">
              {Object.values(data.habits).filter((h) => !h.archived).map((h) => { const hs = habitStats(h, Object.values(data.habitLogs), s.weekStart, days); return (
                <div key={h.id} className="flex items-center gap-3 p-3"><span className="flex-1 truncate text-sm">{h.name}</span><div className="w-28"><ProgressBar value={hs.rate ?? 0} color={h.color} /></div><span className="num w-10 text-end text-sm font-semibold">{hs.rate == null ? '—' : `${fmtNumber(hs.rate, lang)}%`}</span></div>
              ); })}
              {!Object.keys(data.habits).length && <p className="p-3 text-sm text-ink-3">{t('empty_generic')}</p>}
            </Card>
            {tab === 'monthly' && (
              <>
                <SectionTitle>{t('heatmap')}</SectionTitle>
                <Card className="p-4"><Heatmap cells={stats.map((d) => ({ date: d.date, level: d.plannedMin ? Math.min(3, Math.ceil(d.completionPct / 34)) : 0 }))} /></Card>
                <SectionTitle>{t('m_goals')}</SectionTitle>
                <Card className="p-4 text-sm"><div className="flex justify-between"><span>{t('completed')}</span><span className="num font-semibold">{fmtNumber(Object.values(data.tasks).filter((x) => x.completedAt && x.completedAt >= new Date(from + 'T00:00').getTime()).length, lang)} {t('m_tasks')}</span></div>
                  <div className="mt-1 flex justify-between"><span>{t('study_time')}</span><span className="num font-semibold">{fmtDuration(Object.values(data.studySessions).filter((x) => x.date >= from).reduce((a, x) => a + x.minutes, 0), lang)}</span></div></Card>
              </>
            )}
          </>
        )}

        {tab === 'insights' && <Insights labelCat={labelCat} />}
        {tab === 'report' && <Report from={from} labelCat={labelCat} />}
      </Page>
    </div>
  );
}

const Kpi = ({ label, value, extra }: { label: string; value: string; extra?: React.ReactNode }) => (
  <Card className="p-3"><div className="text-[11px] font-medium text-ink-3">{label}</div><div className="mt-0.5 flex items-baseline gap-2"><span className="num text-[19px] font-bold">{value}</span>{extra}</div></Card>
);

function Insights({ labelCat }: { labelCat: (id: string) => string }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const res = useMemo(() => computeInsights(data, s, labelCat, (h) => fmtTime(h * 60, lang, s.clock24)), [data, s, labelCat, lang]);
  const signals = useMemo(() => burnoutSignals(data, s), [data, s]);
  const lighter = async () => {
    const tomorrow = addDays(todayKey(), 1);
    const tpl = data.templates.tpl_light;
    if (tpl) { const n = await useApp.getState().applyTemplate(tpl.id, tomorrow); useApp.getState().toast('success', t('template_applied', { n })); }
    else { await useApp.getState().commit({ activities: [instantiate(coreFrom({ title: t('rest'), categoryId: 'cat_rest', startMin: 15 * 60, durationMin: 60 }), tomorrow)] }); }
  };
  return (
    <>
      <SectionTitle>{t('insights')}</SectionTitle>
      {res.insufficient ? <Card className="p-4 text-sm text-ink-2"><Lightbulb size={18} className="mb-2 text-accent" />{t('not_enough_data', { n: fmtNumber(res.observations, lang), m: fmtNumber(res.required, lang) })}</Card> : (
        <div className="space-y-2">{res.insights.map((i) => (
          <Card key={i.key} className="p-4">
            <div className="flex items-start gap-3"><Lightbulb size={18} className="mt-0.5 shrink-0 text-accent" /><div className="flex-1 text-[15px]">{t(i.key as 'ins_best_hour', { x: i.value })}</div></div>
            <div className="mt-2 flex flex-wrap gap-1.5 ps-8"><Badge tone="accent">{t('confidence')}: {fmtNumber(Math.round(i.confidence * 100), lang)}%</Badge><Badge>{fmtNumber(i.samples, lang)}</Badge><Badge>{t('data_range')}: {fmtDate(i.from, lang, { day: 'numeric', month: 'short' })} – {fmtDate(i.to, lang, { day: 'numeric', month: 'short' })}</Badge></div>
          </Card>
        ))}{!res.insights.length && <Card className="p-4 text-sm text-ink-2">{t('not_enough_data', { n: fmtNumber(res.observations, lang), m: fmtNumber(res.required, lang) })}</Card>}</div>
      )}
      <SectionTitle>{t('burnout')}</SectionTitle>
      <Card className="p-4">
        <div className="flex items-start gap-3"><HeartPulse size={20} className={signals.length ? 'text-warning' : 'text-success'} /><p className="flex-1 text-sm">{signals.length ? t('burnout_warn') : t('burnout_ok')}</p></div>
        {signals.length > 0 && <>
          <ul className="mt-3 space-y-1 ps-8 text-sm text-ink-2">{signals.map((sg) => <li key={sg.key}>• {t(sg.key, sg.params)}</li>)}</ul>
          <Button variant="tinted" className="mt-3 w-full" onClick={lighter}>{t('offer_lighter')}</Button>
        </>}
      </Card>
    </>
  );
}

function Report({ from, labelCat }: { from: string; labelCat: (id: string) => string }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const r = useMemo(() => weeklyReport(data, s, from), [data, s, from]);
  const exportReport = () => saveFile(`dayflow-report-${from}.json`, JSON.stringify({ ...r, days: r.days.map((d) => ({ date: d.date, completionPct: d.completionPct, plannedMin: d.plannedMin, creditedMin: d.creditedMin })) }, null, 2), 'application/json');
  const suggestions: string[] = [];
  const worstCat = Object.entries(r.days.reduce<Record<string, { p: number; c: number }>>((acc, d) => { for (const [k, v] of Object.entries(d.byCategory)) { acc[k] = acc[k] ?? { p: 0, c: 0 }; acc[k].p += v.planned; acc[k].c += v.credited; } return acc; }, {})).filter(([, v]) => v.p >= 60).sort((a, b) => a[1].c / a[1].p - b[1].c / b[1].p)[0];
  if (worstCat && worstCat[1].c / worstCat[1].p < 0.6) suggestions.push(t('ins_low_cat', { x: `${labelCat(worstCat[0])} (${Math.round((worstCat[1].c / worstCat[1].p) * 100)}%)` }));
  if (r.missed.length >= 3) suggestions.push(t('offer_lighter'));
  return (
    <>
      <div className="mt-4 flex items-center justify-between"><Badge tone="accent">{t('average')}: {fmtNumber(r.avgCompletion, lang)}%</Badge><Button size="sm" variant="ghost" icon={<FileText size={14} />} onClick={exportReport}>JSON</Button></div>
      <RSection title={t('rp_priorities')}>{r.completedPriorities.length ? r.completedPriorities.map((b) => <Line key={b.id} a={b.title} b={fmtDate(b.date, lang, { weekday: 'short' })} />) : <Empty />}</RSection>
      <RSection title={t('rp_missed')}>{r.missed.length ? r.missed.map((b) => <Line key={b.id} a={b.title} b={t(b.status === 'missed' ? 'st_missed' : 'st_skipped')} />) : <Empty />}</RSection>
      <RSection title={t('rp_habits')}>{r.habits.length ? r.habits.map((h) => <Line key={h.habit.id} a={h.habit.name} b={h.rate == null ? '—' : `${fmtNumber(h.rate, lang)}%`} />) : <Empty />}</RSection>
      <RSection title={t('rp_study')}><Line a={t('study_time')} b={<>{fmtDuration(r.studyMin, lang)} <Trend value={Math.round(r.studyMin / 60)} prev={Math.round(r.studyPrevMin / 60)} /></>} /></RSection>
      <RSection title={t('rp_workout')}><Line a={t('m_workouts')} b={`${fmtNumber(r.workoutsDone, lang)} / ${fmtNumber(r.workoutsPlanned, lang)}`} /></RSection>
      <RSection title={t('rp_accuracy')}><Line a={t('rp_accuracy')} b={r.accuracy == null ? t('not_enough_data', { n: 0, m: 3 }) : `${fmtNumber(r.accuracy, lang)}%`} /></RSection>
      <RSection title={t('rp_deadlines')}>{r.deadlines.length ? r.deadlines.map((d, i) => <Line key={i} a={d.title} b={fmtDate(d.date, lang, { day: 'numeric', month: 'short' })} />) : <Empty />}</RSection>
      <RSection title={t('rp_suggestions')}>{suggestions.length ? suggestions.map((x, i) => <p key={i} className="py-1 text-sm">• {x}</p>) : <Empty />}</RSection>
      <div className="mt-2 flex gap-2">{Object.values(data.categories).slice(0, 0).map((c) => <Chip key={c.id}>{c.key}</Chip>)}</div>
      <span className="hidden">{uid()}</span>
    </>
  );
}
const RSection = ({ title, children }: { title: string; children: React.ReactNode }) => (<><SectionTitle>{title}</SectionTitle><Card className="divide-y divide-line px-4 py-1">{children}</Card></>);
const Line = ({ a, b }: { a: React.ReactNode; b: React.ReactNode }) => <div className="flex items-center justify-between gap-3 py-2 text-sm"><span className="truncate">{a}</span><span className="num shrink-0 font-semibold text-ink-2">{b}</span></div>;
const Empty = () => { const { t } = useT(); return <p className="py-2 text-sm text-ink-3">{t('empty_generic')}</p>; };
