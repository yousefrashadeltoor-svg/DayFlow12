import { useEffect, useMemo, useRef, useState } from 'react';
import { Pause, Play, RotateCcw, SkipForward, Square, Zap, Music, X, Plus, Info } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { useApp } from '@/stores/appStore';
import { Badge, Button, Card, Chip, Field, Input, Page, ProgressRing, ScreenHeader, SectionTitle, Select, Sheet, Stepper, TextArea, useHaptic, useSettings, useT } from '@/components/common/ui';
import { BarChart } from '@/components/charts/Charts';
import type { FocusMode, FocusTimerState, Settings } from '@/models/types';
import { fmtCountdown, fmtDuration, fmtNumber, fmtTime, todayKey, addDays, rangeKeys, weekdayName } from '@/utils/date';
import { uid } from '@/utils/id';
import { pickFile, speak, isNative } from '@/services/native/dayflowNative';
import { cn } from '@/utils/cn';

const MODES: FocusMode[] = ['pomodoro', 'extended', 'deep', 'open', 'countdown', 'custom'];

export function phaseMinutes(s: Settings, mode: FocusMode, phase: FocusTimerState['phase']): number {
  const f = s.focus;
  if (mode === 'open') return 0;
  if (phase === 'work') return { pomodoro: f.pomodoroWork, extended: f.extendedWork, deep: f.deepWork, countdown: f.countdown, custom: f.customWork, open: 0 }[mode];
  if (phase === 'long_break') return f.pomodoroLong;
  return { pomodoro: f.pomodoroShort, extended: f.extendedBreak, deep: f.deepBreak, countdown: 0, custom: f.customBreak, open: 0 }[mode];
}
export const elapsedMs = (ft: FocusTimerState, now = Date.now()) => (ft.pausedAt ?? now) - ft.phaseStartedAt - ft.pausedTotalMs;

export function FocusScreen() {
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const data = useApp((st) => st.data);
  const ft = data.state.focusTimer as FocusTimerState | undefined;
  const [mode, setMode] = useState<FocusMode>(ft?.mode ?? 'pomodoro');
  const [now, setNow] = useState(Date.now());
  const [distract, setDistract] = useState(false);
  const [newItem, setNewItem] = useState('');
  const [ambience, setAmbience] = useState<{ name: string; src: string } | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const completing = useRef(false);

  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 500); return () => clearInterval(id); }, []);

  const total = ft ? ft.phaseDurationMs : phaseMinutes(s, mode, 'work') * 60000;
  const el = ft ? elapsedMs(ft, now) : 0;
  const remaining = total ? total - el : 0;

  const record = async (timer: FocusTimerState, completed: boolean, endAt: number) => {
    const actualMin = Math.max(0, Math.round((endAt - timer.phaseStartedAt - timer.pausedTotalMs) / 60000));
    if (actualMin < 1 && !completed) return;
    const n = Date.now();
    await useApp.getState().put('focusSessions', { id: uid('f'), date: todayKey(), mode: timer.mode, phase: timer.phase, startedAt: timer.phaseStartedAt, endedAt: endAt, plannedMin: Math.round(timer.phaseDurationMs / 60000), actualMin, completed, taskId: timer.taskId, lessonId: timer.lessonId, subjectId: timer.subjectId, blockId: timer.blockId, note: timer.note, distractions: timer.distractions, createdAt: n, updatedAt: n });
    if (timer.phase === 'work' && actualMin > 0) {
      const lesson = timer.lessonId ? useApp.getState().data.lessons[timer.lessonId] : undefined;
      if (timer.lessonId || timer.subjectId) await useApp.getState().put('studySessions', { id: uid('ss'), subjectId: timer.subjectId ?? lesson?.subjectId, unitId: lesson?.unitId, lessonId: timer.lessonId, date: todayKey(), minutes: actualMin, focusSessionId: undefined, note: '', createdAt: n, updatedAt: n });
      if (timer.taskId) { const task = useApp.getState().data.tasks[timer.taskId]; if (task) await useApp.getState().put('tasks', { ...task, trackedMin: task.trackedMin + actualMin }); }
    }
  };

  const nextPhase = (timer: FocusTimerState): FocusTimerState => {
    const isWork = timer.phase === 'work';
    const cycle = isWork ? timer.cycle : timer.cycle + 1;
    const phase: FocusTimerState['phase'] = isWork ? ((timer.mode === 'pomodoro' && timer.cycle % s.focus.cyclesBeforeLong === 0) ? 'long_break' : 'short_break') : 'work';
    const dur = phaseMinutes(s, timer.mode, phase) * 60000;
    const n = Date.now();
    const autostart = phase !== 'work' ? s.focus.autoStartBreaks : false;
    return { ...timer, phase, cycle, phaseStartedAt: n, phaseDurationMs: dur, pausedAt: autostart ? null : n, pausedTotalMs: 0, running: true, distractions: 0, updatedAt: n };
  };

  // Phase completion (also covers completion that happened while the app was closed: end time is exact, not invented).
  useEffect(() => {
    if (!ft || !ft.running || ft.pausedAt || !ft.phaseDurationMs || remaining > 0 || completing.current) return;
    completing.current = true;
    const endAt = ft.phaseStartedAt + ft.pausedTotalMs + ft.phaseDurationMs;
    (async () => {
      await record(ft, true, endAt);
      h([30, 60, 30]);
      if (ft.phase === 'work') useApp.getState().toast('success', t('break_suggestion', { d: fmtDuration(phaseMinutes(s, ft.mode, 'short_break'), lang) }));
      if (!isNative()) speak(t('n_focus_end'), lang).catch(() => undefined);
      const nx = nextPhase(ft);
      if (!nx.phaseDurationMs) await useApp.getState().setFocusTimer(null); else await useApp.getState().setFocusTimer(nx);
      completing.current = false;
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ft, remaining]);

  const start = async () => {
    h(14);
    const n = Date.now();
    await useApp.getState().setFocusTimer({ id: 'focusTimer', running: true, mode, phase: 'work', phaseStartedAt: n, phaseDurationMs: phaseMinutes(s, mode, 'work') * 60000, pausedAt: null, pausedTotalMs: 0, cycle: 1,
      taskId: ft?.taskId, lessonId: ft?.lessonId, subjectId: ft?.subjectId, blockId: ft?.blockId, checklist: ft?.checklist ?? [], note: ft?.note ?? '', distractions: 0, createdAt: n, updatedAt: n });
  };
  const update = (p: Partial<FocusTimerState>) => {
    const base: FocusTimerState = ft ?? { id: 'focusTimer', running: false, mode, phase: 'work', phaseStartedAt: Date.now(), phaseDurationMs: phaseMinutes(s, mode, 'work') * 60000, pausedAt: Date.now(), pausedTotalMs: 0, cycle: 1, checklist: [], note: '', distractions: 0, createdAt: Date.now(), updatedAt: Date.now() };
    return useApp.getState().setFocusTimer({ ...base, ...p, updatedAt: Date.now() });
  };
  const pause = () => { h(10); update({ pausedAt: Date.now() }); };
  const resume = () => { h(10); if (ft?.pausedAt) update({ pausedTotalMs: ft.pausedTotalMs + (Date.now() - ft.pausedAt), pausedAt: null }); };
  const restart = () => { h(10); update({ phaseStartedAt: Date.now(), pausedAt: null, pausedTotalMs: 0 }); };
  const skip = async () => { if (!ft) return; await record(ft, false, Date.now()); const nx = nextPhase(ft); await useApp.getState().setFocusTimer(nx.phaseDurationMs || ft.mode === 'open' ? nx : null); };
  const end = async () => { if (!ft) return; h(18); await record(ft, ft.mode === 'open', Date.now()); await useApp.getState().setFocusTimer(null); };

  const pickAmbience = async () => {
    try {
      const f = await pickFile('audio', 'audio/*', ['audio/mpeg', 'audio/ogg', 'audio/mp4', 'audio/x-m4a']);
      const src = f.path?.startsWith('data:') ? f.path : Capacitor.convertFileSrc(f.path ?? '');
      setAmbience({ name: f.name, src });
    } catch { /* cancelled */ }
  };
  useEffect(() => {
    if (!ambience) { audioRef.current?.pause(); return; }
    const a = audioRef.current ?? new Audio();
    audioRef.current = a; a.src = ambience.src; a.loop = true; a.volume = 0.5;
    if (ft?.running && !ft.pausedAt) a.play().catch(() => undefined); else a.pause();
    return () => { a.pause(); };
  }, [ambience, ft?.running, ft?.pausedAt]);

  const sessions = Object.values(data.focusSessions);
  const todays = sessions.filter((x) => x.date === todayKey() && x.phase === 'work');
  const todayMin = todays.reduce((a, x) => a + x.actualMin, 0);
  const distractions = Object.values(data.distractions);
  const distToday = distractions.filter((d) => d.date === todayKey());
  const week = rangeKeys(addDays(todayKey(), -6), 7);
  const reasons = useMemo(() => { const m = new Map<string, number>(); for (const d of distractions) m.set(d.reason, (m.get(d.reason) ?? 0) + 1); return [...m.entries()].sort((a, b) => b[1] - a[1]); }, [distractions]);
  const pct = total ? Math.min(100, (el / total) * 100) : 0;
  const phaseColor = ft?.phase === 'work' || !ft ? 'var(--accent)' : 'var(--c-rest)';
  const linkedLabel = ft?.taskId ? data.tasks[ft.taskId]?.title : ft?.lessonId ? data.lessons[ft.lessonId]?.title : ft?.blockId ? data.activities[ft.blockId]?.title : null;

  return (
    <div>
      <ScreenHeader title={t('focus_title')} subtitle={`${t('focus_today')}: ${fmtDuration(todayMin, lang)} · ${fmtNumber(todays.length, lang)} ${t('sessions')}`} />
      <Page>
        {!ft && <div className="-mx-4 flex gap-2 overflow-x-auto px-4 no-scrollbar">{MODES.map((m) => <Chip key={m} active={mode === m} onClick={() => setMode(m)}>{t(`m_${m}` as 'm_pomodoro')}</Chip>)}</div>}
        <Card className="mt-4 flex flex-col items-center p-6">
          <Badge tone={ft?.phase === 'work' || !ft ? 'accent' : 'success'}>{t(`ph_${ft?.phase ?? 'work'}` as 'ph_work')}{ft && ft.mode === 'pomodoro' ? ` · ${t('cycle_n', { n: fmtNumber(ft.cycle, lang) })}` : ''}</Badge>
          <div className="my-5">
            <ProgressRing value={ft?.mode === 'open' ? 100 : pct} size={236} stroke={12} color={phaseColor}>
              <div className="text-center">
                <div className="num text-[52px] font-bold tracking-tight">{ft?.mode === 'open' || (!ft && mode === 'open') ? fmtCountdown(el, lang) : fmtCountdown(ft ? remaining : total, lang)}</div>
                <div className="text-sm text-ink-3">{t(`m_${ft?.mode ?? mode}` as 'm_pomodoro')}</div>
              </div>
            </ProgressRing>
          </div>
          <div className="flex items-center gap-3">
            {!ft && <Button size="lg" className="w-40" onClick={start} icon={<Play size={18} />}>{t('act_start')}</Button>}
            {ft && <>
              <Button variant="secondary" onClick={restart} aria-label={t('restart')} icon={<RotateCcw size={18} />} />
              {ft.pausedAt ? <Button size="lg" className="w-36" onClick={resume} icon={<Play size={18} />}>{t('act_resume')}</Button> : <Button size="lg" className="w-36" onClick={pause} icon={<Pause size={18} />}>{t('act_pause')}</Button>}
              <Button variant="secondary" onClick={skip} aria-label={t('skip_phase')} icon={<SkipForward size={18} />} />
            </>}
          </div>
          {ft && (
            <div className="mt-4 flex gap-2">
              <Button size="sm" variant="danger" icon={<Square size={14} />} onClick={end}>{t('end_session')}</Button>
              {ft.phase === 'work' && <Button size="sm" variant="tinted" icon={<Zap size={14} />} onClick={() => setDistract(true)}>{t('distracted')}{ft.distractions ? ` (${fmtNumber(ft.distractions, lang)})` : ''}</Button>}
            </div>
          )}
        </Card>

        <SectionTitle>{t('focus_on')}</SectionTitle>
        <Card className="p-4">
          <Select ariaLabel={t('focus_on')} value={ft?.taskId ? `t:${ft.taskId}` : ft?.lessonId ? `l:${ft.lessonId}` : ft?.blockId ? `b:${ft.blockId}` : ''}
            onChange={(v) => { const [k, id] = v.split(':'); const lesson = k === 'l' ? data.lessons[id] : undefined; update({ taskId: k === 't' ? id : undefined, lessonId: k === 'l' ? id : undefined, subjectId: lesson?.subjectId, blockId: k === 'b' ? id : undefined }); }}
            options={[{ value: '', label: t('nothing_linked') },
              ...Object.values(data.tasks).filter((x) => x.status !== 'done').map((x) => ({ value: `t:${x.id}`, label: `✓ ${x.title}` })),
              ...Object.values(data.lessons).filter((x) => x.status !== 'done').map((x) => ({ value: `l:${x.id}`, label: `📖 ${data.subjects[x.subjectId]?.title ?? ''} · ${x.title}` })),
              ...Object.values(data.activities).filter((x) => x.date === todayKey() && x.status === 'planned').map((x) => ({ value: `b:${x.id}`, label: `◷ ${fmtTime(x.startMin, lang, s.clock24)} ${x.title}` }))]} />
          {linkedLabel && <p className="mt-2 text-sm text-ink-2">↳ {linkedLabel}</p>}
          <div className="mt-4">
            <div className="mb-2 text-[13px] font-medium text-ink-2">{t('session_checklist')}</div>
            {(ft?.checklist ?? []).map((c) => (
              <div key={c.id} className="flex items-center gap-2 py-1">
                <input type="checkbox" className="h-5 w-5 accent-[var(--accent)]" checked={c.done} onChange={() => update({ checklist: ft!.checklist.map((x) => x.id === c.id ? { ...x, done: !x.done } : x) })} />
                <span className={cn('flex-1 text-sm', c.done && 'text-ink-3 line-through')}>{c.title}</span>
                <button aria-label={t('delete')} onClick={() => update({ checklist: ft!.checklist.filter((x) => x.id !== c.id) })}><X size={14} className="text-ink-3" /></button>
              </div>
            ))}
            <div className="mt-1 flex gap-2"><Input value={newItem} onChange={(e) => setNewItem(e.target.value)} placeholder={t('add_item')} onKeyDown={(e) => { if (e.key === 'Enter' && newItem.trim()) { update({ checklist: [...(ft?.checklist ?? []), { id: uid(), title: newItem.trim(), done: false }] }); setNewItem(''); } }} />
              <Button variant="secondary" onClick={() => { if (newItem.trim()) { update({ checklist: [...(ft?.checklist ?? []), { id: uid(), title: newItem.trim(), done: false }] }); setNewItem(''); } }}><Plus size={16} /></Button></div>
          </div>
          <Field label={t('session_note')}><TextArea className="mt-1" value={ft?.note ?? ''} onChange={(e) => update({ note: e.target.value })} /></Field>
        </Card>

        <SectionTitle>{t('ambience')}</SectionTitle>
        <Card className="flex items-center gap-3 p-4">
          <Music size={20} className="text-accent" />
          <div className="min-w-0 flex-1 text-sm">{ambience ? <span className="font-semibold">{ambience.name}</span> : <span className="text-ink-2">{t('ambience_hint')}</span>}</div>
          {ambience ? <Button size="sm" variant="secondary" onClick={() => setAmbience(null)}>{t('stop')}</Button> : <Button size="sm" variant="tinted" onClick={pickAmbience}>{t('choose_file')}</Button>}
        </Card>

        <SectionTitle>{t('focus_history')}</SectionTitle>
        <Card className="p-4">
          <BarChart labels={week.map((d) => weekdayName(new Date(d + 'T12:00').getDay(), lang, 'narrow'))}
            series={[{ name: t('ph_work'), color: 'var(--accent)', values: week.map((d) => sessions.filter((x) => x.date === d && x.phase === 'work').reduce((a, x) => a + x.actualMin, 0)) }]} />
          <div className="mt-3 divide-y divide-line">
            {todays.slice(-6).reverse().map((x) => (
              <div key={x.id} className="flex items-center justify-between py-2 text-sm"><span>{t(`m_${x.mode}` as 'm_pomodoro')} · {fmtDuration(x.actualMin, lang)}</span><Badge tone={x.completed ? 'success' : 'neutral'}>{x.completed ? t('completed') : t('st_partial')}</Badge></div>
            ))}
          </div>
        </Card>

        <SectionTitle>{t('distractions')}</SectionTitle>
        <Card className="p-4 text-sm">
          <div className="mb-2 flex justify-between"><span>{t('today')}</span><span className="num font-semibold">{fmtNumber(distToday.length, lang)} · {fmtDuration(distToday.reduce((a, d) => a + d.minutesLost, 0), lang)}</span></div>
          {reasons.map(([r, n]) => <div key={r} className="flex justify-between py-0.5 text-ink-2"><span>{t(`dist_${r}` as 'dist_phone')}</span><span className="num">{fmtNumber(n, lang)}</span></div>)}
        </Card>
        <p className="mt-4 flex gap-2 rounded-2xl bg-info/10 p-3 text-xs leading-relaxed text-info"><Info size={16} className="shrink-0" />{t('app_block_notice')}</p>
      </Page>
      <DistractionSheet open={distract} onClose={() => setDistract(false)} onSaved={() => ft && update({ distractions: ft.distractions + 1 })} />
    </div>
  );
}

function DistractionSheet({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved: () => void }) {
  const { t } = useT();
  const [reason, setReason] = useState('phone'); const [mins, setMins] = useState(5); const [note, setNote] = useState('');
  const ft = useApp((s) => s.data.state.focusTimer as FocusTimerState | undefined);
  const save = async () => {
    const n = Date.now();
    if (await useApp.getState().put('distractions', { id: uid('d'), date: todayKey(), at: n, reason, minutesLost: mins, note, blockId: ft?.blockId, createdAt: n, updatedAt: n })) { onSaved(); setNote(''); onClose(); }
  };
  return (
    <Sheet open={open} onClose={onClose} title={t('distracted')} footer={<Button className="w-full" onClick={save}>{t('back_to_task')}</Button>}>
      <div className="space-y-4">
        <Field label={t('distraction_reason')}><div className="flex flex-wrap gap-2">{['phone', 'social', 'people', 'noise', 'thoughts', 'other'].map((r) => <Chip key={r} active={reason === r} onClick={() => setReason(r)}>{t(`dist_${r}` as 'dist_phone')}</Chip>)}</div></Field>
        <div className="flex items-center justify-between"><span>{t('minutes_lost')}</span><Stepper value={mins} onChange={setMins} min={0} max={240} /></div>
        <Field label={t('notes')}><TextArea value={note} onChange={(e) => setNote(e.target.value)} /></Field>
      </div>
    </Sheet>
  );
}
