import { useMemo, useState } from 'react';
import { CheckSquare, Droplets, Search, Plus, Timer, Check, CalendarDays, ArrowRight } from 'lucide-react';
import { useApp, blocksForDate } from '@/stores/appStore';
import { useUI, type Screen } from '@/stores/uiStore';
import { Orn } from '@/features/decor/Decor';
import { Badge, Chevron, Group, ListRow, Page, ScreenHeader, SectionTitle, useSettings, useT } from '@/components/common/ui';
import { todayKey, nowMinutes, fmtTime, fmtDate } from '@/utils/date';
import { uid } from '@/utils/id';
import { coreFrom } from '@/services/defaults';
import type { TKey } from '@/services/localization/i18n';

const ROWS: [Screen, TKey, string, string][] = [
  ['calendar', 'm_calendar', 'calendar', 'var(--c-work)'], ['alarms', 'm_alarms', 'alarm_clock', 'var(--danger)'], ['prayer', 'm_prayer', 'mosque', 'var(--c-rest)'], ['journal', 'm_journal', 'notebook', 'var(--c-meal)'],
  ['tasks', 'm_tasks', 'check_mark_button', 'var(--c-work)'], ['projects', 'm_projects', 'clipboard', 'var(--c-custom)'], ['study', 'm_study', 'books', 'var(--c-study)'], ['workouts', 'm_workouts', 'person_running', 'var(--c-exercise)'],
  ['habits', 'm_habits', 'fire', 'var(--c-rest)'], ['wellness', 'm_wellness', 'droplet', 'var(--c-water)'], ['goals', 'm_goals', 'bullseye', 'var(--warning)'], ['notes', 'm_notes', 'memo', 'var(--c-meal)'],
];
const SYS: [Screen, TKey, string, string][] = [
  ['ai_providers', 'ai_providers_title', 'sparkles', 'var(--accent)'],
  ['notifications', 'm_notifications', 'bell', 'var(--danger)'], ['reliability', 'm_reliability', 'locked', 'var(--success)'], ['themes', 'themes_title', 'artist_palette', 'var(--c-sleep)'],
  ['settings', 'm_settings', 'gear', 'var(--ink-2)'], ['history', 'm_history', 'clipboard', 'var(--c-sleep)'], ['backup', 'm_backup', 'ledger', 'var(--info)'], ['about', 'm_about', 'light_bulb', 'var(--ink-3)'],
];

export function MoreScreen() {
  const { t } = useT();
  const ui = useUI();
  const engine = useApp((s) => s.engine);
  const Row = ([id, k, icon, color]: (typeof ROWS)[number]) => (
    <ListRow key={id} onClick={() => ui.push(id)} icon={<span className="grid h-9 w-9 place-items-center rounded-[11px]" style={{ background: `color-mix(in srgb, ${color} 16%, transparent)` }}><Orn name={icon} size={24} /></span>} title={<span className="font-semibold">{t(k)}</span>} trailing={<Chevron className="text-ink-3" />} />
  );
  return (
    <div>
      <ScreenHeader title={t('more_title')} subtitle={t('privacy_note')} />
      <Page>
        <button onClick={() => ui.set({ commandOpen: true })} className="press card flex w-full items-center gap-3 px-4 py-3 text-ink-3"><Search size={18} />{t('search_placeholder')}</button>
        <SectionTitle>{t('modules')}</SectionTitle>
        <div className="stagger"><Group>{ROWS.map(Row)}</Group></div>
        <SectionTitle>{t('m_settings')}</SectionTitle>
        <Group>{SYS.map(Row)}</Group>
        <p className="mt-6 text-center text-xs text-ink-3">{engine === 'sqlite' ? t('platform_android') : t('platform_web')}</p>
      </Page>
    </div>
  );
}

interface Result { id: string; kind: string; title: string; subtitle?: string; run: () => void; }

export function CommandPalette() {
  const open = useUI((s) => s.commandOpen);
  const { t, lang } = useT();
  const s = useSettings();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const [q, setQ] = useState('');
  const close = () => { setQ(''); ui.set({ commandOpen: false }); };

  const commands: Result[] = useMemo(() => {
    const st = useApp.getState();
    const today = todayKey();
    const nm = nowMinutes();
    const cur = blocksForDate(data, today).find((b) => b.status === 'active' || (b.status === 'planned' && b.startMin <= nm && b.startMin + b.durationMin > nm));
    const nxt = blocksForDate(data, today).find((b) => b.status === 'planned' && b.startMin > nm);
    const rest = q.trim();
    const list: Result[] = [];
    if (rest) {
      list.push({ id: 'c-task', kind: 'cmd', title: t('cmd_add_task') + rest, run: async () => { const n = Date.now(); await st.put('tasks', { id: uid('t'), title: rest, description: '', priority: 3, status: 'todo', estimateMin: 30, trackedMin: 0, tags: [], checklist: [], subtasks: [], notes: '', dependsOn: [], starred: false, someday: false, createdAt: n, updatedAt: n }); st.toast('success', t('saved')); close(); } });
      list.push({ id: 'c-act', kind: 'cmd', title: t('cmd_add_activity') + rest, run: () => { close(); ui.openEditor({ date: today, title: rest, startMin: Math.ceil(nm / 15) * 15 }); } });
    }
    list.push({ id: 'c-focus', kind: 'cmd', title: t('cmd_start_focus'), run: () => { close(); ui.setTab('focus'); } });
    list.push({ id: 'c-water', kind: 'cmd', title: t('cmd_log_water'), run: async () => { const n = Date.now(); const ml = s.water.cupSizes[1] ?? 250; await st.put('waterLogs', { id: uid('w'), date: today, ml, at: n, createdAt: n, updatedAt: n }); st.toast('success', t('water_logged', { x: ml })); close(); } });
    if (cur) list.push({ id: 'c-done', kind: 'cmd', title: `${t('cmd_complete_current')}: ${cur.title}`, run: async () => { await st.blockAction(cur.id, 'complete'); st.toast('success', t('saved')); close(); } });
    list.push({ id: 'c-today', kind: 'cmd', title: t('cmd_open_today'), run: () => { close(); ui.setTab('today'); } });
    if (nxt) list.push({ id: 'c-next', kind: 'cmd', title: `${t('cmd_next')}: ${fmtTime(nxt.startMin, lang, s.clock24)} ${nxt.title}`, run: () => { close(); ui.setTab('today'); ui.set({ detailFor: nxt.id }); } });
    void coreFrom;
    return list;
  }, [q, data, s, lang, t, ui]); // eslint-disable-line react-hooks/exhaustive-deps

  const results: Result[] = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (term.length < 2) return [];
    const m = (x?: string) => !!x && x.toLowerCase().includes(term);
    const out: Result[] = [];
    const push = (r: Result) => { if (out.length < 60) out.push(r); };
    for (const b of Object.values(data.activities)) if (m(b.title) || m(b.notes) || b.tags.some(m)) push({ id: b.id, kind: t('timeline'), title: b.title, subtitle: `${fmtDate(b.date, lang, { day: 'numeric', month: 'short' })} · ${fmtTime(b.startMin, lang, s.clock24)}`, run: () => { close(); ui.setTab('today'); ui.set({ detailFor: b.id }); } });
    const go = (scr: Screen) => () => { close(); ui.setTab('more'); ui.push(scr); };
    for (const x of Object.values(data.tasks)) if (m(x.title) || m(x.notes)) push({ id: x.id, kind: t('m_tasks'), title: x.title, subtitle: x.dueDate, run: go('tasks') });
    for (const x of Object.values(data.projects)) if (m(x.title)) push({ id: x.id, kind: t('m_projects'), title: x.title, run: go('projects') });
    for (const x of Object.values(data.subjects)) if (m(x.title)) push({ id: x.id, kind: t('subjects'), title: x.title, run: go('study') });
    for (const x of Object.values(data.lessons)) if (m(x.title)) push({ id: x.id, kind: t('lessons'), title: x.title, run: go('study') });
    for (const x of Object.values(data.notes)) if (m(x.title) || m(x.body)) push({ id: x.id, kind: t('m_notes'), title: x.title || x.body.slice(0, 40), run: go('notes') });
    for (const x of Object.values(data.habits)) if (m(x.name)) push({ id: x.id, kind: t('m_habits'), title: x.name, run: go('habits') });
    for (const x of Object.values(data.workoutPlans)) if (m(x.name)) push({ id: x.id, kind: t('m_workouts'), title: x.name, run: go('workouts') });
    for (const x of Object.values(data.goals)) if (m(x.title)) push({ id: x.id, kind: t('m_goals'), title: x.title, run: go('goals') });
    for (const x of Object.values(data.scheduleChanges)) if (m(x.reason)) push({ id: x.id, kind: t('logs'), title: x.reason, subtitle: x.date, run: go('history') });
    return out;
  }, [q, data, t, lang, s.clock24, ui]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!open) return null;
  const icon = (id: string) => id === 'c-task' ? <CheckSquare size={16} /> : id === 'c-act' ? <Plus size={16} /> : id === 'c-focus' ? <Timer size={16} /> : id === 'c-water' ? <Droplets size={16} /> : id === 'c-done' ? <Check size={16} /> : id === 'c-today' ? <CalendarDays size={16} /> : <ArrowRight size={16} />;
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-bg/95 backdrop-blur-xl anim-fade safe-top" role="dialog" aria-modal="true">
      <div className="mx-auto flex w-full max-w-xl items-center gap-2 px-4 pt-3">
        <div className="flex flex-1 items-center gap-2 rounded-2xl bg-surface-2 px-3"><Search size={18} className="text-ink-3" />
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') (results[0] ?? commands[0])?.run(); if (e.key === 'Escape') close(); }} placeholder={t('search_placeholder')} className="h-12 flex-1 bg-transparent text-[16px] outline-none" />
        </div>
        <button onClick={close} className="text-[15px] font-semibold text-accent">{t('cancel')}</button>
      </div>
      <div className="mx-auto w-full max-w-xl flex-1 overflow-y-auto px-4 pb-10">
        <SectionTitle>{t('commands')}</SectionTitle>
        <Group>{commands.map((c) => <ListRow key={c.id} onClick={c.run} icon={<span className="grid h-8 w-8 place-items-center rounded-[10px] bg-accent-soft text-accent">{icon(c.id)}</span>} title={c.title} />)}</Group>
        {q.trim().length >= 2 && <>
          <SectionTitle>{t('results')}</SectionTitle>
          {results.length ? <Group>{results.map((r) => <ListRow key={r.kind + r.id} onClick={r.run} title={r.title} subtitle={r.subtitle} trailing={<Badge>{r.kind}</Badge>} />)}</Group> : <p className="px-1 text-sm text-ink-3">{t('no_results')}</p>}
        </>}
      </div>
    </div>
  );
}
