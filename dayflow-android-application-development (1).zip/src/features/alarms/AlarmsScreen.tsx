import { useMemo, useState } from 'react';
import { AlarmClock as AlarmIcon, BellRing, Plus, Trash2, SkipForward, Vibrate } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { Badge, Button, Card, Chip, EmptyState, Field, HelpTip, Input, Page, ScreenHeader, Sheet, SRow, Stepper, Toggle, useNow, useSettings, useT, useHaptic, useConfirm } from '@/components/common/ui';
import { Orn } from '@/features/decor/Decor';
import { SoundField, previewSpec } from './SoundPicker';
import type { AlarmClock } from '@/models/types';
import { defaultAlarm, nextRing, ringsIn } from '@/services/alarmClock';
import { DayflowNative, isNative, errorMessage } from '@/services/native/dayflowNative';
import { fmtDate, fmtTime, inputToMin, minToInput, toDateKey, weekdayName } from '@/utils/date';
import { uid } from '@/utils/id';
import { cn } from '@/utils/cn';

export async function ensureNotificationPermission(): Promise<boolean> {
  if (!isNative()) return true;
  try {
    const cur = await DayflowNative.checkNotificationPermission();
    if (cur.state === 'granted') return true;
    const r = await DayflowNative.requestNotificationPermission();
    return r.state === 'granted';
  } catch { return false; }
}

export function AlarmsScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const now = useNow(20000);
  const alarms = useApp((st) => st.data.alarmClocks);
  const caps = useApp((st) => st.caps);
  const [edit, setEdit] = useState<AlarmClock | null>(null);
  const list = useMemo(() => Object.values(alarms).sort((a, b) => a.minute - b.minute), [alarms]);
  const next = useMemo(() => list.map((a) => ({ a, at: nextRing(a, now) })).filter((x) => x.at != null).sort((x, y) => x.at! - y.at!)[0], [list, now]);
  const create = () => { const d = new Date(); const m = (d.getHours() * 60 + d.getMinutes() + 60) % 1440; const t0 = Date.now(); setEdit({ id: uid('al'), ...defaultAlarm(Math.round(m / 5) * 5 % 1440), createdAt: t0, updatedAt: t0 }); };
  const toggle = async (a: AlarmClock) => {
    if (!a.enabled && !(await ensureNotificationPermission())) { useApp.getState().toast('error', t('perm_notif_needed')); }
    await useApp.getState().put('alarmClocks', { ...a, enabled: !a.enabled, skipDate: undefined });
    if (!a.enabled) { const n = nextRing({ ...a, enabled: true, skipDate: undefined }, Date.now()); if (n) useApp.getState().toast('success', ringsIn(n - Date.now(), lang)); }
  };
  const order = [0, 1, 2, 3, 4, 5, 6].map((i) => (s.weekStart + i) % 7);
  const missingPerm = isNative() && caps && caps.notificationPermission !== 'granted';
  return (
    <div>
      <ScreenHeader title={t('m_alarms')} subtitle={next ? ringsIn(next.at! - now, lang) : t('alarms_none_active')} onBack={onBack} actions={<Button size="sm" icon={<Plus size={16} />} onClick={create}>{t('new')}</Button>} />
      <Page>
        {missingPerm && <div className="mb-3 flex items-center gap-3 rounded-2xl bg-warning/12 p-3 text-sm text-warning"><BellRing size={18} /><span className="flex-1">{t('perm_notif_needed')}</span><Button size="sm" onClick={async () => { await ensureNotificationPermission(); useApp.getState().refreshCaps(); }}>{t('perm_allow')}</Button></div>}
        {!isNative() && <p className="mb-3 rounded-2xl bg-warning/12 p-3 text-sm text-warning">{t('alarms_web_note')}</p>}
        {list.length === 0 ? (
          <EmptyState icon={<Orn name="alarm_clock" size={56} />} title={t('alarms_empty_title')} body={t('alarms_empty_body')} action={<Button onClick={create} icon={<Plus size={16} />}>{t('new_alarm')}</Button>} />
        ) : (
          <div className="stagger space-y-3">{list.map((a, i) => {
            const n = nextRing(a, now);
            return (
              <Card key={a.id} className={cn('p-4 transition-opacity', !a.enabled && 'opacity-60')} style={{ ['--i' as string]: i }}>
                <div className="flex items-center gap-3">
                  <button className="min-w-0 flex-1 text-start" onClick={() => setEdit(a)}>
                    <div className="num text-[40px] font-bold leading-none tracking-tight">{fmtTime(a.minute, lang, s.clock24)}</div>
                    <div className="mt-1 truncate text-[15px] font-semibold">{a.label || t('alarm_default_label')}</div>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {a.days.length ? order.map((d) => <span key={d} className={cn('grid h-6 w-6 place-items-center rounded-full text-[10px] font-bold', a.days.includes(d) ? 'bg-accent text-accent-ink' : 'bg-surface-2 text-ink-3')}>{weekdayName(d, lang, 'narrow')}</span>)
                        : <Badge>{a.oneTimeDate ? fmtDate(a.oneTimeDate, lang, { day: 'numeric', month: 'short' }) : t('once')}</Badge>}
                      {a.vibrate && <Vibrate size={14} className="ms-1 mt-1 text-ink-3" />}
                    </div>
                    <div className="mt-2 text-xs text-ink-3">{a.enabled ? (n ? ringsIn(n - now, lang) : t('alarm_no_next')) : t('disabled')}{a.skipDate ? ` · ${t('alarm_skipped')}` : ''}</div>
                  </button>
                  <button role="switch" aria-checked={a.enabled} aria-label={t('enabled')} onClick={() => toggle(a)} className={cn('relative h-[32px] w-[54px] shrink-0 rounded-full transition-colors', a.enabled ? 'bg-success' : 'bg-line')}>
                    <span className={cn('absolute top-[3px] h-[26px] w-[26px] rounded-full bg-white shadow transition-all', a.enabled ? 'start-[25px]' : 'start-[3px]')} />
                  </button>
                </div>
              </Card>
            );
          })}</div>
        )}
      </Page>
      {edit && <AlarmEditor alarm={edit} isNew={!alarms[edit.id]} onClose={() => setEdit(null)} />}
    </div>
  );
}

function AlarmEditor({ alarm, isNew, onClose }: { alarm: AlarmClock; isNew: boolean; onClose: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const { ask, node } = useConfirm();
  const [a, setA] = useState(alarm);
  const up = <K extends keyof AlarmClock>(k: K, v: AlarmClock[K]) => setA((p) => ({ ...p, [k]: v }));
  const order = [0, 1, 2, 3, 4, 5, 6].map((i) => (s.weekStart + i) % 7);
  const preview = nextRing({ ...a, enabled: true }, Date.now());
  const rel = (min: number) => { const d = new Date(Date.now() + min * 60000); up('minute', d.getHours() * 60 + d.getMinutes()); up('days', []); up('oneTimeDate', undefined); };
  const save = async () => {
    if (!(await ensureNotificationPermission())) useApp.getState().toast('error', t('perm_notif_needed'));
    h(14);
    const nextAt = nextRing({ ...a, enabled: true }, Date.now());
    const rec: AlarmClock = { ...a, enabled: true, label: a.label.trim(), oneTimeDate: a.days.length ? undefined : (a.oneTimeDate ?? (nextAt ? toDateKey(new Date(nextAt)) : undefined)) };
    if (await useApp.getState().put('alarmClocks', rec)) { if (nextAt) useApp.getState().toast('success', ringsIn(nextAt - Date.now(), lang)); onClose(); }
  };
  const remove = async () => { if (await ask(t('delete'), a.label || fmtTime(a.minute, lang, s.clock24))) { await useApp.getState().remove('alarmClocks', [a.id]); onClose(); } };
  const test = async () => { try { await previewSpec(a.sound, a.volume, lang, a.label || undefined); } catch (e) { useApp.getState().toast('error', errorMessage(e)); } };
  return (
    <Sheet open onClose={onClose} tall title={isNew ? t('new_alarm') : t('edit_alarm')}
      footer={<div className="flex gap-2">{!isNew && <Button variant="danger" onClick={remove} icon={<Trash2 size={16} />} aria-label={t('delete')} />}<Button variant="secondary" onClick={test} icon={<BellRing size={16} />}>{t('alarm_test')}</Button><Button className="flex-1" onClick={save}>{t('save')}</Button></div>}>
      {node}
      <div className="text-center">
        <input type="time" value={minToInput(a.minute)} onChange={(e) => e.target.value && up('minute', inputToMin(e.target.value))} aria-label={t('time')}
          className="num w-full rounded-3xl bg-surface-2 py-4 text-center text-[56px] font-bold leading-none outline-none focus:bg-surface" />
        <p className="mt-2 min-h-5 text-sm font-semibold text-accent">{preview ? ringsIn(preview - Date.now(), lang) : ''}</p>
        <div className="mt-2 flex justify-center gap-2">{[5, 15, 30, 60].map((m) => <Chip key={m} onClick={() => rel(m)}>{lang === 'ar' ? `بعد ${m} د` : `+${m} min`}</Chip>)}</div>
      </div>
      <div className="mt-5 space-y-4">
        <Field label={<span className="flex items-center gap-1.5">{t('alarm_label')}<HelpTip id="alarm_label" /></span>}><Input value={a.label} onChange={(e) => up('label', e.target.value)} placeholder={t('alarm_label_ph')} maxLength={80} /></Field>
        <Toggle checked={a.speakLabel} onChange={(v) => up('speakLabel', v)} label={t('alarm_speak')} help="tts" />
        <Field label={<span className="flex items-center gap-1.5">{t('alarm_days')}<HelpTip id="alarm_days" /></span>}>
          <div className="flex flex-wrap gap-2">
            {order.map((d) => <Chip key={d} active={a.days.includes(d)} onClick={() => up('days', a.days.includes(d) ? a.days.filter((x) => x !== d) : [...a.days, d].sort())}>{weekdayName(d, lang, 'short')}</Chip>)}
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            <Chip onClick={() => up('days', [0, 1, 2, 3, 4, 5, 6])}>{t('every_day')}</Chip>
            <Chip onClick={() => up('days', [6, 0, 1, 2, 3, 4])}>{t('workdays_eg')}</Chip>
            <Chip onClick={() => up('days', [5, 6])}>{t('weekend_eg')}</Chip>
            <Chip onClick={() => { up('days', []); }}>{t('once')}</Chip>
          </div>
          {!a.days.length && <div className="mt-2"><Input type="date" min={toDateKey(new Date())} value={a.oneTimeDate ?? ''} onChange={(e) => up('oneTimeDate', e.target.value || undefined)} aria-label={t('date')} /></div>}
        </Field>
        <Card className="overflow-hidden"><SoundField value={a.sound} onChange={(v) => up('sound', v)} volume={a.volume} /></Card>
        <Card className="divide-y divide-line">
          <SRow label={t('volume')}><Stepper value={Math.round(a.volume * 100)} onChange={(v) => up('volume', v / 100)} min={10} max={100} step={10} suffix="%" /></SRow>
          <div className="px-4"><Toggle checked={a.gradual} onChange={(v) => up('gradual', v)} label={t('gradual')} help="gradual" /></div>
          <div className="px-4"><Toggle checked={a.vibrate} onChange={(v) => up('vibrate', v)} label={t('vibrate')} /></div>
        </Card>
        <Card className="divide-y divide-line">
          <SRow label={t('snooze_len')} help="snooze"><Stepper value={a.snoozeMin} onChange={(v) => up('snoozeMin', v)} min={1} max={30} suffix={t('min_short')} /></SRow>
          <SRow label={t('max_snoozes')} help="max_snooze"><Stepper value={a.maxSnoozes} onChange={(v) => up('maxSnoozes', v)} min={0} max={10} /></SRow>
          <SRow label={t('ring_len')} help="ring_duration"><Stepper value={a.ringMin} onChange={(v) => up('ringMin', v)} min={1} max={30} suffix={t('min_short')} /></SRow>
        </Card>
        {!isNew && a.enabled && preview && (
          <Button variant="secondary" className="w-full" icon={<SkipForward size={16} />} onClick={() => up('skipDate', a.skipDate ? undefined : toDateKey(new Date(preview)))}>
            {a.skipDate ? t('alarm_unskip') : t('alarm_skip_next')}
          </Button>
        )}
        <p className="flex items-center gap-1.5 px-1 text-xs text-ink-3"><AlarmIcon size={13} />{t('alarm_real_note')}</p>
      </div>
    </Sheet>
  );
}
