import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Capacitor } from '@capacitor/core';
import { Bell, FileAudio, Library, Mic2, Music2, Play, Smartphone, Square, VolumeX, Scissors, ChevronDown } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { Button, HelpTip, Sheet, Stepper, useSettings, useT } from '@/components/common/ui';
import type { SoundSpec } from '@/models/types';
import { DayflowNative, errorCode, isNative, pickFile, previewSound, speak, stopSound } from '@/services/native/dayflowNative';
import { soundName } from '@/services/alarmClock';
import { uid } from '@/utils/id';
import { fmtCountdown } from '@/utils/date';
import { cn } from '@/utils/cn';

export async function previewSpec(spec: SoundSpec, volume: number, lang: 'ar' | 'en', text?: string): Promise<void> {
  if (spec.kind === 'tts') return speak(text ?? (lang === 'ar' ? 'حان وقت المنبه' : 'Time for your alarm'), lang);
  if (spec.kind === 'silent') return;
  if (spec.kind === 'file' && spec.uri) return previewSound(spec.uri, volume, spec.startMs, spec.endMs);
  const path = spec.uri ?? `default:${spec.kind === 'ringtone' ? 'ringtone' : spec.kind === 'notification' ? 'notification' : 'alarm'}`;
  if (!isNative()) throw Object.assign(new Error('UNSUPPORTED'), { code: 'UNSUPPORTED' });
  return previewSound(path, volume);
}

/** A settings row showing the current sound with a preview button and a picker sheet. */
export function SoundField({ value, onChange, label, volume = 1, allowSilent = true }: { value: SoundSpec; onChange: (v: SoundSpec) => void; label?: ReactNode; volume?: number; allowSilent?: boolean }) {
  const { t, lang } = useT();
  const [open, setOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const toggle = async () => {
    if (playing) { await stopSound(); setPlaying(false); return; }
    try { setPlaying(true); await previewSpec(value, volume, lang); } catch (e) { setPlaying(false); useApp.getState().toast('error', errorCode(e) === 'UNSUPPORTED' ? t('native_only') : errorCode(e).startsWith('TTS') ? t('tts_unavailable') : String((e as Error).message)); }
  };
  useEffect(() => () => { stopSound().catch(() => undefined); }, []);
  return (
    <>
      <div className="flex items-center gap-2 px-4 py-3">
        <button onClick={() => setOpen(true)} className="press flex min-w-0 flex-1 items-center gap-3 text-start">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent"><Music2 size={19} /></span>
          <span className="min-w-0 flex-1"><span className="flex items-center gap-1.5 text-[13px] text-ink-3">{label ?? t('sound')}<HelpTip id="ringtone_kinds" /></span><span className="block truncate text-[15px] font-semibold">{soundName(value, lang)}</span></span>
          <ChevronDown size={16} className="text-ink-3" />
        </button>
        <Button size="sm" variant="tinted" aria-label={t('preview_sound')} onClick={toggle}>{playing ? <Square size={14} /> : <Play size={14} />}</Button>
      </div>
      <SoundSheet open={open} onClose={() => setOpen(false)} value={value} allowSilent={allowSilent} onPick={(v) => { onChange(v); setOpen(false); }} volume={volume} />
    </>
  );
}

function SoundSheet({ open, onClose, value, onPick, allowSilent, volume }: { open: boolean; onClose: () => void; value: SoundSpec; onPick: (v: SoundSpec) => void; allowSilent: boolean; volume: number }) {
  const { t, lang } = useT();
  const sounds = useApp((s) => s.data.sounds);
  const [trim, setTrim] = useState<{ path: string; name: string; durationMs: number; size: number; mime: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const fail = (e: unknown) => { if (errorCode(e) !== 'CANCELLED') useApp.getState().toast('error', errorCode(e) === 'UNSUPPORTED' ? t('native_only') : String((e as Error).message ?? e)); };

  const ring = async (type: 'ringtone' | 'alarm' | 'notification') => {
    if (!isNative()) { useApp.getState().toast('info', t('native_only')); return; }
    try { setBusy(true); const r = await DayflowNative.pickRingtone({ type, existingUri: value.uri }); onPick(r.uri ? { kind: type, uri: r.uri, name: r.name } : { kind: type === 'alarm' ? 'default' : type, name: r.name }); } catch (e) { fail(e); } finally { setBusy(false); }
  };
  const music = async () => {
    try {
      setBusy(true);
      if (isNative()) { const r = await DayflowNative.pickMusic(); setTrim({ path: r.path, name: r.name, durationMs: r.durationMs, size: r.size, mime: r.mimeType }); }
      else { const f = await pickFile('audio', 'audio/*'); const dur = await new Promise<number>((res) => { const a = new Audio(f.path); a.onloadedmetadata = () => res(Math.round(a.duration * 1000)); a.onerror = () => res(0); }); setTrim({ path: f.path ?? '', name: f.name, durationMs: dur, size: f.size, mime: f.mimeType }); }
    } catch (e) { fail(e); } finally { setBusy(false); }
  };
  const Opt = ({ icon, title, sub, onClick, active }: { icon: ReactNode; title: string; sub?: string; onClick: () => void; active?: boolean }) => (
    <button onClick={onClick} disabled={busy} className={cn('press flex w-full items-center gap-3 px-4 py-3 text-start disabled:opacity-50', active && 'bg-accent-soft')}>
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-surface-2 text-accent">{icon}</span>
      <span className="min-w-0 flex-1"><span className="block text-[15px] font-semibold">{title}</span>{sub && <span className="block truncate text-xs text-ink-3">{sub}</span>}</span>
    </button>
  );
  return (
    <>
      <Sheet open={open && !trim} onClose={onClose} title={t('sound')} tall>
        <div className="card divide-y divide-line overflow-hidden">
          <Opt icon={<Bell size={19} />} title={t('snd_alarm_default')} onClick={() => onPick({ kind: 'default' })} active={value.kind === 'default'} />
          <Opt icon={<Smartphone size={19} />} title={t('snd_phone_ringtone')} sub={t('snd_system_picker')} onClick={() => ring('ringtone')} active={value.kind === 'ringtone'} />
          <Opt icon={<Bell size={19} />} title={t('snd_alarm_tone')} sub={t('snd_system_picker')} onClick={() => ring('alarm')} active={value.kind === 'alarm'} />
          <Opt icon={<Bell size={19} />} title={t('snd_notif_tone')} sub={t('snd_system_picker')} onClick={() => ring('notification')} active={value.kind === 'notification'} />
          <Opt icon={<FileAudio size={19} />} title={t('snd_music')} sub={t('snd_music_sub')} onClick={music} active={value.kind === 'file'} />
          <Opt icon={<Mic2 size={19} />} title={t('snd_tts')} sub={t('tts_hint')} onClick={() => onPick({ kind: 'tts' })} active={value.kind === 'tts'} />
          {allowSilent && <Opt icon={<VolumeX size={19} />} title={t('snd_silent')} onClick={() => onPick({ kind: 'silent' })} active={value.kind === 'silent'} />}
        </div>
        {Object.keys(sounds).length > 0 && (
          <>
            <h3 className="mb-2 mt-5 flex items-center gap-2 text-[13px] font-semibold uppercase text-ink-3"><Library size={14} />{t('sounds_library')}</h3>
            <div className="card divide-y divide-line overflow-hidden">
              {Object.values(sounds).map((x) => <Opt key={x.id} icon={<Music2 size={19} />} title={x.name} sub={x.startMs != null ? `${Math.round((x.startMs ?? 0) / 1000)}–${Math.round((x.endMs ?? 0) / 1000)}s` : undefined}
                onClick={() => onPick({ kind: 'file', uri: x.path, name: x.name, startMs: x.startMs, endMs: x.endMs, durationMs: x.durationMs })} active={value.uri === x.path} />)}
            </div>
          </>
        )}
        <p className="mt-4 text-xs text-ink-3">{lang === 'ar' ? 'القص مبيغيّرش الملف الأصلي — بيتحفظ بس مكان البداية والنهاية.' : 'Trimming never changes the original file.'}</p>
      </Sheet>
      {trim && <TrimSheet file={trim} volume={volume} onClose={() => setTrim(null)} onDone={async (spec) => {
        const n = Date.now();
        await useApp.getState().put('sounds', { id: uid('snd'), name: trim.name, path: trim.path, mimeType: trim.mime, size: trim.size, startMs: spec.startMs, endMs: spec.endMs, durationMs: trim.durationMs, origin: 'file', createdAt: n, updatedAt: n });
        setTrim(null); onPick(spec);
      }} />}
    </>
  );
}

function useWaveform(src: string, bars: number) {
  const [peaks, setPeaks] = useState<number[] | null>(null);
  useEffect(() => {
    let dead = false;
    (async () => {
      try {
        const buf = await (await fetch(src)).arrayBuffer();
        const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new Ctx();
        const audio = await ctx.decodeAudioData(buf);
        const ch = audio.getChannelData(0); const step = Math.max(1, Math.floor(ch.length / bars));
        const out: number[] = [];
        for (let i = 0; i < bars; i++) { let m = 0; for (let j = i * step; j < Math.min(ch.length, (i + 1) * step); j += 40) m = Math.max(m, Math.abs(ch[j])); out.push(m); }
        const mx = Math.max(0.001, ...out);
        ctx.close().catch(() => undefined);
        if (!dead) setPeaks(out.map((v) => v / mx));
      } catch { if (!dead) setPeaks([]); }
    })();
    return () => { dead = true; };
  }, [src, bars]);
  return peaks;
}

/** Non-destructive audio trimming: pick the start/end of the played segment on a real waveform. */
export function TrimSheet({ file, volume, onClose, onDone }: { file: { path: string; name: string; durationMs: number }; volume: number; onClose: () => void; onDone: (s: SoundSpec) => void }) {
  const { t, lang } = useT();
  const dur = Math.max(1000, file.durationMs || 30000);
  const [start, setStart] = useState(0);
  const [end, setEnd] = useState(Math.min(dur, 30000));
  const [playing, setPlaying] = useState(false);
  const src = useMemo(() => (isNative() ? Capacitor.convertFileSrc(file.path) : file.path), [file.path]);
  const peaks = useWaveform(src, 96);
  const box = useRef<HTMLDivElement>(null);
  const drag = useRef<'s' | 'e' | null>(null);
  const toMs = (x: number) => { const r = box.current!.getBoundingClientRect(); return Math.max(0, Math.min(dur, ((x - r.left) / r.width) * dur)); };
  const move = (x: number) => { const ms = Math.round(toMs(x) / 100) * 100; if (drag.current === 's') setStart(Math.min(ms, end - 1000)); else if (drag.current === 'e') setEnd(Math.max(ms, start + 1000)); };
  useEffect(() => () => { stopSound().catch(() => undefined); }, []);
  const play = async () => {
    if (playing) { await stopSound(); setPlaying(false); return; }
    try { setPlaying(true); await previewSound(file.path, volume, start, end); setTimeout(() => setPlaying(false), end - start + 300); } catch (e) { setPlaying(false); useApp.getState().toast('error', String((e as Error).message ?? e)); }
  };
  const pct = (ms: number) => `${(ms / dur) * 100}%`;
  return (
    <Sheet open onClose={onClose} tall title={<span className="flex items-center gap-2"><Scissors size={18} />{t('trim_title')}</span>}
      footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={onClose}>{t('cancel')}</Button><Button className="flex-[2]" onClick={() => { stopSound().catch(() => undefined); onDone({ kind: 'file', uri: file.path, name: file.name, startMs: start, endMs: end, durationMs: dur }); }}>{t('use_this_part')}</Button></div>}>
      <p className="mb-1 truncate text-[15px] font-semibold">{file.name}</p>
      <p className="mb-3 flex items-center gap-1.5 text-xs text-ink-3">{t('trim_hint')}<HelpTip id="trim" /></p>
      <div ref={box} dir="ltr" className="relative h-28 touch-none select-none overflow-hidden rounded-2xl bg-surface-2"
        onPointerMove={(e) => drag.current && move(e.clientX)} onPointerUp={() => { drag.current = null; }} onPointerCancel={() => { drag.current = null; }} onPointerLeave={() => { drag.current = null; }}>
        <div className="absolute inset-0 flex items-center gap-[2px] px-1">
          {(peaks && peaks.length ? peaks : Array.from({ length: 96 }, (_, i) => 0.25 + 0.2 * Math.sin(i / 3))).map((p, i, a) => {
            const at = (i / a.length) * dur; const inside = at >= start && at <= end;
            return <span key={i} className="flex-1 rounded-full transition-colors" style={{ height: `${Math.max(8, p * 90)}%`, background: inside ? 'var(--accent)' : 'var(--ink-3)', opacity: inside ? 1 : 0.35 }} />;
          })}
        </div>
        <div className="absolute inset-y-0 bg-accent/10" style={{ left: pct(start), width: pct(end - start) }} />
        {(['s', 'e'] as const).map((k) => (
          <div key={k} role="slider" aria-label={k === 's' ? t('start') : t('end')} aria-valuenow={Math.round((k === 's' ? start : end) / 1000)} className="absolute inset-y-0 z-10 w-6 -translate-x-1/2 cursor-ew-resize" style={{ left: pct(k === 's' ? start : end) }}
            onPointerDown={(e) => { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); drag.current = k; }}>
            <span className="absolute inset-y-0 start-1/2 w-1 -translate-x-1/2 rounded-full bg-accent" /><span className="absolute top-1/2 start-1/2 h-7 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-bg bg-accent" />
          </div>
        ))}
      </div>
      <div className="mt-2 flex justify-between text-xs text-ink-3 num"><span>0:00</span><span>{fmtCountdown(dur, lang)}</span></div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="card p-3"><div className="mb-1 text-xs text-ink-3">{t('start')}</div><div className="num mb-2 text-xl font-bold">{fmtCountdown(start, lang)}</div><Stepper value={Math.round(start / 1000)} onChange={(v) => setStart(Math.min(v * 1000, end - 1000))} min={0} max={Math.floor(dur / 1000)} suffix="s" /></div>
        <div className="card p-3"><div className="mb-1 text-xs text-ink-3">{t('end')}</div><div className="num mb-2 text-xl font-bold">{fmtCountdown(end, lang)}</div><Stepper value={Math.round(end / 1000)} onChange={(v) => setEnd(Math.max(v * 1000, start + 1000))} min={1} max={Math.ceil(dur / 1000)} suffix="s" /></div>
      </div>
      <div className="mt-4 flex items-center justify-between rounded-2xl bg-accent-soft px-4 py-3"><span className="text-sm font-semibold text-accent">{t('trim_length')}</span><span className="num text-lg font-bold text-accent">{fmtCountdown(end - start, lang)}</span></div>
      <Button className="mt-4 w-full" size="lg" variant={playing ? 'danger' : 'secondary'} icon={playing ? <Square size={16} /> : <Play size={16} />} onClick={play}>{playing ? t('stop') : t('trim_play')}</Button>
    </Sheet>
  );
}
export const useVolume = () => useSettings().volume;
