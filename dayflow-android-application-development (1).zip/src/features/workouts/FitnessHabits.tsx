import { useEffect, useMemo, useState } from 'react';
import { Plus, Play, Check, Trash2, Repeat, Pause as PauseIc, Dumbbell, Info } from 'lucide-react';
import { useApp, blocksForDate, instantiate } from '@/stores/appStore';
import { Badge, Button, Card, Chip, EmptyState, Field, Input, Page, ProgressRing, ScreenHeader, SectionTitle, Segmented, Select, Sheet, Stepper, TextArea, useHaptic, useSettings, useT } from '@/components/common/ui';
import { Heatmap, LineChart } from '@/components/charts/Charts';
import type { Habit, WorkoutPlan, WorkoutLog, WorkoutRunState, Exercise } from '@/models/types';
import { addDays, fmtCountdown, fmtDate, fmtNumber, minToInput, inputToMin, todayKey, weekday, weekdayName, startOfWeek, rangeKeys, nowMinutes } from '@/utils/date';
import { uid } from '@/utils/id';
import { speak } from '@/services/native/dayflowNative';
import { habitStats } from '@/services/analytics/stats';
import { coreFrom } from '@/services/defaults';
import { cn } from '@/utils/cn';
import { freeSlots } from '@/services/scheduling/engine';
import { toSched } from '@/components/cards/blocks';

export function WorkoutsScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [tab, setTab] = useState<'plans' | 'exercises' | 'history' | 'metrics'>('plans');
  const [edit, setEdit] = useState<WorkoutPlan | null>(null);
  const [exEdit, setExEdit] = useState<Exercise | null>(null);
  const [missed, setMissed] = useState<WorkoutPlan | null>(null);
  const run = data.state.workoutRun as WorkoutRunState | undefined;
  const today = todayKey();
  const newPlan = () => { const n = Date.now(); setEdit({ id: uid('wp'), name: '', weekdays: [weekday(today)], startMin: 18 * 60, exercises: [], notes: '', light: false, createdAt: n, updatedAt: n }); };
  const startWorkout = async (p: WorkoutPlan) => {
    const n = Date.now();
    const log: WorkoutLog = { id: uid('wl'), planId: p.id, date: today, startedAt: n, sets: [], notes: '', status: 'in_progress', createdAt: n, updatedAt: n };
    await useApp.getState().commit({ workoutLogs: [log], state: [{ id: 'workoutRun', logId: log.id, exerciseIndex: 0, setIndex: 0, restEndsAt: null, createdAt: n, updatedAt: n }] });
  };
  if (run?.logId && data.workoutLogs[run.logId]?.status === 'in_progress') return <WorkoutRun run={run} />;
  const logs = Object.values(data.workoutLogs).sort((a, b) => b.startedAt - a.startedAt);
  const weekStart = startOfWeek(today, s.weekStart);
  return (
    <div>
      <ScreenHeader title={t('m_workouts')} onBack={onBack} actions={tab === 'plans' ? <Button size="sm" icon={<Plus size={15} />} onClick={newPlan}>{t('new_plan')}</Button> : tab === 'exercises' ? <Button size="sm" icon={<Plus size={15} />} onClick={() => { const n = Date.now(); setExEdit({ id: uid('ex'), name: '', category: 'strength', equipment: '', muscles: [], instructions: '', createdAt: n, updatedAt: n }); }}>{t('new_exercise')}</Button> : undefined} />
      <Page>
        <Segmented value={tab} onChange={setTab} size="sm" options={[{ value: 'plans', label: t('plans') }, { value: 'exercises', label: t('exercises') }, { value: 'history', label: t('workout_history') }, { value: 'metrics', label: t('body_metrics').split(' ')[0] }]} />
        <p className="mt-3 flex gap-2 rounded-2xl bg-info/10 p-3 text-xs text-info"><Info size={15} className="shrink-0" />{t('health_note')}</p>
        {tab === 'plans' && (
          <div className="mt-3 space-y-2">
            {!Object.keys(data.workoutPlans).length && <EmptyState icon={<Dumbbell size={28} />} title={t('empty_generic')} action={<Button onClick={newPlan}>{t('new_plan')}</Button>} />}
            {Object.values(data.workoutPlans).map((p) => {
              const doneThisWeek = logs.filter((l) => l.planId === p.id && l.date >= weekStart && l.status === 'completed').map((l) => weekday(l.date));
              const missedDays = p.weekdays.filter((d) => { const k = rangeKeys(weekStart, 7).find((x) => weekday(x) === d)!; return k < today && !doneThisWeek.includes(d); });
              return (
                <Card key={p.id} className="p-4">
                  <div className="flex items-center justify-between"><button className="text-start" onClick={() => setEdit(p)}><div className="text-[16px] font-semibold">{p.name}{p.light && <Badge className="ms-2">{t('light_plan')}</Badge>}</div><div className="text-xs text-ink-3">{p.weekdays.map((d) => weekdayName(d, lang)).join(' · ')} · {fmtNumber(p.exercises.length, lang)} {t('exercises')}</div></button>
                    <Button size="sm" icon={<Play size={14} />} onClick={() => startWorkout(p)} disabled={!p.exercises.length}>{t('start_workout')}</Button></div>
                  <div className="mt-2 flex gap-1">{p.weekdays.map((d) => <span key={d} className={cn('rounded-full px-2 py-0.5 text-[11px] font-semibold', doneThisWeek.includes(d) ? 'bg-success/15 text-success' : missedDays.includes(d) ? 'bg-warning/15 text-warning' : 'bg-surface-2 text-ink-2')}>{weekdayName(d, lang, 'narrow')}</span>)}</div>
                  {missedDays.length > 0 && <Button size="sm" variant="tinted" className="mt-2" onClick={() => setMissed(p)}>{t('missed_workout')}</Button>}
                </Card>
              );
            })}
          </div>
        )}
        {tab === 'exercises' && <Card className="mt-3 divide-y divide-line">{Object.values(data.exercises).map((e) => {
          const hist = logs.flatMap((l) => l.sets.filter((x) => x.exerciseId === e.id));
          return <button key={e.id} onClick={() => setExEdit(e)} className="flex w-full items-center justify-between p-3 text-start"><div><div className="text-[15px] font-medium">{e.name}</div><div className="text-xs text-ink-3">{e.category}{e.muscles.length ? ` · ${e.muscles.join(', ')}` : ''}</div></div><Badge>{fmtNumber(hist.length, lang)} {t('sets')}</Badge></button>;
        })}</Card>}
        {tab === 'history' && <Card className="mt-3 divide-y divide-line">{logs.length ? logs.slice(0, 40).map((l) => <div key={l.id} className="flex items-center justify-between p-3 text-sm"><span>{data.workoutPlans[l.planId]?.name ?? '—'} · {fmtDate(l.date, lang, { day: 'numeric', month: 'short' })}</span><span className="flex gap-1"><Badge>{fmtNumber(l.sets.length, lang)} {t('sets')}</Badge><Badge tone={l.status === 'completed' ? 'success' : 'neutral'}>{t(l.status === 'completed' ? 'completed' : 'st_partial')}</Badge></span></div>) : <p className="p-3 text-sm text-ink-3">{t('empty_generic')}</p>}</Card>}
        {tab === 'metrics' && <Metrics />}
      </Page>
      {edit && <PlanSheet plan={edit} onClose={() => setEdit(null)} />}
      {exEdit && <ExerciseSheet ex={exEdit} onClose={() => setExEdit(null)} />}
      {missed && <MissedSheet plan={missed} onClose={() => setMissed(null)} />}
    </div>
  );
}

function Metrics() {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [kind, setKind] = useState('weight'); const [value, setValue] = useState(''); const [unit, setUnit] = useState('kg');
  const list = Object.values(data.bodyMetrics).filter((m) => m.kind === kind).sort((a, b) => a.date.localeCompare(b.date));
  const max = Math.max(1, ...list.map((m) => m.value)) * 1.1;
  return (
    <>
      <Card className="mt-3 space-y-3 p-4">
        <div className="grid grid-cols-3 gap-2"><Input value={kind} onChange={(e) => setKind(e.target.value)} aria-label={t('name')} /><Input inputMode="decimal" value={value} onChange={(e) => setValue(e.target.value)} aria-label={t('value')} placeholder={t('value')} /><Input value={unit} onChange={(e) => setUnit(e.target.value)} aria-label={t('unit')} /></div>
        <Button className="w-full" disabled={!Number(value)} onClick={async () => { const n = Date.now(); await useApp.getState().put('bodyMetrics', { id: uid('bm'), date: todayKey(), kind, value: Number(value), unit, createdAt: n, updatedAt: n }); setValue(''); }}>{t('add')}</Button>
      </Card>
      {list.length > 1 && <Card className="mt-3 p-4"><LineChart points={list.map((m) => m.value)} labels={list.map((m) => m.date.slice(5))} max={max} suffix={` ${unit}`} /></Card>}
      <Card className="mt-3 divide-y divide-line">{list.slice().reverse().map((m) => <div key={m.id} className="flex justify-between p-3 text-sm"><span>{fmtDate(m.date, lang, { day: 'numeric', month: 'short' })}</span><span className="num">{fmtNumber(m.value, lang, 1)} {m.unit}</span></div>)}</Card>
    </>
  );
}

function PlanSheet({ plan, onClose }: { plan: WorkoutPlan; onClose: () => void }) {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [p, setP] = useState(plan);
  const [exId, setExId] = useState(Object.keys(data.exercises)[0] ?? '');
  const exists = !!data.workoutPlans[p.id];
  return (
    <Sheet open onClose={onClose} tall title={p.name || t('new_plan')} footer={<div className="flex gap-2">{exists && <Button variant="danger" onClick={async () => { await useApp.getState().remove('workoutPlans', [p.id]); onClose(); }} icon={<Trash2 size={15} />} />}<Button className="flex-1" disabled={!p.name.trim()} onClick={async () => { await useApp.getState().put('workoutPlans', { ...p, name: p.name.trim() }); onClose(); }}>{t('save')}</Button></div>}>
      <div className="space-y-4">
        <Field label={t('name')}><Input value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} /></Field>
        <div className="flex flex-wrap gap-1.5">{[0, 1, 2, 3, 4, 5, 6].map((d) => <Chip key={d} active={p.weekdays.includes(d)} onClick={() => setP({ ...p, weekdays: p.weekdays.includes(d) ? p.weekdays.filter((x) => x !== d) : [...p.weekdays, d].sort() })}>{weekdayName(d, lang)}</Chip>)}</div>
        <Field label={t('start')}><Input type="time" value={minToInput(p.startMin)} onChange={(e) => setP({ ...p, startMin: inputToMin(e.target.value) })} /></Field>
        {p.exercises.map((we, i) => (
          <Card key={we.id} className="space-y-2 p-3">
            <div className="flex items-center justify-between"><span className="font-semibold">{data.exercises[we.exerciseId]?.name}</span><button onClick={() => setP({ ...p, exercises: p.exercises.filter((_, j) => j !== i) })} aria-label={t('delete')}><Trash2 size={15} className="text-ink-3" /></button></div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <label className="flex items-center justify-between gap-1">{t('sets')}<Stepper value={we.sets} onChange={(v) => setP({ ...p, exercises: p.exercises.map((x, j) => j === i ? { ...x, sets: v } : x) })} min={1} max={20} /></label>
              <label className="flex items-center justify-between gap-1">{t('reps')}<Stepper value={we.reps} onChange={(v) => setP({ ...p, exercises: p.exercises.map((x, j) => j === i ? { ...x, reps: v } : x) })} min={1} max={200} /></label>
              <label className="flex items-center justify-between gap-1">{t('rest_sec')}<Stepper value={we.restSec} onChange={(v) => setP({ ...p, exercises: p.exercises.map((x, j) => j === i ? { ...x, restSec: v } : x) })} min={0} max={600} step={15} /></label>
              <label className="flex items-center justify-between gap-1">{t('load')}<Stepper value={we.load ?? 0} onChange={(v) => setP({ ...p, exercises: p.exercises.map((x, j) => j === i ? { ...x, load: v || undefined } : x) })} min={0} max={500} step={2.5} /></label>
            </div>
          </Card>
        ))}
        <div className="flex gap-2"><Select value={exId} onChange={setExId} options={Object.values(data.exercises).map((e) => ({ value: e.id, label: e.name }))} /><Button variant="secondary" disabled={!exId} onClick={() => setP({ ...p, exercises: [...p.exercises, { id: uid(), exerciseId: exId, sets: 3, reps: 10, restSec: 60, note: '' }] })}><Plus size={16} /></Button></div>
        <Field label={t('notes')}><TextArea value={p.notes} onChange={(e) => setP({ ...p, notes: e.target.value })} /></Field>
      </div>
    </Sheet>
  );
}

function ExerciseSheet({ ex, onClose }: { ex: Exercise; onClose: () => void }) {
  const { t } = useT(); const [e, setE] = useState(ex);
  return (
    <Sheet open onClose={onClose} title={e.name || t('new_exercise')} footer={<Button className="w-full" disabled={!e.name.trim()} onClick={async () => { await useApp.getState().put('exercises', e); onClose(); }}>{t('save')}</Button>}>
      <div className="space-y-4">
        <Field label={t('name')}><Input value={e.name} onChange={(v) => setE({ ...e, name: v.target.value })} /></Field>
        <Field label={t('category')}><Input value={e.category} onChange={(v) => setE({ ...e, category: v.target.value })} /></Field>
        <Field label={t('equipment')}><Input value={e.equipment} onChange={(v) => setE({ ...e, equipment: v.target.value })} /></Field>
        <Field label={t('muscles')}><Input value={e.muscles.join(', ')} onChange={(v) => setE({ ...e, muscles: v.target.value.split(/[,،]/).map((x) => x.trim()).filter(Boolean) })} /></Field>
        <Field label={t('instructions')}><TextArea value={e.instructions} onChange={(v) => setE({ ...e, instructions: v.target.value })} /></Field>
      </div>
    </Sheet>
  );
}

function MissedSheet({ plan, onClose }: { plan: WorkoutPlan; onClose: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [choice, setChoice] = useState<'tomorrow' | 'week' | 'skip' | 'light'>('tomorrow');
  const duration = Math.max(20, plan.exercises.reduce((a, e) => a + e.sets * (1 + e.restSec / 60), 0));
  const preview = useMemo(() => {
    const tomorrow = addDays(todayKey(), 1);
    const weekEnd = addDays(startOfWeek(todayKey(), s.weekStart), 6);
    const candidates = choice === 'tomorrow' ? [tomorrow] : choice === 'week' ? rangeKeys(tomorrow, Math.max(0, Math.round((new Date(weekEnd).getTime() - new Date(tomorrow).getTime()) / 86400000)) + 1) : choice === 'light' ? [tomorrow] : [];
    const dur = choice === 'light' ? Math.round(duration / 2) : Math.round(duration);
    for (const d of candidates) {
      const pref = freeSlots(blocksForDate(data, d).map(toSched), Math.max(plan.startMin, d === todayKey() ? nowMinutes() : 0), s.dayEndMin, dur)[0] ?? freeSlots(blocksForDate(data, d).map(toSched), s.dayStartMin, s.dayEndMin, dur)[0];
      if (pref) return { date: d, startMin: pref[0], durationMin: dur };
    }
    return null;
  }, [choice, data, plan, s, duration]);
  const apply = async () => {
    if (choice === 'skip') { onClose(); return; }
    if (!preview) return;
    const b = instantiate(coreFrom({ title: choice === 'light' ? `${plan.name} · ${t('light_plan')}` : plan.name, categoryId: 'cat_exercise', startMin: preview.startMin, durationMin: preview.durationMin, workoutPlanId: plan.id }), preview.date, { source: 'catchup' });
    if (await useApp.getState().commit({ activities: [b] })) useApp.getState().toast('success', t('applied'));
    onClose();
  };
  return (
    <Sheet open onClose={onClose} title={t('missed_workout')} footer={<Button className="w-full" onClick={apply} disabled={choice !== 'skip' && !preview}>{t('apply')}</Button>}>
      <Segmented value={choice} onChange={setChoice} size="sm" options={[{ value: 'tomorrow', label: t('move_tomorrow') }, { value: 'week', label: t('reschedule_week') }, { value: 'light', label: t('lighter_session') }, { value: 'skip', label: t('act_skip') }]} />
      <Card className="mt-4 p-4 text-sm">{choice === 'skip' ? t('alt_leave') : preview ? <><div className="font-semibold">{t('preview')}</div><div className="num mt-1">{fmtDate(preview.date, lang)} · {minToInput(preview.startMin)} · {fmtNumber(preview.durationMin, lang)} {t('min_short')}</div></> : t('no_slot')}</Card>
    </Sheet>
  );
}

function WorkoutRun({ run }: { run: WorkoutRunState }) {
  const { t, lang } = useT();
  const h = useHaptic();
  const data = useApp((s) => s.data);
  const log = data.workoutLogs[run.logId!];
  const plan = data.workoutPlans[log.planId];
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 500); return () => clearInterval(id); }, []);
  const we = plan.exercises[run.exerciseIndex];
  const ex = we ? data.exercises[we.exerciseId] : undefined;
  const restLeft = run.restEndsAt ? run.restEndsAt - now : 0;
  useEffect(() => { if (run.restEndsAt && restLeft <= 0 && restLeft > -1500) { h([40, 80, 40]); speak(t('ph_work'), lang).catch(() => undefined); } }, [restLeft > 0]); // eslint-disable-line react-hooks/exhaustive-deps
  const prev = Object.values(data.workoutLogs).filter((l) => l.planId === plan.id && l.id !== log.id && l.status === 'completed').sort((a, b) => b.startedAt - a.startedAt)[0];
  const prevSets = prev?.sets.filter((x) => x.exerciseId === we?.exerciseId) ?? [];
  const setRun = (p: Partial<WorkoutRunState>) => useApp.getState().put('state', { ...run, ...p });
  const completeSet = async () => {
    if (!we) return;
    h(14);
    const sets = [...log.sets, { exerciseId: we.exerciseId, setIndex: run.setIndex, reps: we.reps, load: we.load, completedAt: Date.now() }];
    await useApp.getState().put('workoutLogs', { ...log, sets });
    const lastSet = run.setIndex + 1 >= we.sets;
    const nextEx = lastSet ? run.exerciseIndex + 1 : run.exerciseIndex;
    await setRun({ setIndex: lastSet ? 0 : run.setIndex + 1, exerciseIndex: nextEx, restEndsAt: we.restSec ? Date.now() + we.restSec * 1000 : null });
    if (we.restSec) speak(`${t('rest')} ${we.restSec}`, lang).catch(() => undefined);
  };
  const finish = async (status: WorkoutLog['status']) => {
    await useApp.getState().commit({ workoutLogs: [{ ...log, status, endedAt: Date.now() }] }, { state: ['workoutRun'] });
  };
  const doneSets = log.sets.length, totalSets = plan.exercises.reduce((a, e) => a + e.sets, 0);
  return (
    <div>
      <ScreenHeader title={plan.name} subtitle={`${fmtNumber(doneSets, lang)} / ${fmtNumber(totalSets, lang)} ${t('sets')}`} />
      <Page>
        {we && ex ? (
          <Card className="mt-2 flex flex-col items-center p-6 text-center">
            <h2 className="text-[24px] font-bold">{ex.name}</h2>
            <p className="mt-1 text-ink-2">{t('current_set', { a: fmtNumber(run.setIndex + 1, lang), b: fmtNumber(we.sets, lang) })} · {fmtNumber(we.reps, lang)} {t('reps')}{we.load ? ` · ${fmtNumber(we.load, lang)}` : ''}</p>
            {restLeft > 0 ? (
              <div className="my-6"><ProgressRing value={(restLeft / ((we.restSec || 1) * 1000)) * 100} size={180} stroke={10} color="var(--c-rest)"><div><div className="num text-4xl font-bold">{fmtCountdown(restLeft, lang)}</div><div className="text-sm text-ink-3">{t('rest')}</div></div></ProgressRing>
                <Button variant="secondary" className="mt-4" onClick={() => setRun({ restEndsAt: null })}>{t('skip_rest')}</Button></div>
            ) : <Button size="lg" className="my-6 w-48" icon={<Check size={18} />} onClick={completeSet}>{t('complete_set')}</Button>}
            {ex.instructions && <p className="text-sm text-ink-2">{ex.instructions}</p>}
            {prevSets.length > 0 && <p className="mt-3 text-xs text-ink-3">{t('previous_result')}: {prevSets.map((x) => `${x.reps}${x.load ? `×${x.load}` : ''}`).join(' · ')}</p>}
          </Card>
        ) : <EmptyState icon={<Check size={28} />} title={t('finish_workout')} />}
        <div className="mt-4 flex gap-2"><Button variant="secondary" className="flex-1" icon={<PauseIc size={15} />} onClick={() => finish('abandoned')}>{t('end_session')}</Button><Button className="flex-1" onClick={() => finish('completed')}>{t('finish_workout')}</Button></div>
      </Page>
    </div>
  );
}

// ======================================================================== habits

export function HabitsScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const data = useApp((st) => st.data);
  const [edit, setEdit] = useState<Habit | null>(null);
  const [detail, setDetail] = useState<Habit | null>(null);
  const today = todayKey();
  const logs = Object.values(data.habitLogs);
  const logFor = (hid: string, d = today) => logs.find((l) => l.habitId === hid && l.date === d);
  const setValue = async (hb: Habit, value: number, skipped = false) => {
    h(10);
    const ex = logFor(hb.id); const n = Date.now();
    await useApp.getState().put('habitLogs', ex ? { ...ex, value, skipped } : { id: uid('hl'), habitId: hb.id, date: today, value, note: '', skipped, createdAt: n, updatedAt: n });
  };
  const create = () => { const n = Date.now(); setEdit({ id: uid('h'), name: '', icon: 'star', color: 'var(--c-rest)', category: 'personal', kind: 'check', frequency: 'daily', weekdays: [0, 1, 2, 3, 4, 5, 6], timesPerWeek: 3, target: 1, unit: '', notes: '', archived: false, createdAt: n, updatedAt: n }); };
  const habits = Object.values(data.habits).filter((x) => !x.archived);
  return (
    <div>
      <ScreenHeader title={t('m_habits')} subtitle={t('habit_kind_note')} onBack={onBack} actions={<Button size="sm" icon={<Plus size={15} />} onClick={create}>{t('new_habit')}</Button>} />
      <Page>
        {!habits.length && <EmptyState icon={<Repeat size={28} />} title={t('empty_generic')} action={<Button onClick={create}>{t('new_habit')}</Button>} />}
        <div className="space-y-2">{habits.map((hb) => {
          const st = habitStats(hb, logs, s.weekStart);
          const lg = logFor(hb.id);
          const paused = hb.pausedUntil && today <= hb.pausedUntil;
          const done = hb.kind === 'avoid' ? false : (lg?.value ?? 0) >= Math.max(1, hb.target);
          return (
            <Card key={hb.id} className="p-4">
              <div className="flex items-center gap-3">
                <button className="min-w-0 flex-1 text-start" onClick={() => setDetail(hb)}><div className="text-[16px] font-semibold">{hb.name}</div>
                  <div className="text-xs text-ink-3">{paused ? t('paused_until', { d: fmtDate(hb.pausedUntil!, lang, { day: 'numeric', month: 'short' }) }) : `${t('streak')}: ${fmtNumber(st.current, lang)} · ${t('rate')}: ${st.rate == null ? '—' : fmtNumber(st.rate, lang) + '%'}`}{hb.frequency === 'weekly' ? ` · ${fmtNumber(st.weekCount, lang)}/${fmtNumber(hb.timesPerWeek, lang)}` : ''}</div></button>
                {hb.kind === 'check' && <button aria-label={t('done')} onClick={() => setValue(hb, done ? 0 : 1)} className={cn('press grid h-11 w-11 place-items-center rounded-2xl', done ? 'bg-success text-white' : 'bg-surface-2 text-ink-3')}><Check size={20} /></button>}
                {(hb.kind === 'numeric' || hb.kind === 'timed' || hb.kind === 'avoid') && <Stepper value={lg?.value ?? 0} onChange={(v) => setValue(hb, v)} min={0} max={100000} step={hb.kind === 'timed' ? 5 : 1} suffix={hb.unit || (hb.kind === 'timed' ? t('min_short') : '')} />}
              </div>
              {!paused && !lg && <button className="mt-2 text-xs font-semibold text-ink-3" onClick={() => setValue(hb, 0, true)}>{t('pause_habit')} ({t('today')})</button>}
            </Card>
          );
        })}</div>
      </Page>
      {edit && <HabitSheet habit={edit} onClose={() => setEdit(null)} />}
      {detail && (
        <Sheet open onClose={() => setDetail(null)} title={detail.name} footer={<div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => { setEdit(detail); setDetail(null); }}>{t('edit')}</Button><Button variant="secondary" className="flex-1" onClick={async () => { await useApp.getState().put('habits', { ...detail, pausedUntil: addDays(today, 7) }); setDetail(null); }}>{t('pause_habit')} 7</Button></div>}>
          {(() => { const st = habitStats(detail, logs, s.weekStart); return (<>
            <div className="grid grid-cols-3 gap-2 text-center">{[[t('streak'), st.current], [t('longest'), st.longest], [t('rate'), st.rate == null ? '—' : `${st.rate}%`]].map(([a, b]) => <Card key={String(a)} className="p-3"><div className="num text-xl font-bold">{typeof b === 'number' ? fmtNumber(b, lang) : b}</div><div className="text-[11px] text-ink-3">{a}</div></Card>)}</div>
            <SectionTitle>{t('heatmap')}</SectionTitle><Card className="p-3"><Heatmap cells={st.heat} color={detail.color} /></Card>
            <SectionTitle>{t('history')}</SectionTitle><Card className="divide-y divide-line">{logs.filter((l) => l.habitId === detail.id).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 14).map((l) => <div key={l.id} className="flex justify-between p-2.5 text-sm"><span>{fmtDate(l.date, lang, { weekday: 'short', day: 'numeric' })}</span><span className="num">{l.skipped ? '—' : fmtNumber(l.value, lang)}</span></div>)}</Card>
            {detail.kind === 'avoid' && <p className="mt-3 text-xs text-ink-3">{t('avoid_hint')}</p>}
          </>); })()}
        </Sheet>
      )}
    </div>
  );
}

function HabitSheet({ habit, onClose }: { habit: Habit; onClose: () => void }) {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [x, setX] = useState(habit);
  const exists = !!data.habits[x.id];
  return (
    <Sheet open onClose={onClose} tall title={x.name || t('new_habit')} footer={<div className="flex gap-2">{exists && <Button variant="danger" onClick={async () => { await useApp.getState().put('habits', { ...x, archived: true }); onClose(); }} icon={<Trash2 size={15} />} />}<Button className="flex-1" disabled={!x.name.trim()} onClick={async () => { await useApp.getState().put('habits', { ...x, name: x.name.trim() }); onClose(); }}>{t('save')}</Button></div>}>
      <div className="space-y-4">
        <Field label={t('name')}><Input value={x.name} onChange={(e) => setX({ ...x, name: e.target.value })} autoFocus /></Field>
        <Field label={t('habit_kind')}><Segmented value={x.kind} onChange={(v) => setX({ ...x, kind: v, target: v === 'avoid' ? 0 : Math.max(1, x.target) })} size="sm" options={[{ value: 'check', label: t('hk_check') }, { value: 'numeric', label: t('hk_numeric') }, { value: 'timed', label: t('hk_timed') }, { value: 'avoid', label: t('hk_avoid') }]} /></Field>
        {x.kind !== 'check' && <div className="grid grid-cols-2 gap-3"><Field label={t('target')}><Stepper value={x.target} onChange={(v) => setX({ ...x, target: v })} min={0} max={100000} /></Field><Field label={t('unit')}><Input value={x.unit} onChange={(e) => setX({ ...x, unit: e.target.value })} /></Field></div>}
        <Field label={t('frequency')}><Segmented value={x.frequency} onChange={(v) => setX({ ...x, frequency: v })} size="sm" options={[{ value: 'daily', label: t('hf_daily') }, { value: 'weekly', label: t('hf_weekly') }, { value: 'custom', label: t('hf_custom') }]} /></Field>
        {x.frequency === 'weekly' && <div className="flex items-center justify-between"><span>{t('times_per_week')}</span><Stepper value={x.timesPerWeek} onChange={(v) => setX({ ...x, timesPerWeek: v })} min={1} max={7} /></div>}
        {x.frequency === 'custom' && <div className="flex flex-wrap gap-1.5">{[0, 1, 2, 3, 4, 5, 6].map((d) => <Chip key={d} active={x.weekdays.includes(d)} onClick={() => setX({ ...x, weekdays: x.weekdays.includes(d) ? x.weekdays.filter((y) => y !== d) : [...x.weekdays, d] })}>{weekdayName(d, lang)}</Chip>)}</div>}
        <Field label={t('category')}><Input value={x.category} onChange={(e) => setX({ ...x, category: e.target.value })} /></Field>
        <Field label={t('reminders')}><Input type="time" value={x.reminderMin != null ? minToInput(x.reminderMin) : ''} onChange={(e) => setX({ ...x, reminderMin: e.target.value ? inputToMin(e.target.value) : undefined })} /></Field>
        <Field label={t('color')}><div className="flex gap-2">{['var(--c-rest)', 'var(--c-study)', 'var(--c-exercise)', 'var(--c-water)', 'var(--c-sleep)', 'var(--c-meal)'].map((c) => <button key={c} aria-label={c} onClick={() => setX({ ...x, color: c })} className={cn('h-9 w-9 rounded-full border-2', x.color === c ? 'border-ink' : 'border-transparent')} style={{ background: c }} />)}</div></Field>
        <Field label={t('notes')}><TextArea value={x.notes} onChange={(e) => setX({ ...x, notes: e.target.value })} /></Field>
      </div>
    </Sheet>
  );
}
