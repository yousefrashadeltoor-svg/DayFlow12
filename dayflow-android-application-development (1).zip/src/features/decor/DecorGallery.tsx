import { useMemo, useState } from 'react';
import { Check, Eye, EyeOff, Sparkles, TriangleAlert, Wand2, X } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { Badge, Button, Card, Page, ScreenHeader, SectionTitle, Segmented, Sheet, useSettings, useT } from '@/components/common/ui';
import { Orn, Particles, HangingOrnaments } from './Decor';
import { SEASON_LIST, SEASONS, photoUrl, pickSeasonId, seasonFor, TOD_OVERLAY, MAX_DECOR_PICKS } from '@/services/decor';
import { getTheme } from '@/services/themes';
import { todayKey, diffDays } from '@/utils/date';
import { ASCII_ART } from '@/services/brand';
import { cn } from '@/utils/cn';

const up = (p: Parameters<ReturnType<typeof useApp.getState>['updateSettings']>[0]) => useApp.getState().updateSettings(p);

/** Live miniature of the Home screen with ONE season's decoration applied (same structure as the theme previews). */
export function DecorPreview({ seasonId, scale = 0.52, speed = 1, opacity = 0.85, animate = true }: { seasonId: string; scale?: number; speed?: number; opacity?: number; animate?: boolean }) {
  const { lang } = useT();
  const st = useSettings();
  const theme = getTheme(st.themeId);
  const dark = theme.forceDark || st.theme === 'dark' || (st.theme === 'system' && window.matchMedia?.('(prefers-color-scheme: dark)').matches);
  const sea = useMemo(() => seasonFor(new Date(), st.hijriAdjust, todayKey(), { forced: seasonId }), [seasonId, st.hijriAdjust]);
  const W = 300, H = 470;
  return (
    <div className="relative overflow-hidden" style={{ width: W * scale, height: H * scale, borderRadius: 22 * scale + 8 }}>
      <div data-theme={theme.id} className={dark ? 'dark' : ''} dir={lang === 'ar' ? 'rtl' : 'ltr'}
        style={{ width: W, height: H, transform: `scale(${scale})`, transformOrigin: 'top left', position: 'absolute', inset: 0, background: 'var(--page-bg, var(--bg))', backgroundColor: 'var(--bg)', color: 'var(--ink)', fontFamily: 'var(--font-sans)', overflow: 'hidden' }}>
        {/* hero */}
        <div style={{ margin: 12, borderRadius: 22, position: 'relative', overflow: 'hidden', height: 190, background: sea.tint, color: '#fff' }}>
          <img src={photoUrl(sea.photo)} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />
          <div style={{ position: 'absolute', inset: 0, background: TOD_OVERLAY[sea.tod] }} />
          <div style={{ position: 'absolute', right: 10, top: 6, fontSize: 6.4, lineHeight: 1.15, whiteSpace: 'pre', fontFamily: 'ui-monospace, Menlo, Consolas, monospace', direction: 'ltr', textShadow: '0 1px 4px rgba(0,0,0,.6)', zIndex: 5 }}>{ASCII_ART}</div>
          <div className="pointer-events-none absolute inset-x-0 top-0 h-16" style={{ zIndex: 4 }}>
            {sea.hanging.slice(0, 3).map((n, i) => (
              <div key={i} className={animate ? 'df-swing absolute' : 'absolute'} style={{ left: `${[18, 38, 58][i]}%`, animationDuration: `${(3.8 + i * 0.6) / speed}s` }}>
                <div className="mx-auto w-px bg-white/50" style={{ height: [8, 20, 12][i] }} />
                <Orn name={n} size={i % 2 ? 22 : 27} className="-ms-[12px] drop-shadow" />
              </div>
            ))}
          </div>
          <Orn name={sea.celestial} size={40} className={animate ? 'df-float absolute' : 'absolute'} style={{ top: 34, insetInlineEnd: 10 }} />
          <Orn name={sea.ornaments[0]} size={34} className="absolute drop-shadow-lg" style={{ bottom: 44, insetInlineEnd: 52 }} />
          <div style={{ position: 'absolute', insetInlineStart: 14, bottom: 12, textShadow: '0 1px 6px rgba(0,0,0,.6)' }}>
            <div style={{ fontSize: 10, opacity: 0.9, fontWeight: 600 }}>{lang === 'ar' ? sea.greetingAr : sea.greetingEn}</div>
            <div style={{ fontSize: 21, fontWeight: 800 }}>{lang === 'ar' ? 'صباح الخير' : 'Good morning'}</div>
            <div style={{ fontSize: 24, fontWeight: 800 }} className="num">{lang === 'ar' ? '٩:٤١' : '9:41'}</div>
          </div>
          {animate && <Particles season={sea} speed={speed} opacity={opacity} scoped density={0.55} shadow={false} />}
        </div>
        {/* mini cards */}
        <div className="card" style={{ margin: '0 12px', padding: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
          <svg width="46" height="46" viewBox="0 0 64 64" style={{ transform: 'rotate(-90deg)' }}><circle cx="32" cy="32" r="26" stroke="var(--line)" strokeWidth="8" fill="none" /><circle cx="32" cy="32" r="26" stroke={sea.tint} strokeWidth="8" fill="none" strokeLinecap="round" strokeDasharray="163" strokeDashoffset="60" /></svg>
          <div><div style={{ fontSize: 17, fontWeight: 800 }}>63%</div><div style={{ fontSize: 10, color: 'var(--ink-3)' }}>{lang === 'ar' ? 'تقدّم النهاردة' : 'Day progress'}</div></div>
        </div>
        {[{ t: lang === 'ar' ? 'مذاكرة' : 'Study', c: 'var(--c-study)' }, { t: lang === 'ar' ? 'تمرين' : 'Workout', c: 'var(--c-exercise)' }].map((r, i) => (
          <div key={i} className="card" style={{ margin: '8px 12px 0', padding: '9px 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 9, height: 9, borderRadius: 9, background: r.c }} /><span style={{ flex: 1, fontSize: 12, fontWeight: 700 }}>{r.t}</span><Orn name={sea.ornaments[i + 1] ?? 'sparkles'} size={18} />
          </div>
        ))}
        {/* page-level particles behind cards */}
        {animate && <div style={{ position: 'absolute', inset: 0, zIndex: -1 }}><Particles season={sea} speed={speed} opacity={opacity * 0.6} scoped density={0.5} shadow={false} /></div>}
        <div style={{ position: 'absolute', insetInlineStart: 10, bottom: 8, display: 'flex', gap: 2, alignItems: 'flex-end' }}>{sea.ornaments.slice(0, 2).map((n, i) => <Orn key={i} name={n} size={i ? 18 : 26} />)}</div>
      </div>
      <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-black/10" style={{ borderRadius: 22 * scale + 8 }} />
    </div>
  );
}

export function DecorGallery({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const examsMap = useApp((st) => st.data.exams);
  const studying = useMemo(() => { const td = todayKey(); return Object.values(examsMap).some((e) => e.date >= td && diffDays(td, e.date) <= 10) ? 'exams' as const : null; }, [examsMap]);
  const autoId = pickSeasonId(new Date(), s.hijriAdjust, todayKey(), studying);
  const active = s.decorActive ?? [];
  const solo = s.decorPreview;
  const [warn, setWarn] = useState<string | null>(null);
  const overLimit = active.length > MAX_DECOR_PICKS;

  const toggle = (id: string, force = false) => {
    if (active.includes(id)) { up({ decorActive: active.filter((x) => x !== id), decorPreview: solo === id ? '' : solo }); return; }
    if (active.length >= MAX_DECOR_PICKS && !force) { setWarn(id); return; }
    up({ decorActive: [...active, id].slice(0, 4), decorPreview: '' });
  };
  const previewSolo = (id: string) => up({ decorPreview: solo === id ? '' : id });
  const speed = s.decorSpeed, opacity = s.decorOpacity;

  return (
    <div>
      <ScreenHeader title={t('decor_title')} subtitle={t('decor_gallery_sub')} onBack={onBack}
        actions={active.length > 0 || solo ? <Button size="sm" variant="ghost" icon={<Wand2 size={14} />} onClick={() => up({ decorActive: [], decorPreview: '' })}>{t('decor_back_auto')}</Button> : undefined} />
      <Page>
        {/* status */}
        <div className="anim-pop flex flex-wrap items-center gap-2 rounded-2xl border border-line bg-surface p-3">
          <Sparkles size={16} className="text-accent" />
          <span className="text-[13px] font-semibold">{t('decor_now')}:</span>
          {solo ? <Badge tone="accent"><Eye size={11} />{lang === 'ar' ? SEASONS[solo]?.ar : SEASONS[solo]?.en} · {t('decor_previewing')}</Badge> : <>
            <Badge tone="success"><Wand2 size={11} />{lang === 'ar' ? SEASONS[autoId]?.ar : SEASONS[autoId]?.en} · {t('decor_auto_badge')}</Badge>
            {active.filter((x) => x !== autoId).map((id) => <Badge key={id} tone="accent">{lang === 'ar' ? SEASONS[id]?.ar : SEASONS[id]?.en}</Badge>)}
          </>}
          <span className="ms-auto num text-[12px] font-bold text-ink-3">{Math.min(active.length, 4)}/{MAX_DECOR_PICKS}</span>
        </div>
        {overLimit && <div className="mt-2 flex items-center gap-2 rounded-xl bg-warning/12 px-3 py-2 text-[12px] font-semibold text-warning"><TriangleAlert size={14} />{t('decor_heavy_active')}</div>}

        {/* live controls */}
        <SectionTitle>{t('decor_controls')}</SectionTitle>
        <Card className="divide-y divide-line">
          <div className="p-4"><div className="mb-2 text-[13px] font-medium text-ink-2">{t('decor_level')}</div>
            <Segmented value={s.decor} onChange={(v) => up({ decor: v })} options={[{ value: 'off', label: t('decor_off') }, { value: 'light', label: t('decor_light') }, { value: 'full', label: t('decor_full') }]} />
            <p className="mt-2 text-xs text-ink-3">{t('decor_light_static')}</p></div>
          <div className="p-4"><div className="mb-1 flex justify-between text-[13px] font-medium text-ink-2"><span>{t('decor_speed')}</span><span className="num">{Math.round(speed * 100)}%</span></div>
            <input type="range" min={40} max={250} step={10} value={Math.round(speed * 100)} onChange={(e) => up({ decorSpeed: Number(e.target.value) / 100 })} className="w-full accent-[var(--accent)]" aria-label={t('decor_speed')} /></div>
          <div className="p-4"><div className="mb-1 flex justify-between text-[13px] font-medium text-ink-2"><span>{t('decor_opacity')}</span><span className="num">{Math.round(opacity * 100)}%</span></div>
            <input type="range" min={20} max={100} step={5} value={Math.round(opacity * 100)} onChange={(e) => up({ decorOpacity: Number(e.target.value) / 100 })} className="w-full accent-[var(--accent)]" aria-label={t('decor_opacity')} /></div>
          <div className="p-4"><div className="mb-2 text-[13px] font-medium text-ink-2">{t('decor_position')}</div>
            <Segmented value={s.decorLayer} onChange={(v) => up({ decorLayer: v })} options={[{ value: 'front', label: t('decor_front') }, { value: 'back', label: t('decor_back') }]} />
            <p className="mt-2 text-xs text-ink-3">{s.decorLayer === 'front' ? t('decor_front_hint') : t('decor_back_hint_faint')}</p></div>
        </Card>

        <SectionTitle>{t('decor_seasons')}</SectionTitle>
        <p className="-mt-1 mb-3 px-1 text-xs leading-5 text-ink-3">{t('decor_pick_hint', { n: MAX_DECOR_PICKS })}</p>
        <div className="grid grid-cols-2 gap-3">
          {SEASON_LIST.map((def) => {
            const picked = active.includes(def.id);
            const isAuto = def.id === autoId;
            const isSolo = solo === def.id;
            const enabled = s.decorSeasons[def.id] !== false;
            return (
              <Card key={def.id} className={cn('flex flex-col items-center gap-2 overflow-hidden p-2 transition-all', (picked || isSolo) && 'ring-2 ring-accent', !enabled && 'opacity-60')}>
                <button className="press relative" onClick={() => toggle(def.id)} aria-label={def.ar}>
                  <DecorPreview seasonId={def.id} speed={speed} opacity={Math.max(0.5, opacity)} animate={s.decor !== 'off' && enabled} />
                  <span className={cn('absolute end-1.5 top-1.5 grid h-6 w-6 place-items-center rounded-full border-2 text-white transition-all', picked ? 'border-accent bg-accent' : 'border-white/70 bg-black/25')}>{picked && <Check size={13} />}</span>
                  {isAuto && <Badge tone="success" className="absolute start-1.5 top-1.5"><Wand2 size={10} />{t('decor_auto_badge')}</Badge>}
                  {isSolo && <Badge tone="accent" className="absolute start-1.5 bottom-1.5"><Eye size={10} />{t('decor_previewing')}</Badge>}
                </button>
                <div className="w-full px-1">
                  <div className="truncate text-[13.5px] font-bold">{lang === 'ar' ? def.ar : def.en}</div>
                  <div className="line-clamp-1 text-[10.5px] text-ink-3">{lang === 'ar' ? def.descAr : def.descEn}</div>
                  <div className="mt-1.5 flex items-center gap-1">
                    <Button size="sm" variant={isSolo ? 'primary' : 'secondary'} className="h-8 flex-1 px-2 text-[11.5px]" icon={isSolo ? <X size={12} /> : <Eye size={12} />} onClick={() => previewSolo(def.id)}>{isSolo ? t('decor_stop_preview') : t('decor_solo')}</Button>
                    <button aria-label={t('decor_enable_season')} onClick={() => up({ decorSeasons: { ...s.decorSeasons, [def.id]: !enabled } })} className={cn('press grid h-8 w-8 place-items-center rounded-xl', enabled ? 'bg-surface-2 text-ink-2' : 'bg-danger/10 text-danger')}>{enabled ? <Eye size={14} /> : <EyeOff size={14} />}</button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
        <p className="mt-4 text-center text-xs text-ink-3">{t('decor_note_bundled')}</p>
      </Page>

      {/* >3 warning */}
      <Sheet open={!!warn} onClose={() => setWarn(null)} title={<span className="flex items-center gap-2 text-warning"><TriangleAlert size={20} />{t('decor_warn_title')}</span>}>
        <p className="text-[15px] leading-8">{t('decor_warn_body', { n: MAX_DECOR_PICKS })}</p>
        <div className="mt-4 flex gap-2">
          <Button className="flex-[2]" onClick={() => setWarn(null)}>{t('decor_warn_keep', { n: MAX_DECOR_PICKS })}</Button>
          <Button variant="danger" className="flex-1" onClick={() => { if (warn) { up({ decorActive: [...active, warn].slice(0, 4), decorPreview: '' }); } setWarn(null); }}>{t('decor_warn_force')}</Button>
        </div>
      </Sheet>
    </div>
  );
}
