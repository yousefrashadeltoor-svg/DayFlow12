import { useEffect, useMemo, useState, type CSSProperties, type ReactNode } from 'react';
import { useApp } from '@/stores/appStore';
import { emojiUrl, photoUrl, resolveSeasonIds, seasonFor, SEASONS, TOD_OVERLAY, type SeasonState } from '@/services/decor';
import { todayKey, diffDays } from '@/utils/date';
import { getTheme } from '@/services/themes';

function useStudying(): 'exams' | null {
  const examsMap = useApp((st) => st.data.exams);
  return useMemo(() => {
    const today = todayKey();
    return Object.values(examsMap).some((e) => e.date >= today && diffDays(today, e.date) <= 10) ? 'exams' : null;
  }, [examsMap]);
}
function useTick() {
  const [tick, setTick] = useState(0);
  useEffect(() => { const id = setInterval(() => setTick((t) => t + 1), 5 * 60 * 1000); return () => clearInterval(id); }, []);
  return tick;
}
/** All active seasons: automatic one always on + up to 3 manual picks (or a solo preview). */
export function useSeasons(): SeasonState[] {
  const s = useApp((st) => st.data.settings.app);
  const studying = useStudying();
  const tick = useTick();
  return useMemo(() => {
    const now = new Date(); const key = todayKey();
    const ids = resolveSeasonIds(now, s?.hijriAdjust ?? 0, key, { solo: s?.decorPreview || undefined, active: s?.decorActive, studying, enabled: s?.decorSeasons });
    return ids.map((id) => seasonFor(now, s?.hijriAdjust ?? 0, key, { forced: id, studying }));
  }, [s?.hijriAdjust, s?.decorPreview, s?.decorActive, s?.decorSeasons, studying, tick]);
}
export function useSeason(): SeasonState { return useSeasons()[0]; }

export const Orn = ({ name, size = 40, className = '', style }: { name: string; size?: number; className?: string; style?: CSSProperties }) => (
  <img src={emojiUrl(name)} alt="" width={size} height={size} draggable={false} className={`select-none pointer-events-none ${className}`} style={{ width: size, height: size, ...style }} />
);

function rng(seed: number) { let s = seed >>> 0 || 1; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
const ANIM: Record<string, string> = { fall: 'df-fall', rise: 'df-rise', twinkle: 'df-twinkle', drift: 'df-drift', float: 'df-bob' };

export function Particles({ season, speed = 1, opacity = 0.9, scoped = false, density = 1, shadow = true }: { season: SeasonState; speed?: number; opacity?: number; scoped?: boolean; density?: number; shadow?: boolean }) {
  const items = useMemo(() => {
    const r = rng(season.id.length * 977 + season.particles.count * 31 + season.tod.length + season.id.charCodeAt(0));
    const { names, motion, count } = season.particles;
    const n = Math.max(3, Math.round(count * density));
    return Array.from({ length: n }, (_, i) => {
      const name = names[i % names.length];
      const size = motion === 'drift' ? 36 + r() * 22 : motion === 'twinkle' ? 12 + r() * 16 : motion === 'float' ? 22 + r() * 14 : 14 + r() * 20;
      const base = motion === 'twinkle' ? 2.4 + r() * 3 : motion === 'drift' ? 50 + r() * 40 : motion === 'rise' ? 16 + r() * 14 : motion === 'float' ? 5 + r() * 4 : 12 + r() * 16;
      return { name, size, dur: base / Math.max(0.2, speed), left: r() * 96, top: r() * 92, delay: -r() * base, dx: (r() - 0.5) * 150, rot: (r() > 0.5 ? 1 : -1) * (180 + r() * 360), o: 0.5 + r() * 0.5 };
    });
  }, [season.id, season.particles, season.tod, speed, density]);
  const anim = ANIM[season.particles.motion] ?? 'df-fall';
  return (
    <div className={scoped ? 'absolute inset-0 overflow-hidden' : 'absolute inset-0 overflow-hidden'} aria-hidden style={{ opacity, contain: 'layout style' }}>
      {items.map((p, i) => (
        <img key={i} src={emojiUrl(p.name)} alt="" draggable={false} className={`df-particle${shadow ? ' df-shadow' : ''}`}
          style={{ left: `${p.left}%`, top: season.particles.motion === 'twinkle' ? `${p.top}%` : season.particles.motion === 'drift' ? `${6 + p.top * 0.3}%` : 0, width: p.size, opacity: p.o,
            animationName: anim, animationDuration: `${p.dur}s`, animationDelay: `${p.delay}s`, ['--dx' as string]: `${p.dx}px`, ['--rot' as string]: `${p.rot}deg` }} />
      ))}
    </div>
  );
}

/** Full-page layer. Front = above content (click-through). Back = behind cards, still visible in the gaps but fainter. */
export function DecorLayer() {
  const st = useApp((s) => s.data.settings.app);
  const seasons = useSeasons();
  useEffect(() => {
    const f = () => document.documentElement.classList.toggle('df-hidden', document.visibilityState === 'hidden');
    document.addEventListener('visibilitychange', f); return () => document.removeEventListener('visibilitychange', f);
  }, []);
  const decor = st?.decor ?? 'full';
  const themeId = st?.themeId ?? 'dayflow';
  if (decor === 'off' || !seasons.length) return null;
  const speed = st?.decorSpeed ?? 1, layer = st?.decorLayer ?? 'front';
  const baseOpacity = st?.decorOpacity ?? 0.7;
  const opacity = layer === 'back' ? baseOpacity * 0.55 : baseOpacity;
  const total = seasons.reduce((a, x) => a + x.particles.count, 0);
  const budget = 42; // hard cap keeps the CPU calm even with 3–4 blended seasons
  const ambient = ['gemini', 'oneui', 'sunset', 'ocean', 'rose'].includes(themeId);
  return (
    <div className={`pointer-events-none fixed inset-0 overflow-hidden ${layer === 'back' ? '-z-[1]' : 'z-[30]'}`} aria-hidden>
      {ambient && decor === 'full' && <><div className="df-blob" style={{ width: 320, height: 320, top: '-8%', insetInlineStart: '-12%' }} /><div className="df-blob" style={{ width: 280, height: 280, bottom: '6%', insetInlineEnd: '-14%', animationDelay: '-6s' }} /></>}
      {decor === 'full' && seasons.map((sea) => <Particles key={sea.id} season={sea} speed={speed} opacity={opacity} density={Math.min(1, budget / Math.max(1, total))} shadow={total <= 26} />)}
    </div>
  );
}

/** Always-present STATIC ornament cluster (bottom corner) so decor exists even in Light mode or behind content. */
export function StaticDecor() {
  const st = useApp((s) => s.data.settings.app);
  const seasons = useSeasons();
  const decor = st?.decor ?? 'full';
  if (decor === 'off' || !seasons.length) return null;
  const back = (st?.decorLayer ?? 'front') === 'back';
  const names = seasons.flatMap((x) => x.ornaments).slice(0, 3);
  return (
    <div className="pointer-events-none fixed z-[29] flex items-end gap-0.5" style={{ insetInlineStart: 10, bottom: 'calc(env(safe-area-inset-bottom) + 92px)', opacity: back ? 0.4 : 0.85 }} aria-hidden>
      {names.map((n, i) => <Orn key={i} name={n} size={i === 0 ? 34 : 24} className="drop-shadow-md" />)}
    </div>
  );
}

/** Dangling ornaments on strings. `avoidStart` keeps the start-side clear for the ASCII wordmark. */
export function HangingOrnaments({ names, avoidStart = false }: { names: string[]; avoidStart?: boolean }) {
  const st = useApp((s) => s.data.settings.app);
  const decor = st?.decor ?? 'full';
  if (decor === 'off') return null;
  const list = names.slice(0, avoidStart ? 3 : 5);
  const positions = avoidStart ? [18, 38, 58] : list.map((_, i) => (i + 0.5) * (100 / list.length));
  const lens = [10, 26, 14, 30, 12];
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-10 h-20" aria-hidden>
      {list.map((n, i) => (
        <div key={i} className={decor === 'full' ? 'df-swing absolute' : 'absolute'} style={{ left: `${positions[i]}%`, animationDelay: `${i * 0.55}s`, animationDuration: `${(3.6 + (i % 3) * 0.7) / (st?.decorSpeed ?? 1)}s` }}>
          <div className="mx-auto w-px bg-white/55" style={{ height: lens[i % lens.length] }} />
          <Orn name={n} size={i % 2 ? 28 : 34} className="-ms-[15px] drop-shadow-lg" />
        </div>
      ))}
    </div>
  );
}

export function SeasonHero({ children, className = '' }: { children: ReactNode; className?: string }) {
  const season = useSeason();
  const st = useApp((s) => s.data.settings.app);
  const decor = st?.decor ?? 'full';
  const radius = getTheme(st?.themeId ?? 'dayflow').radius.card + 6;
  const spots = [{ top: 96, end: 78, size: 44, d: 1.2 }, { top: 40, start: 14, size: 38, d: 0.6 }, { top: 128, end: 14, size: 36, d: 2 }] as const;
  const speed = st?.decorSpeed ?? 1;
  return (
    <section className={`relative isolate overflow-hidden text-white shadow-float ${className}`} style={{ borderRadius: radius, background: season.tint }}>
      <img key={season.photo} src={photoUrl(season.photo)} alt="" draggable={false} className="anim-fade absolute inset-0 -z-20 h-full w-full object-cover" />
      <div className="absolute inset-0 -z-10" style={{ background: TOD_OVERLAY[season.tod] }} />
      <div className="absolute inset-0 -z-10" style={{ background: `radial-gradient(120% 90% at 100% 0%, color-mix(in srgb, ${season.tint} 40%, transparent) 0%, transparent 60%)` }} />
      {decor !== 'off' && (
        <div className="pointer-events-none absolute inset-0 -z-[5] overflow-hidden" aria-hidden>
          <Orn name={season.celestial} size={52} className="df-float absolute drop-shadow-xl" style={{ top: 44, insetInlineEnd: 12 }} />
          {season.tod === 'night' && decor === 'full' && [[18, 30], [40, 70], [66, 36], [30, 52]].map(([l, t], i) => <Orn key={i} name="glowing_star" size={12 + (i % 3) * 4} className="absolute" style={{ left: `${l}%`, top: `${t}%`, animation: `df-twinkle ${(2.6 + i * 0.5) / speed}s ease-in-out ${i * 0.4}s infinite` }} />)}
          {spots.map((sp, i) => season.ornaments[i] && (
            <Orn key={i} name={season.ornaments[i]} size={sp.size} className="df-float absolute opacity-95 drop-shadow-xl"
              style={{ top: sp.top, ...('end' in sp ? { insetInlineEnd: sp.end } : { insetInlineStart: sp.start }), animationDelay: `${sp.d}s` }} />
          ))}
        </div>
      )}
      {children}
    </section>
  );
}

export function CornerOrnament() {
  const st = useApp((s) => s.data.settings.app);
  const season = useSeason();
  if ((st?.decor ?? 'full') === 'off') return null;
  return <Orn name={season.ornaments[0] ?? 'sparkles'} size={32} className="df-float absolute end-3 top-2 opacity-90" />;
}
export const SEASON_IDS = Object.keys(SEASONS);
