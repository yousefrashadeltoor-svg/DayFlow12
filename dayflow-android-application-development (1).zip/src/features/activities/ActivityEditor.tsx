import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Trash2, Wand2 } from 'lucide-react';
import type { ActivityBlock, ActivityCore, Energy, NotificationAction, RecurrenceRule, SoundMode } from '@/models/types';
import { useApp, blocksForDate } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { Button, Chip, Field, Icon, ICONS, Input, Segmented, Select, Sheet, Stepper, TextArea, Toggle, useConfirm, useSettings, useT, useHaptic } from '@/components/common/ui';
import { coreFrom, defaultReminder } from '@/services/defaults';
import { detectConflicts, conflictsFor } from '@/services/scheduling/engine';
import { toSched, catName } from '@/components/cards/blocks';
import { addDays, inputToMin, minToInput, todayKey, weekdayName, fmtTime } from '@/utils/date';

const ACTIONS: NotificationAction[] = ['DONE', 'START', 'SNOOZE_5', 'SNOOZE_10', 'SNOOZE_15', 'SKIP', 'PARTIAL', 'DISMISS'];
const ACTION_LABEL: Record<NotificationAction, ['ar' | 'en', string, string]> = {
  DONE: ['ar', 'تم', 'Done'], START: ['ar', 'ابدأ', 'Start'], SNOOZE_5: ['ar', 'غفوة ٥', 'Snooze 5'], SNOOZE_10: ['ar', 'غفوة ١٠', 'Snooze 10'], SNOOZE_15: ['ar', 'غفوة ١٥', 'Snooze 15'],
  SKIP: ['ar', 'تخطٍّ', 'Skip'], PARTIAL: ['ar', 'جزئي', 'Partial'], DISMISS: ['ar', 'إغلاق', 'Dismiss'],
};

export function ActivityEditor() {
  const editor = useUI((s) => s.editor);
  const close = useUI((s) => s.closeEditor);
  if (!editor.open) return null;
  return <EditorInner key={editor.blockId ?? `new-${editor.date}-${editor.startMin}`} onClose={close} />;
}

function EditorInner({ onClose }: { onClose: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const ed = useUI((st) => st.editor);
  const data = useApp((st) => st.data);
  const { createActivity, updateActivity, deleteActivity, toast } = useApp.getState();
  const existing = ed.blockId ? data.activities[ed.blockId] : undefined;
  const { ask, node } = useConfirm();

  const [tab, setTab] = useState<'basics' | 'scheduling' | 'reminders' | 'advanced'>('basics');
  const [date, setDate] = useState(existing?.date ?? ed.date ?? todayKey());
  const [core, setCore] = useState<ActivityCore>(() => {
    if (existing) { const { id: _1, date: _2, status: _3, ...rest } = existing; void _1; void _2; void _3; return structuredClone(rest) as ActivityCore; }
    const task = ed.taskId ? data.tasks[ed.taskId] : undefined;
    const base = coreFrom({ title: ed.title ?? task?.title ?? '', categoryId: ed.categoryId ?? 'cat_personal', startMin: ed.startMin ?? nextQuarter(), durationMin: task?.estimateMin || s.defaultDurationMin, bufferMin: s.defaultBufferMin, taskId: task?.id, projectId: task?.projectId, goalId: task?.goalId });
    base.reminder = defaultReminder(s);
    return base;
  });
  const [recType, setRecType] = useState<'none' | RecurrenceRule['freq']>('none');
  const [rec, setRec] = useState<RecurrenceRule>({ freq: 'weekly', interval: 1, byWeekday: [new Date(date + 'T12:00').getDay()], start: date });
  const [scope, setScope] = useState<'this' | 'future'>('this');
  const [error, setError] = useState<string | null>(null);
  const series = existing?.seriesId ? data.series[existing.seriesId] : undefined;
  useEffect(() => { setRec((r) => ({ ...r, start: date })); }, [date]);

  const upd = <K extends keyof ActivityCore>(k: K, v: ActivityCore[K]) => setCore((c) => ({ ...c, [k]: v }));
  const updRem = <K extends keyof ActivityCore['reminder']>(k: K, v: ActivityCore['reminder'][K]) => setCore((c) => ({ ...c, reminder: { ...c.reminder, [k]: v } }));

  const sameDay = useMemo(() => blocksForDate(data, date).filter((b) => b.id !== existing?.id), [data, date, existing?.id]);
  const conflicts = useMemo(() => {
    const me = toSched({ ...(existing ?? ({} as ActivityBlock)), ...core, id: '__me', date, status: existing?.status ?? 'planned' } as ActivityBlock);
    const all = [...sameDay.map(toSched), me];
    return conflictsFor('__me', detectConflicts(all, 1440)).map((c) => ({ ...c, other: sameDay.find((b) => b.id === (c.a === '__me' ? c.b : c.a)) }));
  }, [core, sameDay, date, existing]);

  const categories = Object.values(data.categories);
  const save = async (applyNow = false) => {
    if (!core.title.trim()) { setError(t('title_required')); setTab('basics'); return; }
    if (core.durationMin < 1 || core.durationMin > 1440) { setError(t('duration_invalid')); return; }
    if (core.windowStartMin != null && core.windowEndMin != null && (core.startMin < core.windowStartMin || core.startMin + core.durationMin > core.windowEndMin)) { setError(t('window_invalid')); setTab('scheduling'); return; }
    if (existing?.fixed && (existing.startMin !== core.startMin || existing.date !== date)) {
      if (!(await ask(t('fixed_move_confirm'), undefined, t('confirm'), false))) return;
    }
    h(12);
    const clean = { ...core, title: core.title.trim(), startMin: Math.max(0, Math.min(1439, core.startMin)) };
    if (existing) {
      const ok = await updateActivity(existing.id, { ...clean, date }, series ? scope : 'this');
      if (ok) { if (applyNow) await useApp.getState().applyDayPlan(date); toast('success', t(existing.applied === false && !applyNow && !s.autoApplyPlan ? 'saved_draft' : 'saved')); onClose(); }
    } else {
      const created = await createActivity(clean, date, recType === 'none' ? null : { ...rec, freq: recType });
      if (created !== null || recType !== 'none') { if (applyNow) await useApp.getState().applyDayPlan(date); toast('success', t(!applyNow && !s.autoApplyPlan && recType === 'none' ? 'saved_draft' : 'saved')); onClose(); }
    }
  };
  const remove = async () => {
    if (!existing) return;
    if (series) {
      const whole = await ask(t('delete_series_q'), undefined, t('whole_series'));
      await deleteActivity(existing.id, whole ? 'series' : 'this');
    } else await deleteActivity(existing.id);
    onClose();
  };

  return (
    <Sheet open onClose={onClose} tall title={existing ? t('edit_activity') : t('new_activity')}
      footer={<div className="flex gap-2">{existing && <Button variant="danger" onClick={remove} icon={<Trash2 size={16} />} aria-label={t('delete')} />}<Button variant="secondary" className="flex-1" onClick={onClose}>{t('cancel')}</Button>{!s.autoApplyPlan && <Button variant="tinted" className="flex-1" onClick={() => save(true)}>{t('save_apply')}</Button>}<Button className="flex-[2]" onClick={() => save(false)}>{t('save')}</Button></div>}>
      {node}
      <Segmented value={tab} onChange={setTab} className="mb-4" size="sm" options={[{ value: 'basics', label: t('basics') }, { value: 'scheduling', label: t('scheduling') }, { value: 'reminders', label: t('reminders') }, { value: 'advanced', label: t('advanced') }]} />
      {error && <div className="mb-3 rounded-xl bg-danger/10 px-3 py-2 text-sm font-medium text-danger" role="alert">{error}</div>}
      {conflicts.length > 0 && (
        <div className="mb-3 flex items-start gap-2 rounded-xl bg-warning/12 px-3 py-2 text-sm text-warning">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{t('conflict_with', { x: [...new Set(conflicts.map((c) => c.other?.title ?? t(c.type === 'window' ? 'window_invalid' : 'conflicts_found', { n: 1 })))].join('، ') })}</span>
        </div>
      )}

      {tab === 'basics' && (
        <div className="space-y-4">
          <Field label={t('title')}><Input autoFocus value={core.title} onChange={(e) => { upd('title', e.target.value); setError(null); }} placeholder={t('title')} /></Field>
          <Field label={t('category')}>
            <div className="flex flex-wrap gap-2">
              {categories.map((c) => <Chip key={c.id} active={core.categoryId === c.id} color={c.color} onClick={() => setCore((x) => ({ ...x, categoryId: c.id, icon: c.icon, color: c.color }))}>{catName(c, lang)}</Chip>)}
            </div>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t('date')}><Input type="date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} /></Field>
            <Field label={t('start')}><Input type="time" value={minToInput(core.startMin)} onChange={(e) => upd('startMin', inputToMin(e.target.value))} /></Field>
          </div>
          <Field label={t('duration')} hint={`${fmtTime(core.startMin, lang, s.clock24)} → ${fmtTime(core.startMin + core.durationMin, lang, s.clock24)}`}>
            <div className="flex flex-wrap items-center gap-2">
              <Stepper value={core.durationMin} onChange={(v) => upd('durationMin', v)} min={1} max={1440} step={5} suffix={t('min_short')} />
              {[15, 30, 45, 60, 90, 120].map((m) => <Chip key={m} active={core.durationMin === m} onClick={() => upd('durationMin', m)}>{m}</Chip>)}
            </div>
          </Field>
          <Toggle checked={core.fixed} onChange={(v) => upd('fixed', v)} label={core.fixed ? t('fixed') : t('flexible')} description={t('fixed_hint')} />
          <Field label={t('icon')}>
            <div className="flex flex-wrap gap-2">{Object.keys(ICONS).map((k) => (
              <button key={k} type="button" aria-label={k} onClick={() => upd('icon', k)} className={`press grid h-10 w-10 place-items-center rounded-xl ${core.icon === k ? 'bg-accent text-accent-ink' : 'bg-surface-2 text-ink-2'}`}><Icon name={k} /></button>
            ))}</div>
          </Field>
          <Field label={t('description')}><TextArea value={core.description} onChange={(e) => upd('description', e.target.value)} /></Field>
          {!existing && (
            <Field label={t('recurrence')}>
              <Select value={recType} onChange={(v) => setRecType(v as typeof recType)} options={[{ value: 'none', label: t('rec_none') }, { value: 'daily', label: t('rec_daily') }, { value: 'weekly', label: t('rec_weekly') }, { value: 'monthly', label: t('rec_monthly') }, { value: 'dates', label: t('rec_dates') }]} />
              {recType !== 'none' && (
                <div className="mt-3 space-y-3 rounded-2xl bg-surface-2/60 p-3">
                  {recType !== 'dates' && <div className="flex items-center gap-2 text-sm">{t('every_n')} <Stepper value={rec.interval} onChange={(v) => setRec({ ...rec, interval: v })} min={1} max={52} /></div>}
                  {recType === 'weekly' && (
                    <div className="flex flex-wrap gap-1.5">
                      {[0, 1, 2, 3, 4, 5, 6].map((d) => <Chip key={d} active={rec.byWeekday?.includes(d)} onClick={() => setRec({ ...rec, byWeekday: rec.byWeekday?.includes(d) ? rec.byWeekday.filter((x) => x !== d) : [...(rec.byWeekday ?? []), d].sort() })}>{weekdayName(d, lang)}</Chip>)}
                      <Chip onClick={() => setRec({ ...rec, byWeekday: lang === 'ar' ? [0, 1, 2, 3, 4] : [1, 2, 3, 4, 5] })}>{t('rec_weekdays_preset')}</Chip>
                    </div>
                  )}
                  {recType === 'dates' && <Input placeholder="2026-01-10, 2026-02-14" value={(rec.dates ?? []).join(', ')} onChange={(e) => setRec({ ...rec, dates: e.target.value.split(/[,\s]+/).filter((x) => /^\d{4}-\d{2}-\d{2}$/.test(x)) })} />}
                  <Field label={t('until')}><Input type="date" value={rec.until ?? ''} min={date} onChange={(e) => setRec({ ...rec, until: e.target.value || undefined })} /></Field>
                </div>
              )}
            </Field>
          )}
          {series && (
            <Field label={t('edit_scope')}><Segmented value={scope} onChange={setScope} options={[{ value: 'this', label: t('this_only') }, { value: 'future', label: t('this_and_future') }]} /></Field>
          )}
        </div>
      )}

      {tab === 'scheduling' && (
        <div className="space-y-4">
          <Field label={t('window')} hint={core.fixed ? t('fixed_hint') : undefined}>
            <div className="grid grid-cols-2 gap-3">
              <Input type="time" aria-label={t('earliest_start')} value={core.windowStartMin != null ? minToInput(core.windowStartMin) : ''} onChange={(e) => upd('windowStartMin', e.target.value ? inputToMin(e.target.value) : undefined)} />
              <Input type="time" aria-label={t('latest_finish')} value={core.windowEndMin != null ? minToInput(core.windowEndMin) : ''} onChange={(e) => upd('windowEndMin', e.target.value ? inputToMin(e.target.value) : undefined)} />
            </div>
          </Field>
          <Row label={t('priority')}><Stepper value={core.priority} onChange={(v) => upd('priority', v)} min={1} max={5} /></Row>
          <Row label={t('importance')}><Stepper value={core.importance} onChange={(v) => upd('importance', v)} min={1} max={5} /></Row>
          <Row label={t('difficulty')}><Stepper value={core.difficulty} onChange={(v) => upd('difficulty', v)} min={1} max={5} /></Row>
          <Field label={t('energy')}><Segmented value={core.energy} onChange={(v: Energy) => upd('energy', v)} options={[{ value: 'low', label: t('low') }, { value: 'medium', label: t('medium') }, { value: 'high', label: t('high') }]} /></Field>
          <Row label={t('prep_time')}><Stepper value={core.prepMin} onChange={(v) => upd('prepMin', v)} max={240} step={5} suffix={t('min_short')} /></Row>
          <Row label={t('cleanup_time')}><Stepper value={core.cleanupMin} onChange={(v) => upd('cleanupMin', v)} max={240} step={5} suffix={t('min_short')} /></Row>
          <Row label={t('buffer_time')}><Stepper value={core.bufferMin} onChange={(v) => upd('bufferMin', v)} max={120} step={5} suffix={t('min_short')} /></Row>
          <Toggle checked={core.splitAllowed} onChange={(v) => upd('splitAllowed', v)} label={t('split_allowed')} />
          {core.splitAllowed && <Row label={t('min_split')}><Stepper value={core.minSplitMin} onChange={(v) => upd('minSplitMin', v)} min={5} max={240} step={5} suffix={t('min_short')} /></Row>}
          <Field label={t('depends_on')}>
            <div className="flex flex-wrap gap-2">{sameDay.length ? sameDay.map((b) => <Chip key={b.id} active={core.dependsOn.includes(b.id)} onClick={() => upd('dependsOn', core.dependsOn.includes(b.id) ? core.dependsOn.filter((x) => x !== b.id) : [...core.dependsOn, b.id])}>{b.title}</Chip>) : <span className="text-sm text-ink-3">{t('no_activities')}</span>}</div>
          </Field>
        </div>
      )}

      {tab === 'reminders' && (
        <div className="space-y-4">
          <Toggle checked={core.reminder.enabled} onChange={(v) => updRem('enabled', v)} label={t('reminders')} />
          {core.reminder.enabled && <>
            <Field label={t('reminder_offsets')}>
              <div className="flex flex-wrap gap-2">{[0, 5, 10, 15, 30, 60].map((m) => <Chip key={m} active={core.reminder.offsets.includes(m)} onClick={() => updRem('offsets', core.reminder.offsets.includes(m) ? core.reminder.offsets.filter((x) => x !== m) : [...core.reminder.offsets, m].sort((a, b) => a - b))}>{m}</Chip>)}</div>
            </Field>
            <Toggle checked={core.reminder.atEnd} onChange={(v) => updRem('atEnd', v)} label={t('remind_at_end')} />
            <Field label={t('sound')}>
              <Select value={core.reminder.soundMode} onChange={(v) => updRem('soundMode', v as SoundMode)} options={(['inherit', 'custom', 'tts', 'tone', 'system', 'none'] as SoundMode[]).map((m) => ({ value: m, label: t(`snd_${m}` as 'snd_inherit') }))} />
            </Field>
            {core.reminder.soundMode === 'custom' && (
              <Field label={t('sounds_library')} hint={Object.keys(data.sounds).length ? undefined : t('import_sound')}>
                <Select value={core.reminder.soundId ?? ''} onChange={(v) => updRem('soundId', v || undefined)} options={[{ value: '', label: '—' }, ...Object.values(data.sounds).map((x) => ({ value: x.id, label: x.name }))]} />
              </Field>
            )}
            {(core.reminder.soundMode === 'tts' || core.reminder.soundMode === 'custom' || (core.reminder.soundMode === 'inherit' && s.soundMode === 'tts')) && (
              <Field label={t('tts_text')}><Input value={core.reminder.ttsText ?? ''} placeholder={core.title} onChange={(e) => updRem('ttsText', e.target.value)} /></Field>
            )}
            <Row label={t('repeat_every')}><Stepper value={core.reminder.repeatIntervalMin} onChange={(v) => updRem('repeatIntervalMin', v)} max={60} /></Row>
            <Row label={t('max_repeats')}><Stepper value={core.reminder.maxRepeats} onChange={(v) => updRem('maxRepeats', v)} max={10} /></Row>
            <Toggle checked={core.reminder.critical} onChange={(v) => updRem('critical', v)} label={t('critical')} />
            <Field label={t('notif_buttons')} hint="Android ≤ 3">
              <div className="flex flex-wrap gap-2">{ACTIONS.map((a) => (
                <Chip key={a} active={core.reminder.actions.includes(a)} onClick={() => updRem('actions', core.reminder.actions.includes(a) ? core.reminder.actions.filter((x) => x !== a) : [...core.reminder.actions, a].slice(-3))}>{lang === 'ar' ? ACTION_LABEL[a][1] : ACTION_LABEL[a][2]}</Chip>
              ))}</div>
            </Field>
          </>}
        </div>
      )}

      {tab === 'advanced' && (
        <div className="space-y-4">
          <Field label={t('linked_task')}><Select value={core.taskId ?? ''} onChange={(v) => upd('taskId', v || undefined)} options={[{ value: '', label: t('none') }, ...Object.values(data.tasks).filter((x) => x.status !== 'done').map((x) => ({ value: x.id, label: x.title }))]} /></Field>
          <Field label={t('linked_project')}><Select value={core.projectId ?? ''} onChange={(v) => upd('projectId', v || undefined)} options={[{ value: '', label: t('none') }, ...Object.values(data.projects).map((x) => ({ value: x.id, label: x.title }))]} /></Field>
          <Field label={t('linked_goal')}><Select value={core.goalId ?? ''} onChange={(v) => upd('goalId', v || undefined)} options={[{ value: '', label: t('none') }, ...Object.values(data.goals).map((x) => ({ value: x.id, label: x.title }))]} /></Field>
          <Field label={t('linked_lesson')}><Select value={core.lessonId ?? ''} onChange={(v) => { const l = data.lessons[v]; setCore((c) => ({ ...c, lessonId: v || undefined, subjectId: l?.subjectId ?? c.subjectId })); }} options={[{ value: '', label: t('none') }, ...Object.values(data.lessons).map((x) => ({ value: x.id, label: `${data.subjects[x.subjectId]?.title ?? ''} · ${x.title}` }))]} /></Field>
          <Field label={t('linked_workout')}><Select value={core.workoutPlanId ?? ''} onChange={(v) => upd('workoutPlanId', v || undefined)} options={[{ value: '', label: t('none') }, ...Object.values(data.workoutPlans).map((x) => ({ value: x.id, label: x.name }))]} /></Field>
          <Field label={t('tags')}><Input value={core.tags.join(', ')} onChange={(e) => upd('tags', e.target.value.split(/[,،]/).map((x) => x.trim()).filter(Boolean))} /></Field>
          <Field label={t('notes')}><TextArea value={core.notes} onChange={(e) => upd('notes', e.target.value)} /></Field>
          {existing && <Button variant="tinted" icon={<Wand2 size={16} />} onClick={() => { onClose(); setTimeout(() => useUI.getState().set({ whatIfFor: existing.id }), 50); }}>{t('what_if')}</Button>}
        </div>
      )}
    </Sheet>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="flex items-center justify-between gap-3"><span className="text-[15px]">{label}</span>{children}</div>;
}
function nextQuarter() { const d = new Date(); const m = d.getHours() * 60 + d.getMinutes(); return Math.min(1425, Math.ceil((m + 1) / 15) * 15); }
export const tomorrowKey = () => addDays(todayKey(), 1);
