import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, CheckSquare, CalendarPlus, NotebookPen, Trash2, Pencil, Eye, EyeOff, CircleCheck, Circle } from 'lucide-react';
import { useApp, blocksForDate } from '@/stores/appStore';
import { useUI } from '@/stores/uiStore';
import { Badge, Button, Card, Chip, Field, HelpButton, HelpTip, Input, Page, ScreenHeader, SectionTitle, Sheet, TextArea, Toggle, useConfirm, useSettings, useT } from '@/components/common/ui';
import { Orn } from '@/features/decor/Decor';
import { TaskEditor } from '@/features/tasks/TasksScreen';
import { occasionsOn, hijriLabel, hijriOf, HIJRI_MONTHS_AR, HIJRI_MONTHS_EN, religionLabel, type Occasion } from '@/services/occasions';
import { photoUrl, allEmojiNames } from '@/services/decor';
import type { SpecialDate, Task, DateKey } from '@/models/types';
import { addDays, fmtDate, fmtNumber, fmtTime, inputToMin, minToInput, monthGrid, todayKey, weekdayName, diffDays } from '@/utils/date';
import { uid } from '@/utils/id';
import { cn } from '@/utils/cn';

const QUICK_EMOJI = ['sparkles', 'party_popper', 'balloon', 'wrapped_gift', 'red_heart', 'trophy', 'books', 'alarm_clock', 'calendar', 'rocket', 'bouquet', 'star', 'fireworks', 'church', 'mosque', 'palm_tree', 'sun', 'fire', 'bell', 'hundred_points'];

export function FlagBadge({ label }: { label: string }) {
  return <span className="inline-flex items-center gap-1 rounded-full bg-danger/12 py-0.5 pe-2 ps-0.5 text-[11px] font-bold text-danger"><span className="grid h-[18px] w-[18px] place-items-center rounded-full bg-danger text-[12px] font-extrabold leading-none text-white">!</span>{label}</span>;
}
export function OfficialBadge({ o, lang }: { o: Occasion; lang: 'ar' | 'en' }) {
  return <Badge tone={o.official ? 'success' : 'neutral'}>{o.official ? '✓ ' : ''}{lang === 'ar' ? o.officialAr : o.officialEn}</Badge>;
}

export function CalendarScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const ui = useUI();
  const data = useApp((st) => st.data);
  const today = todayKey();
  const [month, setMonth] = useState<DateKey>(today.slice(0, 7) + '-01');
  const [sel, setSel] = useState<DateKey>(today);
  const [addOcc, setAddOcc] = useState<SpecialDate | null>(null);
  const [detail, setDetail] = useState<Occasion | null>(null);
  const [task, setTask] = useState<Task | null>(null);
  const user = useMemo(() => Object.values(data.specialDates), [data.specialDates]);
  const opts = useMemo(() => ({ hijriAdjust: s.hijriAdjust, showOtherReligions: s.showOtherReligions, user }), [s.hijriAdjust, s.showOtherReligions, user]);
  const cells = useMemo(() => monthGrid(month, s.weekStart), [month, s.weekStart]);
  const occMap = useMemo(() => new Map(cells.map((d) => [d, occasionsOn(d, opts)])), [cells, opts]);
  const taskDays = useMemo(() => { const m = new Map<string, number>(); for (const x of Object.values(data.tasks)) if (x.dueDate && x.status !== 'done') m.set(x.dueDate, (m.get(x.dueDate) ?? 0) + 1); return m; }, [data.tasks]);
  const blockDays = useMemo(() => { const m = new Map<string, number>(); for (const b of Object.values(data.activities)) if (b.status !== 'cancelled') m.set(b.date, (m.get(b.date) ?? 0) + 1); return m; }, [data.activities]);
  const shift = (n: number) => { const d = new Date(month + 'T12:00'); d.setMonth(d.getMonth() + n, 1); setMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`); };
  const mTitle = new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-US', { month: 'long', year: 'numeric' }).format(new Date(month + 'T12:00'));
  const h1 = hijriOf(cells[7], s.hijriAdjust), h2 = hijriOf(cells[34], s.hijriAdjust);
  const mn = lang === 'ar' ? HIJRI_MONTHS_AR : HIJRI_MONTHS_EN;
  const hijriRange = h1.m === h2.m ? `${mn[h1.m - 1]} ${fmtNumber(h1.y, lang).replace(/[,٬]/g, '')}` : `${mn[h1.m - 1]} – ${mn[h2.m - 1]} ${fmtNumber(h2.y, lang).replace(/[,٬]/g, '')}`;
  const selOcc = occMap.get(sel) ?? occasionsOn(sel, opts);
  const selTasks = Object.values(data.tasks).filter((x) => x.dueDate === sel).sort((a, b) => Number(a.status === 'done') - Number(b.status === 'done'));
  const selBlocks = blocksForDate(data, sel).filter((b) => b.status !== 'cancelled');
  const upcoming = useMemo(() => { const out: Occasion[] = []; for (let i = 0; i < 120 && out.length < 6; i++) out.push(...occasionsOn(addDays(today, i), opts).filter((o) => !o.flagged || s.showOtherReligions)); return out.slice(0, 6); }, [today, opts, s.showOtherReligions]);
  const newOcc = (): SpecialDate => { const n = Date.now(); return { id: uid('sd'), date: sel, label: '', kind: 'special', emoji: 'sparkles', yearly: false, notify: true, notifyMin: 8 * 60, note: '', createdAt: n, updatedAt: n }; };
  const newTask = (): Task => { const n = Date.now(); return { id: uid('t'), title: '', description: '', dueDate: sel, priority: 3, status: 'todo', estimateMin: 30, trackedMin: 0, tags: [], checklist: [], subtasks: [], notes: '', dependsOn: [], starred: false, someday: false, createdAt: n, updatedAt: n }; };
  const week = cells.slice(0, 7);

  return (
    <div>
      <ScreenHeader title={t('m_calendar')} subtitle={`${mTitle} · ${hijriRange}`} onBack={onBack}
        actions={<><Button size="sm" variant={s.showOtherReligions ? 'tinted' : 'ghost'} icon={s.showOtherReligions ? <Eye size={14} /> : <EyeOff size={14} />} onClick={() => useApp.getState().updateSettings({ showOtherReligions: !s.showOtherReligions })}>{t('cal_others')}</Button><HelpTip id="other_religions" /></>} />
      <Page>
        <div className="flex items-center justify-between">
          <Button size="sm" variant="secondary" aria-label={t('back')} onClick={() => shift(-1)}>{lang === 'ar' ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}</Button>
          <button className="text-sm font-bold text-accent" onClick={() => { setMonth(today.slice(0, 7) + '-01'); setSel(today); }}>{t('today')}</button>
          <Button size="sm" variant="secondary" aria-label={t('next_up')} onClick={() => shift(1)}>{lang === 'ar' ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}</Button>
        </div>
        <Card className="anim-page mt-3 p-2.5">
          <div className="mb-1 grid grid-cols-7 text-center text-[11px] font-bold text-ink-3">{week.map((d) => <span key={d} className="py-1">{weekdayName(new Date(d + 'T12:00').getDay(), lang, 'short')}</span>)}</div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((d) => {
              const occ = occMap.get(d) ?? [];
              const isSel = d === sel, isToday = d === today, other = d.slice(0, 7) !== month.slice(0, 7);
              const holiday = occ.some((o) => o.official && !o.flagged) || occ.some((o) => o.official);
              const flagged = occ.some((o) => o.flagged);
              const hj = hijriOf(d, s.hijriAdjust);
              const tc = taskDays.get(d) ?? 0, bc = blockDays.get(d) ?? 0;
              return (
                <button key={d} onClick={() => { setSel(d); if (other) setMonth(d.slice(0, 7) + '-01'); }}
                  className={cn('press relative flex min-h-[64px] flex-col items-center rounded-2xl px-0.5 pb-1 pt-1.5 transition-colors', other && 'opacity-40', isSel ? 'bg-accent text-accent-ink shadow-md' : isToday ? 'bg-accent-soft' : 'hover:bg-surface-2', holiday && !isSel && 'ring-1 ring-success/50')}>
                  <span className={cn('num text-[15px] font-bold leading-4', !isSel && holiday && 'text-success', !isSel && isToday && 'text-accent')}>{fmtNumber(Number(d.slice(8)), lang)}</span>
                  <span className={cn('num text-[9px] leading-3', isSel ? 'opacity-80' : 'text-ink-3')}>{fmtNumber(hj.d, lang)}</span>
                  <span className="mt-0.5 flex h-4 items-center justify-center gap-px">
                    {occ.slice(0, 2).map((o) => <Orn key={o.id} name={o.emoji} size={15} />)}
                  </span>
                  <span className="mt-auto flex items-center gap-0.5">
                    {bc > 0 && <span className={cn('h-1.5 w-1.5 rounded-full', isSel ? 'bg-accent-ink' : 'bg-accent')} />}
                    {tc > 0 && <span className="h-1.5 w-1.5 rounded-full bg-warning" />}
                  </span>
                  {flagged && <span className="absolute -end-0.5 -top-0.5 grid h-[15px] w-[15px] place-items-center rounded-full bg-danger text-[10px] font-extrabold leading-none text-white ring-2 ring-[var(--surface)]">!</span>}
                </button>
              );
            })}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 px-1 text-[10px] text-ink-3">
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-accent" />{t('cal_legend_acts')}</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-warning" />{t('cal_legend_tasks')}</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full ring-1 ring-success" />{t('cal_legend_official')}</span>
            <span className="flex items-center gap-1"><span className="grid h-3 w-3 place-items-center rounded-full bg-danger text-[8px] font-bold text-white">!</span>{t('cal_legend_other')}</span>
          </div>
        </Card>

        {/* selected day */}
        <div key={sel} className="anim-page">
          <SectionTitle>{fmtDate(sel, lang)}</SectionTitle>
          <p className="-mt-1 mb-2 px-1 text-sm text-ink-2">{hijriLabel(sel, s.hijriAdjust, lang)}{sel === today ? ` · ${t('today')}` : sel > today ? ` · ${lang === 'ar' ? `بعد ${fmtNumber(diffDays(today, sel), lang)} يوم` : `in ${diffDays(today, sel)} days`}` : ''}</p>
          <div className="mb-3 grid grid-cols-4 gap-2">
            <ActionBtn icon={<Plus size={18} />} label={t('cal_add_occ')} onClick={() => setAddOcc(newOcc())} />
            <ActionBtn icon={<CheckSquare size={18} />} label={t('cal_add_task')} onClick={() => setTask(newTask())} />
            <ActionBtn icon={<CalendarPlus size={18} />} label={t('cal_add_act')} onClick={() => ui.openEditor({ date: sel })} />
            <ActionBtn icon={<NotebookPen size={18} />} label={t('m_journal')} onClick={() => { ui.set({ selectedDate: sel }); ui.push('journal'); }} />
          </div>

          {selOcc.length === 0 ? <p className="rounded-2xl border border-dashed border-line px-4 py-3 text-sm text-ink-3">{t('cal_no_occ')}</p> : (
            <div className="space-y-2">{selOcc.map((o) => (
              <Card key={o.id} className="overflow-hidden">
                <div className="flex items-stretch">
                  <button onClick={() => setDetail(o)} className="relative w-24 shrink-0 overflow-hidden"><img src={photoUrl(o.image)} alt="" className="absolute inset-0 h-full w-full object-cover" /><span className="absolute inset-0 bg-black/20" /><Orn name={o.emoji} size={34} className="absolute bottom-1.5 end-1.5 drop-shadow-lg" /></button>
                  <div className="min-w-0 flex-1 p-3">
                    <div className="flex items-start gap-2"><div className="min-w-0 flex-1"><div className="text-[15px] font-bold leading-snug">{lang === 'ar' ? o.title : o.titleEn}</div></div><HelpButton onClick={() => setDetail(o)} /></div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      <OfficialBadge o={o} lang={lang} />
                      {o.flagged && <FlagBadge label={(lang === 'ar' ? o.religionLabelAr : o.religionLabelEn) ?? ''} />}
                      {o.source === 'user' && <Badge tone="accent">{t('cal_mine')}</Badge>}
                    </div>
                    {o.flagged && <p className="mt-1.5 text-[11px] text-ink-3">{t('cal_flag_note')}</p>}
                  </div>
                </div>
              </Card>
            ))}</div>
          )}

          <SectionTitle>{t('m_tasks')}</SectionTitle>
          {selTasks.length === 0 ? <p className="px-1 text-sm text-ink-3">{t('cal_no_tasks')}</p> : (
            <Card className="divide-y divide-line">{selTasks.map((x) => (
              <div key={x.id} className="flex items-center gap-3 px-3 py-2.5">
                <button aria-label={t('done')} onClick={() => useApp.getState().put('tasks', { ...x, status: x.status === 'done' ? 'todo' : 'done', completedAt: x.status === 'done' ? undefined : Date.now() })}>{x.status === 'done' ? <CircleCheck size={22} className="text-success" /> : <Circle size={22} className="text-ink-3" />}</button>
                <button className={cn('min-w-0 flex-1 truncate text-start text-[15px]', x.status === 'done' && 'text-ink-3 line-through')} onClick={() => setTask(x)}>{x.title}</button>
              </div>
            ))}</Card>
          )}
          {selBlocks.length > 0 && <>
            <SectionTitle>{t('timeline')}</SectionTitle>
            <Card className="divide-y divide-line">{selBlocks.map((b) => (
              <button key={b.id} onClick={() => ui.set({ detailFor: b.id })} className="flex w-full items-center gap-3 px-3 py-2.5 text-start">
                <span className="h-8 w-1 rounded-full" style={{ background: b.color }} />
                <span className="min-w-0 flex-1"><span className="block truncate text-[15px] font-medium">{b.title}</span><span className="num text-xs text-ink-3">{fmtTime(b.startMin, lang, s.clock24)} – {fmtTime(b.startMin + b.durationMin, lang, s.clock24)}</span></span>
                {b.applied === false && <Badge tone="warning">{t('draft')}</Badge>}
              </button>
            ))}</Card>
          </>}
        </div>

        <SectionTitle>{t('cal_upcoming')}</SectionTitle>
        <Card className="divide-y divide-line">{upcoming.map((o) => (
          <button key={o.id} onClick={() => { setSel(o.date); setMonth(o.date.slice(0, 7) + '-01'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="flex w-full items-center gap-3 px-3 py-2.5 text-start">
            <Orn name={o.emoji} size={30} />
            <span className="min-w-0 flex-1"><span className="flex flex-wrap items-center gap-1.5 text-[15px] font-semibold">{lang === 'ar' ? o.title : o.titleEn}{o.flagged && <FlagBadge label={(lang === 'ar' ? o.religionLabelAr : o.religionLabelEn) ?? ''} />}</span>
              <span className="text-xs text-ink-3">{fmtDate(o.date, lang, { weekday: 'long', day: 'numeric', month: 'long' })} · {lang === 'ar' ? o.officialAr : o.officialEn}</span></span>
            <span className="num text-sm font-bold text-accent">{diffDays(today, o.date) === 0 ? t('today') : fmtNumber(diffDays(today, o.date), lang)}</span>
          </button>
        ))}</Card>
      </Page>
      {addOcc && <OccasionEditor occ={addOcc} onClose={() => setAddOcc(null)} />}
      {detail && <OccasionDetail occ={detail} onClose={() => setDetail(null)} onEdit={(u) => { setDetail(null); setAddOcc(u); }} />}
      {task && <TaskEditor task={task} onClose={() => setTask(null)} />}
    </div>
  );
}

const ActionBtn = ({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) => (
  <button onClick={onClick} className="press card flex flex-col items-center gap-1.5 px-1 py-3"><span className="grid h-9 w-9 place-items-center rounded-2xl bg-accent-soft text-accent">{icon}</span><span className="text-center text-[11px] font-bold leading-tight">{label}</span></button>
);

function OccasionDetail({ occ, onClose, onEdit }: { occ: Occasion; onClose: () => void; onEdit: (u: SpecialDate) => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const { ask, node } = useConfirm();
  const user = occ.userId ? useApp.getState().data.specialDates[occ.userId] : undefined;
  return (
    <Sheet open onClose={onClose} tall title={<span className="flex items-center gap-2"><Orn name={occ.emoji} size={26} />{lang === 'ar' ? occ.title : occ.titleEn}</span>}>
      {node}
      <div className="relative -mx-1 mb-4 h-44 overflow-hidden rounded-3xl">
        <img src={photoUrl(occ.image)} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" />
        <div className="absolute inset-x-3 bottom-3 text-white text-shadow"><div className="text-lg font-bold">{fmtDate(occ.date, lang, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div><div className="text-sm opacity-90">{hijriLabel(occ.date, s.hijriAdjust, lang)}</div></div>
      </div>
      <div className="mb-4 flex flex-wrap items-center gap-2"><OfficialBadge o={occ} lang={lang} /><HelpTip id="official_holiday" />
        {occ.flagged && <FlagBadge label={(lang === 'ar' ? occ.religionLabelAr : occ.religionLabelEn) ?? ''} />}
        {!occ.flagged && <Badge>{religionLabel(occ.religion, lang)}</Badge>}</div>
      <Card className="p-4"><p className="text-[15px] leading-8">{lang === 'ar' ? occ.detailsAr : occ.detailsEn}</p></Card>
      <div className="mt-3 rounded-2xl border border-line bg-surface p-3 text-sm leading-7" style={{ borderInlineStartWidth: 4, borderInlineStartColor: occ.flagged ? 'var(--danger)' : '#22a45d' }}>
        {occ.flagged ? t('cal_flag_note_long') : occ.notify && s.occasionNotify ? t('cal_notified_yes') : t('cal_notified_no')}
        {!occ.flagged && <span className="ms-1 inline-block align-middle"><HelpTip id="occasion_notify" /></span>}
      </div>
      {user && <div className="mt-4 flex gap-2"><Button variant="secondary" className="flex-1" icon={<Pencil size={15} />} onClick={() => onEdit(user)}>{t('edit')}</Button>
        <Button variant="danger" icon={<Trash2 size={15} />} onClick={async () => { if (await ask(t('delete'), user.label)) { await useApp.getState().remove('specialDates', [user.id]); await useApp.getState().syncOccasions(); onClose(); } }}>{t('delete')}</Button></div>}
    </Sheet>
  );
}

function OccasionEditor({ occ, onClose }: { occ: SpecialDate; onClose: () => void }) {
  const { t, lang } = useT();
  const exists = !!useApp.getState().data.specialDates[occ.id];
  const [o, setO] = useState(occ);
  const up = <K extends keyof SpecialDate>(k: K, v: SpecialDate[K]) => setO((p) => ({ ...p, [k]: v }));
  const names = useMemo(() => [...new Set([...QUICK_EMOJI, ...allEmojiNames().slice(0, 40)])].slice(0, 36), []);
  const save = async () => {
    if (!o.label.trim()) return;
    if (await useApp.getState().put('specialDates', { ...o, label: o.label.trim() })) { await useApp.getState().syncOccasions(); useApp.getState().toast('success', t('saved')); onClose(); }
  };
  return (
    <Sheet open onClose={onClose} tall title={exists ? t('cal_edit_occ') : t('cal_add_occ')}
      footer={<div className="flex gap-2">{exists && <Button variant="danger" icon={<Trash2 size={15} />} aria-label={t('delete')} onClick={async () => { await useApp.getState().remove('specialDates', [o.id]); await useApp.getState().syncOccasions(); onClose(); }} />}<Button className="flex-1" disabled={!o.label.trim()} onClick={save}>{t('save')}</Button></div>}>
      <div className="space-y-4">
        <Field label={t('title')}><Input autoFocus value={o.label} onChange={(e) => up('label', e.target.value)} placeholder={t('cal_occ_ph')} maxLength={80} /></Field>
        <Field label={t('date')}><Input type="date" value={o.date} onChange={(e) => e.target.value && up('date', e.target.value)} /></Field>
        <Toggle checked={!!o.yearly} onChange={(v) => up('yearly', v)} label={t('cal_yearly')} description={t('cal_yearly_hint')} />
        <Field label={t('icon')}><div className="grid grid-cols-6 gap-2">{names.map((n) => <button key={n} type="button" onClick={() => up('emoji', n)} className={cn('press grid h-12 place-items-center rounded-2xl', o.emoji === n ? 'bg-accent-soft ring-2 ring-accent' : 'bg-surface-2')}><Orn name={n} size={28} /></button>)}</div></Field>
        <Toggle checked={o.notify !== false} onChange={(v) => up('notify', v)} label={t('cal_notify')} description={t('cal_notify_hint')} help="occasion_notify" />
        {o.notify !== false && <Field label={t('time')}><Input type="time" value={minToInput(o.notifyMin ?? 480)} onChange={(e) => up('notifyMin', inputToMin(e.target.value))} /></Field>}
        <Field label={t('notes')}><TextArea value={o.note ?? ''} onChange={(e) => up('note', e.target.value)} /></Field>
        <Chip active={false}>{lang === 'ar' ? 'هتظهر في التقويم والإشعارات والويدجت' : 'Shown in calendar, notifications and widgets'}</Chip>
      </div>
    </Sheet>
  );
}
