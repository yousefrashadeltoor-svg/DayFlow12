import { useMemo, useState } from 'react';
import { Plus, Star, CalendarPlus, Paperclip, X, Flag, FolderKanban, CheckCircle2, Circle } from 'lucide-react';
import { useApp, blocksForDate, instantiate } from '@/stores/appStore';

import { Badge, Button, Card, Chip, EmptyState, Field, Input, Page, ProgressBar, ScreenHeader, SectionTitle, Segmented, Select, Sheet, Stepper, TextArea, Toggle, useSettings, useT, useConfirm } from '@/components/common/ui';
import type { Task, Project, Subtask } from '@/models/types';
import { addDays, fmtDate, fmtDuration, fmtNumber, nowMinutes, todayKey, inputToMin, minToInput, epochOf } from '@/utils/date';
import { uid } from '@/utils/id';
import { placeAcrossDays } from '@/services/scheduling/engine';
import { toSched } from '@/components/cards/blocks';
import { coreFrom } from '@/services/defaults';
import { pickFile } from '@/services/native/dayflowNative';
import { cn } from '@/utils/cn';

type ListKey = 'inbox' | 'today' | 'upcoming' | 'overdue' | 'completed' | 'starred' | 'someday' | string;
const newTask = (p: Partial<Task> = {}): Task => { const n = Date.now(); return { id: uid('t'), title: '', description: '', priority: 3, status: 'todo', estimateMin: 30, trackedMin: 0, tags: [], checklist: [], subtasks: [], notes: '', dependsOn: [], starred: false, someday: false, createdAt: n, updatedAt: n, ...p }; };

export function TasksScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [list, setList] = useState<ListKey>('today');
  const [edit, setEdit] = useState<Task | null>(null);
  const [newList, setNewList] = useState(false);
  const today = todayKey();
  const tasks = Object.values(data.tasks);
  const filters: Record<string, (x: Task) => boolean> = {
    inbox: (x) => x.status !== 'done' && !x.dueDate && !x.projectId && !x.listId && !x.someday,
    today: (x) => x.status !== 'done' && (x.dueDate === today || (x.startDate != null && x.startDate <= today && (!x.dueDate || x.dueDate >= today))),
    upcoming: (x) => x.status !== 'done' && !!x.dueDate && x.dueDate > today,
    overdue: (x) => x.status !== 'done' && !!x.dueDate && x.dueDate < today,
    completed: (x) => x.status === 'done',
    starred: (x) => x.status !== 'done' && x.starred,
    someday: (x) => x.status !== 'done' && x.someday,
  };
  const visible = tasks.filter(filters[list] ?? ((x) => x.listId === list && x.status !== 'done')).sort((a, b) => (a.dueDate ?? '9').localeCompare(b.dueDate ?? '9') || b.priority - a.priority);
  const toggle = async (x: Task) => {
    const done = x.status !== 'done';
    await useApp.getState().put('tasks', { ...x, status: done ? 'done' : 'todo', completedAt: done ? Date.now() : undefined });
    if (done && x.recurrence && x.dueDate) {
      const step = x.recurrence.freq === 'daily' ? x.recurrence.interval : x.recurrence.freq === 'weekly' ? 7 * x.recurrence.interval : 30 * x.recurrence.interval;
      const nextDue = addDays(x.dueDate, step);
      if (!x.recurrence.until || nextDue <= x.recurrence.until) await useApp.getState().put('tasks', newTask({ ...x, id: uid('t'), status: 'todo', trackedMin: 0, completedAt: undefined, dueDate: nextDue, checklist: x.checklist.map((c) => ({ ...c, done: false })), subtasks: x.subtasks.map((c) => ({ ...c, done: false })) }));
    }
  };
  const counts = (k: string) => tasks.filter(filters[k] ?? ((x) => x.listId === k && x.status !== 'done')).length;

  return (
    <div>
      <ScreenHeader title={t('m_tasks')} onBack={onBack} actions={<Button size="sm" icon={<Plus size={16} />} onClick={() => setEdit(newTask({ dueDate: list === 'today' ? today : undefined, listId: filters[list] ? undefined : list, starred: list === 'starred', someday: list === 'someday' }))}>{t('new_task')}</Button>} />
      <Page>
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 no-scrollbar">
          {(['today', 'inbox', 'upcoming', 'overdue', 'starred', 'someday', 'completed'] as const).map((k) => <Chip key={k} active={list === k} onClick={() => setList(k)}>{t(k === 'completed' ? 'completed' : k === 'today' ? 'today' : k)} {counts(k) ? fmtNumber(counts(k), lang) : ''}</Chip>)}
          {Object.values(data.taskLists).map((l) => <Chip key={l.id} active={list === l.id} color={l.color} onClick={() => setList(l.id)}>{l.name}</Chip>)}
          <Chip onClick={() => setNewList(true)}><Plus size={13} />{t('new_list')}</Chip>
        </div>
        {visible.length === 0 ? <EmptyState icon={<CheckCircle2 size={28} />} title={t('empty_generic')} /> : (
          <Card className="mt-3 divide-y divide-line">
            {visible.map((x) => {
              const sessions = Object.values(data.activities).filter((b) => b.taskId === x.id);
              const blocked = x.dependsOn.some((d) => data.tasks[d] && data.tasks[d].status !== 'done');
              return (
                <div key={x.id} className="flex items-start gap-3 px-3 py-3">
                  <button aria-label={t('done')} onClick={() => toggle(x)} className="mt-0.5">{x.status === 'done' ? <CheckCircle2 size={22} className="text-success" /> : <Circle size={22} className={x.priority >= 4 ? 'text-danger' : 'text-ink-3'} />}</button>
                  <button className="min-w-0 flex-1 text-start" onClick={() => setEdit(x)}>
                    <div className={cn('text-[15px] font-medium', x.status === 'done' && 'text-ink-3 line-through')}>{x.title}</div>
                    <div className="mt-1 flex flex-wrap gap-1.5">
                      {x.dueDate && <Badge tone={x.dueDate < today && x.status !== 'done' ? 'danger' : 'neutral'}>{fmtDate(x.dueDate, lang, { day: 'numeric', month: 'short' })}</Badge>}
                      {x.projectId && data.projects[x.projectId] && <Badge tone="info"><FolderKanban size={10} />{data.projects[x.projectId].title}</Badge>}
                      {(x.checklist.length + x.subtasks.length) > 0 && <Badge>{[...x.checklist, ...x.subtasks].filter((c) => c.done).length}/{x.checklist.length + x.subtasks.length}</Badge>}
                      {x.trackedMin > 0 && <Badge tone="accent">{fmtDuration(x.trackedMin, lang)} / {fmtDuration(x.estimateMin, lang)}</Badge>}
                      {sessions.length > 0 && <Badge>{fmtNumber(sessions.length, lang)} {t('sessions')}</Badge>}
                      {blocked && <Badge tone="warning">{t('depends_on')}</Badge>}
                    </div>
                  </button>
                  {x.starred && <Star size={16} className="mt-1 fill-warning text-warning" />}
                </div>
              );
            })}
          </Card>
        )}
      </Page>
      {edit && <TaskEditor task={edit} onClose={() => setEdit(null)} />}
      <NewListSheet open={newList} onClose={() => setNewList(false)} />
    </div>
  );
}

function NewListSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t } = useT(); const [name, setName] = useState('');
  return <Sheet open={open} onClose={onClose} title={t('new_list')} footer={<Button className="w-full" disabled={!name.trim()} onClick={async () => { const n = Date.now(); await useApp.getState().put('taskLists', { id: uid('l'), name: name.trim(), color: 'var(--accent)', createdAt: n, updatedAt: n }); setName(''); onClose(); }}>{t('save')}</Button>}><Field label={t('list_name')}><Input value={name} onChange={(e) => setName(e.target.value)} autoFocus /></Field></Sheet>;
}

export function TaskEditor({ task, onClose }: { task: Task; onClose: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const data = useApp((st) => st.data);
  const [x, setX] = useState<Task>(task);
  const [item, setItem] = useState(''); const [sub, setSub] = useState('');
  const { ask, node } = useConfirm();
  const isNew = !data.tasks[task.id];
  const up = <K extends keyof Task>(k: K, v: Task[K]) => setX((p) => ({ ...p, [k]: v }));
  const attachments = Object.values(data.attachments).filter((a) => a.ownerType === 'task' && a.ownerId === x.id);
  const save = async () => { if (!x.title.trim()) return; if (await useApp.getState().put('tasks', { ...x, title: x.title.trim() })) { useApp.getState().toast('success', t('saved')); onClose(); } };
  const remove = async () => { if (await ask(t('delete'), x.title)) { await useApp.getState().remove('tasks', [x.id]); onClose(); } };
  const addItem = (k: 'checklist' | 'subtasks', title: string) => { if (title.trim()) up(k, [...x[k], { id: uid(), title: title.trim(), done: false }]); };
  const remaining = Math.max(0, x.estimateMin - x.trackedMin - Object.values(data.activities).filter((b) => b.taskId === x.id && b.status === 'planned').reduce((a, b) => a + b.durationMin, 0));

  const schedule = async () => {
    await useApp.getState().put('tasks', { ...x, title: x.title.trim() || t('new_task') });
    const today = todayKey();
    const horizon = 7;
    const st = useApp.getState();
    await st.ensureDays(today, horizon);
    const days = Array.from({ length: horizon }, (_, i) => addDays(today, i)).map((d) => ({ date: d, items: blocksForDate(useApp.getState().data, d).map(toSched), fromMin: d === today ? Math.ceil(nowMinutes() / 5) * 5 : s.dayStartMin }));
    const { placements, shortages } = placeAcrossDays([{ refId: x.id, title: x.title, durationMin: remaining, priority: x.priority, difficulty: 3, deadline: x.dueDate, splitAllowed: true, minSplitMin: Math.min(25, remaining) }], days,
      { dayStartMin: s.dayStartMin, dayEndMin: s.dayEndMin, productiveStartMin: s.productiveStartMin, productiveEndMin: s.productiveEndMin, bufferMin: s.defaultBufferMin });
    if (!placements.length) { st.toast('error', t('no_slot')); return; }
    const blocks = placements.map((p) => instantiate(coreFrom({ title: x.title, categoryId: x.categoryId ?? 'cat_work', startMin: p.startMin, durationMin: p.durationMin, taskId: x.id, projectId: x.projectId, goalId: x.goalId, priority: x.priority, splitAllowed: true }), p.date, { source: 'task' }));
    if (await st.commit({ activities: blocks })) st.toast(shortages[x.id] ? 'info' : 'success', `${t('task_scheduled', { n: blocks.length })}${shortages[x.id] ? ` · ${t('shortage', { d: fmtDuration(shortages[x.id], lang) })}` : ''}`);
  };
  const attach = async () => {
    try {
      const f = await pickFile('attachment', '*/*');
      const n = Date.now();
      await useApp.getState().put('attachments', { id: uid('a'), name: f.name, path: f.path ?? '', mimeType: f.mimeType, size: f.size, ownerType: 'task', ownerId: x.id, createdAt: n, updatedAt: n });
    } catch { /* cancelled */ }
  };
  const Items = ({ k }: { k: 'checklist' | 'subtasks' }) => (
    <div>{x[k].map((c: Subtask) => (
      <div key={c.id} className="flex items-center gap-2 py-1"><input type="checkbox" className="h-5 w-5 accent-[var(--accent)]" checked={c.done} onChange={() => up(k, x[k].map((y) => y.id === c.id ? { ...y, done: !y.done } : y))} /><span className={cn('flex-1 text-sm', c.done && 'text-ink-3 line-through')}>{c.title}</span><button aria-label={t('delete')} onClick={() => up(k, x[k].filter((y) => y.id !== c.id))}><X size={14} className="text-ink-3" /></button></div>
    ))}</div>
  );
  return (
    <Sheet open onClose={onClose} tall title={isNew ? t('new_task') : x.title} footer={<div className="flex gap-2">{!isNew && <Button variant="danger" onClick={remove}>{t('delete')}</Button>}<Button className="flex-1" disabled={!x.title.trim()} onClick={save}>{t('save')}</Button></div>}>
      {node}
      <div className="space-y-4">
        <Field label={t('title')}><Input value={x.title} onChange={(e) => up('title', e.target.value)} autoFocus={isNew} /></Field>
        <Field label={t('description')}><TextArea value={x.description} onChange={(e) => up('description', e.target.value)} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t('due_date')}><Input type="date" value={x.dueDate ?? ''} onChange={(e) => up('dueDate', e.target.value || undefined)} /></Field>
          <Field label={t('start_date')}><Input type="date" value={x.startDate ?? ''} onChange={(e) => up('startDate', e.target.value || undefined)} /></Field>
        </div>
        <Field label={t('status')}><Segmented value={x.status} onChange={(v) => up('status', v)} size="sm" options={[{ value: 'todo', label: t('st_todo') }, { value: 'in_progress', label: t('st_in_progress') }, { value: 'done', label: t('st_done') }]} /></Field>
        <div className="flex items-center justify-between"><span className="flex items-center gap-1.5"><Flag size={15} />{t('priority')}</span><Stepper value={x.priority} onChange={(v) => up('priority', v)} min={1} max={5} /></div>
        <div className="flex items-center justify-between"><span>{t('estimate')}</span><Stepper value={x.estimateMin} onChange={(v) => up('estimateMin', v)} min={0} max={6000} step={15} /></div>
        <Card className="p-3 text-sm">
          <div className="flex justify-between"><span>{t('tracked_time')}</span><span className="num font-semibold">{fmtDuration(x.trackedMin, lang)}</span></div>
          <div className="flex justify-between"><span>{t('remaining_work')}</span><span className="num font-semibold">{fmtDuration(remaining, lang)}</span></div>
          <div className="flex justify-between"><span>{t('sessions_count')}</span><span className="num font-semibold">{fmtNumber(Object.values(data.activities).filter((b) => b.taskId === x.id).length, lang)}</span></div>
          <ProgressBar className="mt-2" value={(x.trackedMin / Math.max(1, x.estimateMin)) * 100} />
          <Button variant="tinted" className="mt-3 w-full" icon={<CalendarPlus size={16} />} disabled={remaining <= 0 || !x.title.trim()} onClick={schedule}>{t('schedule_task')}</Button>
        </Card>
        <Field label={t('checklist')}><Items k="checklist" /><div className="mt-1 flex gap-2"><Input value={item} onChange={(e) => setItem(e.target.value)} placeholder={t('add_item')} onKeyDown={(e) => { if (e.key === 'Enter') { addItem('checklist', item); setItem(''); } }} /><Button variant="secondary" onClick={() => { addItem('checklist', item); setItem(''); }}><Plus size={16} /></Button></div></Field>
        <Field label={t('subtasks')}><Items k="subtasks" /><div className="mt-1 flex gap-2"><Input value={sub} onChange={(e) => setSub(e.target.value)} placeholder={t('add_item')} onKeyDown={(e) => { if (e.key === 'Enter') { addItem('subtasks', sub); setSub(''); } }} /><Button variant="secondary" onClick={() => { addItem('subtasks', sub); setSub(''); }}><Plus size={16} /></Button></div></Field>
        <Field label={t('reminders')}>
          <div className="grid grid-cols-2 gap-3">
            <Input type="date" value={x.reminderAt ? new Date(x.reminderAt).toISOString().slice(0, 10) : ''} onChange={(e) => up('reminderAt', e.target.value ? epochOf(e.target.value, x.reminderAt ? new Date(x.reminderAt).getHours() * 60 + new Date(x.reminderAt).getMinutes() : 9 * 60) : undefined)} />
            <Input type="time" disabled={!x.reminderAt} value={x.reminderAt ? minToInput(new Date(x.reminderAt).getHours() * 60 + new Date(x.reminderAt).getMinutes()) : ''} onChange={(e) => { if (x.reminderAt) { const d = new Date(x.reminderAt); const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; up('reminderAt', epochOf(k, inputToMin(e.target.value))); } }} />
          </div>
        </Field>
        <Field label={t('recurrence')}><Select value={x.recurrence?.freq ?? 'none'} onChange={(v) => up('recurrence', v === 'none' ? undefined : { freq: v as 'daily', interval: 1, start: x.dueDate ?? todayKey() })} options={[{ value: 'none', label: t('rec_none') }, { value: 'daily', label: t('rec_daily') }, { value: 'weekly', label: t('rec_weekly') }, { value: 'monthly', label: t('rec_monthly') }]} /></Field>
        <Field label={t('linked_project')}><Select value={x.projectId ?? ''} onChange={(v) => up('projectId', v || undefined)} options={[{ value: '', label: t('none') }, ...Object.values(data.projects).map((p) => ({ value: p.id, label: p.title }))]} /></Field>
        <Field label={t('linked_goal')}><Select value={x.goalId ?? ''} onChange={(v) => up('goalId', v || undefined)} options={[{ value: '', label: t('none') }, ...Object.values(data.goals).map((p) => ({ value: p.id, label: p.title }))]} /></Field>
        <Field label={t('lists')}><Select value={x.listId ?? ''} onChange={(v) => up('listId', v || undefined)} options={[{ value: '', label: t('inbox') }, ...Object.values(data.taskLists).map((p) => ({ value: p.id, label: p.name }))]} /></Field>
        <Field label={t('category')}><Select value={x.categoryId ?? ''} onChange={(v) => up('categoryId', v || undefined)} options={[{ value: '', label: t('none') }, ...Object.values(data.categories).map((c) => ({ value: c.id, label: lang === 'ar' ? c.nameAr : c.nameEn }))]} /></Field>
        <Field label={t('depends_on')}><div className="flex flex-wrap gap-2">{Object.values(data.tasks).filter((o) => o.id !== x.id && o.status !== 'done').slice(0, 30).map((o) => <Chip key={o.id} active={x.dependsOn.includes(o.id)} onClick={() => up('dependsOn', x.dependsOn.includes(o.id) ? x.dependsOn.filter((d) => d !== o.id) : [...x.dependsOn, o.id])}>{o.title}</Chip>)}</div></Field>
        <Field label={t('tags')}><Input value={x.tags.join(', ')} onChange={(e) => up('tags', e.target.value.split(/[,،]/).map((v) => v.trim()).filter(Boolean))} /></Field>
        <Toggle checked={x.starred} onChange={(v) => up('starred', v)} label={t('starred')} />
        <Toggle checked={x.someday} onChange={(v) => up('someday', v)} label={t('someday')} />
        <Field label={t('notes')}><TextArea value={x.notes} onChange={(e) => up('notes', e.target.value)} /></Field>
        <Field label={t('attachments')}>
          {attachments.map((a) => <div key={a.id} className="flex items-center justify-between py-1 text-sm"><span className="truncate">{a.name}</span><button onClick={() => useApp.getState().remove('attachments', [a.id])}><X size={14} /></button></div>)}
          <Button variant="secondary" size="sm" icon={<Paperclip size={14} />} onClick={attach} disabled={isNew}>{t('attach_file')}</Button>
        </Field>
      </div>
    </Sheet>
  );
}

export function ProjectsScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [open, setOpen] = useState<Project | null>(null);
  const progress = (p: Project) => { const ts = Object.values(data.tasks).filter((x) => x.projectId === p.id); const ms = Object.values(data.milestones).filter((m) => m.projectId === p.id); const total = ts.length + ms.length; return total ? Math.round(((ts.filter((x) => x.status === 'done').length + ms.filter((m) => m.done).length) / total) * 100) : 0; };
  const create = () => { const n = Date.now(); setOpen({ id: uid('p'), title: '', description: '', objectives: [], notes: '', color: 'var(--accent)', archived: false, createdAt: n, updatedAt: n }); };
  return (
    <div>
      <ScreenHeader title={t('m_projects')} onBack={onBack} actions={<Button size="sm" icon={<Plus size={16} />} onClick={create}>{t('new_project')}</Button>} />
      <Page>
        {Object.values(data.projects).length === 0 ? <EmptyState icon={<FolderKanban size={28} />} title={t('empty_generic')} action={<Button onClick={create}>{t('new_project')}</Button>} /> : (
          <div className="space-y-2">{Object.values(data.projects).filter((p) => !p.archived).map((p) => (
            <Card key={p.id} className="p-4" onClick={() => setOpen(p)}>
              <div className="flex items-center justify-between"><span className="text-[17px] font-semibold">{p.title}</span><span className="num text-sm font-bold">{fmtNumber(progress(p), lang)}%</span></div>
              {p.deadline && <p className="text-xs text-ink-3">{t('deadline')}: {fmtDate(p.deadline, lang, { day: 'numeric', month: 'short', year: 'numeric' })}</p>}
              <ProgressBar className="mt-2" value={progress(p)} />
            </Card>
          ))}</div>
        )}
      </Page>
      {open && <ProjectSheet project={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

function ProjectSheet({ project, onClose }: { project: Project; onClose: () => void }) {
  const { t, lang } = useT();
  const data = useApp((s) => s.data);
  const [p, setP] = useState(project);
  const [ms, setMs] = useState(''); const [obj, setObj] = useState(''); const [taskTitle, setTaskTitle] = useState('');
  const [editTask, setEditTask] = useState<Task | null>(null);
  const tasks = Object.values(data.tasks).filter((x) => x.projectId === p.id);
  const milestones = Object.values(data.milestones).filter((m) => m.projectId === p.id).sort((a, b) => (a.dueDate ?? '9').localeCompare(b.dueDate ?? '9'));
  const isNew = !data.projects[p.id];
  const timeline = useMemo(() => [...tasks.filter((x) => x.dueDate).map((x) => ({ d: x.dueDate!, label: x.title, done: x.status === 'done' })), ...milestones.filter((m) => m.dueDate).map((m) => ({ d: m.dueDate!, label: `◆ ${m.title}`, done: m.done }))].sort((a, b) => a.d.localeCompare(b.d)), [tasks, milestones]);
  const save = async () => { if (p.title.trim() && await useApp.getState().put('projects', { ...p, title: p.title.trim() })) onClose(); };
  const doneTasks = tasks.filter((x) => x.status === 'done');
  return (
    <Sheet open onClose={onClose} tall title={isNew ? t('new_project') : p.title} footer={<div className="flex gap-2">{!isNew && <Button variant="danger" onClick={async () => { await useApp.getState().remove('projects', [p.id]); onClose(); }}>{t('delete')}</Button>}<Button className="flex-1" disabled={!p.title.trim()} onClick={save}>{t('save')}</Button></div>}>
      <div className="space-y-4">
        <Field label={t('title')}><Input value={p.title} onChange={(e) => setP({ ...p, title: e.target.value })} /></Field>
        <Field label={t('description')}><TextArea value={p.description} onChange={(e) => setP({ ...p, description: e.target.value })} /></Field>
        <Field label={t('deadline')}><Input type="date" value={p.deadline ?? ''} onChange={(e) => setP({ ...p, deadline: e.target.value || undefined })} /></Field>
        <Field label={t('objectives')}>{p.objectives.map((o, i) => <div key={i} className="flex justify-between py-1 text-sm"><span>• {o}</span><button onClick={() => setP({ ...p, objectives: p.objectives.filter((_, j) => j !== i) })}><X size={14} /></button></div>)}
          <div className="flex gap-2"><Input value={obj} onChange={(e) => setObj(e.target.value)} /><Button variant="secondary" onClick={() => { if (obj.trim()) { setP({ ...p, objectives: [...p.objectives, obj.trim()] }); setObj(''); } }}><Plus size={16} /></Button></div></Field>
        {!isNew && <>
          <SectionTitle>{t('milestones')}</SectionTitle>
          <Card className="divide-y divide-line">{milestones.map((m) => <div key={m.id} className="flex items-center gap-2 px-3 py-2"><input type="checkbox" className="h-5 w-5 accent-[var(--accent)]" checked={m.done} onChange={() => useApp.getState().put('milestones', { ...m, done: !m.done })} /><span className={cn('flex-1 text-sm', m.done && 'line-through text-ink-3')}>{m.title}</span><input type="date" className="bg-transparent text-xs" value={m.dueDate ?? ''} onChange={(e) => useApp.getState().put('milestones', { ...m, dueDate: e.target.value || undefined })} /></div>)}
            <div className="flex gap-2 p-2"><Input value={ms} onChange={(e) => setMs(e.target.value)} placeholder={t('add_item')} /><Button variant="secondary" onClick={async () => { if (ms.trim()) { const n = Date.now(); await useApp.getState().put('milestones', { id: uid('m'), projectId: p.id, title: ms.trim(), done: false, createdAt: n, updatedAt: n }); setMs(''); } }}><Plus size={16} /></Button></div></Card>
          <SectionTitle>{t('m_tasks')} · {fmtNumber(doneTasks.length, lang)}/{fmtNumber(tasks.length, lang)}</SectionTitle>
          <Card className="divide-y divide-line">{tasks.map((x) => <button key={x.id} onClick={() => setEditTask(x)} className="flex w-full items-center gap-2 px-3 py-2 text-start text-sm">{x.status === 'done' ? <CheckCircle2 size={18} className="text-success" /> : <Circle size={18} className="text-ink-3" />}<span className="flex-1">{x.title}</span>{x.dueDate && <span className="text-xs text-ink-3">{fmtDate(x.dueDate, lang, { day: 'numeric', month: 'short' })}</span>}</button>)}
            <div className="flex gap-2 p-2"><Input value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} placeholder={t('new_task')} /><Button variant="secondary" onClick={async () => { if (taskTitle.trim()) { await useApp.getState().put('tasks', newTask({ title: taskTitle.trim(), projectId: p.id, goalId: p.goalId })); setTaskTitle(''); } }}><Plus size={16} /></Button></div></Card>
          <SectionTitle>{t('project_timeline')}</SectionTitle>
          <Card className="p-3">{timeline.length ? timeline.map((e, i) => <div key={i} className="flex justify-between py-1 text-sm"><span className={e.done ? 'text-ink-3 line-through' : ''}>{e.label}</span><span className="num text-ink-2">{fmtDate(e.d, lang, { day: 'numeric', month: 'short' })}</span></div>) : <p className="text-sm text-ink-3">{t('empty_generic')}</p>}</Card>
          <Card className="p-3 text-sm"><div className="flex justify-between"><span>{t('tracked_time')}</span><span className="num font-semibold">{fmtDuration(tasks.reduce((a, x) => a + x.trackedMin, 0), lang)}</span></div><div className="flex justify-between"><span>{t('estimate')}</span><span className="num font-semibold">{fmtDuration(tasks.reduce((a, x) => a + x.estimateMin, 0), lang)}</span></div></Card>
        </>}
        <Field label={t('linked_goal')}><Select value={p.goalId ?? ''} onChange={(v) => setP({ ...p, goalId: v || undefined })} options={[{ value: '', label: t('none') }, ...Object.values(data.goals).map((g) => ({ value: g.id, label: g.title }))]} /></Field>
        <Field label={t('notes')}><TextArea value={p.notes} onChange={(e) => setP({ ...p, notes: e.target.value })} /></Field>
      </div>
      {editTask && <TaskEditor task={editTask} onClose={() => setEditTask(null)} />}
    </Sheet>
  );
}
