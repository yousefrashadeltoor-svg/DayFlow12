import { useMemo, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, Compass, MapPin } from 'lucide-react';
import { useApp } from '@/stores/appStore';
import { Badge, Button, Card, Chip, HelpTip, Input, Page, ProgressBar, ProgressRing, ScreenHeader, SectionTitle, Segmented, Select, SRow, Stepper, Toggle, useNow, useSettings, useT, useHaptic } from '@/components/common/ui';
import { Orn } from '@/features/decor/Decor';
import { SoundField } from '@/features/alarms/SoundPicker';
import { ensureNotificationPermission } from '@/features/alarms/AlarmsScreen';
import { BarChart } from '@/components/charts/Charts';
import { EGYPT_PLACES, PRAYER_KEYS, nextPrayer, placeOf, prayerStats, qiblaBearing, timesFor } from '@/services/prayer';
import { hijriLabel } from '@/services/occasions';
import { photoUrl } from '@/services/decor';
import type { PrayerKey, Settings } from '@/models/types';
import { addDays, epochOf, fmtCountdown, fmtDate, fmtNumber, fmtTime, todayKey, weekdayName } from '@/utils/date';
import type { TKey } from '@/services/localization/i18n';
import { cn } from '@/utils/cn';

const ICON: Record<PrayerKey | 'sunrise', string> = { fajr: 'night_with_stars', sunrise: 'sunrise', dhuhr: 'sun', asr: 'sun_behind_small_cloud', maghrib: 'sunset', isha: 'crescent_moon' };
export const prayerName = (k: PrayerKey | 'sunrise', t: (k: TKey) => string) => t(`pr_${k}` as TKey);

export function usePrayerNext(tickMs = 1000) {
  const now = useNow(tickMs);
  const cfg = useSettings().prayer;
  return { now, cfg, next: useMemo(() => nextPrayer(now, cfg), [now, cfg]) };
}

/** Compact dashboard card: next prayer + live countdown + progress ring + today's tally. */
export function PrayerCard({ onOpen }: { onOpen: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const logs = useApp((st) => st.data.prayerLogs);
  const { next, now } = usePrayerNext();
  const stats = useMemo(() => prayerStats(Object.values(logs)), [logs]);
  if (!s.prayer.enabled) return (
    <Card onClick={onOpen} className="mt-3 flex items-center gap-3 p-3"><Orn name="mosque" size={40} /><div className="min-w-0 flex-1"><div className="text-[15px] font-bold">{t('prayer_enable_card')}</div><div className="text-xs text-ink-3">{t('prayer_enable_sub')}</div></div><Badge tone="accent">{t('enable')}</Badge></Card>
  );
  if (!next) return null;
  void now;
  return (
    <Card onClick={onOpen} className="mt-3 flex items-center gap-3 p-3">
      <ProgressRing value={next.progress} size={62} stroke={6} color="var(--accent)"><Orn name={ICON[next.key]} size={30} /></ProgressRing>
      <div className="min-w-0 flex-1"><div className="text-[11px] font-bold uppercase text-ink-3">{t('prayer_next')}</div>
        <div className="truncate text-[17px] font-bold">{prayerName(next.key, t)} · <span className="num">{fmtTime(new Date(next.at).getHours() * 60 + new Date(next.at).getMinutes(), lang, s.clock24)}</span></div>
        <div className="num text-sm font-semibold text-accent">{t('prayer_in')} {fmtCountdown(next.remainingMs, lang)}</div></div>
      <div className="text-center"><div className="num text-lg font-bold">{fmtNumber(stats.today, lang)}<span className="text-xs text-ink-3">/{fmtNumber(5, lang)}</span></div><div className="text-[10px] font-semibold text-ink-3">{t('prayer_today')}</div></div>
    </Card>
  );
}

export function PrayerScreen({ onBack }: { onBack: () => void }) {
  const { t, lang } = useT();
  const s = useSettings();
  const h = useHaptic();
  const logs = useApp((st) => st.data.prayerLogs);
  const { now, next } = usePrayerNext();
  const p = s.prayer;
  const [day, setDay] = useState(todayKey());
  const up = (patch: Partial<Settings['prayer']>) => useApp.getState().updateSettings({ prayer: { ...p, ...patch } });
  const times = timesFor(day, p);
  const place = placeOf(p.governorate);
  const stats = useMemo(() => prayerStats(Object.values(logs)), [logs]);
  const done = (d: string, k: PrayerKey) => logs[`${d}:${k}`];
  const ft = (m: number) => fmtTime(m, lang, s.clock24);
  const toggleDone = async (k: PrayerKey) => {
    h(14);
    const id = `${day}:${k}`;
    if (logs[id]) { await useApp.getState().remove('prayerLogs', [id], false); return; }
    const idx = PRAYER_KEYS.indexOf(k);
    const nextAt = idx < 4 && times ? epochOf(day, times[PRAYER_KEYS[idx + 1]]) : epochOf(addDays(day, 1), (timesFor(addDays(day, 1), p)?.fajr ?? 0));
    const n = Date.now();
    await useApp.getState().put('prayerLogs', { id, date: day, prayer: k, prayedAt: n, onTime: n <= nextAt, createdAt: n, updatedAt: n });
  };
  const enable = async (v: boolean) => { await up({ enabled: v }); if (v && !(await ensureNotificationPermission())) useApp.getState().toast('error', t('perm_notif_needed')); };
  const locate = () => {
    if (!('geolocation' in navigator)) { useApp.getState().toast('error', t('location_denied')); return; }
    navigator.geolocation.getCurrentPosition((pos) => up({ lat: Math.round(pos.coords.latitude * 1e4) / 1e4, lng: Math.round(pos.coords.longitude * 1e4) / 1e4 }), () => useApp.getState().toast('error', t('location_denied')), { enableHighAccuracy: false, timeout: 15000, maximumAge: 86400000 });
  };
  const week = stats.byDay;
  const qibla = Math.round(qiblaBearing(p.lat ?? place.lat, p.lng ?? place.lng));

  return (
    <div>
      <ScreenHeader title={t('prayer_title')} subtitle={`${lang === 'ar' ? place.ar : place.en} · ${hijriLabel(todayKey(), s.hijriAdjust, lang)}`} onBack={onBack} />
      <Page>
        {/* hero */}
        <section className="relative overflow-hidden rounded-[28px] text-white shadow-float">
          <img src={photoUrl(next && new Date(next.at).getHours() >= 17 ? 'mosque1' : 'oldcairo1')} alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0b1230]/55 to-[#0b1230]/90" />
          <div className="relative flex flex-col items-center px-4 pb-5 pt-5">
            {s.prayer.enabled && next ? <>
              <div className="text-[12px] font-bold uppercase tracking-wider text-white/80 text-shadow">{t('prayer_next')}</div>
              <div className="my-3"><ProgressRing value={next.progress} size={196} stroke={11} color="#f2c14e" track="rgba(255,255,255,.22)">
                <div className="text-center"><Orn name={ICON[next.key]} size={44} className="mx-auto" /><div className="mt-1 text-[22px] font-extrabold text-shadow">{prayerName(next.key, t)}</div>
                  <div className="num text-lg font-bold text-shadow">{ft(new Date(next.at).getHours() * 60 + new Date(next.at).getMinutes())}</div></div></ProgressRing></div>
              <div className="num text-[34px] font-extrabold leading-none text-shadow">{fmtCountdown(next.remainingMs, lang)}</div>
              <div className="mt-1 text-xs text-white/80">{t('prayer_since')} {prayerName(next.prevKey, t)} · <span className="num">{fmtNumber(Math.round(next.progress), lang)}%</span></div>
            </> : <div className="py-6 text-center"><Orn name="mosque" size={64} className="mx-auto" /><p className="mt-2 text-sm font-semibold">{t('prayer_off_hint')}</p></div>}
            <div className="mt-4 grid w-full grid-cols-3 gap-2 text-center">
              <HeroStat n={`${fmtNumber(stats.today, lang)}/${fmtNumber(5, lang)}`} l={t('prayer_today')} /><HeroStat n={`${fmtNumber(stats.weekRate, lang)}%`} l={t('prayer_week')} /><HeroStat n={fmtNumber(stats.streak, lang)} l={t('prayer_streak')} />
            </div>
          </div>
        </section>

        <div className="mt-4 flex items-center justify-between">
          <Button size="sm" variant="secondary" aria-label={t('back')} onClick={() => setDay(addDays(day, -1))}>{lang === 'ar' ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}</Button>
          <button className="text-center" onClick={() => setDay(todayKey())}><div className="text-[15px] font-bold">{fmtDate(day, lang, { weekday: 'long', day: 'numeric', month: 'long' })}</div><div className="text-xs text-ink-3">{hijriLabel(day, s.hijriAdjust, lang)}</div></button>
          <Button size="sm" variant="secondary" aria-label={t('next_up')} onClick={() => setDay(addDays(day, 1))}>{lang === 'ar' ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}</Button>
        </div>

        {times ? (
          <div className="stagger mt-3 space-y-2">
            {([['fajr', times.fajr], ['sunrise', times.sunrise], ['dhuhr', times.dhuhr], ['asr', times.asr], ['maghrib', times.maghrib], ['isha', times.isha]] as [PrayerKey | 'sunrise', number][]).map(([k, m], i) => {
              const at = epochOf(day, m);
              const isNext = next && day === todayKey() && k !== 'sunrise' && next.key === k && !next.isTomorrow;
              const d = k !== 'sunrise' ? done(day, k as PrayerKey) : undefined;
              const passed = at <= now;
              return (
                <Card key={k} className={cn('flex items-center gap-3 p-3', isNext && 'ring-2 ring-accent')} style={{ ['--i' as string]: i }}>
                  <Orn name={ICON[k]} size={36} />
                  <div className="min-w-0 flex-1"><div className="text-[16px] font-bold">{prayerName(k, t)}</div>{k === 'sunrise' ? <div className="text-xs text-ink-3">{t('prayer_sunrise_note')}</div> : d ? <div className="text-xs font-semibold text-success">✓ {d.onTime ? t('prayer_on_time') : t('prayer_late')}</div> : isNext ? <div className="text-xs font-semibold text-accent">{t('prayer_next')}</div> : null}</div>
                  <div className="num text-[19px] font-extrabold">{ft(m)}</div>
                  {k !== 'sunrise' && <button aria-label={t('prayer_mark')} disabled={!passed && !d} onClick={() => toggleDone(k as PrayerKey)} className={cn('press grid h-11 w-11 place-items-center rounded-2xl transition-colors disabled:opacity-30', d ? 'bg-success text-white' : 'bg-surface-2 text-ink-3')}><Check size={20} /></button>}
                </Card>
              );
            })}
          </div>
        ) : <p className="mt-4 text-sm text-danger">{t('prayer_need_coords')}</p>}

        <SectionTitle>{t('prayer_stats')}</SectionTitle>
        <Card className="p-4">
          <BarChart labels={week.map((d) => weekdayName(new Date(d.date + 'T12:00').getDay(), lang, 'narrow'))} series={[{ name: t('m_prayer'), color: 'var(--accent)', values: week.map((d) => d.done) }]} height={120} />
          <div className="mt-3 space-y-2">{PRAYER_KEYS.map((k) => (
            <div key={k} className="flex items-center gap-2 text-sm"><Orn name={ICON[k]} size={20} /><span className="w-14 text-ink-2">{prayerName(k, t)}</span><ProgressBar className="flex-1" value={(stats.perPrayer[k] / 7) * 100} /><span className="num w-8 text-end font-bold">{fmtNumber(stats.perPrayer[k], lang)}/{fmtNumber(7, lang)}</span></div>
          ))}</div>
        </Card>

        <SectionTitle>{t('prayer_settings')}</SectionTitle>
        <Card className="divide-y divide-line">
          <div className="px-4"><Toggle checked={p.enabled} onChange={enable} label={t('prayer_enable')} description={t('prayer_enable_desc')} /></div>
          <div className="p-4">
            <div className="mb-2 flex items-center gap-1.5 text-[13px] font-medium text-ink-2"><MapPin size={14} />{t('prayer_place')}</div>
            <Select value={p.governorate} onChange={(v) => { const pl = placeOf(v); up({ governorate: v, city: v, lat: pl.lat, lng: pl.lng }); }}
              options={[...EGYPT_PLACES.filter((x) => x.governorate).map((x) => ({ value: x.key, label: `${lang === 'ar' ? x.ar : x.en}` })), ...EGYPT_PLACES.filter((x) => !x.governorate).map((x) => ({ value: x.key, label: `· ${lang === 'ar' ? x.ar : x.en}` }))]} />
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-ink-3"><span className="num">{(p.lat ?? place.lat).toFixed(3)}°, {(p.lng ?? place.lng).toFixed(3)}°</span><Button size="sm" variant="ghost" icon={<MapPin size={13} />} onClick={locate}>{t('use_location')}</Button></div>
            <div className="mt-2 flex items-center gap-2 text-sm"><Compass size={16} className="text-accent" /><span>{t('prayer_qibla')}: <b className="num">{fmtNumber(qibla, lang)}°</b></span><HelpTip id="qibla" /></div>
          </div>
          <div className="p-4"><div className="mb-2 flex items-center gap-1.5 text-[13px] font-medium text-ink-2">{t('calc_method')}<HelpTip id="prayer_method" /></div>
            <Select value={p.method} onChange={(v) => up({ method: v as Settings['prayer']['method'] })} options={[{ value: 'egypt', label: t('pm_egypt') }, { value: 'makkah', label: t('pm_makkah') }, { value: 'mwl', label: t('pm_mwl') }, { value: 'karachi', label: t('pm_karachi') }, { value: 'isna', label: t('pm_isna') }]} />
            <div className="mt-3"><Segmented size="sm" value={p.asr} onChange={(v) => up({ asr: v })} options={[{ value: 'standard', label: t('asr_standard') }, { value: 'hanafi', label: t('asr_hanafi') }]} /></div></div>
          <div className="p-4"><div className="mb-2 text-[13px] font-medium text-ink-2">{t('prayer_tune')}</div>
            <div className="space-y-2">{PRAYER_KEYS.map((k) => <div key={k} className="flex items-center justify-between"><span className="text-[15px]">{prayerName(k, t)}</span><Stepper value={p.adjustments[k] ?? 0} onChange={(v) => up({ adjustments: { ...p.adjustments, [k]: v } })} min={-30} max={30} suffix={t('min_short')} /></div>)}</div>
            <p className="mt-2 text-xs text-ink-3">{t('prayer_accuracy_note')}</p></div>
          <div className="px-4"><Toggle checked={p.reminder} onChange={(v) => up({ reminder: v })} label={t('prayer_alert_at')} description={t('prayer_alert_at_desc')} /></div>
          <SRow label={t('prayer_lead')} help="prayer_lead"><Stepper value={p.leadMin} onChange={(v) => up({ leadMin: v })} min={0} max={60} step={5} suffix={t('min_short')} /></SRow>
          <div className="px-4"><Toggle checked={p.ongoing} onChange={(v) => up({ ongoing: v })} label={t('prayer_ongoing')} description={t('prayer_ongoing_desc')} help="ongoing_prayer" /></div>
          <SoundField label={t('prayer_sound')} value={p.sound} onChange={(v) => up({ sound: v })} volume={s.volume} />
          <div className="px-4"><Toggle checked={p.createBlocks} onChange={(v) => up({ createBlocks: v })} label={t('prayer_blocks')} /></div>
          {p.createBlocks && <SRow label={t('duration')}><Stepper value={p.durationMin} onChange={(v) => up({ durationMin: v })} min={5} max={60} step={5} suffix={t('min_short')} /></SRow>}
          <SRow label={t('hijri_adjust')} help="hijri_adjust"><Stepper value={s.hijriAdjust} onChange={(v) => useApp.getState().updateSettings({ hijriAdjust: v })} min={-2} max={2} suffix={t('days')} /></SRow>
        </Card>
        <p className="mt-3 flex flex-wrap items-center gap-1 px-1 text-xs text-ink-3">{t('prayer_method_note')}<Chip>{p.method.toUpperCase()}</Chip></p>
        {void Input}
      </Page>
    </div>
  );
}
const HeroStat = ({ n, l }: { n: string; l: string }) => <div className="rounded-2xl bg-white/12 py-2 backdrop-blur"><div className="num text-lg font-extrabold">{n}</div><div className="text-[10px] font-semibold text-white/80">{l}</div></div>;
