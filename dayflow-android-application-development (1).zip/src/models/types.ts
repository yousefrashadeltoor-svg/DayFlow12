/**
 * DAYFLOW domain model. Every interface maps to a persisted collection
 * (SQLite `records` table on Android, IndexedDB object store on the web).
 * Relations are expressed by id references and validated by the repository layer.
 */
export type ID = string;
/** Local calendar date, YYYY-MM-DD */
export type DateKey = string;

export interface BaseEntity {
  id: ID;
  createdAt: number;
  updatedAt: number;
}

export type Lang = 'ar' | 'en';
export type ThemeMode = 'system' | 'light' | 'dark';
export type Accent = 'indigo' | 'teal' | 'rose' | 'amber' | 'graphite' | 'emerald';

export type BlockStatus = 'planned' | 'active' | 'paused' | 'completed' | 'partial' | 'skipped' | 'missed' | 'cancelled';
export type NotificationAction = 'DONE' | 'SNOOZE_5' | 'SNOOZE_10' | 'SNOOZE_15' | 'SKIP' | 'START' | 'PARTIAL' | 'DISMISS';
export type SoundMode = 'inherit' | 'custom' | 'tts' | 'tone' | 'system' | 'none';
export type Energy = 'low' | 'medium' | 'high';

export interface ReminderConfig {
  enabled: boolean;
  /** minutes before planned start; 0 = at start */
  offsets: number[];
  atEnd: boolean;
  soundMode: SoundMode;
  soundId?: ID;
  ttsText?: string;
  repeatIntervalMin: number;
  maxRepeats: number;
  /** critical reminders may bypass quiet hours */
  critical: boolean;
  actions: NotificationAction[];
}

export interface BlockEvent { at: number; action: string; source: 'app' | 'notification' | 'widget' | 'command' | 'catchup'; }

export interface ActivityCore {
  title: string;
  description: string;
  categoryId: ID;
  icon: string;
  color: string;
  startMin: number;
  durationMin: number;
  fixed: boolean;
  windowStartMin?: number;
  windowEndMin?: number;
  preferredMin?: number;
  priority: number; // 1..5
  importance: number; // 1..5
  energy: Energy;
  difficulty: number; // 1..5
  reminder: ReminderConfig;
  goalId?: ID;
  projectId?: ID;
  lessonId?: ID;
  subjectId?: ID;
  workoutPlanId?: ID;
  taskId?: ID;
  habitId?: ID;
  prepMin: number;
  cleanupMin: number;
  bufferMin: number;
  dependsOn: ID[];
  notes: string;
  tags: string[];
  splitAllowed: boolean;
  minSplitMin: number;
}

export interface ActivityBlock extends BaseEntity, ActivityCore {
  date: DateKey;
  status: BlockStatus;
  actualStart?: number | null;
  actualEnd?: number | null;
  pausedAt?: number | null;
  pausedTotalMs: number;
  snoozeCount: number;
  completionPercent?: number | null;
  seriesId?: ID;
  /** true when this occurrence was edited individually and must not follow series edits */
  detached?: boolean;
  templateId?: ID;
  splitGroup?: ID;
  /** false = draft: no reminders / widgets until the day plan is applied. undefined (legacy) = applied. */
  applied?: boolean;
  source: 'manual' | 'template' | 'series' | 'import' | 'prayer' | 'task' | 'catchup' | 'routine' | 'command';
  events: BlockEvent[];
}

export type RecurrenceFreq = 'daily' | 'weekly' | 'monthly' | 'dates';
export interface RecurrenceRule {
  freq: RecurrenceFreq;
  interval: number;
  byWeekday?: number[]; // 0=Sun..6=Sat
  byMonthDay?: number;
  dates?: DateKey[];
  start: DateKey;
  until?: DateKey;
  count?: number;
}

export interface ActivitySeries extends BaseEntity {
  core: ActivityCore;
  recurrence: RecurrenceRule;
  exceptions: DateKey[];
  active: boolean;
}

export interface ActivityCategory extends BaseEntity {
  key: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  color: string; // css var token or hex
  builtin: boolean;
  productive: boolean;
}

export type TemplateKind = 'normal' | 'school' | 'exam' | 'work' | 'weekend' | 'vacation' | 'recovery' | 'light' | 'custom';
export interface DayTemplate extends BaseEntity {
  name: string;
  kind: TemplateKind;
  blocks: ActivityCore[];
  builtin: boolean;
}
export interface WeekdayAssignment extends BaseEntity { weekday: number; templateId: ID; }
export interface SpecialDate extends BaseEntity {
  date: DateKey; label: string; kind: 'holiday' | 'special'; templateId?: ID;
  emoji?: string; note?: string; yearly?: boolean; notify?: boolean; notifyMin?: number; official?: boolean;
}

export interface RoutineStep { id: ID; title: string; durationMin: number; required: boolean; }
export interface Routine extends BaseEntity {
  name: string;
  kind: 'morning' | 'evening' | 'pre_study' | 'after_work' | 'workout_prep' | 'pre_sleep' | 'custom';
  steps: RoutineStep[];
  categoryId: ID;
}
export interface RoutineRun extends BaseEntity { routineId: ID; date: DateKey; doneStepIds: ID[]; completedAt?: number; }

export interface BlockSnapshot { id: ID; date: DateKey; startMin: number; durationMin: number; status: BlockStatus; title: string; }
export interface ScheduleChange extends BaseEntity {
  date: DateKey;
  reason: string;
  kind: 'catchup' | 'what_if' | 'drag' | 'rule' | 'template' | 'manual' | 'undo' | 'apply';
  before: BlockSnapshot[];
  after: BlockSnapshot[];
  created: ID[];
  deleted: ID[];
  reverted: boolean;
}

export type RuleType =
  | 'recovery_after_study' | 'prep_before_workout' | 'no_overlap' | 'difficult_in_productive_hours'
  | 'water_on_active_days' | 'quiet_sleep' | 'min_rest' | 'subject_session_limit' | 'deadline_guard' | 'protect_breaks';
export interface ScheduleRule extends BaseEntity {
  type: RuleType;
  enabled: boolean;
  priority: number;
  params: Record<string, number>;
  override: boolean;
}

export interface ReminderLog extends BaseEntity {
  alarmKey: string;
  kind: string;
  refId?: ID;
  title: string;
  triggerAt: number;
  state: 'scheduled' | 'failed' | 'cancelled' | 'unsupported';
  exact?: boolean;
  error?: string;
}

export interface SoundAsset extends BaseEntity { name: string; path: string; mimeType: string; size: number; startMs?: number; endMs?: number; durationMs?: number; origin?: 'file' | 'ringtone' | 'alarm' | 'notification'; }

export type TaskStatus = 'todo' | 'in_progress' | 'done' | 'cancelled';
export interface Subtask { id: ID; title: string; done: boolean; }
export interface Attachment extends BaseEntity { name: string; path: string; mimeType: string; size: number; ownerType: string; ownerId: ID; }
export interface Task extends BaseEntity {
  title: string;
  description: string;
  dueDate?: DateKey;
  startDate?: DateKey;
  priority: number;
  status: TaskStatus;
  estimateMin: number;
  trackedMin: number;
  categoryId?: ID;
  tags: string[];
  checklist: Subtask[];
  subtasks: Subtask[];
  recurrence?: RecurrenceRule;
  reminderAt?: number;
  notes: string;
  dependsOn: ID[];
  projectId?: ID;
  goalId?: ID;
  milestoneId?: ID;
  listId?: ID;
  starred: boolean;
  someday: boolean;
  completedAt?: number;
}
export interface TaskList extends BaseEntity { name: string; color: string; }
export interface Project extends BaseEntity {
  title: string; description: string; objectives: string[]; deadline?: DateKey; notes: string; goalId?: ID; color: string; archived: boolean;
}
export interface ProjectMilestone extends BaseEntity { projectId: ID; title: string; dueDate?: DateKey; done: boolean; }

export interface Goal extends BaseEntity {
  title: string; description: string; horizon: 'short' | 'monthly' | 'long'; targetDate?: DateKey;
  metric: 'tasks' | 'manual' | 'habits' | 'study';
  targetValue: number; manualValue: number; unit: string;
  habitIds: ID[]; subjectIds: ID[];
  reviews: { at: number; note: string; value: number }[];
  archived: boolean;
}
export interface GoalMilestone extends BaseEntity { goalId: ID; title: string; dueDate?: DateKey; done: boolean; }

export type StudyStatus = 'not_started' | 'in_progress' | 'done';
export interface StudyItemBase extends BaseEntity {
  title: string; description: string; estimateHours: number; difficulty: number; priority: number; dueDate?: DateKey;
  status: StudyStatus; resources: string[]; notes: string; examId?: ID;
}
export interface StudySubject extends StudyItemBase { color: string; }
export interface StudyUnit extends StudyItemBase { subjectId: ID; }
export interface StudyLesson extends StudyItemBase { subjectId: ID; unitId: ID; }
export interface StudySession extends BaseEntity { subjectId?: ID; unitId?: ID; lessonId?: ID; date: DateKey; minutes: number; focusSessionId?: ID; note: string; }
export interface FlashcardDeck extends BaseEntity { name: string; subjectId?: ID; }
export interface Flashcard extends BaseEntity {
  deckId: ID; question: string; answer: string; tags: string[]; difficulty: number;
  step: number; ease: number; dueDate: DateKey; lastReviewed?: number; reviews: number; lapses: number;
}
export interface ReviewTask extends BaseEntity { cardId: ID; deckId: ID; date: DateKey; grade: 0 | 1 | 2 | 3; prevStep: number; nextStep: number; nextDue: DateKey; }
export interface Exam extends BaseEntity {
  name: string; subjectId?: ID; date: DateKey; timeMin: number; location: string; topics: string[]; prepProgress: number; studyMinutesPerDay: number;
}

export interface WorkoutExercise { id: ID; exerciseId: ID; sets: number; reps: number; restSec: number; load?: number; note: string; }
export interface WorkoutPlan extends BaseEntity { name: string; weekdays: number[]; startMin: number; exercises: WorkoutExercise[]; notes: string; light: boolean; }
export interface Exercise extends BaseEntity { name: string; category: string; equipment: string; muscles: string[]; instructions: string; }
export interface ExerciseSet { exerciseId: ID; setIndex: number; reps: number; load?: number; completedAt: number; }
export interface WorkoutLog extends BaseEntity {
  planId: ID; date: DateKey; startedAt: number; endedAt?: number; sets: ExerciseSet[]; notes: string; status: 'in_progress' | 'completed' | 'abandoned';
}

export interface Habit extends BaseEntity {
  name: string; icon: string; color: string; category: string;
  kind: 'check' | 'numeric' | 'timed' | 'avoid';
  frequency: 'daily' | 'weekly' | 'custom';
  weekdays: number[];
  timesPerWeek: number;
  target: number; unit: string;
  reminderMin?: number;
  notes: string;
  pausedUntil?: DateKey;
  archived: boolean;
}
export interface HabitLog extends BaseEntity { habitId: ID; date: DateKey; value: number; note: string; skipped: boolean; }

export interface WaterLog extends BaseEntity { date: DateKey; ml: number; at: number; }
export interface MealLog extends BaseEntity { date: DateKey; name: string; plannedMin?: number; actualAt?: number; notes: string; kcal?: number; protein?: number; carbs?: number; fat?: number; }
export interface SleepLog extends BaseEntity { date: DateKey; bedAt: number; wakeAt: number; quality?: number; note: string; }

export type FocusMode = 'pomodoro' | 'extended' | 'deep' | 'open' | 'countdown' | 'custom';
export interface FocusSession extends BaseEntity {
  date: DateKey; mode: FocusMode; phase: 'work' | 'short_break' | 'long_break'; startedAt: number; endedAt: number;
  plannedMin: number; actualMin: number; completed: boolean; taskId?: ID; lessonId?: ID; subjectId?: ID; blockId?: ID; note: string; distractions: number;
}
export interface DistractionLog extends BaseEntity { date: DateKey; at: number; reason: string; minutesLost: number; note: string; focusSessionId?: ID; blockId?: ID; }

export interface DailyLog extends BaseEntity { date: DateKey; appliedTemplateIds: ID[]; materialized: boolean; journal: string; }
export interface ProductivityRating extends BaseEntity { date: DateKey; at: number; hour: number; energy: number; focus: number; note: string; }
export interface BodyMetric extends BaseEntity { date: DateKey; kind: string; value: number; unit: string; }

export interface PersonalNote extends BaseEntity {
  title: string; body: string; kind: 'quick' | 'rich' | 'checklist' | 'study' | 'meeting' | 'journal';
  checklist: Subtask[]; tags: string[]; favorite: boolean; linkedNoteIds: ID[]; blockId?: ID; projectId?: ID; lessonId?: ID; date?: DateKey;
}

export interface BackupHistory extends BaseEntity { kind: 'export' | 'restore' | 'import'; format: string; records: number; encrypted: boolean; fileName: string; }
export interface DatabaseMigration extends BaseEntity { version: number; description: string; }

export interface FocusTimerState extends BaseEntity {
  running: boolean;
  mode: FocusMode;
  phase: 'work' | 'short_break' | 'long_break';
  phaseStartedAt: number;
  phaseDurationMs: number; // 0 for open timer
  pausedAt: number | null;
  pausedTotalMs: number;
  cycle: number;
  taskId?: ID; lessonId?: ID; subjectId?: ID; blockId?: ID;
  checklist: Subtask[];
  note: string;
  distractions: number;
}
export interface WorkoutRunState extends BaseEntity {
  logId: ID | null; exerciseIndex: number; setIndex: number; restEndsAt: number | null;
}


/** Where a sound comes from. Ringtone/alarm/notification URIs come from Android's own picker; files are copied into app storage and may be trimmed non-destructively. */
export interface SoundSpec {
  kind: 'default' | 'ringtone' | 'alarm' | 'notification' | 'file' | 'tts' | 'silent';
  uri?: string;      // content:// URI (system tones) or absolute path (copied file)
  name?: string;
  startMs?: number;  // trim start (file only)
  endMs?: number;    // trim end (file only)
  durationMs?: number;
}

/** A real user alarm clock (scheduled natively with AlarmManager.setAlarmClock). */
export interface AlarmClock extends BaseEntity {
  label: string;
  minute: number;
  days: number[];            // 0=Sun..6=Sat. Empty => one-time
  enabled: boolean;
  sound: SoundSpec;
  volume: number;            // 0..1
  gradual: boolean;
  vibrate: boolean;
  speakLabel: boolean;       // read the label aloud (TTS) before the sound
  snoozeMin: number;
  maxSnoozes: number;        // 0 = snooze disabled
  ringMin: number;           // auto-stop after N minutes
  skipDate?: DateKey;        // skip a single upcoming date
  oneTimeDate?: DateKey;     // set when days is empty and the date is explicit
}

export type PrayerKey = 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
export interface PrayerLog extends BaseEntity { date: DateKey; prayer: PrayerKey; prayedAt: number; onTime: boolean; }

/** Materialised occasion (derived). Rebuilt from the built-in catalogue + user occasions; read natively by notifications and widgets. */
export interface OccasionRecord extends BaseEntity {
  date: DateKey; key: string; title: string; titleEn: string; emoji: string; official: boolean; kind: string; image: string;
  notify: boolean; notifyMin: number; source: 'builtin' | 'user'; note: string;
}

export interface JournalPlanSnapshot { at: number; title: string; blocks: { id: ID; title: string; startMin: number; durationMin: number }[]; }
export interface JournalEntry extends BaseEntity {
  date: DateKey; mood: number; energy: number; title: string; body: string;
  gratitude: string[]; highlight: string; lesson: string; tags: string[]; favorite: boolean;
  plans: JournalPlanSnapshot[];
}

export type AiCardType = 'activity' | 'schedule' | 'alarm' | 'alarms' | 'task' | 'tasks' | 'note' | 'journal' | 'occasion' | 'prayer' | 'water' | 'stats' | 'habit' | 'goal' | 'settings' | 'focus' | 'search' | 'overview' | 'deleted';
export interface AiCard { type: AiCardType; title?: string; data: unknown; open?: { screen?: string; tab?: string; blockId?: string } }
export interface AiToolCall { id: string; name: string; args: Record<string, unknown> }
export interface AiToolRun {
  callId: string; name: string; args: Record<string, unknown>;
  status: 'pending' | 'running' | 'done' | 'error' | 'cancelled' | 'needs_confirm';
  summary?: string; error?: string; cards?: AiCard[]; undoable?: boolean; undone?: boolean;
}
export interface AiMessage {
  id: string; role: 'user' | 'assistant' | 'tool' | 'error';
  content: string; at: number;
  toolCalls?: AiToolCall[]; toolCallId?: string; toolName?: string;
  runs?: AiToolRun[]; providerId?: string; modelId?: string;
  usage?: { input?: number; output?: number }; ms?: number; fallbackFrom?: string;
}
export interface AiChat extends BaseEntity { title: string; messages: AiMessage[]; providerId: string; modelId: string; pinned: boolean; }
export interface AiProviderConfig { enabled: boolean; baseUrl?: string; accountId?: string; models?: { id: string; name?: string; free?: boolean; tools?: boolean; context?: number }[]; modelsFetchedAt?: number; toolMode?: Record<string, 'native' | 'json'>; badModels?: string[] }

export interface Settings extends BaseEntity {
  userName: string;
  language: Lang;
  theme: ThemeMode;
  accent: Accent;
  weekStart: 0 | 1 | 6;
  clock24: boolean;
  fontScale: number;
  density: 'compact' | 'comfortable' | 'spacious';
  haptics: boolean;
  reducedMotion: 'system' | 'on' | 'off';
  dashboard: { overview: boolean; quickActions: boolean; water: boolean; habits: boolean; collapseCompleted: boolean; prayer: boolean; tasks: boolean };
  themeId: string;
  decor: 'off' | 'light' | 'full';
  decorSpeed: number;        // 0.4 .. 2.5 (higher = faster)
  decorOpacity: number;      // 0.2 .. 1
  decorLayer: 'front' | 'back';
  decorSeasons: Record<string, boolean>; // per-season on/off
  decorPreview: string;      // '' = none; otherwise a season id shown ALONE (solo preview)
  decorActive: string[];     // up to 3 manually chosen seasons, blended with the automatic one
  hijriAdjust: number;
  autoApplyPlan: boolean;
  occasionNotify: boolean;
  showOtherReligions: boolean;
  journal: { reminderEnabled: boolean; reminderMin: number };
  widgetLayout: 'compact' | 'medium' | 'large';
  defaultDurationMin: number;
  defaultBufferMin: number;
  defaultReminderOffsets: number[];
  defaultActions: NotificationAction[];
  soundMode: Exclude<SoundMode, 'inherit'>;
  defaultSoundId?: ID;
  volume: number;
  gradualVolume: boolean;
  vibrate: boolean;
  audioRepeat: number;
  escalation: { repeatIntervalMin: number; maxRepeats: number };
  quietHours: { enabled: boolean; startMin: number; endMin: number; days: number[]; allowCritical: boolean };
  reminderHorizonDays: number;
  dayStartMin: number;
  dayEndMin: number;
  productiveStartMin: number;
  productiveEndMin: number;
  water: { targetMl: number; cupSizes: number[]; reminderEnabled: boolean; intervalMin: number; wakeStartMin: number; wakeEndMin: number; workoutBonusMl: number };
  sleep: { bedtimeMin: number; wakeMin: number; prepReminderMin: number; prepReminderEnabled: boolean; wakeReminder: boolean };
  focus: { pomodoroWork: number; pomodoroShort: number; pomodoroLong: number; cyclesBeforeLong: number; extendedWork: number; extendedBreak: number; deepWork: number; deepBreak: number; countdown: number; customWork: number; customBreak: number; autoStartBreaks: boolean };
  srsIntervals: number[];
  burnout: { enabled: boolean; maxDailyWorkMin: number; lowEnergyThreshold: number; lookbackDays: number; postponeThreshold: number };
  insightsMinObservations: number;
  prayer: { governorate: string; leadMin: number; ongoing: boolean; sound: SoundSpec; enabled: boolean; method: 'mwl' | 'isna' | 'egypt' | 'makkah' | 'karachi' | 'tehran' | 'gulf' | 'kuwait' | 'qatar'; asr: 'standard' | 'hanafi'; lat: number | null; lng: number | null; city: string; adjustments: Record<string, number>; createBlocks: boolean; durationMin: number; reminder: boolean };
  aiCoachEnabled: boolean;
  ai: {
    consent: boolean; providerId: string; modelId: string; execution: 'auto' | 'confirm_destructive' | 'confirm_all';
    shareContext: boolean; temperature: number; providers: Record<string, AiProviderConfig>; freeOnly: boolean;
  };
  onboarded: boolean;
  timeZoneBehavior: 'device' | 'fixed';
  lastTimeZone: string;
}

export type CollectionName =
  | 'activities' | 'series' | 'categories' | 'templates' | 'weekdayAssignments' | 'specialDates' | 'routines' | 'routineRuns'
  | 'scheduleChanges' | 'rules' | 'reminderLogs' | 'sounds' | 'tasks' | 'taskLists' | 'projects' | 'milestones'
  | 'goals' | 'goalMilestones' | 'subjects' | 'units' | 'lessons' | 'studySessions' | 'decks' | 'flashcards' | 'reviews' | 'exams'
  | 'workoutPlans' | 'exercises' | 'workoutLogs' | 'habits' | 'habitLogs' | 'waterLogs' | 'mealLogs' | 'sleepLogs'
  | 'focusSessions' | 'distractions' | 'dailyLogs' | 'ratings' | 'bodyMetrics' | 'notes' | 'attachments'
  | 'alarmClocks' | 'prayerLogs' | 'occasions' | 'journal' | 'aiChats'
  | 'backups' | 'migrations' | 'settings' | 'state';

export const ALL_COLLECTIONS: CollectionName[] = [
  'activities', 'series', 'categories', 'templates', 'weekdayAssignments', 'specialDates', 'routines', 'routineRuns',
  'scheduleChanges', 'rules', 'reminderLogs', 'sounds', 'tasks', 'taskLists', 'projects', 'milestones',
  'goals', 'goalMilestones', 'subjects', 'units', 'lessons', 'studySessions', 'decks', 'flashcards', 'reviews', 'exams',
  'workoutPlans', 'exercises', 'workoutLogs', 'habits', 'habitLogs', 'waterLogs', 'mealLogs', 'sleepLogs',
  'focusSessions', 'distractions', 'dailyLogs', 'ratings', 'bodyMetrics', 'notes', 'attachments',
  'alarmClocks', 'prayerLogs', 'occasions', 'journal', 'aiChats',
  'backups', 'migrations', 'settings', 'state',
];

export interface CollectionTypes {
  activities: ActivityBlock; series: ActivitySeries; categories: ActivityCategory; templates: DayTemplate;
  weekdayAssignments: WeekdayAssignment; specialDates: SpecialDate; routines: Routine; routineRuns: RoutineRun;
  scheduleChanges: ScheduleChange; rules: ScheduleRule; reminderLogs: ReminderLog; sounds: SoundAsset; tasks: Task;
  taskLists: TaskList; projects: Project; milestones: ProjectMilestone; goals: Goal; goalMilestones: GoalMilestone;
  subjects: StudySubject; units: StudyUnit; lessons: StudyLesson; studySessions: StudySession; decks: FlashcardDeck;
  flashcards: Flashcard; reviews: ReviewTask; exams: Exam; workoutPlans: WorkoutPlan; exercises: Exercise;
  workoutLogs: WorkoutLog; habits: Habit; habitLogs: HabitLog; waterLogs: WaterLog; mealLogs: MealLog; sleepLogs: SleepLog;
  focusSessions: FocusSession; distractions: DistractionLog; dailyLogs: DailyLog; ratings: ProductivityRating;
  bodyMetrics: BodyMetric; notes: PersonalNote; attachments: Attachment; alarmClocks: AlarmClock; prayerLogs: PrayerLog; occasions: OccasionRecord;
  journal: JournalEntry; aiChats: AiChat; backups: BackupHistory; migrations: DatabaseMigration;
  settings: Settings; state: FocusTimerState | WorkoutRunState;
}

export type Collections = { [K in CollectionName]: Record<ID, CollectionTypes[K]> };
