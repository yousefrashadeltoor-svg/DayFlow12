import { useEffect, useMemo, useRef, useState, type ReactNode, type ButtonHTMLAttributes, type InputHTMLAttributes } from 'react';
import {
  BookOpen, Briefcase, Dumbbell, Coffee, Utensils, Moon, Droplets, User, Sunrise, ListChecks, CalendarClock, Circle, Heart, Music, Code, Palette, Plane,
  ShoppingCart, Phone, Car, Gamepad2, Leaf, Star, Brain, Target, Flame, X, Check, ChevronLeft, ChevronRight, Info, AlertTriangle, CheckCircle2, Minus, Plus,
  type LucideIcon,
} from 'lucide-react';
import { useApp } from '@/stores/appStore';
import type { TKey } from '@/services/localization/i18n';
import type { Settings } from '@/models/types';
import { cn } from '@/utils/cn';
import { haptic } from '@/services/native/dayflowNative';
import { HELP } from '@/services/help';
import { CornerOrnament } from '@/features/decor/Decor';

// ------------------------------------------------------------------ hooks

export function useSettings(): Settings { return useApp((s) => s.data.settings.app); }
export function useT() {
  const lang = useApp((s) => s.data.settings.app?.language ?? 'ar');
  const t = useApp((s) => s.t);
  return useMemo(() => ({ t: (k: TKey, p?: Record<string, string | number>) => t(k, p), lang }), [lang, t]);
}
/** Ticks every `ms` (default 30s) so time-based UI stays current without per-second re-render storms. */
export function useNow(ms = 30000): number {
  const [n, setN] = useState(Date.now());
  useEffect(() => { const id = setInterval(() => setN(Date.now()), ms); return () => clearInterval(id); }, [ms]);
  return n;
}
export function useHaptic() { const on = useApp((s) => s.data.settings.app?.haptics ?? true); return (p?: number | number[]) => haptic(on, p); }

// ------------------------------------------------------------------ icons

export const ICONS: Record<string, LucideIcon> = {
  'book-open': BookOpen, briefcase: Briefcase, dumbbell: Dumbbell, coffee: Coffee, utensils: Utensils, moon: Moon, droplets: Droplets, user: User,
  sunrise: Sunrise, 'list-checks': ListChecks, 'calendar-clock': CalendarClock, circle: Circle, heart: Heart, music: Music, code: Code, palette: Palette,
  plane: Plane, cart: ShoppingCart, phone: Phone, car: Car, gamepad: Gamepad2, leaf: Leaf, star: Star, brain: Brain, target: Target, flame: Flame,
};
export function Icon({ name, size = 18, className, strokeWidth = 1.9 }: { name: string; size?: number; className?: string; strokeWidth?: number }) {
  const C = ICONS[name] ?? Circle;
  return <C size={size} className={className} strokeWidth={strokeWidth} aria-hidden />;
}
export const Chevron = ({ size = 18, className }: { size?: number; className?: string }) => {
  const rtl = useApp((s) => s.data.settings.app?.language === 'ar');
  return rtl ? <ChevronLeft size={size} className={className} /> : <ChevronRight size={size} className={className} />;
};

// ------------------------------------------------------------------ primitives

type BtnVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'tinted';
export function Button({ variant = 'primary', size = 'md', className, children, icon, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: 'sm' | 'md' | 'lg'; icon?: ReactNode }) {
  const v = {
    primary: 'bg-accent text-accent-ink shadow-sm hover:opacity-95',
    secondary: 'bg-surface-2 text-ink hover:bg-line',
    ghost: 'text-ink-2 hover:bg-surface-2',
    danger: 'bg-danger/10 text-danger hover:bg-danger/15',
    tinted: 'bg-accent-soft text-accent',
  }[variant];
  const s = { sm: 'h-9 px-3 text-[13px] rounded-xl gap-1.5', md: 'h-11 px-4 text-[15px] rounded-2xl gap-2', lg: 'h-13 px-5 text-base rounded-2xl gap-2' }[size];
  return <button {...p} className={cn('press inline-flex items-center justify-center font-semibold disabled:opacity-40 disabled:pointer-events-none select-none whitespace-nowrap', v, s, className)}>{icon}{children}</button>;
}
export function IconButton({ label, className, children, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return <button aria-label={label} title={label} {...p} className={cn('press inline-flex h-10 w-10 items-center justify-center rounded-full text-ink-2 hover:bg-surface-2', className)}>{children}</button>;
}
export function Card({ className, children, onClick, ...p }: { className?: string; children: ReactNode; onClick?: () => void } & React.HTMLAttributes<HTMLDivElement>) {
  return <div {...p} onClick={onClick} className={cn('card', onClick && 'press cursor-pointer', className)}>{children}</div>;
}
export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return <div className="mb-2 mt-6 flex items-center justify-between px-1"><h2 className="text-[13px] font-semibold uppercase tracking-wide text-ink-3">{children}</h2>{action}</div>;
}
export function Badge({ children, tone = 'neutral', className }: { children: ReactNode; tone?: 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'info'; className?: string }) {
  const c = { neutral: 'bg-surface-2 text-ink-2', accent: 'bg-accent-soft text-accent', success: 'bg-success/12 text-success', warning: 'bg-warning/14 text-warning', danger: 'bg-danger/12 text-danger', info: 'bg-info/12 text-info' }[tone];
  return <span className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold', c, className)}>{children}</span>;
}

export function Field({ label, hint, error, children }: { label?: ReactNode; hint?: ReactNode; error?: string | null; children: ReactNode }) {
  return (
    <label className="block">
      {label && <span className="mb-1.5 block text-[13px] font-medium text-ink-2">{label}</span>}
      {children}
      {hint && !error && <span className="mt-1 block text-xs text-ink-3">{hint}</span>}
      {error && <span className="mt-1 block text-xs font-medium text-danger" role="alert">{error}</span>}
    </label>
  );
}
export const inputCls = 'w-full h-11 rounded-xl bg-surface-2 px-3.5 text-[15px] outline-none border border-transparent focus:border-accent/50 focus:bg-surface placeholder:text-ink-3 transition-colors';
export function Input(p: InputHTMLAttributes<HTMLInputElement>) { return <input {...p} className={cn(inputCls, p.className)} />; }
export function TextArea(p: React.TextareaHTMLAttributes<HTMLTextAreaElement>) { return <textarea {...p} className={cn(inputCls, 'h-auto min-h-[88px] py-2.5 leading-relaxed', p.className)} />; }
export function Select({ value, onChange, options, className, ariaLabel }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[]; className?: string; ariaLabel?: string }) {
  return (
    <select aria-label={ariaLabel} value={value} onChange={(e) => onChange(e.target.value)} className={cn(inputCls, 'appearance-none', className)}>
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}
export function Segmented<T extends string>({ value, onChange, options, className, size = 'md' }: { value: T; onChange: (v: T) => void; options: { value: T; label: ReactNode }[]; className?: string; size?: 'sm' | 'md' }) {
  const h = useHaptic();
  return (
    <div role="tablist" className={cn('flex rounded-xl bg-surface-2 p-1 no-scrollbar overflow-x-auto', className)}>
      {options.map((o) => (
        <button key={o.value} role="tab" aria-selected={value === o.value} onClick={() => { h(6); onChange(o.value); }}
          className={cn('press flex-1 whitespace-nowrap rounded-lg px-3 font-semibold transition-all', size === 'sm' ? 'h-8 text-[12px]' : 'h-9 text-[13px]',
            value === o.value ? 'bg-surface text-ink shadow-sm' : 'text-ink-2')}>{o.label}</button>
      ))}
    </div>
  );
}
export function Toggle({ checked, onChange, label, description, disabled, help }: { checked: boolean; onChange: (v: boolean) => void; label: ReactNode; description?: ReactNode; disabled?: boolean; help?: string }) {
  const h = useHaptic();
  return (
    <button type="button" role="switch" aria-checked={checked} disabled={disabled} onClick={() => { h(8); onChange(!checked); }} className="flex w-full items-center justify-between gap-3 py-2.5 text-start disabled:opacity-40">
      <span className="min-w-0"><span className="flex items-center gap-1.5 text-[15px] text-ink">{label}{help && <HelpTip id={help} />}</span>{description && <span className="mt-0.5 block text-xs text-ink-3">{description}</span>}</span>
      <span className={cn('relative h-[30px] w-[50px] shrink-0 rounded-full transition-colors', checked ? 'bg-success' : 'bg-line')}>
        <span className={cn('absolute top-[3px] h-6 w-6 rounded-full bg-white shadow transition-all', checked ? 'start-[23px]' : 'start-[3px]')} />
      </span>
    </button>
  );
}
export function Stepper({ value, onChange, min = 0, max = 9999, step = 1, suffix }: { value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number; suffix?: string }) {
  const clamp = (v: number) => Math.min(max, Math.max(min, v));
  return (
    <div className="inline-flex items-center gap-1 rounded-xl bg-surface-2 p-1">
      <button type="button" aria-label="-" className="press grid h-8 w-8 place-items-center rounded-lg hover:bg-surface" onClick={() => onChange(clamp(value - step))}><Minus size={15} /></button>
      <input inputMode="numeric" className="num w-14 bg-transparent text-center text-[15px] font-semibold outline-none" value={value}
        onChange={(e) => { const n = Number(e.target.value.replace(/[^\d.-]/g, '')); if (Number.isFinite(n)) onChange(clamp(n)); }} />
      {suffix && <span className="pe-1 text-xs text-ink-3">{suffix}</span>}
      <button type="button" aria-label="+" className="press grid h-8 w-8 place-items-center rounded-lg hover:bg-surface" onClick={() => onChange(clamp(value + step))}><Plus size={15} /></button>
    </div>
  );
}
export function Chip({ active, children, onClick, color }: { active?: boolean; children: ReactNode; onClick?: () => void; color?: string }) {
  return (
    <button type="button" onClick={onClick} className={cn('press inline-flex h-8 items-center gap-1.5 whitespace-nowrap rounded-full border px-3 text-[13px] font-medium transition-colors',
      active ? 'border-transparent bg-ink text-bg' : 'border-line bg-surface text-ink-2')}>
      {color && <span className="h-2 w-2 rounded-full" style={{ background: color }} />}{children}
    </button>
  );
}
export function ProgressRing({ value, size = 64, stroke = 7, color = 'var(--accent)', children, track = 'var(--line)' }: { value: number; size?: number; stroke?: number; color?: string; children?: ReactNode; track?: string }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className="relative inline-grid place-items-center" style={{ width: size, height: size }} role="progressbar" aria-valuenow={Math.round(v)} aria-valuemin={0} aria-valuemax={100}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke={track} strokeWidth={stroke} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c - (c * v) / 100} style={{ transition: 'stroke-dashoffset .6s cubic-bezier(.22,1,.36,1)' }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}
export function ProgressBar({ value, color = 'var(--accent)', className }: { value: number; color?: string; className?: string }) {
  return (
    <div className={cn('h-2 w-full overflow-hidden rounded-full bg-line', className)} role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: color }} />
    </div>
  );
}
export function EmptyState({ icon, title, body, action }: { icon: ReactNode; title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center px-6 py-10 text-center anim-fade">
      <div className="mb-4 grid h-16 w-16 place-items-center rounded-3xl bg-accent-soft text-accent">{icon}</div>
      <h3 className="text-[17px] font-semibold">{title}</h3>
      {body && <p className="mt-1.5 max-w-xs text-sm leading-relaxed text-ink-2">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
export function ListRow({ icon, title, subtitle, trailing, onClick, danger }: { icon?: ReactNode; title: ReactNode; subtitle?: ReactNode; trailing?: ReactNode; onClick?: () => void; danger?: boolean }) {
  const Comp = onClick ? 'button' : 'div';
  return (
    <Comp onClick={onClick} className={cn('flex w-full items-center gap-3 px-4 py-3 text-start', onClick && 'press hover:bg-surface-2/60')}>
      {icon && <span className="grid h-8 w-8 shrink-0 place-items-center rounded-[10px]">{icon}</span>}
      <span className="min-w-0 flex-1"><span className={cn('block truncate text-[15px]', danger && 'text-danger')}>{title}</span>{subtitle && <span className="mt-0.5 block truncate text-xs text-ink-3">{subtitle}</span>}</span>
      {trailing}
    </Comp>
  );
}
export function Group({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn('card divide-y divide-line overflow-hidden', className)}>{children}</div>;
}

// ------------------------------------------------------------------ overlays

export function Sheet({ open, onClose, title, children, footer, tall }: { open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode; footer?: ReactNode; tall?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const startY = useRef<number | null>(null);
  const [dy, setDy] = useState(0);
  const { t } = useT();
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/35 anim-fade" onClick={onClose} />
      <div ref={ref} className={cn('relative flex w-full max-w-xl flex-col rounded-t-[var(--r-sheet,28px)] bg-bg shadow-float anim-sheet safe-bottom', tall ? 'h-[92vh]' : 'max-h-[90vh]')}
        style={{ transform: dy > 0 ? `translateY(${dy}px)` : undefined, transition: startY.current == null ? 'transform .2s' : 'none' }}>
        <div className="cursor-grab touch-none px-5 pb-2 pt-2.5"
          onPointerDown={(e) => { startY.current = e.clientY; (e.target as HTMLElement).setPointerCapture(e.pointerId); }}
          onPointerMove={(e) => { if (startY.current != null) setDy(Math.max(0, e.clientY - startY.current)); }}
          onPointerUp={() => { if (dy > 120) onClose(); startY.current = null; setDy(0); }}>
          <div className="mx-auto mb-2 h-1.5 w-10 rounded-full bg-line" />
          <div className="flex items-center justify-between gap-2">
            <h2 className="truncate text-[19px] font-bold">{title}</h2>
            <IconButton label={t('close')} onClick={onClose} className="bg-surface-2 h-8 w-8"><X size={17} /></IconButton>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-5 no-scrollbar">{children}</div>
        {footer && <div className="border-t border-line px-5 py-3">{footer}</div>}
      </div>
    </div>
  );
}

export function Dialog({ open, title, body, onClose, actions }: { open: boolean; title: ReactNode; body?: ReactNode; onClose: () => void; actions: { label: string; onClick: () => void; variant?: BtnVariant }[] }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center p-6" role="alertdialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/40 anim-fade" onClick={onClose} />
      <div className="relative w-full max-w-sm rounded-3xl bg-surface p-5 shadow-float anim-pop">
        <h3 className="text-[17px] font-bold">{title}</h3>
        {body && <div className="mt-2 text-sm leading-relaxed text-ink-2">{body}</div>}
        <div className="mt-5 flex flex-col gap-2">{actions.map((a) => <Button key={a.label} variant={a.variant ?? 'secondary'} onClick={a.onClick}>{a.label}</Button>)}</div>
      </div>
    </div>
  );
}

export function useConfirm() {
  const [state, setState] = useState<{ title: string; body?: string; confirm: string; danger?: boolean; resolve: (v: boolean) => void } | null>(null);
  const { t } = useT();
  const ask = (title: string, body?: string, confirm?: string, danger = true) => new Promise<boolean>((resolve) => setState({ title, body, confirm: confirm ?? t('confirm'), danger, resolve }));
  const node = (
    <Dialog open={!!state} title={state?.title} body={state?.body} onClose={() => { state?.resolve(false); setState(null); }}
      actions={state ? [{ label: state.confirm, variant: state.danger ? 'danger' : 'primary', onClick: () => { state.resolve(true); setState(null); } }, { label: t('cancel'), onClick: () => { state.resolve(false); setState(null); } }] : []} />
  );
  return { ask, node };
}

export function Toasts() {
  const toasts = useApp((s) => s.toasts);
  const dismiss = useApp((s) => s.dismissToast);
  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-[70] flex flex-col items-center gap-2 px-4 pt-[calc(env(safe-area-inset-top)+12px)]" aria-live="polite">
      {toasts.map((x) => (
        <div key={x.id} className="pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-2xl glass border border-line px-4 py-3 shadow-float anim-pop">
          {x.kind === 'success' ? <CheckCircle2 size={18} className="text-success" /> : x.kind === 'error' ? <AlertTriangle size={18} className="text-danger" /> : <Info size={18} className="text-info" />}
          <span className="flex-1 text-sm font-medium">{x.message}</span>
          {x.action && <button className="text-sm font-bold text-accent" onClick={() => { x.action!.run(); dismiss(x.id); }}>{x.action.label}</button>}
        </div>
      ))}
    </div>
  );
}

export function ScreenHeader({ title, subtitle, onBack, actions, large = true }: { title: ReactNode; subtitle?: ReactNode; onBack?: () => void; actions?: ReactNode; large?: boolean }) {
  const { t } = useT();
  return (
    <header className="sticky top-0 z-20 glass border-b border-line/60 safe-top relative">
      <CornerOrnament />
      <div className="mx-auto flex h-14 max-w-2xl items-center gap-1 px-2">
        {onBack && <IconButton label={t('back')} onClick={onBack}><span className="rtl:rotate-180"><ChevronLeft size={22} /></span></IconButton>}
        <div className="min-w-0 flex-1 px-2">
          {!large && <h1 className="truncate text-[17px] font-semibold">{title}</h1>}
        </div>
        <div className="flex items-center gap-1">{actions}</div>
      </div>
      {large && (
        <div className="screen-title-wrap mx-auto max-w-2xl px-4 pb-3">
          <h1 className="screen-title text-[30px] font-bold leading-tight tracking-tight">{title}</h1>
          {subtitle && <p className="screen-sub mt-0.5 text-sm text-ink-2">{subtitle}</p>}
        </div>
      )}
    </header>
  );
}

export function Page({ children, className }: { children: ReactNode; className?: string }) {
  return <main className={cn('mx-auto w-full max-w-2xl px-4 pb-32 pt-2', className)}>{children}</main>;
}

export const StatusIcon = ({ done }: { done: boolean }) => done ? <Check size={14} /> : null;


// ------------------------------------------------------------------ contextual help (green "?" circle)

export function HelpButton({ onClick, label }: { onClick: () => void; label?: string }) {
  return (
    <span role="button" tabIndex={0} aria-label={label ?? '?'} onClick={(e) => { e.stopPropagation(); e.preventDefault(); onClick(); }}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.stopPropagation(); e.preventDefault(); onClick(); } }}
      className="press inline-grid h-[20px] w-[20px] shrink-0 cursor-pointer place-items-center rounded-full bg-[#22a45d] text-[12px] font-extrabold leading-none text-white shadow-sm">?</span>
  );
}
export function HelpTip({ id }: { id: string }) {
  const [open, setOpen] = useState(false);
  const { lang } = useT();
  const h = HELP[id];
  if (!h) return null;
  const i = lang === 'ar' ? 0 : 1;
  return (
    <>
      <HelpButton onClick={() => setOpen(true)} />
      <Sheet open={open} onClose={() => setOpen(false)} title={<span className="flex items-center gap-2"><span className="grid h-7 w-7 place-items-center rounded-full bg-[#22a45d] text-sm font-extrabold text-white">?</span>{h.title[i]}</span>}>
        <div className="space-y-4 pb-2">
          <HelpBlock tone="info" title={lang === 'ar' ? 'إيه ده؟' : 'What is it?'} text={h.what[i]} />
          <HelpBlock tone="ok" title={lang === 'ar' ? 'ليه مهم؟' : 'Why it matters'} text={h.why[i]} />
          {h.tip && <HelpBlock tone="tip" title={lang === 'ar' ? 'نصيحة' : 'Tip'} text={h.tip[i]} />}
        </div>
      </Sheet>
    </>
  );
}
function HelpBlock({ title, text, tone }: { title: string; text: string; tone: 'info' | 'ok' | 'tip' }) {
  const c = { info: 'var(--info)', ok: '#22a45d', tip: 'var(--warning)' }[tone];
  return (
    <div className="rounded-2xl border border-line bg-surface p-4" style={{ borderInlineStartColor: c, borderInlineStartWidth: 4 }}>
      <div className="mb-1 text-[13px] font-bold" style={{ color: c }}>{title}</div>
      <p className="text-[15px] leading-7 text-ink">{text}</p>
    </div>
  );
}
/** A labelled settings row with optional help circle. */
export function SRow({ label, help, children, sub }: { label: ReactNode; help?: string; children?: ReactNode; sub?: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 px-4 py-3">
      <span className="min-w-0"><span className="flex items-center gap-1.5 text-[15px]">{label}{help && <HelpTip id={help} />}</span>{sub && <span className="mt-0.5 block text-xs text-ink-3">{sub}</span>}</span>
      {children}
    </div>
  );
}
