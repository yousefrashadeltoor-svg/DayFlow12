import { Component, type ErrorInfo, type ReactNode } from 'react';

/** Catches any render-time error so the app never shows an empty white screen. */
export class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error('DAYFLOW render error', error, info.componentStack); }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div dir="rtl" className="grid min-h-full place-items-center bg-[#f7f5f0] p-6 text-center text-[#1c1b22]">
        <div className="max-w-sm">
          <div className="mb-3 text-4xl">⚠️</div>
          <h1 className="text-xl font-bold">حصلت مشكلة بسيطة</h1>
          <p className="mt-2 text-sm leading-7 text-[#5f5c69]">بياناتك في أمان ومتمسحتش. اضغط «افتح من الأول» وهيشتغل التطبيق تاني.</p>
          <p className="mt-3 break-all text-[11px] text-[#9a97a3]">{this.state.error.message}</p>
          <button onClick={() => { try { sessionStorage.clear(); } catch { /* ignore */ } location.reload(); }} className="mt-5 h-11 rounded-2xl bg-[#5b5bd6] px-6 font-bold text-white">افتح من الأول</button>
        </div>
      </div>
    );
  }
}
