import { useState } from 'react';
import { useT } from '@/components/common/ui';
import { fmtNumber } from '@/utils/date';

/** Lightweight accessible SVG charts (no external chart dependency). */

export function LineChart({ points, labels, height = 140, color = 'var(--accent)', max = 100, suffix = '%' }: { points: (number | null)[]; labels: string[]; height?: number; color?: string; max?: number; suffix?: string }) {
  const { lang } = useT();
  const [hover, setHover] = useState<number | null>(null);
  const w = 320, padX = 14, padY = 14;
  const n = Math.max(1, points.length - 1);
  const x = (i: number) => padX + (i * (w - padX * 2)) / n;
  const y = (v: number) => height - padY - (Math.min(max, v) / max) * (height - padY * 2);
  const valid = points.map((v, i) => (v == null ? null : [x(i), y(v)] as const));
  const path = valid.reduce((acc, p, i) => (p ? acc + `${acc && valid[i - 1] ? 'L' : 'M'}${p[0]},${p[1]}` : acc), '');
  const area = valid.filter(Boolean).length > 1 ? `${path}L${valid.filter(Boolean).at(-1)![0]},${height - padY}L${valid.find(Boolean)![0]},${height - padY}Z` : '';
  return (
    <figure className="w-full" dir="ltr">
      <svg viewBox={`0 0 ${w} ${height}`} className="w-full" role="img" aria-label={points.map((p, i) => `${labels[i]}: ${p ?? '-'}`).join(', ')}>
        <defs><linearGradient id="lc-g" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={color} stopOpacity="0.25" /><stop offset="1" stopColor={color} stopOpacity="0" /></linearGradient></defs>
        {[0.25, 0.5, 0.75, 1].map((f) => <line key={f} x1={padX} x2={w - padX} y1={y(max * f)} y2={y(max * f)} stroke="var(--line)" strokeDasharray="3 4" />)}
        {area && <path d={area} fill="url(#lc-g)" />}
        <path d={path} fill="none" stroke={color} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
        {valid.map((p, i) => p && <circle key={i} cx={p[0]} cy={p[1]} r={hover === i ? 5 : 3.2} fill="var(--surface)" stroke={color} strokeWidth={2} onPointerEnter={() => setHover(i)} onPointerLeave={() => setHover(null)} />)}
        {hover != null && valid[hover] && <text x={valid[hover]![0]} y={valid[hover]![1] - 10} textAnchor="middle" fontSize="11" fontWeight="700" fill="var(--ink)">{fmtNumber(points[hover]!, lang)}{suffix}</text>}
      </svg>
      <div className="mt-1 flex justify-between px-1 text-[10px] text-ink-3">{labels.map((l, i) => <span key={i} className={labels.length > 10 && i % 5 ? 'invisible' : ''}>{l}</span>)}</div>
    </figure>
  );
}

export function BarChart({ series, labels, height = 150, stacked = true }: { series: { name: string; color: string; values: number[] }[]; labels: string[]; height?: number; stacked?: boolean }) {
  const { lang } = useT();
  const w = 320, pad = 10;
  const n = labels.length || 1;
  const totals = labels.map((_, i) => stacked ? series.reduce((a, s) => a + (s.values[i] ?? 0), 0) : Math.max(...series.map((s) => s.values[i] ?? 0)));
  const max = Math.max(1, ...totals);
  const bw = ((w - pad * 2) / n) * 0.62;
  return (
    <figure className="w-full" dir="ltr">
      <svg viewBox={`0 0 ${w} ${height}`} className="w-full" role="img" aria-label={labels.map((l, i) => `${l}: ${fmtNumber(totals[i], lang)}`).join(', ')}>
        {labels.map((_, i) => {
          const cx = pad + ((i + 0.5) * (w - pad * 2)) / n;
          let acc = 0;
          return (
            <g key={i}>
              <rect x={cx - bw / 2} y={pad} width={bw} height={height - pad * 2} rx={6} fill="var(--surface-2)" />
              {series.map((s, si) => {
                const v = s.values[i] ?? 0;
                const h = (v / max) * (height - pad * 2);
                const yy = height - pad - acc - h;
                if (stacked) acc += h;
                const x0 = stacked ? cx - bw / 2 : cx - bw / 2 + (si * bw) / series.length;
                const ww = stacked ? bw : bw / series.length;
                return v > 0 ? <rect key={si} x={x0} y={yy} width={ww} height={Math.max(1, h)} rx={stacked ? 3 : 4} fill={s.color}><title>{`${s.name}: ${fmtNumber(v, lang)}`}</title></rect> : null;
              })}
            </g>
          );
        })}
      </svg>
      <div className="mt-1 flex justify-around text-[10px] text-ink-3">{labels.map((l, i) => <span key={i}>{l}</span>)}</div>
    </figure>
  );
}

export function Donut({ parts, size = 150, label }: { parts: { name: string; value: number; color: string }[]; size?: number; label?: string }) {
  const { lang } = useT();
  const total = parts.reduce((a, p) => a + p.value, 0);
  const r = size / 2 - 12, c = 2 * Math.PI * r;
  let off = 0;
  return (
    <div className="flex items-center gap-5">
      <svg width={size} height={size} className="-rotate-90 shrink-0" role="img" aria-label={parts.map((p) => `${p.name} ${Math.round((p.value / Math.max(1, total)) * 100)}%`).join(', ')}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-2)" strokeWidth={16} />
        {total > 0 && parts.map((p, i) => {
          const len = (p.value / total) * c;
          const el = <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={p.color} strokeWidth={16} strokeDasharray={`${Math.max(0, len - 2)} ${c}`} strokeDashoffset={-off} />;
          off += len; return el;
        })}
        {label && <text x={size / 2} y={size / 2} transform={`rotate(90 ${size / 2} ${size / 2})`} textAnchor="middle" dominantBaseline="middle" fontSize="15" fontWeight="700" fill="var(--ink)">{label}</text>}
      </svg>
      <ul className="min-w-0 flex-1 space-y-1.5">
        {parts.filter((p) => p.value > 0).map((p) => (
          <li key={p.name} className="flex items-center gap-2 text-[13px]"><span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: p.color }} /><span className="flex-1 truncate">{p.name}</span><span className="num font-semibold text-ink-2">{fmtNumber(Math.round((p.value / Math.max(1, total)) * 100), lang)}%</span></li>
        ))}
      </ul>
    </div>
  );
}

export function Heatmap({ cells, columns = 7, color = 'var(--accent)' }: { cells: { date: string; level: number }[]; columns?: number; color?: string }) {
  const op = [0, 0.3, 0.6, 1];
  return (
    <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }} role="img" aria-label={cells.map((c) => `${c.date}:${c.level}`).join(' ')}>
      {cells.map((c) => (
        <div key={c.date} title={c.date} className="aspect-square rounded-[6px]" style={{ background: c.level ? color : 'var(--surface-2)', opacity: c.level ? op[c.level] : 1 }} />
      ))}
    </div>
  );
}

export function Trend({ value, prev, suffix = '' }: { value: number; prev: number; suffix?: string }) {
  const { lang } = useT();
  const d = value - prev;
  if (!prev && !value) return null;
  return <span className={d >= 0 ? 'text-success text-xs font-semibold' : 'text-warning text-xs font-semibold'}>{d >= 0 ? '▲' : '▼'} {fmtNumber(Math.abs(d), lang)}{suffix}</span>;
}
