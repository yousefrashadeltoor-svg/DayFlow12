import type { ActivityBlock, ActivityCategory, BlockStatus, Collections } from '@/models/types';
import type { SchedItem } from '@/services/scheduling/engine';
import type { TKey } from '@/services/localization/i18n';
import { useApp } from '@/stores/appStore';
import { Icon } from '@/components/common/ui';

export type EffStatus = BlockStatus | 'delayed';

/** Status shown to the user: planned blocks whose end passed today are "delayed" (derived, not stored). */
export function effectiveStatus(b: ActivityBlock, isToday: boolean, nowMin: number): EffStatus {
  if (b.status === 'planned' && isToday && b.startMin + b.durationMin <= nowMin) return 'delayed';
  return b.status;
}
export const statusKey = (s: EffStatus) => `st_${s}` as TKey;
export const statusTone = (s: EffStatus): 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'info' =>
  ({ planned: 'neutral', active: 'accent', paused: 'info', completed: 'success', partial: 'info', skipped: 'neutral', missed: 'danger', cancelled: 'neutral', delayed: 'warning' } as const)[s];

export function useCategory(id: string | undefined): ActivityCategory | undefined {
  return useApp((s) => (id ? s.data.categories[id] : undefined));
}
export function catName(c: ActivityCategory | undefined, lang: string) { return c ? (lang === 'ar' ? c.nameAr : c.nameEn) : ''; }
export function catLabel(data: Collections, id: string, lang: string) { return catName(data.categories[id], lang) || id; }

export function BlockIcon({ block, size = 40 }: { block: Pick<ActivityBlock, 'icon' | 'color'>; size?: number }) {
  return (
    <span className="grid shrink-0 place-items-center rounded-[14px]" style={{ width: size, height: size, background: `color-mix(in srgb, ${block.color} 16%, transparent)`, color: block.color }}>
      <Icon name={block.icon} size={Math.round(size * 0.48)} />
    </span>
  );
}

export const toSched = (b: ActivityBlock): SchedItem => ({
  id: b.id, title: b.title, startMin: b.startMin, durationMin: b.durationMin, fixed: b.fixed, status: b.status, priority: b.priority, difficulty: b.difficulty,
  windowStartMin: b.windowStartMin, windowEndMin: b.windowEndMin, prepMin: b.prepMin, cleanupMin: b.cleanupMin, bufferMin: b.bufferMin, dependsOn: b.dependsOn,
  splitAllowed: b.splitAllowed, minSplitMin: b.minSplitMin, categoryId: b.categoryId,
});
