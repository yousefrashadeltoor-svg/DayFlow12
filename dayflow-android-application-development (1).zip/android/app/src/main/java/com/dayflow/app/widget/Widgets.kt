package com.dayflow.app.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.dayflow.app.MainActivity
import com.dayflow.app.R
import com.dayflow.app.alarm.ActivityActions
import com.dayflow.app.alarm.AlarmScheduler
import com.dayflow.app.alarm.LocaleHelper
import com.dayflow.app.alarm.PrayerEngine
import com.dayflow.app.data.DayflowDatabase
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import kotlin.math.min

/** Snapshot of today's applied schedule, occasions and tasks computed from the native database (no web layer involved). */
data class DaySnapshot(
    val blocks: List<JSONObject>,
    val current: JSONObject?,
    val next: List<JSONObject>,
    val progressPercent: Int,
    val completedCount: Int,
    val totalCount: Int,
    val nowMin: Int,
    val occasions: List<JSONObject>,
    val tasksDue: Int,
)

object WidgetUpdater {
    private val TERMINAL = setOf("completed", "skipped", "cancelled", "partial")

    fun snapshot(context: Context): DaySnapshot {
        val db = DayflowDatabase.get(context)
        val today = LocalDate.now().toString()
        val now = LocalTime.now()
        val nowMin = now.hour * 60 + now.minute
        val blocks = try {
            db.getByDate("activities", today).filter { it.optString("status") != "cancelled" && it.optBoolean("applied", true) }.sortedBy { it.optInt("startMin") }
        } catch (_: Exception) { emptyList() }

        val current = blocks.firstOrNull { it.optString("status") == "active" }
            ?: blocks.firstOrNull {
                val s = it.optInt("startMin"); val e = s + it.optInt("durationMin")
                nowMin in s until e && it.optString("status") !in TERMINAL
            }
        val next = blocks.filter { it.optInt("startMin") > nowMin && it.optString("status") == "planned" && it !== current }

        var planned = 0.0; var done = 0.0
        blocks.forEach { b ->
            val dur = b.optInt("durationMin").toDouble()
            planned += dur
            when (b.optString("status")) {
                "completed" -> done += dur
                "partial" -> {
                    val a = b.optLong("actualStart", 0); val z = b.optLong("actualEnd", 0)
                    if (a > 0 && z > a) done += minOf(dur, (z - a) / 60000.0)
                }
            }
        }
        val pct = if (planned > 0) ((done / planned) * 100).toInt().coerceIn(0, 100) else 0
        val occasions = try { db.getByDate("occasions", today) } catch (_: Exception) { emptyList() }
        val tasksDue = try {
            val arr = db.getAll("tasks"); var n = 0
            for (i in 0 until arr.length()) { val t = arr.getJSONObject(i); if (t.optString("dueDate") == today && t.optString("status") != "done" && t.optString("status") != "cancelled") n++ }
            n
        } catch (_: Exception) { 0 }
        return DaySnapshot(blocks, current, next, pct, blocks.count { it.optString("status") == "completed" }, blocks.size, nowMin, occasions, tasksDue)
    }

    fun fmt(context: Context, minute: Int): String {
        val m = ((minute % 1440) + 1440) % 1440
        val use24 = (DayflowDatabase.get(context).getKv("clock24") ?: "true") == "true"
        val lang = LocaleHelper.language(context)
        val locale = Locale.forLanguageTag(lang)
        return if (use24) String.format(locale, "%02d:%02d", m / 60, m % 60)
        else {
            val h = if (m / 60 % 12 == 0) 12 else m / 60 % 12
            val suffix = if (m < 720) (if (lang == "ar") "ص" else "AM") else (if (lang == "ar") "م" else "PM")
            String.format(locale, "%d:%02d %s", h, m % 60, suffix)
        }
    }
    fun fmtEpoch(context: Context, ms: Long): String {
        val dt = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
        return fmt(context, dt.hour * 60 + dt.minute)
    }

    fun isDark(context: Context): Boolean = when (DayflowDatabase.get(context).getKv("theme")) {
        "dark" -> true
        "light" -> false
        else -> (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    fun accent(context: Context): Int = try { Color.parseColor(DayflowDatabase.get(context).getKv("accent") ?: "#5B5BD6") } catch (_: Exception) { Color.parseColor("#5B5BD6") }

    fun openAppIntent(context: Context, code: Int, screen: String? = null): PendingIntent =
        PendingIntent.getActivity(
            context, code, Intent(context, MainActivity::class.java).putExtra("openScreen", screen).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun actionIntent(context: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            context, code, Intent(context, WidgetActionReceiver::class.java).setAction(action).setPackage(context.packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun applyTheme(context: Context, views: RemoteViews, textIds: IntArray, secondaryIds: IntArray) {
        val dark = isDark(context)
        views.setInt(R.id.widget_root, "setBackgroundResource", if (dark) R.drawable.widget_bg_dark else R.drawable.widget_bg_light)
        val primary = context.getColor(if (dark) R.color.widget_text_dark else R.color.widget_text_light)
        val secondary = context.getColor(if (dark) R.color.widget_text2_dark else R.color.widget_text2_light)
        textIds.forEach { views.setTextColor(it, primary) }
        secondaryIds.forEach { views.setTextColor(it, secondary) }
    }

    /** Live ticking countdown rendered by Android itself (no updates needed while it runs). */
    fun setCountdown(views: RemoteViews, id: Int, targetMs: Long) {
        val base = SystemClock.elapsedRealtime() + (targetMs - System.currentTimeMillis())
        views.setChronometerCountDown(id, true)
        views.setChronometer(id, base, null, true)
    }

    fun occasionLine(context: Context, s: DaySnapshot): String? {
        val o = s.occasions.firstOrNull() ?: return null
        val ar = LocaleHelper.language(context) == "ar"
        val ctx = LocaleHelper.localized(context)
        val title = if (ar) o.optString("title") else o.optString("titleEn").ifEmpty { o.optString("title") }
        return (if (o.optBoolean("official")) "\uD83C\uDF89 " else "\uD83D\uDCC5 ") + title + (if (o.optBoolean("official")) " · " + ctx.getString(R.string.widget_official) else "")
    }

    fun refreshAll(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        var any = false
        listOf(CompactWidgetProvider(), MediumWidgetProvider(), LargeWidgetProvider(), PrayerWidgetProvider()).forEach { p ->
            val ids = mgr.getAppWidgetIds(ComponentName(context, p.javaClass))
            if (ids.isNotEmpty()) { any = true; try { p.onUpdate(context, mgr, ids) } catch (_: Exception) { } }
        }
        if (any) scheduleNextRefresh(context)
    }

    /** Wakes the widgets exactly when something changes on screen (a block starts/ends, a prayer begins, midnight). */
    fun scheduleNextRefresh(context: Context) {
        try {
            val now = System.currentTimeMillis()
            val today = LocalDate.now()
            var next = AlarmScheduler.localToEpoch(today.plusDays(1).toString(), 0) + 1000
            for (b in snapshot(context).blocks) {
                val st = AlarmScheduler.localToEpoch(today.toString(), b.optInt("startMin"))
                val en = st + b.optInt("durationMin") * 60_000L
                if (st > now) next = min(next, st)
                if (en > now) next = min(next, en)
            }
            PrayerEngine.next(context)?.let { next = min(next, it.at) }
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC, next + 1500, actionIntent(context, WidgetActionReceiver.REFRESH, 650))
        } catch (_: Exception) { }
    }

    fun remainingMin(block: JSONObject, nowMin: Int): Int = (block.optInt("startMin") + block.optInt("durationMin") - nowMin).coerceAtLeast(0)
}

object RingRenderer {
    fun render(size: Int, progress: Int, ring: Int, track: Int, text: String, textColor: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val stroke = size * 0.11f
        val pad = stroke / 2f + 2f
        val rect = RectF(pad, pad, size - pad, size - pad)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke; color = track }
        c.drawArc(rect, 0f, 360f, false, tp)
        val pp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke; color = ring; strokeCap = Paint.Cap.ROUND }
        c.drawArc(rect, -90f, 360f * progress / 100f, false, pp)
        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = textColor; textSize = size * 0.19f; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
        c.drawText(text, size / 2f, size / 2f - (txt.descent() + txt.ascent()) / 2f, txt)
        return bmp
    }
}

private fun bindCurrent(context: Context, ctx: Context, v: RemoteViews, s: DaySnapshot) {
    val cur = s.current
    v.setTextViewText(R.id.w_label, ctx.getString(R.string.widget_now))
    if (cur != null) {
        v.setTextViewText(R.id.w_current_title, cur.optString("title"))
        v.setViewVisibility(R.id.w_rem_row, View.VISIBLE)
        v.setTextViewText(R.id.w_rem_label, ctx.getString(R.string.widget_remaining_label))
        val endMs = AlarmScheduler.localToEpoch(LocalDate.now().toString(), cur.optInt("startMin") + cur.optInt("durationMin"))
        if (endMs > System.currentTimeMillis()) { v.setViewVisibility(R.id.w_chrono, View.VISIBLE); v.setViewVisibility(R.id.w_remaining, View.GONE); WidgetUpdater.setCountdown(v, R.id.w_chrono, endMs) }
        else { v.setViewVisibility(R.id.w_chrono, View.GONE); v.setViewVisibility(R.id.w_remaining, View.VISIBLE); v.setTextViewText(R.id.w_remaining, ctx.getString(R.string.widget_overdue)) }
    } else {
        v.setTextViewText(R.id.w_current_title, ctx.getString(if (s.totalCount == 0) R.string.widget_empty else R.string.widget_free))
        v.setViewVisibility(R.id.w_rem_row, View.GONE)
    }
    v.setViewVisibility(R.id.w_btn_done, if (cur != null) View.VISIBLE else View.GONE)
    v.setOnClickPendingIntent(R.id.w_btn_done, WidgetUpdater.actionIntent(context, WidgetActionReceiver.COMPLETE_CURRENT, 601))
}

private fun bindOccasion(context: Context, v: RemoteViews, s: DaySnapshot) {
    val line = WidgetUpdater.occasionLine(context, s)
    v.setViewVisibility(R.id.w_occ, if (line != null) View.VISIBLE else View.GONE)
    if (line != null) v.setTextViewText(R.id.w_occ, line)
}

class CompactWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val ctx = LocaleHelper.localized(context)
        val s = WidgetUpdater.snapshot(context)
        ids.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.widget_compact)
            WidgetUpdater.applyTheme(context, v, intArrayOf(R.id.w_current_title, R.id.w_chrono), intArrayOf(R.id.w_label, R.id.w_remaining, R.id.w_rem_label, R.id.w_next, R.id.w_occ))
            bindCurrent(context, ctx, v, s)
            bindOccasion(context, v, s)
            v.setTextViewText(R.id.w_btn_done, ctx.getString(R.string.action_done))
            val n = s.next.firstOrNull()
            v.setTextViewText(R.id.w_next, if (n != null) ctx.getString(R.string.widget_next_fmt, WidgetUpdater.fmt(context, n.optInt("startMin")), n.optString("title")) else ctx.getString(R.string.widget_no_next))
            v.setOnClickPendingIntent(R.id.widget_root, WidgetUpdater.openAppIntent(context, 501))
            mgr.updateAppWidget(id, v)
        }
    }
}

class MediumWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val ctx = LocaleHelper.localized(context)
        val s = WidgetUpdater.snapshot(context)
        ids.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.widget_medium)
            WidgetUpdater.applyTheme(context, v, intArrayOf(R.id.w_current_title, R.id.w_next1, R.id.w_next2, R.id.w_chrono), intArrayOf(R.id.w_label, R.id.w_remaining, R.id.w_rem_label, R.id.w_progress_text, R.id.w_occ))
            bindCurrent(context, ctx, v, s)
            bindOccasion(context, v, s)
            val rows = intArrayOf(R.id.w_next1, R.id.w_next2)
            rows.forEachIndexed { i, rid ->
                val b = s.next.getOrNull(i)
                if (b != null) { v.setViewVisibility(rid, View.VISIBLE); v.setTextViewText(rid, "${WidgetUpdater.fmt(context, b.optInt("startMin"))}  ${b.optString("title")}") }
                else if (i == 0) { v.setViewVisibility(rid, View.VISIBLE); v.setTextViewText(rid, ctx.getString(R.string.widget_no_next)) }
                else v.setViewVisibility(rid, View.GONE)
            }
            v.setProgressBar(R.id.w_progress, 100, s.progressPercent, false)
            v.setTextViewText(R.id.w_progress_text, ctx.getString(R.string.widget_progress_fmt, s.progressPercent, s.completedCount, s.totalCount))
            v.setTextViewText(R.id.w_btn_done, ctx.getString(R.string.action_done))
            v.setTextViewText(R.id.w_btn_start, ctx.getString(R.string.widget_start_next))
            v.setViewVisibility(R.id.w_btn_start, if (s.next.isNotEmpty()) View.VISIBLE else View.GONE)
            v.setOnClickPendingIntent(R.id.w_btn_start, WidgetUpdater.actionIntent(context, WidgetActionReceiver.START_NEXT, 602))
            v.setOnClickPendingIntent(R.id.widget_root, WidgetUpdater.openAppIntent(context, 502))
            mgr.updateAppWidget(id, v)
        }
    }
}

class LargeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val ctx = LocaleHelper.localized(context)
        val s = WidgetUpdater.snapshot(context)
        ids.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.widget_large)
            val rows = intArrayOf(R.id.w_row1, R.id.w_row2, R.id.w_row3, R.id.w_row4, R.id.w_row5)
            WidgetUpdater.applyTheme(context, v, intArrayOf(R.id.w_current_title, R.id.w_chrono) + rows, intArrayOf(R.id.w_label, R.id.w_remaining, R.id.w_rem_label, R.id.w_progress_text, R.id.w_header, R.id.w_occ, R.id.w_tasks))
            v.setTextViewText(R.id.w_header, ctx.getString(R.string.widget_today))
            bindCurrent(context, ctx, v, s)
            bindOccasion(context, v, s)
            v.setViewVisibility(R.id.w_tasks, if (s.tasksDue > 0) View.VISIBLE else View.GONE)
            if (s.tasksDue > 0) v.setTextViewText(R.id.w_tasks, ctx.getString(R.string.widget_tasks_today, s.tasksDue))
            val startIdx = s.blocks.indexOfFirst { it.optInt("startMin") + it.optInt("durationMin") > s.nowMin }.let { if (it < 0) s.blocks.size else it }
            val visible = s.blocks.drop(startIdx).take(rows.size)
            rows.forEachIndexed { i, rid ->
                val b = visible.getOrNull(i)
                if (b == null) v.setViewVisibility(rid, View.GONE)
                else {
                    v.setViewVisibility(rid, View.VISIBLE)
                    val mark = when (b.optString("status")) { "completed" -> "✓ "; "skipped" -> "⤼ "; "active" -> "● "; else -> "" }
                    v.setTextViewText(rid, "${WidgetUpdater.fmt(context, b.optInt("startMin"))}  $mark${b.optString("title")}")
                }
            }
            v.setProgressBar(R.id.w_progress, 100, s.progressPercent, false)
            v.setTextViewText(R.id.w_progress_text, ctx.getString(R.string.widget_progress_fmt, s.progressPercent, s.completedCount, s.totalCount))
            v.setTextViewText(R.id.w_btn_done, ctx.getString(R.string.action_done))
            v.setTextViewText(R.id.w_btn_start, ctx.getString(R.string.widget_start_next))
            v.setTextViewText(R.id.w_btn_open, ctx.getString(R.string.widget_open))
            v.setOnClickPendingIntent(R.id.w_btn_start, WidgetUpdater.actionIntent(context, WidgetActionReceiver.START_NEXT, 602))
            v.setOnClickPendingIntent(R.id.w_btn_open, WidgetUpdater.openAppIntent(context, 603))
            v.setViewVisibility(R.id.w_btn_start, if (s.next.isNotEmpty()) View.VISIBLE else View.GONE)
            v.setOnClickPendingIntent(R.id.widget_root, WidgetUpdater.openAppIntent(context, 504))
            mgr.updateAppWidget(id, v)
        }
    }
}

/** Next prayer with a progress ring, live countdown, today's tally and a one-tap "I prayed" button. */
class PrayerWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val ctx = LocaleHelper.localized(context)
        val cfg = PrayerEngine.cfg(context)
        val dark = WidgetUpdater.isDark(context)
        val prayerIds = intArrayOf(R.id.w_pr1, R.id.w_pr2, R.id.w_pr3, R.id.w_pr4, R.id.w_pr5)
        ids.forEach { id ->
            val v = RemoteViews(context.packageName, R.layout.widget_prayer)
            WidgetUpdater.applyTheme(context, v, intArrayOf(R.id.w_p_name, R.id.w_p_chrono), intArrayOf(R.id.w_p_label, R.id.w_p_rem_label, R.id.w_p_stats) + prayerIds)
            v.setOnClickPendingIntent(R.id.widget_root, WidgetUpdater.openAppIntent(context, 701, "prayer"))
            v.setTextViewText(R.id.w_p_label, ctx.getString(R.string.widget_prayer_next))
            val next = if (cfg != null && cfg.enabled) PrayerEngine.next(context) else null
            if (next == null) {
                v.setTextViewText(R.id.w_p_name, ctx.getString(R.string.widget_prayer_off))
                v.setViewVisibility(R.id.w_p_row, View.GONE); v.setViewVisibility(R.id.w_btn_prayed, View.GONE)
                v.setTextViewText(R.id.w_p_stats, "")
                prayerIds.forEach { v.setViewVisibility(it, View.GONE) }
                v.setImageViewBitmap(R.id.w_ring, RingRenderer.render(240, 0, WidgetUpdater.accent(context), Color.parseColor(if (dark) "#33FFFFFF" else "#1F000000"), "", Color.WHITE))
            } else {
                val done = PrayerEngine.doneToday(context)
                val now = System.currentTimeMillis()
                val textColor = context.getColor(if (dark) R.color.widget_text_dark else R.color.widget_text_light)
                v.setImageViewBitmap(R.id.w_ring, RingRenderer.render(240, next.progress(now), Color.parseColor("#22A45D"), Color.parseColor(if (dark) "#33FFFFFF" else "#1F000000"), "${next.progress(now)}%", textColor))
                v.setTextViewText(R.id.w_p_name, "${PrayerEngine.name(context, next.key)} · ${WidgetUpdater.fmtEpoch(context, next.at)}")
                v.setViewVisibility(R.id.w_p_row, View.VISIBLE)
                v.setTextViewText(R.id.w_p_rem_label, ctx.getString(R.string.widget_remaining_label))
                WidgetUpdater.setCountdown(v, R.id.w_p_chrono, next.at)
                v.setTextViewText(R.id.w_p_stats, ctx.getString(R.string.widget_prayer_stats, done.size, PrayerEngine.weekCount(context)))
                PrayerEngine.KEYS.forEachIndexed { i, k ->
                    v.setViewVisibility(prayerIds[i], View.VISIBLE)
                    v.setTextViewText(prayerIds[i], (if (k in done) "✓ " else "○ ") + PrayerEngine.name(context, k))
                }
                v.setTextViewText(R.id.w_btn_prayed, ctx.getString(R.string.action_prayed))
                v.setViewVisibility(R.id.w_btn_prayed, View.VISIBLE)
                v.setOnClickPendingIntent(R.id.w_btn_prayed, WidgetUpdater.actionIntent(context, WidgetActionReceiver.MARK_PRAYED, 702))
            }
            mgr.updateAppWidget(id, v)
        }
    }
}

/** Widget quick actions update the real stored records through the shared action pipeline. */
class WidgetActionReceiver : BroadcastReceiver() {
    companion object {
        const val COMPLETE_CURRENT = "com.dayflow.app.widget.COMPLETE_CURRENT"
        const val START_NEXT = "com.dayflow.app.widget.START_NEXT"
        const val MARK_PRAYED = "com.dayflow.app.widget.MARK_PRAYED"
        const val REFRESH = "com.dayflow.app.widget.REFRESH"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        try {
            val s = WidgetUpdater.snapshot(context)
            when (intent.action) {
                COMPLETE_CURRENT -> s.current?.let { ActivityActions.apply(context, "DONE", null, it.optString("id"), "widget") }
                START_NEXT -> s.next.firstOrNull()?.let { ActivityActions.apply(context, "START", null, it.optString("id"), "widget") }
                MARK_PRAYED -> { PrayerEngine.markLatest(context); ActivityActions.afterChange(context) }
            }
            WidgetUpdater.refreshAll(context)
            PrayerEngine.refreshOngoing(context)
        } finally { pending.finish() }
    }
}
