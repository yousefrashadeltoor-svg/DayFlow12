package com.dayflow.app.alarm

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.dayflow.app.R

/** Full-screen alarm UI shown over the lock screen. Snooze/Stop call the same native code as the notification buttons. */
class AlarmRingActivity : Activity() {
    companion object { const val ACTION_DISMISSED = "com.dayflow.app.alarm.RING_DISMISSED" }

    private var pulse: ObjectAnimator? = null
    private var alarmKey: String = ""
    private val dismissReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { finishAndRemoveTask() }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            (if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1) WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON else 0))
        setContentView(R.layout.activity_alarm_ring)
        bind(intent)
        val ring = findViewById<View>(R.id.ring_pulse)
        pulse = ObjectAnimator.ofPropertyValuesHolder(ring,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.7f), PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.7f), PropertyValuesHolder.ofFloat(View.ALPHA, 0.55f, 0f)).apply {
            duration = 1500; repeatCount = ValueAnimator.INFINITE; start()
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); bind(intent) }

    private fun bind(i: Intent) {
        val ctx = LocaleHelper.localized(this)
        alarmKey = i.getStringExtra("alarmKey") ?: ""
        val left = i.getIntExtra("snoozeLeft", 0)
        val snoozeMin = i.getIntExtra("snoozeMin", 9)
        val rtl = LocaleHelper.language(this) == "ar"
        findViewById<View>(R.id.ring_root).layoutDirection = if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        findViewById<TextView>(R.id.ring_time).text = i.getStringExtra("time") ?: ""
        findViewById<TextView>(R.id.ring_label).text = i.getStringExtra("title") ?: ""
        findViewById<TextView>(R.id.ring_sub).text = ctx.getString(R.string.alarm_ring_title)
        val snooze = findViewById<TextView>(R.id.btn_snooze)
        snooze.text = ctx.getString(R.string.alarm_snooze_fmt, snoozeMin)
        snooze.visibility = if (left > 0) View.VISIBLE else View.GONE
        snooze.setOnClickListener { UserAlarms.snooze(this, alarmKey); finishAndRemoveTask() }
        val stop = findViewById<TextView>(R.id.btn_stop)
        stop.text = ctx.getString(R.string.alarm_stop)
        stop.setOnClickListener { UserAlarms.stop(this, alarmKey); finishAndRemoveTask() }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, dismissReceiver, IntentFilter(ACTION_DISMISSED), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        try { unregisterReceiver(dismissReceiver) } catch (_: Exception) { }
        super.onStop()
    }

    override fun onDestroy() { pulse?.cancel(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* the user must choose Snooze or Stop */ }
}
