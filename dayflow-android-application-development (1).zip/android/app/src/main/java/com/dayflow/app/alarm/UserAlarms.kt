package com.dayflow.app.alarm

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.dayflow.app.R
import com.dayflow.app.audio.AlarmAudioService
import com.dayflow.app.data.DayflowDatabase
import com.dayflow.app.widget.WidgetUpdater
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Real alarm clocks. Records live in the `alarmClocks` collection (written by the web layer through the plugin).
 * Each enabled alarm owns one AlarmManager.setAlarmClock entry (key `ua:<id>`), which is exempt from Doze and does not need
 * the exact-alarm permission. After ringing, repeating alarms schedule their own next occurrence natively, so they keep
 * working even if the app is never opened again. Snoozes use the key `ua:<id>#snooze`.
 */
object UserAlarms {
    const val KIND = "useralarm"
    fun key(id: String) = "ua:$id"

    /** Mirrors nextRing() in src/services/alarmClock.ts. Returns epoch millis strictly after [from], or null. */
    fun nextTrigger(rec: JSONObject, from: Long): Long? {
        if (!rec.optBoolean("enabled", true)) return null
        val minute = rec.optInt("minute", 0)
        val daysArr = rec.optJSONArray("days") ?: JSONArray()
        val days = (0 until daysArr.length()).map { daysArr.getInt(it) }
        val zone = ZoneId.systemDefault()
        val base = Instant.ofEpochMilli(from).atZone(zone).toLocalDate()
        val skip = rec.optString("skipDate").ifEmpty { null }
        val one = rec.optString("oneTimeDate").ifEmpty { null }
        for (i in 0..8) {
            val d = base.plusDays(i.toLong())
            val t = d.atStartOfDay(zone).plusMinutes(minute.toLong()).toInstant().toEpochMilli()
            if (t <= from) continue
            val k = d.toString()
            if (skip == k) continue
            val dow = d.dayOfWeek.value % 7 // Sunday = 0
            if (days.isNotEmpty()) { if (dow in days) return t }
            else if (one != null) { if (k == one) return t; if (k > one) return null }
            else return t
        }
        if (days.isEmpty() && one != null) {
            val t = LocalDate.parse(one).atStartOfDay(zone).plusMinutes(minute.toLong()).toInstant().toEpochMilli()
            return if (t > from) t else null
        }
        return null
    }

    private fun soundFields(sound: JSONObject?, p: JSONObject) {
        when (sound?.optString("kind") ?: "default") {
            "tts" -> p.put("soundMode", "tts")
            "silent" -> p.put("soundMode", "none")
            "file" -> { p.put("soundMode", "custom"); p.put("soundUri", sound?.optString("uri")); p.put("startMs", sound?.optInt("startMs", 0) ?: 0); p.put("endMs", sound?.optInt("endMs", 0) ?: 0) }
            "ringtone", "alarm", "notification" -> {
                val uri = sound?.optString("uri").orEmpty()
                if (uri.isNotEmpty()) { p.put("soundMode", "custom"); p.put("soundUri", uri) } else p.put("soundMode", "tone")
            }
            else -> p.put("soundMode", "tone")
        }
    }

    fun buildPayload(context: Context, rec: JSONObject, at: Long): JSONObject {
        val ctx = LocaleHelper.localized(context)
        val label = rec.optString("label").trim()
        val minute = rec.optInt("minute", 0)
        return JSONObject().apply {
            put("kind", KIND)
            put("blockId", rec.getString("id"))
            put("title", label.ifEmpty { ctx.getString(R.string.alarm_default_label) })
            put("body", WidgetUpdater.fmt(context, minute))
            put("category", "alarm")
            put("triggerAt", at)
            put("absolute", true)
            put("alarmClock", true)
            put("silent", false)
            put("vibrate", rec.optBoolean("vibrate", true))
            put("volume", rec.optDouble("volume", 1.0))
            put("gradual", rec.optBoolean("gradual", true))
            put("speakLabel", rec.optBoolean("speakLabel", false))
            put("ttsText", label)
            put("ttsLang", LocaleHelper.language(context))
            put("snoozeMin", rec.optInt("snoozeMin", 9))
            put("maxSnoozes", rec.optInt("maxSnoozes", 3))
            put("ringMin", rec.optInt("ringMin", 5))
            put("colorHex", "#EF4444")
            put("actions", JSONArray())
            soundFields(rec.optJSONObject("sound"), this)
        }
    }

    fun scheduleOne(context: Context, rec: JSONObject): Long? {
        val id = rec.optString("id")
        if (id.isEmpty()) return null
        val at = nextTrigger(rec, System.currentTimeMillis())
        if (at == null) { AlarmScheduler.cancel(context, key(id)); return null }
        return try { AlarmScheduler.schedule(context, key(id), buildPayload(context, rec, at)); at } catch (_: Exception) { null }
    }

    /** Re-registers every enabled alarm and removes alarms (and snoozes) of deleted/disabled records. Idempotent. */
    fun rescheduleAll(context: Context): Int {
        val db = DayflowDatabase.get(context)
        val recs = db.getAll("alarmClocks")
        val enabled = HashSet<String>()
        val keep = HashSet<String>()
        var count = 0
        for (i in 0 until recs.length()) {
            val r = recs.getJSONObject(i)
            if (!r.optBoolean("enabled", true)) continue
            enabled.add(r.optString("id"))
            if (scheduleOne(context, r) != null) { keep.add(key(r.optString("id"))); count++ }
        }
        val stale = mutableListOf<String>()
        db.readableDatabase.rawQuery("SELECT alarm_key FROM alarms WHERE kind = ? AND state IN ('scheduled','snoozed','escalating')", arrayOf(KIND)).use { c ->
            while (c.moveToNext()) {
                val k = c.getString(0)
                val parent = k.removePrefix("ua:").substringBefore("#")
                if (k !in keep && !(k.endsWith("#snooze") && parent in enabled)) stale.add(k)
            }
        }
        stale.forEach { AlarmScheduler.cancel(context, it) }
        WidgetUpdater.refreshAll(context)
        return count
    }

    /** Called by AlarmReceiver when an alarm (or its snooze) fires. Returns after starting the ringing service. */
    fun onFire(context: Context, alarmKey: String, alarm: JSONObject) {
        val db = DayflowDatabase.get(context)
        val id = alarm.optString("blockId")
        val isSnooze = alarmKey.endsWith("#snooze")
        val rec = db.get("alarmClocks", id)
        if (rec == null || (!isSnooze && !rec.optBoolean("enabled", true))) { AlarmScheduler.cancel(context, alarmKey); return }
        db.writableDatabase.execSQL("UPDATE alarms SET state = 'delivered', delivered_at = ?, updated_at = ? WHERE alarm_key = ?", arrayOf<Any>(System.currentTimeMillis(), System.currentTimeMillis(), alarmKey))
        if (!isSnooze) {
            AlarmScheduler.cancel(context, alarmKey + "#snooze")
            val days = rec.optJSONArray("days")
            if (days != null && days.length() > 0) scheduleOne(context, rec)       // repeating: perpetuate natively
            else { rec.put("enabled", false); rec.put("updatedAt", System.currentTimeMillis()); db.put("alarmClocks", rec); ActivityActions.afterChange(context) } // one-time: done
        }
        db.logAction(alarmKey, id, "FIRE", "delivered")
        val intent = Intent(context, AlarmAudioService::class.java).setAction(AlarmAudioService.ACTION_PLAY_ALARM).putExtra("alarm", alarm.toString())
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (e: Exception) {
            db.logAction(alarmKey, id, "RING", "fallback_notification:${e.javaClass.simpleName}")
            NotificationHelper.showReminder(context, alarm.put("actions", JSONArray().put("DISMISS")), alarm.optInt("_requestCode", 1), false)
        }
    }

    /** Snooze: schedules `ua:<id>#snooze` and silences the ringing. Returns false when the snooze limit is reached. */
    fun snooze(context: Context, alarmKey: String): Boolean {
        val db = DayflowDatabase.get(context)
        val alarm = AlarmScheduler.loadAlarm(context, alarmKey) ?: return false
        val id = alarm.optString("blockId")
        val used = alarm.optInt("_repeatCount", 0)
        if (used >= alarm.optInt("maxSnoozes", 0)) return false
        val at = System.currentTimeMillis() + alarm.optInt("snoozeMin", 9).coerceIn(1, 60) * 60_000L
        val payload = JSONObject(alarm.toString())
        listOf("_requestCode", "_repeatCount", "_state", "_triggerAt", "_alarmKey").forEach { payload.remove(it) }
        payload.put("triggerAt", at).put("absolute", true).put("alarmClock", true)
        return try {
            AlarmScheduler.schedule(context, key(id) + "#snooze", payload, repeatCount = used + 1)
            db.logAction(alarmKey, id, "ALARM_SNOOZE", "ok")
            stopRinging(context)
            ActivityActions.afterChange(context)
            true
        } catch (e: Exception) { db.logAction(alarmKey, id, "ALARM_SNOOZE", "error:${e.message}"); false }
    }

    fun stop(context: Context, alarmKey: String) {
        val db = DayflowDatabase.get(context)
        val id = alarmKey.removePrefix("ua:").substringBefore("#")
        AlarmScheduler.markState(context, alarmKey, "acknowledged")
        AlarmScheduler.cancel(context, key(id) + "#snooze")
        db.logAction(alarmKey, id, "ALARM_STOP", "ok")
        stopRinging(context)
        ActivityActions.afterChange(context)
    }

    fun markMissed(context: Context, alarmKey: String) {
        AlarmScheduler.markState(context, alarmKey, "missed")
        val alarm = AlarmScheduler.loadAlarm(context, alarmKey)
        val ctx = LocaleHelper.localized(context)
        NotificationHelper.showSimple(context, 9_300_001, ctx.getString(R.string.alarm_missed_title), ctx.getString(R.string.alarm_missed_body, alarm?.optString("title") ?: ""), false)
        DayflowDatabase.get(context).logAction(alarmKey, alarm?.optString("blockId"), "RING", "missed_timeout")
    }

    fun stopRinging(context: Context) {
        try { context.startService(Intent(context, AlarmAudioService::class.java).setAction(AlarmAudioService.ACTION_STOP)) } catch (_: Exception) { }
        NotificationHelper.cancel(context, AlarmAudioService.RING_ID)
    }
}
