package com.dayflow.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Build
import com.dayflow.app.MainActivity
import com.dayflow.app.data.DayflowDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Result of a real scheduling call. `exact == false` means Android denied exact alarm access
 * and the alarm was scheduled with an inexact (allow-while-idle) window instead.
 */
data class ScheduleResult(val alarmKey: String, val requestCode: Int, val triggerAt: Long, val exact: Boolean)

/**
 * Native AlarmManager based scheduler. No JavaScript timers are involved: alarms are owned by
 * the operating system and delivered to [AlarmReceiver] even if the app process is dead.
 */
object AlarmScheduler {

    const val ACTION_FIRE = "com.dayflow.app.action.ALARM_FIRE"
    const val EXTRA_ALARM_KEY = "alarmKey"

    fun canScheduleExact(context: Context): Boolean {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.canScheduleExactAlarms() else true
    }

    /** Converts a local wall-clock date + minute to epoch millis in the device's current zone. */
    fun localToEpoch(localDate: String, localMinute: Int): Long {
        val d = LocalDate.parse(localDate)
        val ldt = LocalDateTime.of(d, java.time.LocalTime.MIDNIGHT).plusMinutes(localMinute.toLong())
        return ldt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    private fun nextRequestCode(db: SQLiteDatabase): Int {
        db.rawQuery("SELECT COALESCE(MAX(request_code), 10000) + 1 FROM alarms", null).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else 10001
        }
    }

    private fun existingRequestCode(db: SQLiteDatabase, alarmKey: String): Int? {
        db.rawQuery("SELECT request_code FROM alarms WHERE alarm_key = ?", arrayOf(alarmKey)).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else null
        }
    }

    private fun pendingIntent(context: Context, alarmKey: String, requestCode: Int, flags: Int): PendingIntent? {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_FIRE
            putExtra(EXTRA_ALARM_KEY, alarmKey)
            setPackage(context.packageName)
        }
        return PendingIntent.getBroadcast(context, requestCode, intent, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    /**
     * Upserts an alarm. Re-scheduling the same alarmKey reuses its request code and replaces the
     * PendingIntent, so repeated synchronisation never creates duplicates.
     * payload fields: kind, blockId, title, body, category, localDate, localMinute, triggerAt,
     *   soundMode, soundUri, ttsText, ttsLang, vibrate, silent, repeatIntervalMin, maxRepeats, actions[]
     */
    @Synchronized
    fun schedule(context: Context, alarmKey: String, payload: JSONObject, repeatCount: Int = 0): ScheduleResult {
        val db = DayflowDatabase.get(context).writableDatabase
        val localDate = payload.optString("localDate").ifEmpty { null }
        val localMinute = if (payload.has("localMinute")) payload.getInt("localMinute") else null
        val triggerAt = if (payload.has("triggerAt")) payload.getLong("triggerAt")
            else if (localDate != null && localMinute != null) localToEpoch(localDate, localMinute)
            else throw IllegalArgumentException("triggerAt or localDate/localMinute required")
        if (triggerAt <= System.currentTimeMillis() - 60_000) {
            throw IllegalArgumentException("Trigger time is in the past")
        }

        val now = System.currentTimeMillis()
        val requestCode = existingRequestCode(db, alarmKey) ?: nextRequestCode(db)
        val alarmClock = payload.optBoolean("alarmClock", false)
        val exact = alarmClock || canScheduleExact(context)

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context, alarmKey, requestCode, PendingIntent.FLAG_UPDATE_CURRENT)!!
        if (alarmClock) {
            // setAlarmClock: shown as an alarm in the status bar, exempt from Doze, no special permission required.
            val show = PendingIntent.getActivity(
                context, 7010, Intent(context, MainActivity::class.java).putExtra("openScreen", "alarms").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), pi)
        } else if (exact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }

        val cv = ContentValues().apply {
            put("alarm_key", alarmKey)
            put("request_code", requestCode)
            put("block_id", payload.optString("blockId").ifEmpty { null })
            put("kind", payload.optString("kind", "block"))
            put("trigger_at", triggerAt)
            put("local_date", localDate)
            if (localMinute != null) put("local_minute", localMinute) else putNull("local_minute")
            put("payload", payload.toString())
            put("repeat_count", repeatCount)
            put("state", if (repeatCount > 0) "escalating" else "scheduled")
            put("exact", if (exact) 1 else 0)
            put("created_at", now)
            put("updated_at", now)
        }
        db.insertWithOnConflict("alarms", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        if (payload.optString("kind") != "maintenance") DayflowDatabase.get(context).setKv("last_schedule_at", now.toString())
        return ScheduleResult(alarmKey, requestCode, triggerAt, exact)
    }

    @Synchronized
    fun cancel(context: Context, alarmKey: String): Boolean {
        val db = DayflowDatabase.get(context).writableDatabase
        val code = existingRequestCode(db, alarmKey) ?: return false
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        pendingIntent(context, alarmKey, code, PendingIntent.FLAG_NO_CREATE)?.let {
            am.cancel(it); it.cancel()
        }
        db.delete("alarms", "alarm_key = ?", arrayOf(alarmKey))
        NotificationHelper.cancel(context, code)
        return true
    }

    fun cancelForBlock(context: Context, blockId: String): Int {
        val keys = mutableListOf<String>()
        DayflowDatabase.get(context).readableDatabase.rawQuery(
            "SELECT alarm_key FROM alarms WHERE block_id = ?", arrayOf(blockId)
        ).use { c -> while (c.moveToNext()) keys.add(c.getString(0)) }
        keys.forEach { cancel(context, it) }
        return keys.size
    }

    /**
     * Rolling-horizon synchronisation: the web layer sends the complete desired alarm set.
     * Alarms not present are cancelled, present ones are upserted. Returns per-alarm results.
     */
    fun sync(context: Context, desired: JSONArray, managedKinds: Set<String>, markSync: Boolean = true): JSONObject {
        val desiredKeys = HashSet<String>()
        val results = JSONArray()
        var failures = 0
        for (i in 0 until desired.length()) {
            val a = desired.getJSONObject(i)
            val key = a.getString("alarmKey")
            desiredKeys.add(key)
            try {
                val r = schedule(context, key, a.getJSONObject("payload"))
                results.put(JSONObject().put("alarmKey", key).put("ok", true).put("exact", r.exact).put("triggerAt", r.triggerAt))
            } catch (e: Exception) {
                failures++
                results.put(JSONObject().put("alarmKey", key).put("ok", false).put("error", e.message ?: "error"))
            }
        }
        // Cancel stale alarms (only for kinds the caller manages; snoozes are preserved).
        val stale = mutableListOf<String>()
        // Only pending alarms are cancelled: delivered/acknowledged rows own notifications the user may still see.
        DayflowDatabase.get(context).readableDatabase.rawQuery("SELECT alarm_key, kind FROM alarms WHERE state IN ('scheduled','escalating','snoozed')", null).use { c ->
            while (c.moveToNext()) {
                val key = c.getString(0); val kind = c.getString(1)
                if (kind in managedKinds && key !in desiredKeys) stale.add(key)
            }
        }
        stale.forEach { cancel(context, it) }
        if (markSync) DayflowDatabase.get(context).setKv("last_sync_at", System.currentTimeMillis().toString())
        return JSONObject().put("results", results).put("cancelled", stale.size).put("failures", failures)
    }

    /**
     * Re-registers all future alarms with AlarmManager. Used after reboot, app update,
     * time change and time-zone change. Wall-clock alarms are recomputed from local fields.
     */
    fun restoreAll(context: Context, reason: String): Int {
        val db = DayflowDatabase.get(context)
        val rows = mutableListOf<Triple<String, JSONObject, Int>>()
        db.readableDatabase.rawQuery(
            "SELECT alarm_key, payload, repeat_count, local_date, local_minute, trigger_at FROM alarms WHERE state IN ('scheduled','escalating','snoozed') AND kind NOT IN ('useralarm','prayer','maintenance')",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val p = JSONObject(c.getString(1))
                if (!c.isNull(3) && !c.isNull(4) && !p.optBoolean("absolute", false)) {
                    p.remove("triggerAt") // recompute in the current zone
                } else {
                    p.put("triggerAt", c.getLong(5))
                }
                rows.add(Triple(c.getString(0), p, c.getInt(2)))
            }
        }
        var restored = 0
        val now = System.currentTimeMillis()
        for ((key, payload, repeat) in rows) {
            try {
                val trigger = if (payload.has("triggerAt")) payload.getLong("triggerAt")
                    else localToEpoch(payload.getString("localDate"), payload.getInt("localMinute"))
                if (trigger < now - 60_000) {
                    // Missed while the device was off: mark it so the UI can report honestly.
                    db.writableDatabase.execSQL("UPDATE alarms SET state = 'missed', updated_at = ? WHERE alarm_key = ?", arrayOf<Any>(now, key))
                    continue
                }
                schedule(context, key, payload, repeat)
                restored++
            } catch (_: Exception) { }
        }
        db.setKv("last_restore_at", now.toString())
        db.setKv("last_restore_reason", reason)
        db.setKv("last_restore_count", restored.toString())
        return restored
    }

    fun markState(context: Context, alarmKey: String, state: String) {
        DayflowDatabase.get(context).writableDatabase.execSQL(
            "UPDATE alarms SET state = ?, updated_at = ? WHERE alarm_key = ?",
            arrayOf<Any>(state, System.currentTimeMillis(), alarmKey)
        )
    }

    fun loadAlarm(context: Context, alarmKey: String): JSONObject? {
        DayflowDatabase.get(context).readableDatabase.rawQuery(
            "SELECT payload, request_code, repeat_count, state, trigger_at, block_id FROM alarms WHERE alarm_key = ?",
            arrayOf(alarmKey)
        ).use { c ->
            if (!c.moveToFirst()) return null
            return JSONObject(c.getString(0)).apply {
                put("_requestCode", c.getInt(1)); put("_repeatCount", c.getInt(2)); put("_state", c.getString(3))
                put("_triggerAt", c.getLong(4)); put("_alarmKey", alarmKey)
            }
        }
    }

    fun status(context: Context): JSONObject {
        val db = DayflowDatabase.get(context)
        val now = System.currentTimeMillis()
        var pending = 0
        var next: JSONObject? = null
        val upcoming = JSONArray()
        db.readableDatabase.rawQuery(
            "SELECT alarm_key, kind, trigger_at, payload, exact, state FROM alarms WHERE state IN ('scheduled','escalating','snoozed') AND trigger_at >= ? ORDER BY trigger_at ASC",
            arrayOf(now.toString())
        ).use { c ->
            while (c.moveToNext()) {
                pending++
                val p = JSONObject(c.getString(3))
                val o = JSONObject().put("alarmKey", c.getString(0)).put("kind", c.getString(1))
                    .put("triggerAt", c.getLong(2)).put("title", p.optString("title"))
                    .put("exact", c.getInt(4) == 1).put("state", c.getString(5)).put("blockId", p.optString("blockId"))
                if (next == null) next = o
                if (upcoming.length() < 200) upcoming.put(o)
            }
        }
        var missed = 0; var delivered = 0
        db.readableDatabase.rawQuery("SELECT state, COUNT(*) FROM alarms GROUP BY state", null).use { c ->
            while (c.moveToNext()) when (c.getString(0)) {
                "missed" -> missed = c.getInt(1)
                "delivered", "acknowledged" -> delivered += c.getInt(1)
            }
        }
        return JSONObject().apply {
            put("pendingCount", pending)
            put("next", next ?: JSONObject.NULL)
            put("upcoming", upcoming)
            put("missedCount", missed)
            put("deliveredCount", delivered)
            put("lastScheduleAt", db.getKv("last_schedule_at")?.toLongOrNull() ?: JSONObject.NULL)
            put("lastSyncAt", db.getKv("last_sync_at")?.toLongOrNull() ?: JSONObject.NULL)
            put("lastRestoreAt", db.getKv("last_restore_at")?.toLongOrNull() ?: JSONObject.NULL)
            put("lastRestoreReason", db.getKv("last_restore_reason") ?: JSONObject.NULL)
            put("lastRestoreCount", db.getKv("last_restore_count")?.toIntOrNull() ?: 0)
            put("exactAllowed", canScheduleExact(context))
            put("recentActions", db.recentActions(30))
        }
    }

    /** Removes delivered/acknowledged alarm rows older than 14 days. */
    fun prune(context: Context) {
        val cutoff = System.currentTimeMillis() - 14L * 24 * 3600 * 1000
        DayflowDatabase.get(context).writableDatabase.execSQL(
            "DELETE FROM alarms WHERE state IN ('delivered','acknowledged','missed') AND trigger_at < ?",
            arrayOf<Any>(cutoff)
        )
    }
}
