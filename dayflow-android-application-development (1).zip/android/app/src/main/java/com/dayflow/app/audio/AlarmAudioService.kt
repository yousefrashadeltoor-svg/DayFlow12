package com.dayflow.app.audio

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.dayflow.app.R
import com.dayflow.app.alarm.AlarmRingActivity
import com.dayflow.app.alarm.LocaleHelper
import com.dayflow.app.alarm.NotificationHelper
import com.dayflow.app.alarm.UserAlarms
import com.dayflow.app.data.DayflowDatabase
import org.json.JSONObject
import java.util.Locale

/**
 * Foreground service (type mediaPlayback) that plays alarm audio. Fallback order:
 *   1. Custom sound (system ringtone/alarm tone URI or an imported file, optionally trimmed [startMs, endMs])
 *   2. Android Text-to-Speech announcing the title (Arabic / English engines)
 *   3. Default alarm tone selected on the device
 * Activity reminders play a bounded number of repeats (hard cap 90 s). User alarm clocks ring until the user stops them
 * or `ringMin` elapses, with vibration, gradual volume and full-screen UI.
 */
class AlarmAudioService : Service(), AudioManager.OnAudioFocusChangeListener {

    companion object {
        const val ACTION_PLAY_ALARM = "com.dayflow.app.audio.PLAY_ALARM"
        const val ACTION_STOP = "com.dayflow.app.audio.STOP"
        const val FOREGROUND_ID = 9_100_001
        const val RING_ID = 9_100_002
        private const val HARD_CAP_MS = 90_000L
        @Volatile var lastFallbackUsed: String? = null
        @Volatile var ringingKey: String? = null
    }

    private var player: SegmentPlayer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var focusRequest: AudioFocusRequest? = null
    private var remainingRepeats = 0
    private var userAlarm = false
    private var vibrator: Vibrator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopEverything(); return START_NOT_STICKY }
            ACTION_PLAY_ALARM -> {
                val alarm = try { JSONObject(intent.getStringExtra("alarm") ?: "{}") } catch (_: Exception) { JSONObject() }
                userAlarm = alarm.optString("kind") == "useralarm"
                startAsForeground(alarm)
                ringingKey = alarm.optString("_alarmKey").ifEmpty { null }
                play(alarm)
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(alarm: JSONObject) {
        NotificationHelper.createChannels(this)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        if (userAlarm) {
            ServiceCompat.startForeground(this, RING_ID, NotificationHelper.buildRingNotification(this, alarm), type)
            return
        }
        val ctx = LocaleHelper.localized(this)
        val stopIntent = android.app.PendingIntent.getService(
            this, 77, Intent(this, AlarmAudioService::class.java).setAction(ACTION_STOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_PLAYBACK)
            .setSmallIcon(R.drawable.ic_stat_dayflow)
            .setContentTitle(alarm.optString("title", ctx.getString(R.string.app_name)))
            .setContentText(ctx.getString(R.string.audio_playing))
            .addAction(0, ctx.getString(R.string.action_stop_sound), stopIntent)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, FOREGROUND_ID, n, type)
    }

    private fun play(alarm: JSONObject) {
        stopPlayers()
        val loops = if (userAlarm) -1 else alarm.optInt("audioRepeat", 2).coerceIn(1, 10)
        remainingRepeats = if (userAlarm) 1000 else loops
        val volume = alarm.optDouble("volume", 1.0).toFloat().coerceIn(0.05f, 1f)
        val gradual = alarm.optBoolean("gradual", true)
        if (userAlarm) handler.postDelayed({ onRingTimeout() }, alarm.optInt("ringMin", 5).coerceIn(1, 30) * 60_000L)
        else handler.postDelayed({ stopEverything() }, HARD_CAP_MS)
        requestFocus()
        if (alarm.optBoolean("vibrate", true)) vibrate(userAlarm)

        val mode = alarm.optString("soundMode", "tts")
        val uriStr = alarm.optString("soundUri")
        val text = alarm.optString("ttsText").ifEmpty { alarm.optString("title") }
        val lang = alarm.optString("ttsLang").ifEmpty { LocaleHelper.language(this) }

        fun toneFallback() = playTone(loops, volume, gradual)
        fun startSound() {
            when {
                mode == "none" -> { if (!userAlarm) stopEverything() }
                (mode == "custom" || mode == "tone") && uriStr.isNotEmpty() || mode == "tone" -> {
                    val uri = AudioUtil.resolve(this, if (uriStr.isNotEmpty()) uriStr else "default:alarm")
                    val p = SegmentPlayer(applicationContext, AudioAttributes.USAGE_ALARM)
                    p.onFinished = { handler.post { stopEverything() } }
                    player = p
                    val started = uri != null && p.play(uri, alarm.optInt("startMs", 0), alarm.optInt("endMs", 0), loops, volume, gradual)
                    if (started) {
                        lastFallbackUsed = if (mode == "tone") "alarm_tone" else "custom"
                    } else if (text.isNotEmpty()) {
                        speak(text, lang, repeat = true) { ok -> if (!ok) toneFallback() }
                    } else {
                        toneFallback()
                    }
                }
                mode == "tts" && text.isNotEmpty() -> speak(text, lang, repeat = true) { ok -> if (!ok) toneFallback() }
                else -> toneFallback()
            }
        }
        if (userAlarm && alarm.optBoolean("speakLabel") && text.isNotEmpty() && mode != "tts") speak(text, lang, repeat = false) { startSound() } else startSound()
    }

    private fun playTone(loops: Int, volume: Float, gradual: Boolean) {
        handler.post {
            player?.stop()
            val uri = AudioUtil.resolve(this, "default:alarm")
            val p = SegmentPlayer(applicationContext, AudioAttributes.USAGE_ALARM)
            p.onFinished = { handler.post { stopEverything() } }
            player = p
            lastFallbackUsed = "alarm_tone"
            if (uri == null || !p.play(uri, 0, 0, loops, volume, gradual)) {
                lastFallbackUsed = "system_notification"
                if (!userAlarm) stopEverything()
            }
            try { DayflowDatabase.get(this).setKv("last_audio_fallback", lastFallbackUsed) } catch (_: Exception) { }
        }
    }

    /** Speaks text; repeats with a pause until stopped (user alarm) or until remainingRepeats is used up. `done(false)` reports an unusable engine/language. */
    private fun speak(text: String, lang: String, repeat: Boolean, done: (Boolean) -> Unit) {
        tts = TextToSpeech(this) { status ->
            val engine = tts
            if (status != TextToSpeech.SUCCESS || engine == null) { handler.post { done(false) }; return@TextToSpeech }
            val res = engine.setLanguage(Locale.forLanguageTag(lang))
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) { handler.post { done(false) }; return@TextToSpeech }
            engine.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { lastFallbackUsed = "tts" }
                override fun onDone(utteranceId: String?) {
                    if (!repeat) { handler.post { done(true) }; return }
                    remainingRepeats--
                    if (remainingRepeats > 0) handler.postDelayed({ try { engine.speak(text, TextToSpeech.QUEUE_ADD, null, "dayflow") } catch (_: Exception) { } }, 1500)
                    else handler.post { stopEverything() }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { handler.post { done(false) } }
            })
            if (engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dayflow") != TextToSpeech.SUCCESS) handler.post { done(false) }
        }
    }

    private fun vibrate(loop: Boolean) {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            else @Suppress("DEPRECATION") (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            vibrator = v
            v.vibrate(if (loop) VibrationEffect.createWaveform(longArrayOf(0, 700, 600), 0) else VibrationEffect.createWaveform(longArrayOf(0, 400, 250, 400), -1))
        } catch (_: Exception) { }
    }

    private fun requestFocus() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            .setOnAudioFocusChangeListener(this).build()
        focusRequest = req
        am.requestAudioFocus(req)
    }

    override fun onAudioFocusChange(focusChange: Int) {
        // A phone call took focus: user alarms keep ringing (they are the point), reminders stop.
        if (!userAlarm && (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT)) stopEverything()
    }

    private fun onRingTimeout() {
        val key = ringingKey
        if (key != null) UserAlarms.markMissed(this, key)
        stopEverything()
    }

    private fun stopPlayers() {
        player?.stop(); player = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        try { vibrator?.cancel() } catch (_: Exception) { }
    }

    private fun stopEverything() {
        handler.removeCallbacksAndMessages(null)
        stopPlayers()
        focusRequest?.let { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(it) }
        if (userAlarm) sendBroadcast(Intent(AlarmRingActivity.ACTION_DISMISSED).setPackage(packageName))
        ringingKey = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopPlayers()
        super.onDestroy()
    }
}
