package com.dayflow.app

import android.content.Intent
import android.os.Bundle
import com.dayflow.app.alarm.ActivityActions
import com.dayflow.app.alarm.AlarmScheduler
import com.dayflow.app.alarm.NotificationHelper
import com.dayflow.app.plugin.DayflowNativePlugin
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Custom plugins must be registered before the bridge is created.
        registerPlugin(DayflowNativePlugin::class.java)
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannels(this)
        AlarmScheduler.prune(this)
        handleLaunch(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleLaunch(intent)
    }

    /** Opening the app from a notification acknowledges it (stops escalation) and routes to the right screen. */
    private fun handleLaunch(intent: Intent?) {
        val key = intent?.getStringExtra("alarmKey")
        val blockId = intent?.getStringExtra("openBlockId")
        val screen = intent?.getStringExtra("openScreen")
        if (!key.isNullOrEmpty()) Thread { try { ActivityActions.apply(this, "DISMISS", key, blockId, "app") } catch (_: Exception) { } }.start()
        if (!screen.isNullOrEmpty()) DayflowNativePlugin.emitOpenScreen(screen)
        if (!blockId.isNullOrEmpty()) DayflowNativePlugin.emitOpenBlock(blockId)
    }
}
