package com.dayflow.app.alarm

import android.content.Context
import com.dayflow.app.R
import com.dayflow.app.data.DayflowDatabase
import com.dayflow.app.widget.WidgetUpdater
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.tan

/**
 * Native prayer-time engine (same astronomical formulas as src/services/prayer.ts, default: Egyptian General Authority of Survey).
 * Owns the prayer alarms for the next 7 days and re-creates them daily (maintenance alarm), after reboot, time/zone change and
 * settings change — so prayer alerts keep working even if the app is never opened. Also drives the persistent "next prayer"
 * notification (live chronometer countdown) and the prayer widget.
 */
object PrayerEngine {
    val KEYS = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")
    const val ONGOING_ID = 9_200_001

    data class Cfg(
        val enabled: Boolean, val lat: Double, val lng: Double, val method: String, val hanafi: Boolean, val adj: Map<String, Int>,
        val leadMin: Int, val ongoing: Boolean, val reminder: Boolean, val city: String, val sound: JSONObject?, val volume: Double, val vibrate: Boolean,
    )
    data class Next(val key: String, val at: Long, val prevKey: String, val prevAt: Long) {
        fun progress(now: Long): Int = (((now - prevAt).toDouble() / (at - prevAt).toDouble()) * 100).toInt().coerceIn(0, 100)
    }

    fun cfg(context: Context): Cfg? {
        val raw = DayflowDatabase.get(context).getKv("prayer_cfg") ?: return null
        return try {
            val o = JSONObject(raw)
            val adjO = o.optJSONObject("adjustments") ?: JSONObject()
            Cfg(
                o.optBoolean("enabled", false), o.optDouble("lat", 30.0444), o.optDouble("lng", 31.2357), o.optString("method", "egypt"), o.optString("asr", "standard") == "hanafi",
                KEYS.associateWith { adjO.optInt(it, 0) }, o.optInt("leadMin", 10), o.optBoolean("ongoing", true), o.optBoolean("reminder", true),
                o.optString("city", ""), o.optJSONObject("sound"), o.optDouble("volume", 0.9), o.optBoolean("vibrate", true),
            )
        } catch (_: Exception) { null }
    }

    fun configure(context: Context, json: JSONObject): Int {
        DayflowDatabase.get(context).setKv("prayer_cfg", json.toString())
        return schedule(context)
    }

    // ------------------------------------------------------------------ astronomy
    private fun d2r(d: Double) = d * PI / 180.0
    private fun r2d(r: Double) = r * 180.0 / PI
    private fun sind(d: Double) = sin(d2r(d))
    private fun cosd(d: Double) = cos(d2r(d))
    private fun tand(d: Double) = tan(d2r(d))
    private fun fix(a: Double, b: Double): Double { val x = a - b * floor(a / b); return if (x < 0) x + b else x }
    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0; var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }
    private fun sun(jd: Double): Pair<Double, Double> { // (declination, equation of time)
        val dd = jd - 2451545.0
        val g = fix(357.529 + 0.98560028 * dd, 360.0)
        val q = fix(280.459 + 0.98564736 * dd, 360.0)
        val l = fix(q + 1.915 * sind(g) + 0.02 * sind(2 * g), 360.0)
        val e = 23.439 - 0.00000036 * dd
        val ra = r2d(atan2(cosd(e) * sind(l), cosd(l))) / 15.0
        return r2d(asin(sind(e) * sind(l))) to (q / 15.0 - fix(ra, 24.0))
    }
    private data class MethodP(val fajr: Double, val isha: Double, val ishaMin: Double, val maghrib: Double?)
    private fun method(m: String) = when (m) {
        "mwl" -> MethodP(18.0, 17.0, 0.0, null)
        "isna" -> MethodP(15.0, 15.0, 0.0, null)
        "makkah" -> MethodP(18.5, 0.0, 90.0, null)
        "karachi" -> MethodP(18.0, 18.0, 0.0, null)
        "tehran" -> MethodP(17.7, 14.0, 0.0, 4.5)
        "gulf" -> MethodP(19.5, 0.0, 90.0, null)
        "kuwait" -> MethodP(18.0, 17.5, 0.0, null)
        "qatar" -> MethodP(18.0, 0.0, 90.0, null)
        else -> MethodP(19.5, 17.5, 0.0, null) // egypt
    }

    /** Minutes from local midnight: fajr, sunrise, dhuhr, asr, maghrib, isha — or null if the sun never reaches the angle. */
    fun times(date: LocalDate, c: Cfg): Map<String, Double>? {
        val zone = ZoneId.systemDefault()
        val tz = zone.rules.getOffset(date.atTime(12, 0).atZone(zone).toInstant()).totalSeconds / 3600.0
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - c.lng / (15.0 * 24.0)
        val mp = method(c.method)
        fun midDay(t: Double) = fix(12 - sun(jd + t).second, 24.0)
        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sun(jd + t).first
            val tt = r2d(acos((-sind(angle) - sind(decl) * sind(c.lat)) / (cosd(decl) * cosd(c.lat)))) / 15.0
            return midDay(t) + if (ccw) -tt else tt
        }
        fun asrTime(factor: Double, t: Double): Double {
            val decl = sun(jd + t).first
            val angle = -r2d(atan(1.0 / (factor + tand(abs(c.lat - decl)))))
            return angleTime(angle, t, false)
        }
        var fajr = 5.0; var sunrise = 6.0; var dhuhr = 12.0; var asr = 13.0; var sunset = 18.0; var maghrib = 18.0; var isha = 18.0
        repeat(2) {
            val pf = fajr / 24; val pr = sunrise / 24; val pd = dhuhr / 24; val pa = asr / 24; val ps = sunset / 24; val pm = maghrib / 24; val pi = isha / 24
            fajr = angleTime(mp.fajr, pf, true)
            sunrise = angleTime(0.833, pr, true)
            dhuhr = midDay(pd)
            asr = asrTime(if (c.hanafi) 2.0 else 1.0, pa)
            sunset = angleTime(0.833, ps, false)
            maghrib = angleTime(mp.maghrib ?: 0.833, pm, false)
            isha = if (mp.ishaMin > 0) maghrib + mp.ishaMin / 60.0 else angleTime(mp.isha, pi, false)
        }
        fun toMin(h: Double, adj: Int = 0) = fix((h + tz - c.lng / 15.0) * 60 + adj, 1440.0)
        val out = mapOf(
            "fajr" to toMin(fajr, c.adj["fajr"] ?: 0), "sunrise" to toMin(sunrise), "dhuhr" to toMin(dhuhr, (c.adj["dhuhr"] ?: 0) + 1),
            "asr" to toMin(asr, c.adj["asr"] ?: 0), "maghrib" to toMin(maghrib, c.adj["maghrib"] ?: 0), "isha" to toMin(isha, c.adj["isha"] ?: 0),
        )
        return if (out.values.any { it.isNaN() || it.isInfinite() }) null else out
    }

    fun epoch(date: LocalDate, minute: Double): Long =
        date.atStartOfDay(ZoneId.systemDefault()).plusMinutes(minute.roundToLong()).toInstant().toEpochMilli()

    private fun sequence(c: Cfg, around: LocalDate): List<Triple<String, LocalDate, Long>> {
        val out = mutableListOf<Triple<String, LocalDate, Long>>()
        for (off in -1..1) {
            val d = around.plusDays(off.toLong())
            val t = times(d, c) ?: continue
            for (k in KEYS) out.add(Triple(k, d, epoch(d, t.getValue(k))))
        }
        return out
    }

    fun next(context: Context, now: Long = System.currentTimeMillis()): Next? {
        val c = cfg(context) ?: return null
        val seq = sequence(c, LocalDate.now())
        val i = seq.indexOfFirst { it.third > now }
        if (i <= 0) return null
        return Next(seq[i].first, seq[i].third, seq[i - 1].first, seq[i - 1].third)
    }

    fun name(context: Context, key: String): String {
        val ctx = LocaleHelper.localized(context)
        return ctx.getString(when (key) { "fajr" -> R.string.pr_fajr; "dhuhr" -> R.string.pr_dhuhr; "asr" -> R.string.pr_asr; "maghrib" -> R.string.pr_maghrib; else -> R.string.pr_isha })
    }

    fun doneToday(context: Context): Set<String> =
        DayflowDatabase.get(context).getByDate("prayerLogs", LocalDate.now().toString()).map { it.optString("prayer") }.toSet()

    fun weekCount(context: Context): Int {
        val db = DayflowDatabase.get(context); var n = 0
        for (i in 0..6) n += db.getByDate("prayerLogs", LocalDate.now().minusDays(i.toLong()).toString()).size
        return n
    }

    // ------------------------------------------------------------------ scheduling
    private fun soundFields(sound: JSONObject?, p: JSONObject) {
        val kind = sound?.optString("kind") ?: "default"
        when (kind) {
            "silent" -> p.put("silent", true)
            "tts" -> p.put("soundMode", "tts")
            "file", "ringtone", "alarm", "notification" -> {
                val uri = sound?.optString("uri").orEmpty()
                if (uri.isNotEmpty()) { p.put("soundMode", "custom"); p.put("soundUri", uri); p.put("startMs", sound?.optInt("startMs", 0) ?: 0); p.put("endMs", sound?.optInt("endMs", 0) ?: 0) }
                else p.put("soundMode", "system")
            }
            else -> p.put("soundMode", "system")
        }
    }

    fun schedule(context: Context): Int {
        val c = cfg(context)
        val desired = JSONArray()
        if (c != null && c.enabled) {
            val ctx = LocaleHelper.localized(context)
            val now = System.currentTimeMillis()
            for (off in 0..6) {
                val d = LocalDate.now().plusDays(off.toLong())
                val t = times(d, c) ?: continue
                val tomorrow = times(d.plusDays(1), c)
                KEYS.forEachIndexed { idx, k ->
                    val at = epoch(d, t.getValue(k))
                    val nextKey = if (idx < 4) KEYS[idx + 1] else "fajr"
                    val nextAt = if (idx < 4) epoch(d, t.getValue(nextKey)) else tomorrow?.let { epoch(d.plusDays(1), it.getValue("fajr")) }
                    val timeLabel = WidgetUpdater.fmtEpoch(context, at)
                    val nm = name(context, k)
                    val nextLabel = if (nextAt != null) ctx.getString(R.string.prayer_next_fmt, name(context, nextKey), WidgetUpdater.fmtEpoch(context, nextAt)) else ""
                    if (c.reminder && at > now + 5000) {
                        val p = JSONObject().put("kind", "prayer").put("blockId", "$d:$k").put("title", ctx.getString(R.string.prayer_title_fmt, nm))
                            .put("body", ctx.getString(R.string.prayer_body_fmt, timeLabel, c.city)).put("nextLabel", nextLabel).put("category", "prayer").put("colorHex", "#22A45D")
                            .put("triggerAt", at).put("absolute", true).put("vibrate", c.vibrate).put("volume", c.volume).put("gradual", false).put("audioRepeat", 1)
                            .put("ttsLang", LocaleHelper.language(context)).put("ttsText", ctx.getString(R.string.prayer_title_fmt, nm))
                            .put("actions", JSONArray().put("PRAYED").put("SNOOZE_10").put("DISMISS"))
                        soundFields(c.sound, p)
                        desired.put(JSONObject().put("alarmKey", "prayer:$d:$k").put("payload", p))
                    }
                    val lead = at - c.leadMin * 60_000L
                    if (c.leadMin > 0 && lead > now + 5000) {
                        val p = JSONObject().put("kind", "prayer").put("blockId", "$d:$k").put("title", ctx.getString(R.string.prayer_pre_title_fmt, c.leadMin, nm))
                            .put("body", ctx.getString(R.string.prayer_pre_body_fmt, timeLabel)).put("category", "prayer").put("colorHex", "#22A45D")
                            .put("triggerAt", lead).put("absolute", true).put("soundMode", "system").put("vibrate", false)
                            .put("actions", JSONArray().put("DISMISS"))
                        desired.put(JSONObject().put("alarmKey", "prayer:$d:$k:pre").put("payload", p))
                    }
                }
            }
        }
        AlarmScheduler.sync(context, desired, setOf("prayer"), markSync = false)
        refreshOngoing(context)
        WidgetUpdater.refreshAll(context)
        return desired.length()
    }

    // ------------------------------------------------------------------ ongoing notification + actions
    fun refreshOngoing(context: Context) {
        val c = cfg(context)
        if (c == null || !c.enabled || !c.ongoing || !NotificationHelper.hasPermission(context)) { NotificationHelper.cancel(context, ONGOING_ID); return }
        val n = next(context) ?: return
        NotificationHelper.showPrayerOngoing(context, name(context, n.key), WidgetUpdater.fmtEpoch(context, n.at), n.at, n.progress(System.currentTimeMillis()), doneToday(context).size, c.city)
    }

    private fun windowEnd(c: Cfg, date: LocalDate, key: String): Long {
        val t = times(date, c) ?: return Long.MAX_VALUE
        val idx = KEYS.indexOf(key)
        return when {
            key == "fajr" -> epoch(date, t.getValue("sunrise"))
            idx in 0..3 -> epoch(date, t.getValue(KEYS[idx + 1]))
            else -> times(date.plusDays(1), c)?.let { epoch(date.plusDays(1), it.getValue("fajr")) } ?: Long.MAX_VALUE
        }
    }

    fun markPrayed(context: Context, date: String, key: String) {
        val c = cfg(context)
        val now = System.currentTimeMillis()
        val onTime = c == null || now <= windowEnd(c, LocalDate.parse(date), key)
        val rec = JSONObject().put("id", "$date:$key").put("date", date).put("prayer", key).put("prayedAt", now).put("onTime", onTime).put("createdAt", now).put("updatedAt", now)
        DayflowDatabase.get(context).put("prayerLogs", rec)
        refreshOngoing(context)
        WidgetUpdater.refreshAll(context)
    }

    /** Marks the most recent prayer whose time has passed and is not logged yet today. Returns its key or null. */
    fun markLatest(context: Context): String? {
        val c = cfg(context) ?: return null
        val today = LocalDate.now()
        val t = times(today, c) ?: return null
        val now = System.currentTimeMillis()
        val done = doneToday(context)
        val key = KEYS.filter { epoch(today, t.getValue(it)) <= now && it !in done }.lastOrNull() ?: return null
        markPrayed(context, today.toString(), key)
        return key
    }
}
