package com.dayflow.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.dayflow.app.audio.AlarmAudioService
import com.dayflow.app.data.DayflowDatabase
import com.dayflow.app.plugin.DayflowNativePlugin
import com.dayflow.app.widget.WidgetUpdater
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** Daily maintenance: renews prayer alarms, user alarm clocks and widgets, so everything keeps working without opening the app. */
object Maintenance {
    const val KEY = "maint:daily"
    fun ensure(context: Context) {
        val at = AlarmScheduler.localToEpoch(LocalDate.now().plusDays(1).toString(), 5)
        val p = JSONObject().put("kind", "maintenance").put("title", "maintenance").put("body", "").put("triggerAt", at).put("absolute", true).put("silent", true)
        try { AlarmScheduler.schedule(context, KEY, p) } catch (_: Exception) { }
    }
    fun run(context: Context) {
        NotificationHelper.createChannels(context)
        PrayerEngine.schedule(context)
        UserAlarms.rescheduleAll(context)
        AlarmScheduler.prune(context)
        WidgetUpdater.refreshAll(context)
        ensure(context)
    }
}

/**
 * Single source of truth for applying an action (from a notification, widget or the web layer) to a stored record.
 * Idempotent: repeated taps and stale notifications are detected and logged.
 */
object ActivityActions {
    private val TERMINAL = setOf("completed", "skipped", "cancelled", "partial")

    data class Outcome(val result: String, val record: JSONObject?)

    fun apply(context: Context, action: String, alarmKey: String?, blockId: String?, source: String): Outcome {
        val db = DayflowDatabase.get(context)
        val alarm = alarmKey?.let { AlarmScheduler.loadAlarm(context, it) }
        val kind = alarm?.optString("kind") ?: "block"
        val ref = alarm?.optString("refKind")?.ifEmpty { null } ?: kind

        if (action == "ALARM_STOP") { if (alarmKey != null) UserAlarms.stop(context, alarmKey); return Outcome("ok", null) }
        if (action == "ALARM_SNOOZE") { val ok = alarmKey != null && UserAlarms.snooze(context, alarmKey); return Outcome(if (ok) "ok" else "limit", null) }

        if (alarmKey != null && action != "DISMISS" && db.isDuplicateAction(alarmKey, action, 4000)) {
            db.logAction(alarmKey, blockId, action, "duplicate")
            return Outcome("duplicate", null)
        }
        // Every action acknowledges the alarm: escalation stops and audio is released (a ringing alarm clock is never silenced by an unrelated action).
        if (alarmKey != null) AlarmScheduler.markState(context, alarmKey, "acknowledged")
        stopAudio(context, alarmKey)
        alarm?.optInt("_requestCode")?.let { if (it > 0) NotificationHelper.cancel(context, it) }

        if (action == "DISMISS") { db.logAction(alarmKey, blockId, action, "ok"); return Outcome("ok", null) }

        if (action == "PRAYED") {
            val ref0 = alarm?.optString("blockId").orEmpty().ifEmpty { blockId.orEmpty() }
            if (ref0.contains(":")) PrayerEngine.markPrayed(context, ref0.substringBefore(":").let { d -> if (d.length == 10) d else LocalDate.now().toString() }, ref0.substringAfter(":"))
            else PrayerEngine.markLatest(context)
            db.logAction(alarmKey, ref0, action, "ok")
            afterChange(context)
            return Outcome("ok", null)
        }

        if (action.startsWith("SNOOZE_")) {
            val minutes = action.removePrefix("SNOOZE_").toIntOrNull() ?: 10
            if (alarm == null) { db.logAction(alarmKey, blockId, action, "missing_alarm"); return Outcome("missing_alarm", null) }
            val payload = JSONObject(alarm.toString())
            listOf("_requestCode", "_repeatCount", "_state", "_triggerAt", "_alarmKey").forEach { payload.remove(it) }
            payload.put("triggerAt", System.currentTimeMillis() + minutes * 60_000L)
            payload.put("absolute", true)
            payload.put("maxRepeats", 0)
            payload.put("kind", "snooze")      // kind "snooze" is never cancelled by the periodic web sync
            payload.put("refKind", ref)
            val baseKey = alarmKey!!.substringBefore("#snooze")
            try {
                AlarmScheduler.schedule(context, "$baseKey#snooze", payload)
                AlarmScheduler.markState(context, "$baseKey#snooze", "snoozed")
            } catch (e: Exception) {
                db.logAction(alarmKey, blockId, action, "error:${e.message}")
                return Outcome("error", null)
            }
            if (blockId != null && (ref == "block" || ref == "task")) {
                val col = if (ref == "task") "tasks" else "activities"
                db.get(col, blockId)?.let { rec ->
                    rec.put("snoozeCount", rec.optInt("snoozeCount", 0) + 1)
                    appendEvent(rec, action, source)
                    rec.put("updatedAt", System.currentTimeMillis())
                    db.put(col, rec)
                }
            }
            db.logAction(alarmKey, blockId, action, "ok")
            afterChange(context)
            return Outcome("ok", null)
        }

        // Occasions, prayers, journal nudges and other plain reminders have no record to update.
        if (ref != "block" && ref != "task") { db.logAction(alarmKey, blockId, action, "ok"); return Outcome("ok", null) }

        if (blockId == null) { db.logAction(alarmKey, null, action, "missing_record"); return Outcome("missing_record", null) }
        val collection = if (ref == "task") "tasks" else "activities"
        val rec = db.get(collection, blockId)
        if (rec == null) { db.logAction(alarmKey, blockId, action, "missing_record"); return Outcome("missing_record", null) }

        val now = System.currentTimeMillis()
        if (collection == "tasks") {
            if (rec.optString("status") == "done") { db.logAction(alarmKey, blockId, action, "stale"); return Outcome("stale", rec) }
            when (action) {
                "DONE" -> { rec.put("status", "done"); rec.put("completedAt", now) }
                "START" -> rec.put("status", "in_progress")
                else -> { }
            }
        } else {
            val status = rec.optString("status", "planned")
            if (status in TERMINAL) { db.logAction(alarmKey, blockId, action, "stale"); return Outcome("stale", rec) }
            when (action) {
                "DONE" -> {
                    if (!rec.has("actualStart") || rec.isNull("actualStart")) rec.put("actualStart", plannedStartEpoch(rec))
                    rec.put("actualEnd", now); rec.put("status", "completed"); rec.put("completionPercent", 100)
                }
                "START" -> {
                    if (status == "active") { db.logAction(alarmKey, blockId, action, "stale"); return Outcome("stale", rec) }
                    rec.put("actualStart", now); rec.put("status", "active")
                }
                "PARTIAL" -> {
                    if (!rec.has("actualStart") || rec.isNull("actualStart")) rec.put("actualStart", plannedStartEpoch(rec))
                    rec.put("actualEnd", now); rec.put("status", "partial")
                }
                "SKIP" -> rec.put("status", "skipped")
                else -> { db.logAction(alarmKey, blockId, action, "unknown_action"); return Outcome("unknown_action", rec) }
            }
        }
        appendEvent(rec, action, source)
        rec.put("updatedAt", now)
        db.put(collection, rec)
        db.logAction(alarmKey, blockId, action, "ok")
        if (action == "DONE" || action == "SKIP" || action == "PARTIAL") AlarmScheduler.cancelForBlock(context, blockId) // remove remaining escalations / snoozes
        afterChange(context)
        return Outcome("ok", rec)
    }

    private fun plannedStartEpoch(rec: JSONObject): Long = try {
        AlarmScheduler.localToEpoch(rec.getString("date"), rec.getInt("startMin"))
    } catch (_: Exception) { System.currentTimeMillis() }

    private fun appendEvent(rec: JSONObject, action: String, source: String) {
        val events = rec.optJSONArray("events") ?: JSONArray().also { rec.put("events", it) }
        events.put(JSONObject().put("at", System.currentTimeMillis()).put("action", action).put("source", source))
    }

    fun stopAudio(context: Context, forKey: String? = null) {
        val ringing = AlarmAudioService.ringingKey
        if (ringing != null && ringing.startsWith("ua:") && ringing != forKey) return
        try { context.startService(Intent(context, AlarmAudioService::class.java).setAction(AlarmAudioService.ACTION_STOP)) } catch (_: Exception) { }
    }

    fun afterChange(context: Context) {
        WidgetUpdater.refreshAll(context)
        DayflowNativePlugin.emitDataChanged()
    }
}

/** Delivered by AlarmManager at the scheduled time. Works when the app process is not running. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.ACTION_FIRE) return
        val alarmKey = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_KEY) ?: return
        val pending = goAsync()
        try { handle(context, alarmKey) } finally { pending.finish() }
    }

    private fun handle(context: Context, alarmKey: String) {
        val db = DayflowDatabase.get(context)
        val alarm = AlarmScheduler.loadAlarm(context, alarmKey) ?: return
        val state = alarm.optString("_state")
        val kind = alarm.optString("kind")
        if (kind == "maintenance") { Maintenance.run(context); return }
        if (kind == "useralarm") { UserAlarms.onFire(context, alarmKey, alarm); WidgetUpdater.refreshAll(context); return }
        if (state == "acknowledged" || state == "cancelled") return

        val ref = alarm.optString("refKind").ifEmpty { kind }
        val blockId = alarm.optString("blockId").ifEmpty { null }
        if (blockId != null && (ref == "block" || ref == "task")) {
            val col = if (ref == "task") "tasks" else "activities"
            val rec = db.get(col, blockId)
            val st = rec?.optString("status")
            if (rec == null || st in setOf("completed", "skipped", "cancelled", "partial", "done") || rec.optBoolean("applied", true).not()) {
                AlarmScheduler.markState(context, alarmKey, "acknowledged")
                db.logAction(alarmKey, blockId, "FIRE", "suppressed_already_handled")
                return
            }
        }

        val silent = alarm.optBoolean("silent", false)
        val soundMode = alarm.optString("soundMode", "system")
        var ownAudio = false
        if (!silent && soundMode != "system" && soundMode != "none") {
            try {
                val svc = Intent(context, AlarmAudioService::class.java).apply { action = AlarmAudioService.ACTION_PLAY_ALARM; putExtra("alarm", alarm.toString()) }
                ContextCompat.startForegroundService(context, svc)
                ownAudio = true
            } catch (e: Exception) {
                db.logAction(alarmKey, blockId, "AUDIO", "fallback_system:${e.javaClass.simpleName}") // e.g. ForegroundServiceStartNotAllowedException
            }
        }
        val requestCode = alarm.optInt("_requestCode")
        val posted = NotificationHelper.showReminder(context, alarm, requestCode, ownAudio)
        if (!posted) {
            AlarmScheduler.markState(context, alarmKey, "blocked")
            db.logAction(alarmKey, blockId, "FIRE", "blocked_no_permission")
            if (ownAudio) ActivityActions.stopAudio(context, alarmKey)
            return
        }
        db.writableDatabase.execSQL("UPDATE alarms SET state = 'delivered', delivered_at = ?, updated_at = ? WHERE alarm_key = ?", arrayOf<Any>(System.currentTimeMillis(), System.currentTimeMillis(), alarmKey))
        db.logAction(alarmKey, blockId, "FIRE", "delivered")

        // Bounded escalation: never an unlimited loop.
        val repeat = alarm.optInt("_repeatCount", 0)
        val maxRepeats = alarm.optInt("maxRepeats", 0).coerceIn(0, 10)
        val interval = alarm.optInt("repeatIntervalMin", 0)
        if (!silent && interval > 0 && repeat < maxRepeats) {
            val payload = JSONObject(alarm.toString())
            listOf("_requestCode", "_repeatCount", "_state", "_triggerAt", "_alarmKey").forEach { payload.remove(it) }
            payload.put("triggerAt", System.currentTimeMillis() + interval * 60_000L).put("absolute", true)
            try { AlarmScheduler.schedule(context, alarmKey, payload, repeat + 1) } catch (_: Exception) { }
        }
        if (kind == "prayer") PrayerEngine.refreshOngoing(context)
        WidgetUpdater.refreshAll(context)
        DayflowNativePlugin.emitDataChanged()
    }
}

/** Handles notification action buttons without opening the application. */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.getStringExtra("action") ?: return
        if (action !in NotificationHelper.INTERNAL_ACTIONS) return
        val alarmKey = intent.getStringExtra("alarmKey")?.ifEmpty { null }
        val blockId = intent.getStringExtra("blockId")?.ifEmpty { null }
        val pending = goAsync()
        try {
            ActivityActions.apply(context, action, alarmKey, blockId, "notification")
            val nid = intent.getIntExtra("notificationId", -1)
            if (nid > 0 && action != "PRAYED") NotificationHelper.cancel(context, nid)
        } finally { pending.finish() }
    }
}

/** Re-registers alarms after reboot, app update, clock or time-zone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val reason = when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> "boot"
            Intent.ACTION_MY_PACKAGE_REPLACED -> "app_update"
            Intent.ACTION_TIME_CHANGED -> "time_changed"
            Intent.ACTION_TIMEZONE_CHANGED -> "timezone_changed"
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" -> "exact_permission_changed"
            else -> return
        }
        val pending = goAsync()
        try {
            NotificationHelper.createChannels(context)
            AlarmScheduler.restoreAll(context, reason)   // reminders, snoozes (user alarms / prayers are rebuilt below)
            UserAlarms.rescheduleAll(context)            // alarm clocks: recomputed in the (possibly new) time zone
            PrayerEngine.schedule(context)               // prayer alarms + ongoing notification
            Maintenance.ensure(context)
            AlarmScheduler.prune(context)
            WidgetUpdater.refreshAll(context)
            DayflowNativePlugin.emitDataChanged()
        } finally { pending.finish() }
    }
}
