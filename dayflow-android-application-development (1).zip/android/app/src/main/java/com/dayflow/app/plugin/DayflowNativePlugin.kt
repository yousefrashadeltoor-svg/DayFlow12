package com.dayflow.app.plugin

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.media.MediaMetadataRetriever
import android.media.RingtoneManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import androidx.activity.result.ActivityResult
import com.dayflow.app.alarm.ActivityActions
import com.dayflow.app.alarm.AlarmScheduler
import com.dayflow.app.alarm.Maintenance
import com.dayflow.app.alarm.NotificationHelper
import com.dayflow.app.alarm.PrayerEngine
import com.dayflow.app.alarm.UserAlarms
import com.dayflow.app.audio.AlarmAudioService
import com.dayflow.app.audio.PreviewAudio
import com.dayflow.app.data.DayflowDatabase
import com.dayflow.app.widget.CompactWidgetProvider
import com.dayflow.app.widget.LargeWidgetProvider
import com.dayflow.app.widget.MediumWidgetProvider
import com.dayflow.app.widget.WidgetUpdater
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.lang.ref.WeakReference
import java.time.ZoneId
import java.util.TimeZone
import java.util.UUID

/**
 * Bridge between the React UI and Android. Every method resolves only after the native
 * operation actually succeeded, and rejects with a stable error code otherwise.
 *
 * Error codes: INVALID_ARGUMENT, PERMISSION_DENIED, NOT_FOUND, IO_ERROR, SCHEDULE_FAILED,
 *              CANCELLED, UNSUPPORTED, DB_ERROR, TTS_*.
 */
@CapacitorPlugin(
    name = "DayflowNative",
    permissions = [Permission(alias = "notifications", strings = [Manifest.permission.POST_NOTIFICATIONS])]
)
class DayflowNativePlugin : Plugin() {

    companion object {
        private var ref: WeakReference<DayflowNativePlugin>? = null
        @Volatile var pendingLaunchBlockId: String? = null
        @Volatile var pendingLaunchScreen: String? = null
        private const val MAX_IMPORT_BYTES = 25L * 1024 * 1024
        private val MANAGED_KINDS = setOf("block", "task", "water", "sleep", "habit", "meal", "review", "reminder", "occasion")  // prayer + user alarms are owned by native code

        fun emitDataChanged() {
            ref?.get()?.notifyListeners("dataChanged", JSObject().put("at", System.currentTimeMillis()), true)
        }
        fun emitOpenScreen(screen: String) {
            val p = ref?.get()
            if (p == null) pendingLaunchScreen = screen
            else p.notifyListeners("openScreen", JSObject().put("screen", screen), true)
        }
        fun emitOpenBlock(blockId: String) {
            val p = ref?.get()
            if (p == null) pendingLaunchBlockId = blockId
            else p.notifyListeners("openBlock", JSObject().put("blockId", blockId), true)
        }
    }

    private val db get() = DayflowDatabase.get(context)

    override fun load() {
        ref = WeakReference(this)
        NotificationHelper.createChannels(context)
    }

    private fun obj(o: JSONObject): JSObject = JSObject.fromJSONObject(o)

    // ------------------------------------------------------------------ lifecycle / capabilities

    @PluginMethod
    fun initialize(call: PluginCall) {
        try {
            NotificationHelper.createChannels(context)
            db.writableDatabase // opens + migrates
            Maintenance.ensure(context)
            UserAlarms.rescheduleAll(context)
            PrayerEngine.schedule(context)
            call.resolve(capabilities())
        } catch (e: Exception) {
            call.reject("Database initialisation failed: ${e.message}", "DB_ERROR", e)
        }
    }

    @PluginMethod
    fun getPlatformCapabilities(call: PluginCall) = call.resolve(capabilities())

    private fun notificationPermissionString(): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return when (getPermissionState("notifications")) {
                PermissionState.GRANTED -> if (NotificationHelper.hasPermission(context)) "granted" else "disabled"
                PermissionState.DENIED -> "denied"
                else -> "prompt"
            }
        }
        return if (NotificationHelper.hasPermission(context)) "granted" else "disabled"
    }

    private fun capabilities(): JSObject {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return JSObject().apply {
            put("platform", "android")
            put("sdkInt", Build.VERSION.SDK_INT)
            put("release", Build.VERSION.RELEASE)
            put("manufacturer", Build.MANUFACTURER)
            put("model", Build.MODEL)
            put("notificationPermission", notificationPermissionString())
            put("exactAlarmRequiresPermission", Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            put("exactAlarmAllowed", AlarmScheduler.canScheduleExact(context))
            put("ignoringBatteryOptimizations", pm.isIgnoringBatteryOptimizations(context.packageName))
            put("powerSaveMode", pm.isPowerSaveMode)
            put("nativeDatabase", true)
            put("widgets", true)
            put("tts", true)
            put("customAudio", true)
            put("dbVersion", DayflowDatabase.DB_VERSION)
            put("fullScreenIntentAllowed", NotificationHelper.canUseFullScreenIntent(context))
            put("alarmClockApi", true)
            put("migrations", db.migrationHistory())
            put("lastAudioFallback", db.getKv("last_audio_fallback"))
        }
    }

    // ------------------------------------------------------------------ permissions

    @PluginMethod
    fun checkNotificationPermission(call: PluginCall) =
        call.resolve(JSObject().put("state", notificationPermissionString()))

    @PluginMethod
    fun requestNotificationPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && getPermissionState("notifications") != PermissionState.GRANTED) {
            requestPermissionForAlias("notifications", call, "notificationPermissionCallback")
        } else if (!NotificationHelper.hasPermission(context)) {
            openSettings(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
            call.resolve(JSObject().put("state", "disabled").put("openedSettings", true))
        } else call.resolve(JSObject().put("state", "granted"))
    }

    @PermissionCallback
    private fun notificationPermissionCallback(call: PluginCall) {
        call.resolve(JSObject().put("state", notificationPermissionString()))
    }

    @PluginMethod
    fun checkExactAlarmPermission(call: PluginCall) = call.resolve(
        JSObject().put("allowed", AlarmScheduler.canScheduleExact(context))
            .put("requiresPermission", Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
    )

    @PluginMethod
    fun requestExactAlarmPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !AlarmScheduler.canScheduleExact(context)) {
            openSettings(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))
            call.resolve(JSObject().put("allowed", false).put("openedSettings", true))
        } else call.resolve(JSObject().put("allowed", true))
    }

    @PluginMethod
    fun getBatteryOptimizationStatus(call: PluginCall) {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        call.resolve(JSObject()
            .put("ignoring", pm.isIgnoringBatteryOptimizations(context.packageName))
            .put("powerSaveMode", pm.isPowerSaveMode)
            .put("manufacturer", Build.MANUFACTURER))
    }

    @PluginMethod
    fun requestBatterySettings(call: PluginCall) {
        openSettings(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        call.resolve(JSObject().put("openedSettings", true))
    }

    @PluginMethod
    fun openNotificationSettings(call: PluginCall) {
        openSettings(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
        call.resolve(JSObject().put("openedSettings", true))
    }

    private fun openSettings(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { context.startActivity(intent) } catch (_: Exception) {
            context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    @PluginMethod
    fun getDeviceTimeZone(call: PluginCall) {
        val tz = TimeZone.getDefault()
        call.resolve(JSObject().put("timeZone", ZoneId.systemDefault().id)
            .put("offsetMinutes", tz.getOffset(System.currentTimeMillis()) / 60000))
    }

    // ------------------------------------------------------------------ alarms

    private fun scheduleFromCall(call: PluginCall, kind: String) {
        val key = call.getString("alarmKey")
        val payload = call.getObject("payload")
        if (key.isNullOrBlank() || payload == null) { call.reject("alarmKey and payload are required", "INVALID_ARGUMENT"); return }
        if (payload.optString("title").isBlank()) { call.reject("payload.title is required", "INVALID_ARGUMENT"); return }
        if (!payload.has("kind")) payload.put("kind", kind)
        try {
            val r = AlarmScheduler.schedule(context, key, payload)
            call.resolve(JSObject().put("alarmKey", r.alarmKey).put("requestCode", r.requestCode)
                .put("triggerAt", r.triggerAt).put("exact", r.exact)
                .put("notificationPermission", notificationPermissionString()))
        } catch (e: IllegalArgumentException) {
            call.reject(e.message ?: "invalid", "INVALID_ARGUMENT")
        } catch (e: Exception) {
            call.reject("Scheduling failed: ${e.message}", "SCHEDULE_FAILED", e)
        }
    }

    @PluginMethod fun scheduleBlockAlarm(call: PluginCall) = scheduleFromCall(call, "block")
    @PluginMethod fun scheduleReminder(call: PluginCall) = scheduleFromCall(call, "reminder")

    @PluginMethod
    fun cancelAlarm(call: PluginCall) {
        val key = call.getString("alarmKey") ?: return call.reject("alarmKey required", "INVALID_ARGUMENT")
        call.resolve(JSObject().put("cancelled", AlarmScheduler.cancel(context, key)))
    }

    @PluginMethod
    fun cancelBlockAlarms(call: PluginCall) {
        val id = call.getString("blockId") ?: return call.reject("blockId required", "INVALID_ARGUMENT")
        call.resolve(JSObject().put("cancelled", AlarmScheduler.cancelForBlock(context, id)))
    }

    /** Rolling-horizon sync: full desired set in, stale alarms cancelled, duplicates impossible. */
    @PluginMethod
    fun rescheduleUpcomingAlarms(call: PluginCall) {
        val alarms = call.getArray("alarms") ?: return call.reject("alarms required", "INVALID_ARGUMENT")
        try {
            val res = AlarmScheduler.sync(context, alarms, MANAGED_KINDS)
            WidgetUpdater.refreshAll(context)
            call.resolve(obj(res).put("exactAllowed", AlarmScheduler.canScheduleExact(context))
                .put("notificationPermission", notificationPermissionString()))
        } catch (e: Exception) {
            call.reject("Sync failed: ${e.message}", "SCHEDULE_FAILED", e)
        }
    }

    @PluginMethod
    fun getScheduledAlarmStatus(call: PluginCall) = call.resolve(obj(AlarmScheduler.status(context)))

    // ------------------------------------------------------------------ audio / speech

    @PluginMethod
    fun playCustomAlarmAudio(call: PluginCall) {
        val path = call.getString("path") ?: return call.reject("path required", "INVALID_ARGUMENT")
        val volume = (call.getFloat("volume") ?: 1f).coerceIn(0f, 1f)
        if (!path.startsWith("content://") && !path.startsWith("default:") && !File(path).exists()) return call.reject("Sound file not found", "NOT_FOUND")
        if (PreviewAudio.playFile(context, path, volume, call.getInt("startMs") ?: 0, call.getInt("endMs") ?: 0)) call.resolve(JSObject().put("playing", true))
        else call.reject("Unable to play this file", "IO_ERROR")
    }

    @PluginMethod
    fun stopAlarmAudio(call: PluginCall) {
        PreviewAudio.stop()
        ActivityActions.stopAudio(context)
        call.resolve(JSObject().put("stopped", true))
    }

    @PluginMethod
    fun speakText(call: PluginCall) {
        val text = call.getString("text")
        if (text.isNullOrBlank()) return call.reject("text required", "INVALID_ARGUMENT")
        val lang = call.getString("lang") ?: "ar"
        PreviewAudio.speak(context, text, lang) { ok, err ->
            if (ok) call.resolve(JSObject().put("spoken", true)) else call.reject("Speech unavailable for $lang", err ?: "TTS_FAILED")
        }
    }

    // ------------------------------------------------------------------ notifications

    @PluginMethod
    fun createNotification(call: PluginCall) {
        val id = call.getInt("id") ?: (System.currentTimeMillis() % 1_000_000).toInt()
        val title = call.getString("title") ?: return call.reject("title required", "INVALID_ARGUMENT")
        val posted = NotificationHelper.showSimple(context, id, title, call.getString("body") ?: "", call.getBoolean("silent") ?: false)
        if (posted) call.resolve(JSObject().put("id", id).put("posted", true))
        else call.reject("Notifications are not permitted", "PERMISSION_DENIED")
    }

    @PluginMethod fun updateNotification(call: PluginCall) = createNotification(call)

    @PluginMethod
    fun registerNotificationActions(call: PluginCall) {
        call.getString("language")?.let { db.setKv("language", it) }
        NotificationHelper.createChannels(context)
        call.resolve(JSObject().put("actions", JSArray(NotificationHelper.ALL_ACTIONS)))
    }

    @PluginMethod
    fun handleNotificationAction(call: PluginCall) {
        val action = call.getString("action") ?: return call.reject("action required", "INVALID_ARGUMENT")
        if (action !in NotificationHelper.ALL_ACTIONS) return call.reject("Unknown action", "INVALID_ARGUMENT")
        val outcome = ActivityActions.apply(context, action, call.getString("alarmKey"), call.getString("blockId"), "app")
        call.resolve(JSObject().put("result", outcome.result).put("record", outcome.record?.let { obj(it) }))
    }

    // ------------------------------------------------------------------ database bridge

    @PluginMethod
    fun dbLoadAll(call: PluginCall) {
        try { call.resolve(JSObject().put("collections", db.getAllCollections())) }
        catch (e: Exception) { call.reject("Load failed: ${e.message}", "DB_ERROR", e) }
    }

    @PluginMethod
    fun dbGetAll(call: PluginCall) {
        val col = call.getString("collection") ?: return call.reject("collection required", "INVALID_ARGUMENT")
        try { call.resolve(JSObject().put("records", db.getAll(col))) }
        catch (e: Exception) { call.reject("Query failed: ${e.message}", "DB_ERROR", e) }
    }

    @PluginMethod
    fun dbBatch(call: PluginCall) {
        val ops = call.getArray("ops") ?: return call.reject("ops required", "INVALID_ARGUMENT")
        try {
            db.batch(ops)
            val cols = (0 until ops.length()).map { ops.getJSONObject(it).optString("collection") }.toSet()
            if (cols.any { it in setOf("activities", "occasions", "tasks") }) WidgetUpdater.refreshAll(context)
            if ("alarmClocks" in cols) UserAlarms.rescheduleAll(context)          // real AlarmManager alarms follow the saved records
            if ("prayerLogs" in cols) { PrayerEngine.refreshOngoing(context); WidgetUpdater.refreshAll(context) }
            call.resolve(JSObject().put("applied", ops.length()))
        } catch (e: Exception) { call.reject("Transaction failed and was rolled back: ${e.message}", "DB_ERROR", e) }
    }

    @PluginMethod
    fun setNativePreferences(call: PluginCall) {
        listOf("language", "theme", "clock24", "widgetLayout", "accent", "hijriAdjust").forEach { k -> call.getString(k)?.let { db.setKv(k, it) } }
        NotificationHelper.createChannels(context)
        WidgetUpdater.refreshAll(context)
        call.resolve()
    }

    @PluginMethod
    fun consumeLaunchTarget(call: PluginCall) {
        val id = pendingLaunchBlockId
        val screen = pendingLaunchScreen
        pendingLaunchBlockId = null
        pendingLaunchScreen = null
        call.resolve(JSObject().put("blockId", id).put("screen", screen))
    }

    // ------------------------------------------------------------------ files

    @PluginMethod
    fun importNativeFile(call: PluginCall) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            val mimes = call.getArray("mimeTypes")?.toList<String>()
            if (!mimes.isNullOrEmpty()) putExtra(Intent.EXTRA_MIME_TYPES, mimes.toTypedArray())
        }
        startActivityForResult(call, intent, "importResult")
    }

    @ActivityCallback
    private fun importResult(call: PluginCall?, result: ActivityResult) {
        if (call == null) return
        val uri = result.data?.data
        if (result.resultCode != Activity.RESULT_OK || uri == null) return call.reject("User cancelled", "CANCELLED")
        try {
            val (name, size) = queryMeta(uri)
            if (size > MAX_IMPORT_BYTES) return call.reject("File is too large", "INVALID_ARGUMENT")
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return call.reject("Cannot read file", "IO_ERROR")
            when (call.getString("mode", "text")) {
                "audio" -> {
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (ext !in setOf("mp3", "ogg", "m4a", "aac", "wav")) return call.reject("Unsupported audio format", "INVALID_ARGUMENT")
                    val dir = File(context.filesDir, "sounds").apply { mkdirs() }
                    val out = File(dir, "${UUID.randomUUID()}.$ext")
                    out.writeBytes(bytes)
                    call.resolve(JSObject().put("path", out.absolutePath).put("name", name).put("size", bytes.size).put("mimeType", mime))
                }
                "binary" -> call.resolve(JSObject().put("name", name).put("size", bytes.size).put("mimeType", mime)
                    .put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP)))
                "attachment" -> {
                    val dir = File(context.filesDir, "attachments").apply { mkdirs() }
                    val safe = name.replace(Regex("[^\\p{L}\\p{N}._-]"), "_")
                    val out = File(dir, "${UUID.randomUUID()}_$safe")
                    out.writeBytes(bytes)
                    call.resolve(JSObject().put("path", out.absolutePath).put("name", name).put("size", bytes.size).put("mimeType", mime))
                }
                else -> call.resolve(JSObject().put("name", name).put("size", bytes.size).put("mimeType", mime)
                    .put("text", String(bytes, Charsets.UTF_8)))
            }
        } catch (e: Exception) {
            call.reject("Import failed: ${e.message}", "IO_ERROR", e)
        }
    }

    private fun queryMeta(uri: Uri): Pair<String, Long> {
        var name = "file"; var size = 0L
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0) size = c.getLong(si)
            }
        }
        return name to size
    }

    @PluginMethod
    fun deleteAppFile(call: PluginCall) {
        val path = call.getString("path") ?: return call.reject("path required", "INVALID_ARGUMENT")
        val f = File(path).canonicalFile
        if (!f.path.startsWith(context.filesDir.canonicalPath)) return call.reject("Path outside app storage", "INVALID_ARGUMENT")
        call.resolve(JSObject().put("deleted", f.delete()))
    }

    @PluginMethod
    fun exportBackup(call: PluginCall) {
        val fileName = call.getString("fileName") ?: return call.reject("fileName required", "INVALID_ARGUMENT")
        if (call.getString("content") == null) return call.reject("content required", "INVALID_ARGUMENT")
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = call.getString("mimeType") ?: "application/json"
            putExtra(Intent.EXTRA_TITLE, fileName)
        }
        startActivityForResult(call, intent, "exportResult")
    }

    @ActivityCallback
    private fun exportResult(call: PluginCall?, result: ActivityResult) {
        if (call == null) return
        val uri = result.data?.data
        if (result.resultCode != Activity.RESULT_OK || uri == null) return call.reject("User cancelled", "CANCELLED")
        try {
            val content = call.getString("content") ?: ""
            val bytes = if (call.getBoolean("base64") == true) Base64.decode(content, Base64.DEFAULT) else content.toByteArray(Charsets.UTF_8)
            context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: return call.reject("Cannot open destination", "IO_ERROR")
            call.resolve(JSObject().put("uri", uri.toString()).put("bytes", bytes.size))
        } catch (e: Exception) {
            call.reject("Export failed: ${e.message}", "IO_ERROR", e)
        }
    }

    // ------------------------------------------------------------------ widgets

    @PluginMethod
    fun updateWidget(call: PluginCall) {
        WidgetUpdater.refreshAll(context)
        val mgr = AppWidgetManager.getInstance(context)
        val count = listOf(CompactWidgetProvider::class.java, MediumWidgetProvider::class.java, LargeWidgetProvider::class.java)
            .sumOf { mgr.getAppWidgetIds(ComponentName(context, it)).size }
        call.resolve(JSObject().put("installedWidgets", count))
    }

    // ------------------------------------------------------------------ tones, music and trimming

    /** Opens Android's own ringtone / alarm-tone / notification-tone picker (not the file manager). */
    @PluginMethod
    fun pickRingtone(call: PluginCall) {
        val type = when (call.getString("type")) { "ringtone" -> RingtoneManager.TYPE_RINGTONE; "notification" -> RingtoneManager.TYPE_NOTIFICATION; else -> RingtoneManager.TYPE_ALARM }
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, type)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(type))
            call.getString("existingUri")?.takeIf { it.isNotEmpty() }?.let { putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it)) }
        }
        try { startActivityForResult(call, intent, "ringtoneResult") } catch (e: Exception) { call.reject("No tone picker available", "UNSUPPORTED") }
    }

    @ActivityCallback
    private fun ringtoneResult(call: PluginCall?, result: ActivityResult) {
        if (call == null) return
        if (result.resultCode != Activity.RESULT_OK) return call.reject("User cancelled", "CANCELLED")
        val uri: Uri? = pickedUri(result.data)
        val name = if (uri == null) "—" else (try { RingtoneManager.getRingtone(context, uri)?.getTitle(context) } catch (_: Exception) { null } ?: "—")
        val res = JSObject().put("name", name).put("isDefault", uri == null)
        if (uri != null) res.put("uri", uri.toString())
        call.resolve(res)
    }

    @Suppress("DEPRECATION")
    private fun pickedUri(data: Intent?): Uri? =
        if (Build.VERSION.SDK_INT >= 33) data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        else data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)

    /** Opens the device's default music picker (media library), copies the chosen track into app storage and reports its duration so the UI can trim it. */
    @PluginMethod
    fun pickMusic(call: PluginCall) {
        try { startActivityForResult(call, Intent(Intent.ACTION_PICK, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI), "musicResult") }
        catch (e: Exception) {
            val alt = Intent(Intent.ACTION_GET_CONTENT).apply { type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            try { startActivityForResult(call, alt, "musicResult") } catch (e2: Exception) { call.reject("No audio picker available", "UNSUPPORTED") }
        }
    }

    @ActivityCallback
    private fun musicResult(call: PluginCall?, result: ActivityResult) {
        if (call == null) return
        val uri = result.data?.data
        if (result.resultCode != Activity.RESULT_OK || uri == null) return call.reject("User cancelled", "CANCELLED")
        try {
            val (name, size) = queryMeta(uri)
            if (size > MAX_IMPORT_BYTES) return call.reject("File is too large", "INVALID_ARGUMENT")
            val mime = context.contentResolver.getType(uri) ?: "audio/mpeg"
            var ext = name.substringAfterLast('.', "").lowercase()
            if (ext !in setOf("mp3", "ogg", "m4a", "aac", "wav")) ext = when { mime.contains("ogg") -> "ogg"; mime.contains("mp4") || mime.contains("m4a") || mime.contains("aac") -> "m4a"; mime.contains("wav") -> "wav"; mime.contains("mpeg") || mime.contains("mp3") -> "mp3"; else -> "" }
            if (ext.isEmpty()) return call.reject("Unsupported audio format", "INVALID_ARGUMENT")
            val dir = File(context.filesDir, "sounds").apply { mkdirs() }
            val out = File(dir, "${UUID.randomUUID()}.$ext")
            context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } } ?: return call.reject("Cannot read file", "IO_ERROR")
            if (out.length() > MAX_IMPORT_BYTES) { out.delete(); return call.reject("File is too large", "INVALID_ARGUMENT") }
            call.resolve(JSObject().put("path", out.absolutePath).put("name", name).put("size", out.length()).put("mimeType", mime).put("durationMs", audioDuration(out.absolutePath)))
        } catch (e: Exception) { call.reject("Import failed: ${e.message}", "IO_ERROR", e) }
    }

    private fun audioDuration(path: String): Long {
        val r = MediaMetadataRetriever()
        return try { r.setDataSource(path); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L } catch (_: Exception) { 0L } finally { try { r.release() } catch (_: Exception) { } }
    }

    @PluginMethod
    fun getAudioInfo(call: PluginCall) {
        val path = call.getString("path") ?: return call.reject("path required", "INVALID_ARGUMENT")
        if (!File(path).exists()) return call.reject("Sound file not found", "NOT_FOUND")
        call.resolve(JSObject().put("durationMs", audioDuration(path)))
    }

    // ------------------------------------------------------------------ prayer + alarm helpers

    @PluginMethod
    fun configurePrayer(call: PluginCall) {
        try {
            val cfg = JSONObject(call.data.toString())
            cfg.optString("language").takeIf { it.isNotEmpty() }?.let { db.setKv("language", it) }
            call.resolve(JSObject().put("scheduled", PrayerEngine.configure(context, cfg)))
        } catch (e: Exception) { call.reject("Prayer configuration failed: ${e.message}", "SCHEDULE_FAILED", e) }
    }

    @PluginMethod
    fun canUseFullScreenIntent(call: PluginCall) = call.resolve(JSObject().put("allowed", NotificationHelper.canUseFullScreenIntent(context)))

    @PluginMethod
    fun openFullScreenIntentSettings(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= 34) openSettings(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${context.packageName}")))
        else openSettings(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
        call.resolve(JSObject().put("openedSettings", true))
    }

    @PluginMethod
    fun stopAlarmRinging(call: PluginCall) { UserAlarms.stopRinging(context); call.resolve(JSObject().put("stopped", true)) }

    @PluginMethod
    fun getAudioDiagnostics(call: PluginCall) {
        call.resolve(JSObject().put("lastFallbackUsed", AlarmAudioService.lastFallbackUsed ?: db.getKv("last_audio_fallback")))
    }
}

private fun JSONArray.toStringList(): List<String> = (0 until length()).map { getString(it) }
