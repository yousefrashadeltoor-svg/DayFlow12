package com.dayflow.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.io.File
import java.util.Locale

object AudioUtil {
    /** Resolves a stored sound reference: `default:<alarm|ringtone|notification>`, content:// URI, file:// URI or absolute path. */
    fun resolve(context: Context, path: String): Uri? {
        if (path.startsWith("default:")) {
            val type = when (path.removePrefix("default:")) {
                "ringtone" -> RingtoneManager.TYPE_RINGTONE
                "notification" -> RingtoneManager.TYPE_NOTIFICATION
                else -> RingtoneManager.TYPE_ALARM
            }
            return RingtoneManager.getActualDefaultRingtoneUri(context, type) ?: RingtoneManager.getDefaultUri(type)
        }
        if (path.startsWith("content://") || path.startsWith("file://") || path.startsWith("android.resource://")) return Uri.parse(path)
        val f = File(path)
        return if (f.exists()) Uri.fromFile(f) else null
    }
}

/**
 * Plays a segment [startMs, endMs] of an audio source, optionally looping (loops = -1 means until stop()).
 * The source file is never modified: trimming is purely playback positions.
 */
class SegmentPlayer(private val context: Context, private val usage: Int) {
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var endTask: Runnable? = null
    private var rampTask: Runnable? = null
    private var loopsLeft = 0
    private var startMs = 0
    private var endMs = 0
    var onFinished: (() -> Unit)? = null
    @Volatile var playing = false
        private set

    fun play(uri: Uri, startMsIn: Int, endMsIn: Int, loops: Int, volume: Float, gradual: Boolean): Boolean {
        stop()
        return try {
            val p = MediaPlayer()
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setDataSource(context, uri)
            p.prepare()
            val dur = p.duration.coerceAtLeast(1)
            startMs = startMsIn.coerceIn(0, (dur - 500).coerceAtLeast(0))
            endMs = if (endMsIn > startMs + 300) endMsIn.coerceAtMost(dur) else dur
            loopsLeft = loops
            mp = p
            p.setOnCompletionListener { onSegmentEnd() }
            p.setOnErrorListener { _, _, _ -> stop(); onFinished?.invoke(); true }
            applyVolume(p, volume, gradual)
            playing = true
            beginSegment()
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    private fun beginSegment() {
        val p = mp ?: return
        try {
            p.seekTo(startMs.toLong(), MediaPlayer.SEEK_CLOSEST)
            p.start()
            endTask?.let { handler.removeCallbacks(it) }
            endTask = null
            if (endMs < p.duration) {
                val t = Runnable { onSegmentEnd() }
                endTask = t
                handler.postDelayed(t, (endMs - startMs).toLong().coerceAtLeast(300L))
            }
        } catch (e: Exception) {
            stop(); onFinished?.invoke()
        }
    }

    private fun onSegmentEnd() {
        val p = mp ?: return
        try { p.pause() } catch (_: Exception) { }
        if (loopsLeft < 0 || --loopsLeft > 0) beginSegment() else { stop(); onFinished?.invoke() }
    }

    private fun applyVolume(p: MediaPlayer, volume: Float, gradual: Boolean) {
        val vol = volume.coerceIn(0f, 1f)
        if (!gradual) { p.setVolume(vol, vol); return }
        var cur = 0.15f
        p.setVolume(cur * vol, cur * vol)
        val r = object : Runnable {
            override fun run() {
                cur = (cur + 0.12f).coerceAtMost(1f)
                try { mp?.setVolume(cur * vol, cur * vol) } catch (_: Exception) { }
                if (cur < 1f) handler.postDelayed(this, 1200)
            }
        }
        rampTask = r
        handler.postDelayed(r, 1200)
    }

    fun stop() {
        playing = false
        endTask?.let { handler.removeCallbacks(it) }
        rampTask?.let { handler.removeCallbacks(it) }
        endTask = null
        rampTask = null
        try { mp?.stop() } catch (_: Exception) { }
        mp?.release()
        mp = null
    }
}

/** In-app (foreground) preview player used by the plugin for sound previews and speech tests. */
object PreviewAudio {
    private var player: SegmentPlayer? = null
    private var tts: TextToSpeech? = null

    fun playFile(context: Context, path: String, volume: Float, startMs: Int = 0, endMs: Int = 0): Boolean {
        stop()
        val uri = AudioUtil.resolve(context, path) ?: return false
        val p = SegmentPlayer(context.applicationContext, AudioAttributes.USAGE_MEDIA)
        player = p
        return p.play(uri, startMs, endMs, 1, volume, false)
    }

    fun speak(context: Context, text: String, lang: String, result: (Boolean, String?) -> Unit) {
        stop()
        tts = TextToSpeech(context.applicationContext) { status ->
            val engine = tts
            if (status != TextToSpeech.SUCCESS || engine == null) { result(false, "TTS_INIT_FAILED"); return@TextToSpeech }
            val r = engine.setLanguage(Locale.forLanguageTag(lang))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) { result(false, "TTS_LANGUAGE_UNAVAILABLE"); return@TextToSpeech }
            val ok = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview") == TextToSpeech.SUCCESS
            result(ok, if (ok) null else "TTS_SPEAK_FAILED")
        }
    }

    fun stop() {
        player?.stop()
        player = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
    }
}
