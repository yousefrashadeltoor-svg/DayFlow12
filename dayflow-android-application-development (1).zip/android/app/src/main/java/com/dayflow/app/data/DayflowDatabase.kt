package com.dayflow.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/**
 * DAYFLOW native SQLite database.
 *
 * Storage model:
 *  - `records`: every domain entity (ActivityBlock, Task, Habit, ...) is stored as one row,
 *    keyed by (collection, id). The JSON payload holds the full typed entity defined in
 *    src/models/types.ts. Frequently queried attributes (date_key, parent_id, status) are
 *    projected into indexed columns so native components (receivers, widgets) can query
 *    them without loading the whole database.
 *  - `alarms`: native alarm registry. Stable request codes prevent duplicate PendingIntents.
 *  - `notification_action_log`: audit trail of every notification action (idempotency).
 *  - `database_migration`: applied schema versions. Migrations never drop user data.
 *  - `kv`: small native preferences mirrored from the web layer (language, theme, quiet hours).
 *
 * All SQL uses bound parameters. Multi-row writes run inside transactions.
 */
class DayflowDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    companion object {
        const val DB_NAME = "dayflow.db"
        const val DB_VERSION = 3

        @Volatile private var instance: DayflowDatabase? = null

        fun get(context: Context): DayflowDatabase =
            instance ?: synchronized(this) {
                instance ?: DayflowDatabase(context).also { instance = it }
            }
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Fresh installs run every migration in order so that the schema is identical
        // to an upgraded install.
        for (v in 1..DB_VERSION) applyMigration(db, v)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Stepwise, additive migrations. Existing records are always preserved.
        for (v in (oldVersion + 1)..newVersion) applyMigration(db, v)
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Refuse to destroy data on downgrade. Keep the newer schema (it is additive).
    }

    private fun applyMigration(db: SQLiteDatabase, version: Int) {
        when (version) {
            1 -> {
                db.execSQL(
                    """CREATE TABLE IF NOT EXISTS records(
                        collection TEXT NOT NULL CHECK(length(collection) > 0),
                        id TEXT NOT NULL CHECK(length(id) > 0),
                        data TEXT NOT NULL CHECK(length(data) > 1),
                        date_key TEXT,
                        parent_id TEXT,
                        updated_at INTEGER NOT NULL,
                        PRIMARY KEY(collection, id)
                    )"""
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_records_date ON records(collection, date_key)")
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_records_parent ON records(collection, parent_id)")
                db.execSQL(
                    """CREATE TABLE IF NOT EXISTS database_migration(
                        version INTEGER PRIMARY KEY,
                        applied_at INTEGER NOT NULL,
                        description TEXT NOT NULL
                    )"""
                )
                db.execSQL("CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT)")
                logMigration(db, 1, "records, kv, migration registry")
            }
            2 -> {
                db.execSQL(
                    """CREATE TABLE IF NOT EXISTS alarms(
                        alarm_key TEXT PRIMARY KEY,
                        request_code INTEGER NOT NULL UNIQUE,
                        block_id TEXT,
                        kind TEXT NOT NULL,
                        trigger_at INTEGER NOT NULL,
                        local_date TEXT,
                        local_minute INTEGER,
                        payload TEXT NOT NULL,
                        repeat_count INTEGER NOT NULL DEFAULT 0,
                        state TEXT NOT NULL DEFAULT 'scheduled',
                        exact INTEGER NOT NULL DEFAULT 0,
                        delivered_at INTEGER,
                        created_at INTEGER NOT NULL,
                        updated_at INTEGER NOT NULL
                    )"""
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_alarms_trigger ON alarms(state, trigger_at)")
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_alarms_block ON alarms(block_id)")
                db.execSQL(
                    """CREATE TABLE IF NOT EXISTS notification_action_log(
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        alarm_key TEXT,
                        block_id TEXT,
                        action TEXT NOT NULL,
                        result TEXT NOT NULL,
                        handled_at INTEGER NOT NULL
                    )"""
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_action_log_block ON notification_action_log(block_id, handled_at)")
                logMigration(db, 2, "native alarm registry and notification action log")
            }
            3 -> {
                // Status projection for fast native widget queries. Additive column.
                if (!columnExists(db, "records", "status")) {
                    db.execSQL("ALTER TABLE records ADD COLUMN status TEXT")
                }
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_records_status ON records(collection, date_key, status)")
                // Backfill without relying on the optional JSON1 SQLite extension (absent on old devices).
                val rows = mutableListOf<Pair<String, String?>>()
                db.rawQuery("SELECT id, data FROM records WHERE collection = 'activities'", null).use { c ->
                    while (c.moveToNext()) {
                        val st = try { JSONObject(c.getString(1)).optString("status").ifEmpty { null } } catch (e: Exception) { null }
                        rows.add(c.getString(0) to st)
                    }
                }
                for ((id, st) in rows) {
                    db.execSQL("UPDATE records SET status = ? WHERE collection = 'activities' AND id = ?", arrayOf<Any?>(st, id))
                }
                logMigration(db, 3, "status projection for activities")
            }
        }
    }

    private fun columnExists(db: SQLiteDatabase, table: String, column: String): Boolean {
        db.rawQuery("PRAGMA table_info($table)", null).use { c ->
            val idx = c.getColumnIndex("name")
            while (c.moveToNext()) if (c.getString(idx) == column) return true
        }
        return false
    }

    private fun logMigration(db: SQLiteDatabase, version: Int, description: String) {
        val cv = ContentValues().apply {
            put("version", version)
            put("applied_at", System.currentTimeMillis())
            put("description", description)
        }
        db.insertWithOnConflict("database_migration", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ---------------------------------------------------------------- records API

    fun getAll(collection: String): JSONArray {
        val out = JSONArray()
        readableDatabase.rawQuery(
            "SELECT data FROM records WHERE collection = ?", arrayOf(collection)
        ).use { c -> while (c.moveToNext()) out.put(JSONObject(c.getString(0))) }
        return out
    }

    fun getAllCollections(): JSONObject {
        val out = JSONObject()
        readableDatabase.rawQuery("SELECT collection, data FROM records", null).use { c ->
            while (c.moveToNext()) {
                val col = c.getString(0)
                val arr = out.optJSONArray(col) ?: JSONArray().also { out.put(col, it) }
                arr.put(JSONObject(c.getString(1)))
            }
        }
        return out
    }

    fun get(collection: String, id: String): JSONObject? {
        readableDatabase.rawQuery(
            "SELECT data FROM records WHERE collection = ? AND id = ?", arrayOf(collection, id)
        ).use { c -> return if (c.moveToFirst()) JSONObject(c.getString(0)) else null }
    }

    fun getByDate(collection: String, dateKey: String): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        readableDatabase.rawQuery(
            "SELECT data FROM records WHERE collection = ? AND date_key = ?", arrayOf(collection, dateKey)
        ).use { c -> while (c.moveToNext()) out.add(JSONObject(c.getString(0))) }
        return out
    }

    private fun putInternal(db: SQLiteDatabase, collection: String, obj: JSONObject) {
        val id = obj.optString("id")
        require(id.isNotEmpty()) { "Record without id in $collection" }
        val cv = ContentValues().apply {
            put("collection", collection)
            put("id", id)
            put("data", obj.toString())
            put("date_key", obj.optString("date").ifEmpty { null })
            put("parent_id", obj.optString("parentId").ifEmpty { null })
            put("status", obj.optString("status").ifEmpty { null })
            put("updated_at", obj.optLong("updatedAt", System.currentTimeMillis()))
        }
        db.insertWithOnConflict("records", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun put(collection: String, obj: JSONObject) = putInternal(writableDatabase, collection, obj)

    /**
     * Executes a batch of operations atomically.
     * ops: [{ op: "put"|"delete"|"clear", collection, record?, id? }]
     */
    fun batch(ops: JSONArray) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (i in 0 until ops.length()) {
                val op = ops.getJSONObject(i)
                val collection = op.getString("collection")
                when (op.getString("op")) {
                    "put" -> putInternal(db, collection, op.getJSONObject("record"))
                    "delete" -> db.delete("records", "collection = ? AND id = ?", arrayOf(collection, op.getString("id")))
                    "clear" -> db.delete("records", "collection = ?", arrayOf(collection))
                    else -> throw IllegalArgumentException("Unknown op ${op.getString("op")}")
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun migrationHistory(): JSONArray {
        val out = JSONArray()
        readableDatabase.rawQuery("SELECT version, applied_at, description FROM database_migration ORDER BY version", null).use { c ->
            while (c.moveToNext()) out.put(JSONObject().apply {
                put("version", c.getInt(0)); put("appliedAt", c.getLong(1)); put("description", c.getString(2))
            })
        }
        return out
    }

    // ---------------------------------------------------------------- kv

    fun setKv(key: String, value: String?) {
        val cv = ContentValues().apply { put("key", key); put("value", value) }
        writableDatabase.insertWithOnConflict("kv", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getKv(key: String): String? {
        readableDatabase.rawQuery("SELECT value FROM kv WHERE key = ?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    // ---------------------------------------------------------------- action log

    fun logAction(alarmKey: String?, blockId: String?, action: String, result: String) {
        val cv = ContentValues().apply {
            put("alarm_key", alarmKey); put("block_id", blockId); put("action", action)
            put("result", result); put("handled_at", System.currentTimeMillis())
        }
        writableDatabase.insert("notification_action_log", null, cv)
    }

    fun recentActions(limit: Int): JSONArray {
        val out = JSONArray()
        readableDatabase.rawQuery(
            "SELECT alarm_key, block_id, action, result, handled_at FROM notification_action_log ORDER BY handled_at DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.put(JSONObject().apply {
                put("alarmKey", c.getString(0)); put("blockId", c.getString(1)); put("action", c.getString(2))
                put("result", c.getString(3)); put("handledAt", c.getLong(4))
            })
        }
        return out
    }

    /** True if the same action for the same alarm was handled in the last [windowMs]. Prevents duplicate intents. */
    fun isDuplicateAction(alarmKey: String, action: String, windowMs: Long): Boolean {
        val since = System.currentTimeMillis() - windowMs
        readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM notification_action_log WHERE alarm_key = ? AND action = ? AND handled_at >= ? AND result = 'ok'",
            arrayOf(alarmKey, action, since.toString())
        ).use { c -> return c.moveToFirst() && c.getInt(0) > 0 }
    }
}
