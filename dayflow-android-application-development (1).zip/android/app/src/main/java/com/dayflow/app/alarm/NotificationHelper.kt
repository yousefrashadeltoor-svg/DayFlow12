package com.dayflow.app.alarm

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.dayflow.app.MainActivity
import com.dayflow.app.R
import com.dayflow.app.data.DayflowDatabase
import org.json.JSONObject
import java.util.Locale

/** Wraps a context with the language selected inside DAYFLOW so native text matches the UI. */
object LocaleHelper {
    fun localized(context: Context): Context {
        val lang = try { DayflowDatabase.get(context).getKv("language") } catch (_: Exception) { null } ?: return context
        val locale = Locale.forLanguageTag(lang)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return context.createConfigurationContext(config)
    }
    fun language(context: Context): String =
        try { DayflowDatabase.get(context).getKv("language") } catch (_: Exception) { null } ?: Locale.getDefault().language
}

object NotificationHelper {
    const val CHANNEL_REMINDERS = "dayflow_reminders"
    const val CHANNEL_ALARM_AUDIO = "dayflow_alarm_audio"
    const val CHANNEL_QUIET = "dayflow_quiet"
    const val CHANNEL_PLAYBACK = "dayflow_playback"
    const val CHANNEL_USER_ALARM = "dayflow_user_alarm"
    const val CHANNEL_PRAYER = "dayflow_prayer"
    const val CHANNEL_PRAYER_ONGOING = "dayflow_prayer_ongoing"
    const val CHANNEL_OCCASION = "dayflow_occasion"
    const val GROUP_KEY = "com.dayflow.app.REMINDERS"
    const val SUMMARY_ID = 9_000_001

    val ALL_ACTIONS = listOf("DONE", "SNOOZE_5", "SNOOZE_10", "SNOOZE_15", "SKIP", "START", "PARTIAL", "DISMISS", "PRAYED")
    val INTERNAL_ACTIONS = ALL_ACTIONS + listOf("ALARM_SNOOZE", "ALARM_STOP")

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val ctx = LocaleHelper.localized(context)
        val nm = context.getSystemService(NotificationManager::class.java)
        val notifSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).build()
        val reminders = NotificationChannel(CHANNEL_REMINDERS, ctx.getString(R.string.channel_reminders), NotificationManager.IMPORTANCE_HIGH).apply {
            description = ctx.getString(R.string.channel_reminders_desc); enableVibration(true); setSound(notifSound, attrs)
        }
        val alarmAudio = NotificationChannel(CHANNEL_ALARM_AUDIO, ctx.getString(R.string.channel_alarm_audio), NotificationManager.IMPORTANCE_HIGH).apply {
            description = ctx.getString(R.string.channel_alarm_audio_desc); setSound(null, null); enableVibration(true)
        }
        val quiet = NotificationChannel(CHANNEL_QUIET, ctx.getString(R.string.channel_quiet), NotificationManager.IMPORTANCE_LOW).apply {
            description = ctx.getString(R.string.channel_quiet_desc); setSound(null, null); enableVibration(false)
        }
        val playback = NotificationChannel(CHANNEL_PLAYBACK, ctx.getString(R.string.channel_playback), NotificationManager.IMPORTANCE_LOW).apply { setSound(null, null) }
        val userAlarm = NotificationChannel(CHANNEL_USER_ALARM, ctx.getString(R.string.channel_user_alarm), NotificationManager.IMPORTANCE_HIGH).apply {
            description = ctx.getString(R.string.channel_user_alarm_desc); setSound(null, null); enableVibration(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val prayer = NotificationChannel(CHANNEL_PRAYER, ctx.getString(R.string.channel_prayer), NotificationManager.IMPORTANCE_HIGH).apply {
            description = ctx.getString(R.string.channel_prayer_desc); enableVibration(true); setSound(notifSound, attrs)
        }
        val ongoing = NotificationChannel(CHANNEL_PRAYER_ONGOING, ctx.getString(R.string.channel_prayer_ongoing), NotificationManager.IMPORTANCE_LOW).apply {
            description = ctx.getString(R.string.channel_prayer_ongoing_desc); setSound(null, null); setShowBadge(false)
        }
        val occasion = NotificationChannel(CHANNEL_OCCASION, ctx.getString(R.string.channel_occasion), NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = ctx.getString(R.string.channel_occasion_desc); setSound(notifSound, attrs)
        }
        nm.createNotificationChannels(listOf(reminders, alarmAudio, quiet, playback, userAlarm, prayer, ongoing, occasion))
    }

    fun hasPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun canUseFullScreenIntent(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 34) context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent() else true

    private fun actionLabel(ctx: Context, action: String): String = when (action) {
        "DONE" -> ctx.getString(R.string.action_done)
        "SNOOZE_5" -> ctx.getString(R.string.action_snooze_5)
        "SNOOZE_10" -> ctx.getString(R.string.action_snooze_10)
        "SNOOZE_15" -> ctx.getString(R.string.action_snooze_15)
        "SKIP" -> ctx.getString(R.string.action_skip)
        "START" -> ctx.getString(R.string.action_start)
        "PARTIAL" -> ctx.getString(R.string.action_partial)
        "PRAYED" -> ctx.getString(R.string.action_prayed)
        else -> ctx.getString(R.string.action_dismiss)
    }

    fun actionIntent(context: Context, action: String, alarmKey: String, blockId: String?, requestCode: Int, notificationId: Int): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = "com.dayflow.app.action.NOTIF_$action"
            setPackage(context.packageName)
            putExtra("action", action)
            putExtra("alarmKey", alarmKey)
            putExtra("blockId", blockId)
            putExtra("notificationId", notificationId)
        }
        val code = requestCode * 16 + INTERNAL_ACTIONS.indexOf(action).coerceAtLeast(0)
        return PendingIntent.getBroadcast(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun categoryIcon(category: String): Int = when (category) {
        "study" -> R.drawable.ic_cat_study
        "exercise" -> R.drawable.ic_cat_exercise
        "water" -> R.drawable.ic_cat_water
        "sleep" -> R.drawable.ic_cat_sleep
        "meal" -> R.drawable.ic_cat_meal
        "prayer" -> R.drawable.ic_cat_prayer
        "occasion" -> R.drawable.ic_cat_occasion
        "alarm" -> R.drawable.ic_cat_alarm
        "journal" -> R.drawable.ic_cat_journal
        else -> R.drawable.ic_stat_dayflow
    }

    private fun parseColor(hex: String, fallback: Int): Int = try { Color.parseColor(hex) } catch (_: Exception) { fallback }

    private fun openApp(context: Context, requestCode: Int, alarmKey: String?, blockId: String?, screen: String?): PendingIntent {
        val i = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openBlockId", blockId); putExtra("alarmKey", alarmKey); putExtra("openScreen", screen)
        }
        return PendingIntent.getActivity(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /**
     * Posts a reminder with: title, planned time + duration, the note, what comes next, category (subtext) and colour,
     * plus up to 3 working action buttons. Returns false when Android does not allow posting so callers record the honest state.
     */
    fun showReminder(context: Context, alarm: JSONObject, notificationId: Int, playsOwnAudio: Boolean): Boolean {
        if (!hasPermission(context)) return false
        createChannels(context)
        val ctx = LocaleHelper.localized(context)
        val alarmKey = alarm.getString("_alarmKey")
        val blockId = alarm.optString("blockId").ifEmpty { null }
        val kind = alarm.optString("kind")
        val silent = alarm.optBoolean("silent", false)
        val channel = when {
            silent -> CHANNEL_QUIET
            kind == "occasion" -> CHANNEL_OCCASION
            kind == "prayer" -> if (playsOwnAudio) CHANNEL_ALARM_AUDIO else CHANNEL_PRAYER
            playsOwnAudio -> CHANNEL_ALARM_AUDIO
            else -> CHANNEL_REMINDERS
        }
        val screen = when { kind == "prayer" -> "prayer"; kind == "occasion" -> "calendar"; alarm.optString("category") == "journal" -> "journal"; kind == "useralarm" -> "alarms"; else -> null }
        val repeat = alarm.optInt("_repeatCount", 0)
        val title = alarm.optString("title")
        var body = alarm.optString("body")
        if (repeat > 0 && kind != "useralarm") body = ctx.getString(R.string.notif_repeat_prefix, repeat) + " · " + body
        val note = alarm.optString("note")
        val next = alarm.optString("nextLabel")
        val big = StringBuilder(body)
        if (note.isNotEmpty()) big.append("\n\uD83D\uDCDD ").append(note)
        if (next.isNotEmpty()) big.append("\n").append(next)
        val catName = alarm.optString("catName")
        val accent = ContextCompat.getColor(context, R.color.dayflow_accent)

        val builder = NotificationCompat.Builder(context, channel)
            .setSmallIcon(categoryIcon(alarm.optString("category")))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(big.toString()))
            .setPriority(if (silent) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (kind == "block") NotificationCompat.CATEGORY_REMINDER else NotificationCompat.CATEGORY_EVENT)
            .setContentIntent(openApp(context, notificationId, alarmKey, blockId, screen))
            .setAutoCancel(true)
            .setGroup(GROUP_KEY)
            .setWhen(alarm.optLong("_triggerAt", System.currentTimeMillis()))
            .setShowWhen(true)
            .setColor(parseColor(alarm.optString("colorHex"), accent))
        if (catName.isNotEmpty()) builder.setSubText(catName)
        if (!alarm.optBoolean("vibrate", true) || silent) builder.setVibrate(longArrayOf(0L))

        // Android displays at most 3 action buttons; the configured order decides which are visible.
        val actions = alarm.optJSONArray("actions")
        val chosen = mutableListOf<String>()
        if (actions != null) for (i in 0 until actions.length()) chosen.add(actions.getString(i))
        if (chosen.isEmpty() && kind != "occasion") chosen.addAll(listOf("DONE", "SNOOZE_10", "SKIP"))
        val requestCode = alarm.optInt("_requestCode", notificationId)
        chosen.filter { it in ALL_ACTIONS && it != "DISMISS" }.take(3).forEach { a ->
            builder.addAction(0, actionLabel(ctx, a), actionIntent(context, a, alarmKey, blockId, requestCode, notificationId))
        }
        builder.setDeleteIntent(actionIntent(context, "DISMISS", alarmKey, blockId, requestCode, notificationId))

        return try {
            val nm = NotificationManagerCompat.from(context)
            nm.notify(notificationId, builder.build())
            val summary = NotificationCompat.Builder(context, CHANNEL_QUIET)
                .setSmallIcon(R.drawable.ic_stat_dayflow).setContentTitle(ctx.getString(R.string.app_name))
                .setGroup(GROUP_KEY).setGroupSummary(true).setAutoCancel(true).setColor(accent).build()
            nm.notify(SUMMARY_ID, summary)
            true
        } catch (e: SecurityException) { false }
    }

    /** Full-screen alarm notification (also the foreground-service notification while an alarm clock rings). */
    fun buildRingNotification(context: Context, alarm: JSONObject): Notification {
        createChannels(context)
        val ctx = LocaleHelper.localized(context)
        val key = alarm.optString("_alarmKey")
        val id = alarm.optString("blockId")
        val left = (alarm.optInt("maxSnoozes", 0) - alarm.optInt("_repeatCount", 0)).coerceAtLeast(0)
        val snoozeMin = alarm.optInt("snoozeMin", 9)
        val ring = Intent(context, AlarmRingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("alarmKey", key); putExtra("title", alarm.optString("title")); putExtra("time", alarm.optString("body"))
            putExtra("snoozeLeft", left); putExtra("snoozeMin", snoozeMin)
        }
        val ringPi = PendingIntent.getActivity(context, 7001, ring, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(context, CHANNEL_USER_ALARM)
            .setSmallIcon(R.drawable.ic_cat_alarm)
            .setContentTitle(alarm.optString("title"))
            .setContentText(alarm.optString("body"))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true).setAutoCancel(false)
            .setContentIntent(ringPi).setFullScreenIntent(ringPi, true)
            .setColor(parseColor(alarm.optString("colorHex"), Color.RED))
        if (left > 0) b.addAction(0, ctx.getString(R.string.alarm_snooze_fmt, snoozeMin), actionIntent(context, "ALARM_SNOOZE", key, id, 7002, com.dayflow.app.audio.AlarmAudioService.RING_ID))
        b.addAction(0, ctx.getString(R.string.alarm_stop), actionIntent(context, "ALARM_STOP", key, id, 7003, com.dayflow.app.audio.AlarmAudioService.RING_ID))
        return b.build()
    }

    /** Persistent next-prayer notification: Android itself renders the live countdown (chronometer), no app process needed. */
    fun showPrayerOngoing(context: Context, name: String, timeLabel: String, nextAt: Long, progress: Int, done: Int, city: String) {
        if (!hasPermission(context)) return
        createChannels(context)
        val ctx = LocaleHelper.localized(context)
        val b = NotificationCompat.Builder(context, CHANNEL_PRAYER_ONGOING)
            .setSmallIcon(R.drawable.ic_cat_prayer)
            .setContentTitle(ctx.getString(R.string.prayer_ongoing_title, name, timeLabel))
            .setContentText(ctx.getString(R.string.prayer_ongoing_text, done, city))
            .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(true).setWhen(nextAt)
            .setUsesChronometer(true).setChronometerCountDown(true)
            .setProgress(100, progress, false)
            .setPriority(NotificationCompat.PRIORITY_LOW).setCategory(NotificationCompat.CATEGORY_STATUS)
            .setColor(Color.parseColor("#22A45D"))
            .setContentIntent(openApp(context, 7100, null, null, "prayer"))
            .addAction(0, ctx.getString(R.string.action_prayed), actionIntent(context, "PRAYED", "", null, 7101, PrayerEngine.ONGOING_ID))
        try { NotificationManagerCompat.from(context).notify(PrayerEngine.ONGOING_ID, b.build()) } catch (_: SecurityException) { }
    }

    fun showSimple(context: Context, id: Int, title: String, body: String, silent: Boolean): Boolean {
        if (!hasPermission(context)) return false
        createChannels(context)
        val n = NotificationCompat.Builder(context, if (silent) CHANNEL_QUIET else CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_stat_dayflow).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(openApp(context, id, null, null, null)).setAutoCancel(true)
            .setColor(ContextCompat.getColor(context, R.color.dayflow_accent)).build()
        return try { NotificationManagerCompat.from(context).notify(id, n); true } catch (_: SecurityException) { false }
    }

    fun cancel(context: Context, id: Int) { NotificationManagerCompat.from(context).cancel(id) }
}
