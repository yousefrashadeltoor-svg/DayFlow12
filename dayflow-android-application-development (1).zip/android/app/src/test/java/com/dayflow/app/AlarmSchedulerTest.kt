package com.dayflow.app

import com.dayflow.app.alarm.AlarmScheduler
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class AlarmSchedulerTest {
    @Test
    fun localToEpoch_matchesWallClock() {
        val expected = LocalDateTime.of(2030, 1, 15, 9, 30).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        assertEquals(expected, AlarmScheduler.localToEpoch("2030-01-15", 9 * 60 + 30))
    }

    @Test
    fun localToEpoch_handlesCrossMidnightMinutes() {
        val expected = LocalDateTime.of(2030, 1, 16, 0, 30).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        assertEquals(expected, AlarmScheduler.localToEpoch("2030-01-15", 24 * 60 + 30))
    }
}
