package com.dayflow.app

import com.dayflow.app.alarm.PrayerEngine
import com.dayflow.app.alarm.UserAlarms
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

class NativeLogicTest {
    private fun at(y: Int, m: Int, d: Int, h: Int, mi: Int = 0) =
        LocalDateTime.of(y, m, d, h, mi).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private fun alarm(minute: Int, days: List<Int> = emptyList(), enabled: Boolean = true, skip: String? = null, one: String? = null) = JSONObject().apply {
        put("minute", minute); put("enabled", enabled); put("days", JSONArray(days))
        if (skip != null) put("skipDate", skip); if (one != null) put("oneTimeDate", one)
    }

    @Test fun oneTimeAlarmRingsTodayOrTomorrow() {
        assertEquals(at(2030, 5, 1, 8), UserAlarms.nextTrigger(alarm(8 * 60), at(2030, 5, 1, 7)))
        assertEquals(at(2030, 5, 2, 8), UserAlarms.nextTrigger(alarm(8 * 60), at(2030, 5, 1, 9)))
    }

    @Test fun repeatingAlarmUsesSundayZeroWeekdays() {
        // 2030-05-01 is a Wednesday; next Monday (1) is 2030-05-06
        assertEquals(at(2030, 5, 6, 7), UserAlarms.nextTrigger(alarm(7 * 60, listOf(1)), at(2030, 5, 1, 9)))
    }

    @Test fun skipDateAndDisabledAreHonoured() {
        val everyDay = listOf(0, 1, 2, 3, 4, 5, 6)
        assertEquals(at(2030, 5, 3, 7), UserAlarms.nextTrigger(alarm(7 * 60, everyDay, skip = "2030-05-02"), at(2030, 5, 1, 9)))
        assertNull(UserAlarms.nextTrigger(alarm(7 * 60, enabled = false), 0))
    }

    @Test fun explicitOneTimeDate() {
        assertEquals(at(2030, 6, 10, 6, 30), UserAlarms.nextTrigger(alarm(6 * 60 + 30, one = "2030-06-10"), at(2030, 5, 1, 9)))
        assertNull(UserAlarms.nextTrigger(alarm(6 * 60 + 30, one = "2030-04-10"), at(2030, 5, 1, 9)))
    }

    private fun cfg(lat: Double, lng: Double, method: String = "egypt") =
        PrayerEngine.Cfg(true, lat, lng, method, false, PrayerEngine.KEYS.associateWith { 0 }, 10, true, true, "", null, 0.9, true)

    @Test fun prayerTimesAreOrderedAndPlausibleForCairo() {
        val t = PrayerEngine.times(LocalDate.of(2030, 6, 21), cfg(30.0444, 31.2357))
        assertNotNull(t)
        val v = t!!
        assertTrue(v.getValue("fajr") < v.getValue("sunrise"))
        assertTrue(v.getValue("sunrise") < v.getValue("dhuhr"))
        assertTrue(v.getValue("dhuhr") < v.getValue("asr"))
        assertTrue(v.getValue("asr") < v.getValue("maghrib"))
        assertTrue(v.getValue("maghrib") < v.getValue("isha"))
    }

    @Test fun everyEgyptianLatitudeProducesTimes() {
        for (lat in listOf(22.0, 24.09, 27.18, 30.04, 31.41)) assertNotNull(PrayerEngine.times(LocalDate.of(2030, 1, 15), cfg(lat, 31.0)))
    }
}
