# Capacitor bridge + DAYFLOW native plugin (reflection based method lookup)
-keep class com.getcapacitor.** { *; }
-keep @com.getcapacitor.annotation.CapacitorPlugin public class * { *; }
-keepclassmembers class * extends com.getcapacitor.Plugin {
    @com.getcapacitor.PluginMethod public *;
    @com.getcapacitor.annotation.ActivityCallback *;
    @com.getcapacitor.annotation.PermissionCallback *;
}
-keep class com.dayflow.app.** { *; }
-keepattributes *Annotation*,JavascriptInterface
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
