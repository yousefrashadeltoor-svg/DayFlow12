const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const p = await b.newPage({ viewport: { width: 390, height: 844 } });
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERROR ' + e.message.slice(0, 200)));
  p.on('console', m => { if (m.type() === 'error') errs.push('console ' + m.text().slice(0, 160)); });
  await p.route('https://openrouter.ai/api/v1/models', r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ data:
    Array.from({ length: 14 }, (_, i) => ({ id: `vendor/model-${i}-free:free`, name: `Model ${i} Free`, pricing: { prompt: '0', completion: '0' }, supported_parameters: ['tools'], context_length: 131072, architecture: { output_modalities: ['text'] } }))
    .concat([{ id: 'openai/gpt-4.1', pricing: { prompt: '0.000002', completion: '0.000008' }, architecture: { output_modalities: ['text'] } },
             { id: 'google/imagen-out', pricing: { prompt: '0', completion: '0' }, architecture: { output_modalities: ['image'] } }]) }) }));
  await p.goto('file:///home/user/sandbox/dist/index.html');
  await p.waitForTimeout(1500);
  console.log('signature:', await p.locator('.signature').textContent().catch(() => 'MISSING'));
  for (let i = 0; i < 9; i++) { const btn = p.locator('button', { hasText: /التالي|يلا نبدأ/ }).first(); if (!(await btn.count())) break; await btn.click(); await p.waitForTimeout(220); }
  await p.waitForTimeout(1300);
  const ascii = await p.locator('pre.ascii-mark').textContent();
  console.log('ascii exact:', ascii === '█▀▄ ▄▀█ █▄█   █▀▀ █░░ █▀█ █░█░█\n█▄▀ █▀█ ░█░   █▀░ █▄▄ █▄█ ▀▄▀▄▀');
  console.log('title:', await p.title());
  await p.screenshot({ path: '/home/user/sandbox/_f1_home.png' });
  const tap = async (txt) => { await p.locator('button, div[role=button]').filter({ hasText: txt }).first().click({ timeout: 9000 }); await p.waitForTimeout(450); };
  await tap('المزيد'); await tap('الإعدادات'); await tap('المظهر والشكل'); await tap('الزينة والمواسم');
  await p.waitForTimeout(1000);
  await p.screenshot({ path: '/home/user/sandbox/_f2_gallery.png' });
  for (const name of ['رمضان', 'الشتا', 'الصيف']) { await p.locator(`button[aria-label="${name}"]`).click(); await p.waitForTimeout(280); }
  await p.locator('button[aria-label="الربيع"]').click(); await p.waitForTimeout(600);
  console.log('warning on 4th:', (await p.locator('text=خد بالك من الأداء').count()) > 0);
  await p.screenshot({ path: '/home/user/sandbox/_f3_warning.png' });
  await p.locator('button', { hasText: 'خليها 3' }).click(); await p.waitForTimeout(350);
  await p.locator('button', { hasText: 'لوحدها' }).first().click(); await p.waitForTimeout(450);
  console.log('solo badge:', (await p.locator('text=بيعاين').count()) > 0);
  await p.locator('button', { hasText: 'رجّع التلقائي' }).click(); await p.waitForTimeout(350);
  await p.locator('button', { hasText: 'خلف المحتوى' }).click(); await p.waitForTimeout(350);
  await p.locator('button[aria-label="النهاردة"]').click(); await p.waitForTimeout(1000);
  await p.screenshot({ path: '/home/user/sandbox/_f4_back.png' });
  await p.locator('button[aria-label="المساعد"]').click(); await p.waitForTimeout(800);
  const agree = p.locator('button', { hasText: 'موافق' }); if (await agree.count()) { await agree.click(); await p.waitForTimeout(450); }
  await p.locator('header button').nth(1).click(); await p.waitForTimeout(1400);
  const allChip = p.locator('button', { hasText: 'كل المزوّدين' }).last(); if (await allChip.count()) { await allChip.click(); await p.waitForTimeout(1400); }
  console.log('fetched free models visible:', await p.locator('text=Model 1 Free').count(), '| gpt-4.1:', await p.locator('text=openai/gpt-4.1').count(), '| image filtered:', (await p.locator('text=imagen-out').count()) === 0);
  await p.screenshot({ path: '/home/user/sandbox/_f5_models.png' });
  console.log(errs.length ? errs.join('\n') : 'no errors');
  await b.close();
})();
