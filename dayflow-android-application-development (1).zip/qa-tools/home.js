const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const p = await b.newPage({ viewport: { width: 390, height: 844 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message.slice(0, 160)));
  await p.goto('file:///home/user/sandbox/dist/index.html'); await p.waitForTimeout(1400);
  for (let i = 0; i < 9; i++) { const btn = p.locator('button', { hasText: /التالي|يلا نبدأ/ }).first(); if (!(await btn.count())) break; await btn.click(); await p.waitForTimeout(260); }
  await p.waitForTimeout(3600); // let toasts expire for a clean hero shot
  const box = await p.locator('pre.ascii-mark').boundingBox();
  const hero = await p.locator('section').first().boundingBox();
  console.log('ascii right-aligned:', box && hero && (hero.x + hero.width - (box.x + box.width)) < 30 && box.x > hero.width / 2);
  console.log('toasts now:', await p.locator('text=اتطبقت الخطة').count());
  await p.screenshot({ path: '/home/user/sandbox/_g1_home.png' });
  // back layer faint check
  await p.locator('button[aria-label="المزيد"]').click(); await p.waitForTimeout(350);
  await p.locator('button, div[role=button]').filter({ hasText: 'الإعدادات' }).first().click(); await p.waitForTimeout(350);
  await p.locator('button, div[role=button]').filter({ hasText: 'المظهر والشكل' }).first().click(); await p.waitForTimeout(350);
  await p.locator('button, div[role=button]').filter({ hasText: 'الزينة والمواسم' }).first().click(); await p.waitForTimeout(600);
  await p.locator('button', { hasText: 'خلف المحتوى' }).click(); await p.waitForTimeout(300);
  await p.locator('button[aria-label="النهاردة"]').click(); await p.waitForTimeout(900);
  await p.screenshot({ path: '/home/user/sandbox/_g2_back.png' });
  console.log(errs.length ? errs.join('|') : 'no errors');
  await b.close();
})();
