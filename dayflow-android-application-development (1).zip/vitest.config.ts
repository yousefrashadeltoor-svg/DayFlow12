import path from 'path';
import { defineConfig } from 'vitest/config';

export default defineConfig({
  resolve: { alias: { '@': path.resolve(__dirname, 'src') } },
  test: {
    pool: 'forks',
    fileParallelism: false, // jsdom suites are heavy; sequential files keep timings deterministic
    testTimeout: 60000,
    hookTimeout: 30000,
  },
});
