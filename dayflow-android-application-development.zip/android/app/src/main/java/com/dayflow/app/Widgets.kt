package com.dayflow.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

open class BaseWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetRenderer.refreshAll(context)
    }
    override fun onEnabled(context: Context) {
        WidgetRenderer.refreshAll(context)
    }
}
class CompactWidgetProvider : BaseWidgetProvider()
class MediumWidgetProvider : BaseWidgetProvider()
class LargeWidgetProvider : BaseWidgetProvider()
class PrayerWidgetProvider : BaseWidgetProvider()

/**
 * Renders all 4 native home-screen widgets offline from SharedPreferences + real clock:
 *  - CompactWidget: current activity + countdown + done ✓ button + next activity
 *  - MediumWidget: current activity + day completion progress + next 2 + quick 💧 + seasonal icon
 *  - LargeWidget: date + hijri + seasonal 3D decor + progress + current block (with note & ✓)
 *    + animated ViewFlipper (next prayer w/ progress & stats ↔ today's occasion) + up to 5 timeline blocks + 💧
 *  - PrayerWidget: next prayer + exact time + live countdown + smooth progress bar + today's X/5 count
 *    + 5-prayer inline status bar (فجر✓ ظهر✓ عصر مغرب عشاء) + one-tap صلّيت ✓
 * Also auto-schedules the next block-boundary silent refresh so widgets update on exact transitions.
 */
object WidgetRenderer {

    fun saveSnapshot(c: Context, json: String) {
        DayflowAlarms.prefs(c).edit().putString("widget_snapshot", json).apply()
        try {
            val o = JSONObject(json)
            val e = DayflowAlarms.prefs(c).edit()
            o.optString("lang").takeIf { it.isNotEmpty() }?.let { e.putString("lang", it) }
            if (o.has("hour12")) e.putBoolean("hour12", o.optBoolean("hour12"))
            o.optJSONObject("water")?.let { w ->
                DayflowAlarms.setWaterTodayMl(c, w.optInt("ml"), w.optInt("target", 2500))
            }
            e.apply()
        } catch (_: Exception) {}
        refreshAll(c)
    }

    private fun snapshot(c: Context): JSONObject =
        try { JSONObject(DayflowAlarms.prefs(c).getString("widget_snapshot", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    /** Directly patch a block inside the widget snapshot for instant zero-latency feedback. */
    fun patchBlockStatus(c: Context, blockId: String, status: String) {
        val s = snapshot(c)
        val blocks = s.optJSONArray("blocks") ?: return
        var dirty = false
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            if (b.optString("id") == blockId) { b.put("status", status); dirty = true; break }
        }
        if (dirty) DayflowAlarms.prefs(c).edit().putString("widget_snapshot", s.toString()).apply()
    }

    private fun nowMin(): Int {
        val k = Calendar.getInstance()
        return k.get(Calendar.HOUR_OF_DAY) * 60 + k.get(Calendar.MINUTE)
    }

    private fun active(b: JSONObject) = b.optString("status") !in setOf("done", "skipped", "cancelled", "missed")

    private fun current(blocks: JSONArray): JSONObject? {
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            if (b.optString("status") == "in_progress") return b
        }
        val n = nowMin()
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            if (active(b) && b.optInt("startMin") <= n && b.optInt("endMin") > n) return b
        }
        return null
    }

    private fun upcoming(blocks: JSONArray, curId: String?, limit: Int): List<JSONObject> {
        val n = nowMin()
        val out = ArrayList<JSONObject>()
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            if (active(b) && b.optString("id") != curId && b.optInt("endMin") > n) out.add(b)
        }
        return out.sortedBy { it.optInt("startMin") }.take(limit)
    }

    private fun hhmm(c: Context, min: Int): String {
        val m = ((min % 1440) + 1440) % 1440
        val h = m / 60; val mm = m % 60
        return if (DayflowAlarms.prefs(c).getBoolean("hour12", false)) {
            val h12 = if (h % 12 == 0) 12 else h % 12
            val ap = if (L10n.lang(c) == "en") (if (h >= 12) "PM" else "AM") else (if (h >= 12) "م" else "ص")
            String.format(Locale.US, "%d:%02d %s", h12, mm, ap)
        } else String.format(Locale.US, "%02d:%02d", h, mm)
    }

    private fun fmtTime(c: Context, millis: Long): String {
        val k = Calendar.getInstance().apply { timeInMillis = millis }
        return hhmm(c, k.get(Calendar.HOUR_OF_DAY) * 60 + k.get(Calendar.MINUTE))
    }

    private fun midnight(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Pick an authentic bundled 3D seasonal icon automatically by scene or calendar date. */
    private fun seasonalDrawable(sceneId: String): Int {
        return when (sceneId) {
            "ramadan", "eidFitr", "islamic" -> R.drawable.decor_crescent
            "eidAdha" -> R.drawable.decor_mosque
            "newyear", "nye" -> R.drawable.decor_xmas_tree
            "winter" -> R.drawable.decor_snowflake
            "autumn" -> R.drawable.decor_leaf_maple
            "spring", "sham", "summer" -> R.drawable.decor_sun
            else -> {
                val cal = Calendar.getInstance()
                val m = cal.get(Calendar.MONTH) + 1
                val d = cal.get(Calendar.DAY_OF_MONTH)
                val md = m * 100 + d
                when {
                    md >= 1215 || md <= 107 -> R.drawable.decor_xmas_tree
                    m == 12 || m <= 2 -> R.drawable.decor_snowflake
                    md >= 922 -> R.drawable.decor_leaf_maple
                    else -> R.drawable.decor_sun
                }
            }
        }
    }

    private fun pi(c: Context, req: Int, act: String, extras: Map<String, String> = emptyMap()): PendingIntent {
        val i = Intent(c, WidgetActionReceiver::class.java).apply {
            action = "com.dayflow.app.W.$act.$req"
            setPackage(c.packageName)
            putExtra("w_act", act)
            extras.forEach { (k, v) -> putExtra(k, v) }
        }
        return PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun openApp(c: Context): PendingIntent = PendingIntent.getActivity(
        c, 9001,
        Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun refreshAll(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        val hasAny = render(c, m, CompactWidgetProvider::class.java, R.layout.widget_compact) or
            render(c, m, MediumWidgetProvider::class.java, R.layout.widget_medium) or
            render(c, m, LargeWidgetProvider::class.java, R.layout.widget_large) or
            render(c, m, PrayerWidgetProvider::class.java, R.layout.widget_prayer)
        if (hasAny) scheduleNextBoundary(c)
    }

    /** Wake only once at the very next block transition, prayer time, or midnight — zero polling waste. */
    private fun scheduleNextBoundary(c: Context) {
        val now = System.currentTimeMillis()
        val base = midnight()
        var best = base + 24 * 3600_000L + 5_000L // midnight reset
        val s = snapshot(c)
        if (s.optString("date") == DayflowAlarms.todayStr()) {
            val blocks = s.optJSONArray("blocks") ?: JSONArray()
            for (i in 0 until blocks.length()) {
                val b = blocks.getJSONObject(i)
                if (!active(b)) continue
                val st = base + b.optInt("startMin") * 60_000L
                val en = base + b.optInt("endMin") * 60_000L
                if (st > now + 5_000L && st < best) best = st
                if (en > now + 5_000L && en < best) best = en
            }
        }
        PrayerScheduler.next(c, now)?.let { if (it.at > now + 5_000L && it.at < best) best = it.at + 2_000L }
        DayflowAlarms.scheduleNextWidgetRefresh(c, best)
    }

    private fun render(c: Context, m: AppWidgetManager, cls: Class<*>, layout: Int): Boolean {
        val ids = m.getAppWidgetIds(ComponentName(c, cls))
        if (ids.isEmpty()) return false
        val v = RemoteViews(c.packageName, layout)
        val s = snapshot(c)
        val today = DayflowAlarms.todayStr()
        val fresh = s.optString("date") == today
        val blocks = if (fresh) (s.optJSONArray("blocks") ?: JSONArray()) else JSONArray()
        val cur = current(blocks)
        val next = upcoming(blocks, cur?.optString("id"), 5)
        val sceneId = if (fresh) s.optString("scene", "") else ""
        val waterMl = DayflowAlarms.getWaterTodayMl(c)
        val occObj = if (fresh) s.optJSONObject("occasion")?.takeUnless { DayflowAlarms.isExcludedReligion(it) } else null
        v.setOnClickPendingIntent(R.id.w_root, openApp(c))

        if (layout != R.layout.widget_prayer) {
            if (cur != null) {
                v.setTextViewText(R.id.w_title, cur.optString("title"))
                val note = cur.optString("note").takeIf { it.isNotBlank() }?.let { " · $it" } ?: ""
                v.setTextViewText(R.id.w_sub, "${hhmm(c, cur.optInt("startMin"))} – ${hhmm(c, cur.optInt("endMin"))}$note")
                val endAt = midnight() + cur.optInt("endMin") * 60_000L
                if (endAt > System.currentTimeMillis()) {
                    v.setViewVisibility(R.id.w_timer, View.VISIBLE)
                    v.setChronometer(R.id.w_timer, SystemClock.elapsedRealtime() + (endAt - System.currentTimeMillis()), null, true)
                    v.setChronometerCountDown(R.id.w_timer, true)
                } else v.setViewVisibility(R.id.w_timer, View.GONE)
                v.setViewVisibility(R.id.w_done, View.VISIBLE)
                v.setOnClickPendingIntent(R.id.w_done, pi(c, 101, "DONE", mapOf("block_id" to cur.optString("id"))))
            } else {
                val first = next.firstOrNull()
                v.setTextViewText(
                    R.id.w_title,
                    if (first != null) "${L10n.t(c, "next")}: ${first.optString("title")}"
                    else L10n.t(c, if (blocks.length() == 0) "free_day" else "no_activity")
                )
                val firstNote = first?.optString("note")?.takeIf { it.isNotBlank() }?.let { " · $it" } ?: ""
                v.setTextViewText(R.id.w_sub, if (first != null) "${hhmm(c, first.optInt("startMin"))}$firstNote" else "")
                v.setViewVisibility(R.id.w_timer, View.GONE)
                v.setViewVisibility(R.id.w_done, View.GONE)
            }
        }

        if (layout == R.layout.widget_compact) {
            val second = if (cur != null) next.firstOrNull() else next.getOrNull(1)
            val txt = second?.let { "${L10n.t(c, "next")} · ${hhmm(c, it.optInt("startMin"))} ${it.optString("title")}" }
                ?: occObj?.let { "✨ ${it.optString("name")}" }
                ?: ""
            v.setTextViewText(R.id.w_next, txt)
        }

        if (layout == R.layout.widget_medium || layout == R.layout.widget_large) {
            var planned = 0; var done = 0
            for (i in 0 until blocks.length()) {
                val b = blocks.getJSONObject(i)
                val st = b.optString("status")
                if (st == "cancelled") continue
                val d = (b.optInt("endMin") - b.optInt("startMin")).coerceAtLeast(0)
                planned += d
                if (st == "done") done += d else if (st == "partial") done += d / 2
            }
            val pct = if (planned > 0) (done * 100 / planned).coerceIn(0, 100) else 0
            v.setProgressBar(R.id.w_progress, 100, pct, false)
            v.setTextViewText(R.id.w_progress_label, "${L10n.t(c, "progress")} $pct%")
            val rows = intArrayOf(R.id.w_row1, R.id.w_row2, R.id.w_row3, R.id.w_row4, R.id.w_row5)
            val maxRows = if (layout == R.layout.widget_medium) 2 else 5
            for (i in 0 until maxRows) {
                if (i < next.size) {
                    val b = next[i]
                    val n = b.optString("note").takeIf { it.isNotBlank() }?.let { " — $it" } ?: ""
                    v.setViewVisibility(rows[i], View.VISIBLE)
                    v.setTextViewText(rows[i], "${hhmm(c, b.optInt("startMin"))}  ${b.optString("title")}$n")
                } else v.setViewVisibility(rows[i], View.GONE)
            }
            v.setOnClickPendingIntent(R.id.w_water, pi(c, 102, "WATER"))
            v.setTextViewText(R.id.w_water, "💧 $waterMl")
        }

        if (layout == R.layout.widget_medium) {
            v.setImageViewResource(R.id.w_season_icon, seasonalDrawable(sceneId))
            if (occObj != null) {
                v.setViewVisibility(R.id.w_occ_chip, View.VISIBLE)
                val off = if (occObj.optBoolean("official")) " · ${L10n.t(c, "official_holiday")}" else ""
                v.setTextViewText(R.id.w_occ_chip, "✨ ${occObj.optString("name")}$off")
            } else v.setViewVisibility(R.id.w_occ_chip, View.GONE)
        }

        if (layout == R.layout.widget_large) {
            v.setImageViewResource(R.id.w_season_icon, seasonalDrawable(sceneId))
            val loc = if (L10n.lang(c) == "en") Locale.ENGLISH else Locale("ar", "EG")
            val dateText = if (fresh && s.optString("dateLabel").isNotBlank()) s.optString("dateLabel")
            else SimpleDateFormat("EEEE، d MMMM", loc).format(Date())
            val hijri = if (fresh) s.optString("hijriLabel") else ""
            v.setTextViewText(R.id.w_date, dateText)
            v.setTextViewText(R.id.w_hijri, hijri)
            val occLine = if (occObj != null) {
                val off = if (occObj.optBoolean("official")) " · ${L10n.t(c, "official_holiday")}" else ""
                "✨ ${occObj.optString("name")}$off"
            } else {
                val cnt = PrayerScheduler.prayedCountToday(c)
                val g = if (fresh) s.optString("greeting") else ""
                if (g.isNotBlank()) "$g · ${L10n.t(c, "prayed_done", cnt)}" else L10n.t(c, "prayer_stats", cnt)
            }
            v.setTextViewText(R.id.w_occasion, occLine)
        }

        if (layout == R.layout.widget_large || layout == R.layout.widget_prayer) {
            val np = PrayerScheduler.next(c)
            if (np != null) {
                v.setTextViewText(R.id.w_prayer_name, "${L10n.t(c, "next_prayer")}: ${L10n.t(c, np.name)}")
                v.setTextViewText(R.id.w_prayer_time, fmtTime(c, np.at))
                v.setChronometer(R.id.w_prayer_timer, SystemClock.elapsedRealtime() + (np.at - System.currentTimeMillis()), null, true)
                v.setChronometerCountDown(R.id.w_prayer_timer, true)
                v.setProgressBar(R.id.w_prayer_progress, 1000, np.progressPermille, false)
                if (layout == R.layout.widget_prayer) {
                    val prayed = PrayerScheduler.prayedSetToday(c)
                    v.setTextViewText(R.id.w_prayer_stats, L10n.t(c, "prayer_stats", prayed.size))
                    val strip = PrayerTimes.FARD.joinToString("  ") { p ->
                        val sName = L10n.t(c, "${p}_s")
                        if (p in prayed) "$sName✓" else "$sName·"
                    }
                    v.setTextViewText(R.id.w_prayer_strip, strip)
                    v.setOnClickPendingIntent(R.id.w_prayed, pi(c, 103, "PRAYED", mapOf("prayer" to np.prevName)))
                }
            } else {
                v.setTextViewText(R.id.w_prayer_name, L10n.t(c, "next_prayer"))
                v.setTextViewText(R.id.w_prayer_time, "—")
            }
        }
        m.updateAppWidget(ids, v)
        return true
    }
}
