package com.dayflow.app

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

/**
 * DAYFLOW native application setup.
 * Registers all notification channels before any broadcast can post:
 *  - CHANNEL_BLOCKS: activity reminders, tasks, water & eligible occasions (default tone).
 *  - CHANNEL_ALARM_RING: silent high-importance channel used whenever AlarmAudioService
 *    plays custom music / alarm tone / TTS / adhan — guarantees zero double-ringing.
 *  - CHANNEL_PRAYER: gentle/high-importance prayer alerts (for users managing system settings).
 *  - CHANNEL_MISC: silent low-importance channel for quiet hours & foreground service notice.
 */
class DayflowApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createChannels(this)
        val p = DayflowAlarms.prefs(this)
        if (!p.contains("boot_recovery")) {
            p.edit().putString("boot_recovery", "registered").apply()
        }
    }

    companion object {
        const val CHANNEL_BLOCKS = "dayflow_blocks"
        const val CHANNEL_ALARM = "dayflow_alarm_ring"
        const val CHANNEL_PRAYER = "dayflow_prayer"
        const val CHANNEL_MISC = "dayflow_misc"

        fun createChannels(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val blocks = NotificationChannel(
                CHANNEL_BLOCKS,
                context.getString(R.string.channel_blocks_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.channel_blocks_desc)
                enableVibration(true)
                enableLights(true)
                lightColor = 0xFF5856D6.toInt()
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                vibrationPattern = longArrayOf(0, 220, 140, 220)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }

            // Silent audio on channel because AlarmAudioService plays custom clip / adhan / TTS
            // with full AudioFocus and volume ramp — avoids overlapping two alarm sounds at once.
            val alarmRing = NotificationChannel(
                CHANNEL_ALARM,
                context.getString(R.string.channel_alarm_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.channel_alarm_desc)
                setSound(null, null)
                enableVibration(false)
                enableLights(true)
                lightColor = 0xFF8E8CFF.toInt()
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setBypassDnd(true)
            }

            val prayer = NotificationChannel(
                CHANNEL_PRAYER,
                context.getString(R.string.channel_prayer_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.channel_prayer_desc)
                setSound(null, null)
                enableVibration(true)
                enableLights(true)
                lightColor = 0xFF0DA271.toInt()
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                vibrationPattern = longArrayOf(0, 250, 180, 250)
            }

            val misc = NotificationChannel(
                CHANNEL_MISC,
                context.getString(R.string.channel_misc_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.channel_misc_desc)
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }

            nm.createNotificationChannels(listOf(blocks, alarmRing, prayer, misc))
        }
    }
}
