package com.dayflow.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * DAYFLOW — single source of truth for native Android alarm scheduling,
 * persistent reboot survival, date-safe water counters, durable action queue,
 * direct SQLite persistence (zero JSON1 requirement), and widget boundary sync.
 */
object DayflowAlarms {
    const val PREFS = "dayflow_alarms"
    private const val KEY_REGISTRY = "registry"
    private const val KEY_PENDING = "pending_actions"
    const val ACTION_TRIGGER = "com.dayflow.app.ALARM_TRIGGER"
    const val ACTION_WIDGET_TICK = "com.dayflow.app.WIDGET_TICK"
    const val ACTION_CLOSE_RING = "com.dayflow.app.CLOSE_RING"
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun todayStr(): String = dayFmt.format(Date())
    fun requestCode(id: String): Int = id.hashCode()
    fun notificationId(id: String): Int = (id.hashCode() and 0x7fffffff).let { if (it == 0x0DAF || it == 0x0DA1 || it == 0) it + 17 else it }

    /* ---------------- date-safe water tracker ---------------- */
    @Synchronized fun getWaterTodayMl(c: Context): Int {
        val p = prefs(c)
        val savedDate = p.getString("water_date", "")
        val today = todayStr()
        if (savedDate != today) {
            p.edit().putString("water_date", today).putInt("water_today_ml", 0).apply()
            return 0
        }
        return p.getInt("water_today_ml", 0)
    }

    @Synchronized fun setWaterTodayMl(c: Context, ml: Int, target: Int? = null) {
        val e = prefs(c).edit().putString("water_date", todayStr()).putInt("water_today_ml", ml.coerceAtLeast(0))
        if (target != null && target > 0) e.putInt("water_target_ml", target)
        e.apply()
    }

    @Synchronized fun addWaterTodayMl(c: Context, deltaMl: Int): Int {
        val next = getWaterTodayMl(c) + deltaMl.coerceAtLeast(0)
        setWaterTodayMl(c, next)
        return next
    }

    /* ---------------- belt-and-suspenders safety guard ---------------- */
    /** Christian and Jewish occasions are never pushed into Android notifications or widgets. */
    fun isExcludedReligion(obj: JSONObject): Boolean {
        val rel = obj.optString("religion", "").lowercase(Locale.US)
        val occKind = obj.optString("occasionKind", "").lowercase(Locale.US)
        if (obj.has("notify") && !obj.optBoolean("notify", true)) return true
        return occKind == "christian" || occKind == "jewish" ||
            rel.contains("christian") || rel.contains("jewish") ||
            rel.contains("مسيح") || rel.contains("يهود")
    }

    /* ---------------- persistent registry ---------------- */
    @Synchronized fun readRegistry(c: Context): JSONArray =
        try { JSONArray(prefs(c).getString(KEY_REGISTRY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    @Synchronized fun writeRegistry(c: Context, a: JSONArray) {
        prefs(c).edit().putString(KEY_REGISTRY, a.toString()).apply()
    }

    @Synchronized fun upsert(c: Context, alarm: JSONObject) {
        val id = alarm.optString("id")
        val old = readRegistry(c)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val a = old.getJSONObject(i)
            if (a.optString("id") != id) out.put(a)
        }
        out.put(alarm)
        writeRegistry(c, out)
    }

    @Synchronized fun remove(c: Context, id: String) {
        val old = readRegistry(c)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val a = old.getJSONObject(i)
            if (a.optString("id") != id) out.put(a)
        }
        writeRegistry(c, out)
    }

    fun find(c: Context, id: String): JSONObject? {
        val r = readRegistry(c)
        for (i in 0 until r.length()) {
            val a = r.getJSONObject(i)
            if (a.optString("id") == id) return a
        }
        return null
    }

    /* ---------------- scheduling ---------------- */
    fun canExact(c: Context): Boolean {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
    }

    private fun triggerIntent(c: Context, id: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).apply {
            action = ACTION_TRIGGER
            setPackage(c.packageName)
            putExtra("alarm_id", id)
        }
        return PendingIntent.getBroadcast(
            c, requestCode(id), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * Persist and arm a real AlarmManager wake-up alarm.
     * Returns exact delivery class: "alarm_clock" | "exact" | "inexact" | "past" | "excluded".
     */
    fun schedule(c: Context, alarm: JSONObject): String {
        if (isExcludedReligion(alarm)) return "excluded"
        val id = alarm.optString("id")
        val at = alarm.optLong("triggerAtMillis")
        if (id.isEmpty() || at <= System.currentTimeMillis() - 1000L) return "past"
        upsert(c, alarm)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = triggerIntent(c, id)
        val kind = alarm.optString("kind", "block")
        val exact = canExact(c)
        val delivery = try {
            when {
                (kind == "user_alarm" || alarm.optBoolean("isCritical")) && exact -> {
                    val show = PendingIntent.getActivity(
                        c, requestCode("show:$id"),
                        Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
                    "alarm_clock"
                }
                exact -> {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    "exact"
                }
                else -> {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    "inexact"
                }
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            "inexact"
        }
        setLastScheduleResult(c, "$delivery:$kind:$id")
        return delivery
    }

    /** Schedule a gentle widget refresh at the next block boundary / midnight so widgets never go stale. */
    fun scheduleNextWidgetRefresh(c: Context, atMillis: Long) {
        if (atMillis <= System.currentTimeMillis() + 5_000L) return
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(c, WidgetTickReceiver::class.java).apply { action = ACTION_WIDGET_TICK; setPackage(c.packageName) }
        val pi = PendingIntent.getBroadcast(c, 0x0DF7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC, atMillis, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC, atMillis, pi)
        } catch (_: Exception) {
            am.set(AlarmManager.RTC, atMillis, pi)
        }
    }

    fun cancel(c: Context, id: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(triggerIntent(c, id))
        remove(c, id)
        Notifier.cancel(c, id)
    }

    /** Cancel every alarm in [kinds] not in [keep] — makes sync completely idempotent (no dupes). */
    @Synchronized fun cancelStale(c: Context, kinds: Set<String>, keep: Set<String>): Int {
        val r = readRegistry(c)
        var n = 0
        for (i in 0 until r.length()) {
            val a = r.getJSONObject(i)
            val id = a.optString("id")
            if (a.optString("kind") in kinds && id !in keep) {
                cancel(c, id)
                n++
            }
        }
        return n
    }

    /** Re-arm all future entries after reboot, time/timezone change, app update, or permission grant. */
    fun rearmAll(c: Context): Int {
        val r = readRegistry(c)
        var n = 0
        val now = System.currentTimeMillis()
        for (i in 0 until r.length()) {
            val a = r.getJSONObject(i)
            val kind = a.optString("kind")
            if (kind == "prayer" || kind == "user_alarm") continue // recomputed accurately below
            if (a.optLong("triggerAtMillis") > now) {
                val res = schedule(c, a)
                if (res != "past" && res != "excluded") n++
            } else {
                remove(c, a.optString("id"))
            }
        }
        n += UserAlarms.rescheduleAll(c)
        n += PrayerScheduler.reschedule(c)
        return n
    }

    /* ---------------- native → JS durable action queue ---------------- */
    @Synchronized fun enqueuePendingAction(c: Context, action: String, refId: String, extra: JSONObject? = null) {
        val arr = try { JSONArray(prefs(c).getString(KEY_PENDING, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val o = JSONObject()
            .put("id", "$refId:$action:${System.currentTimeMillis()}")
            .put("action", action)
            .put("blockId", refId)
            .put("at", System.currentTimeMillis())
        if (extra != null) o.put("extra", extra)
        arr.put(o)
        // Bounded safety cap
        val capped = JSONArray()
        val start = maxOf(0, arr.length() - 500)
        for (i in start until arr.length()) capped.put(arr.get(i))
        prefs(c).edit().putString(KEY_PENDING, capped.toString()).apply()
    }

    @Synchronized fun drainPendingActions(c: Context): JSONArray {
        val arr = try { JSONArray(prefs(c).getString(KEY_PENDING, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        prefs(c).edit().putString(KEY_PENDING, "[]").apply()
        return arr
    }

    /* ---------------- direct SQLite persistence (zero JSON1 needed) ---------------- */
    private fun openDb(c: Context): SQLiteDatabase? {
        val f = listOf(c.getDatabasePath("dayflowSQLite.db"), c.getDatabasePath("dayflow.db")).firstOrNull { it.exists() } ?: return null
        return try { SQLiteDatabase.openDatabase(f.absolutePath, null, SQLiteDatabase.OPEN_READWRITE) } catch (_: Exception) { null }
    }

    fun patchBlockStatusDirect(c: Context, blockId: String, status: String): Boolean {
        val db = openDb(c) ?: return false
        return try {
            db.rawQuery("SELECT data FROM activity_blocks WHERE id = ?", arrayOf(blockId)).use { cur ->
                if (!cur.moveToFirst()) return false
                val o = JSONObject(cur.getString(0))
                if (o.optString("status") == "done" && status != "planned") return true
                val cal = Calendar.getInstance()
                val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
                val nowMs = System.currentTimeMillis()
                o.put("status", status).put("updatedAt", nowMs)
                if (status == "in_progress" && o.isNull("actualStartMin")) o.put("actualStartMin", nowMin)
                if (status == "done" || status == "partial") o.put("actualEndMin", nowMin)
                db.execSQL("UPDATE activity_blocks SET data = ?, updated_at = ? WHERE id = ?", arrayOf<Any>(o.toString(), nowMs, blockId))
            }
            true
        } catch (_: Exception) { false } finally { try { db.close() } catch (_: Exception) {} }
    }

    fun patchTaskDoneDirect(c: Context, taskId: String): Boolean {
        val db = openDb(c) ?: return false
        return try {
            db.rawQuery("SELECT data FROM tasks WHERE id = ?", arrayOf(taskId)).use { cur ->
                if (!cur.moveToFirst()) return false
                val o = JSONObject(cur.getString(0))
                val nowMs = System.currentTimeMillis()
                o.put("status", "done").put("updatedAt", nowMs)
                db.execSQL("UPDATE tasks SET data = ?, updated_at = ? WHERE id = ?", arrayOf<Any>(o.toString(), nowMs, taskId))
            }
            true
        } catch (_: Exception) { false } finally { try { db.close() } catch (_: Exception) {} }
    }

    fun writePrayerLogDirect(c: Context, date: String, prayer: String): Boolean {
        val db = openDb(c) ?: return false
        return try {
            val id = "$date:$prayer"
            val nowMs = System.currentTimeMillis()
            val o = JSONObject().put("id", id).put("date", date).put("prayer", prayer).put("prayedAt", nowMs).put("source", "native")
            db.execSQL("INSERT OR REPLACE INTO prayer_logs (id, updated_at, data) VALUES (?, ?, ?)", arrayOf<Any>(id, nowMs, o.toString()))
            true
        } catch (_: Exception) { false } finally { try { db.close() } catch (_: Exception) {} }
    }

    fun writeWaterLogDirect(c: Context, ml: Int): Boolean {
        val db = openDb(c) ?: return false
        return try {
            val nowMs = System.currentTimeMillis()
            val cal = Calendar.getInstance()
            val id = "w-$nowMs"
            val o = JSONObject().put("id", id).put("date", todayStr())
                .put("timeMin", cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE))
                .put("amountMl", ml).put("createdAt", nowMs)
            db.execSQL("INSERT OR REPLACE INTO water_logs (id, updated_at, data) VALUES (?, ?, ?)", arrayOf<Any>(id, nowMs, o.toString()))
            true
        } catch (_: Exception) { false } finally { try { db.close() } catch (_: Exception) {} }
    }

    fun broadcastCloseRing(c: Context) {
        c.sendBroadcast(Intent(ACTION_CLOSE_RING).setPackage(c.packageName))
    }

    fun markBootRecovery(c: Context, state: String) {
        prefs(c).edit().putString("boot_recovery", state).putLong("boot_recovery_at", System.currentTimeMillis()).apply()
    }

    fun setLastScheduleResult(c: Context, r: String) {
        prefs(c).edit().putString("last_schedule_result", r).putLong("last_schedule_at", System.currentTimeMillis()).apply()
    }

    fun nextPending(c: Context): JSONObject? {
        val r = readRegistry(c)
        var best: JSONObject? = null
        val now = System.currentTimeMillis()
        for (i in 0 until r.length()) {
            val a = r.getJSONObject(i)
            val t = a.optLong("triggerAtMillis")
            if (t > now && (best == null || t < best.optLong("triggerAtMillis"))) best = a
        }
        return best
    }
}
