package com.dayflow.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(DayflowNativePlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
