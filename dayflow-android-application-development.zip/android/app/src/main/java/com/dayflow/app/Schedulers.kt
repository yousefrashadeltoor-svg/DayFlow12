package com.dayflow.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.*

/**
 * Full-featured native user alarm clock:
 * repeating weekdays (or one-shot auto-disable), exact setAlarmClock,
 * snooze interval, max snoozes, repeat count, custom song + trimmed clip
 * [clipStartMs, clipEndMs], phone ringtone, alarm tone, volume, gradual fade-in,
 * vibration, and optional Arabic/English TTS announcement of the label.
 */
object UserAlarms {
    private const val KEY = "user_alarms"

    fun all(c: Context): JSONArray =
        try { JSONArray(DayflowAlarms.prefs(c).getString(KEY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun save(c: Context, a: JSONArray) {
        DayflowAlarms.prefs(c).edit().putString(KEY, a.toString()).apply()
    }

    @Synchronized fun upsert(c: Context, cfg: JSONObject): Long {
        val id = cfg.optString("id")
        val old = all(c)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val a = old.getJSONObject(i)
            if (a.optString("id") != id) out.put(a)
        }
        out.put(cfg)
        save(c, out)
        // Reset snooze count whenever user explicitly updates the alarm
        DayflowAlarms.prefs(c).edit().remove("snoozes:$id").apply()
        return schedule(c, cfg)
    }

    @Synchronized fun delete(c: Context, id: String) {
        val old = all(c)
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val a = old.getJSONObject(i)
            if (a.optString("id") != id) out.put(a)
        }
        save(c, out)
        DayflowAlarms.prefs(c).edit().remove("snoozes:$id").apply()
        DayflowAlarms.cancel(c, "ualarm:$id")
    }

    /** Next trigger strictly after [from]. days: 0=Sun..6=Sat; empty = one-shot. */
    fun nextTrigger(cfg: JSONObject, from: Long = System.currentTimeMillis()): Long {
        val days = cfg.optJSONArray("days") ?: JSONArray()
        val set = (0 until days.length()).map { days.getInt(it) }.toSet()
        val cal = Calendar.getInstance().apply {
            timeInMillis = from
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        for (d in 0..7) {
            val c2 = (cal.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, d)
                set(Calendar.HOUR_OF_DAY, cfg.optInt("hour"))
                set(Calendar.MINUTE, cfg.optInt("minute"))
            }
            if (c2.timeInMillis <= from) continue
            if (set.isEmpty() || (c2.get(Calendar.DAY_OF_WEEK) - 1) in set) return c2.timeInMillis
        }
        return -1L
    }

    fun schedule(c: Context, cfg: JSONObject, from: Long = System.currentTimeMillis()): Long {
        val id = cfg.optString("id")
        if (!cfg.optBoolean("enabled", true)) {
            DayflowAlarms.cancel(c, "ualarm:$id")
            return -1L
        }
        val at = nextTrigger(cfg, from)
        if (at <= 0L) return -1L
        DayflowAlarms.schedule(c, payload(c, cfg, at))
        return at
    }

    fun payload(c: Context, cfg: JSONObject, at: Long): JSONObject {
        val label = cfg.optString("label").ifBlank { if (L10n.lang(c) == "en") "Alarm" else "منبه" }
        val toneUri = cfg.optString("toneUri")
        val timeFmt = if (DayflowAlarms.prefs(c).getBoolean("hour12", false)) "hh:mm a" else "HH:mm"
        val toneName = cfg.optString("toneName")
        val body = SimpleDateFormat(timeFmt, Locale.US).format(Date(at)) +
            if (toneName.isNotBlank()) " · $toneName" else ""
        return JSONObject()
            .put("id", "ualarm:${cfg.optString("id")}")
            .put("refId", cfg.optString("id"))
            .put("kind", "user_alarm")
            .put("triggerAtMillis", at)
            .put("startAtMillis", at)
            .put("title", "⏰ $label")
            .put("body", body)
            .put("label", label)
            .put("toneUri", toneUri)
            .put("sound", if (toneUri.isEmpty()) "alarm" else toneUri)
            .put("clipStartMs", cfg.optInt("clipStartMs", 0))
            .put("clipEndMs", cfg.optInt("clipEndMs", 0))
            .put("repeatCount", cfg.optInt("repeatCount", 20).coerceIn(1, 30))
            .put("volume", cfg.optDouble("volume", 1.0))
            .put("gradual", cfg.optBoolean("gradual", true))
            .put("vibrate", cfg.optBoolean("vibrate", true))
            .put("speakLabel", cfg.optBoolean("speakLabel", false))
            .put("snoozeMin", cfg.optInt("snoozeMin", 10))
            .put("maxSnoozes", cfg.optInt("maxSnoozes", 3))
            .put("isCritical", true)
    }

    private fun cfgFor(c: Context, alarm: JSONObject): JSONObject? {
        val id = alarm.optString("refId")
        val a = all(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).optString("id") == id) return a.getJSONObject(i)
        return null
    }

    fun snoozeCount(c: Context, id: String) = DayflowAlarms.prefs(c).getInt("snoozes:$id", 0)
    fun canSnooze(c: Context, alarm: JSONObject) = snoozeCount(c, alarm.optString("refId")) < alarm.optInt("maxSnoozes", 3)

    fun snooze(c: Context, alarm: JSONObject) {
        AlarmAudioService.stop(c)
        Notifier.cancel(c, alarm.optString("id"))
        DayflowAlarms.broadcastCloseRing(c)
        val ref = alarm.optString("refId")
        if (!canSnooze(c, alarm)) { dismiss(c, alarm); return }
        val sn = alarm.optInt("snoozeMin", 10).coerceIn(1, 60)
        DayflowAlarms.prefs(c).edit().putInt("snoozes:$ref", snoozeCount(c, ref) + 1).apply()
        val at = System.currentTimeMillis() + sn * 60_000L
        val timeFmt = if (DayflowAlarms.prefs(c).getBoolean("hour12", false)) "hh:mm a" else "HH:mm"
        DayflowAlarms.schedule(c, JSONObject(alarm.toString())
            .put("triggerAtMillis", at)
            .put("body", SimpleDateFormat(timeFmt, Locale.US).format(Date(at))))
        DayflowAlarms.enqueuePendingAction(c, "ALARM_SNOOZE", ref, JSONObject().put("minutes", sn).put("title", alarm.optString("label")))
    }

    fun dismiss(c: Context, alarm: JSONObject) {
        AlarmAudioService.stop(c)
        Notifier.cancel(c, alarm.optString("id"))
        DayflowAlarms.broadcastCloseRing(c)
        val ref = alarm.optString("refId")
        DayflowAlarms.prefs(c).edit().remove("snoozes:$ref").apply()
        DayflowAlarms.remove(c, alarm.optString("id"))
        val cfg = cfgFor(c, alarm)
        if (cfg != null) {
            val days = cfg.optJSONArray("days")
            if (days == null || days.length() == 0) {
                cfg.put("enabled", false)
                upsert(c, cfg)
                DayflowAlarms.enqueuePendingAction(c, "ALARM_OFF", ref, JSONObject().put("title", alarm.optString("label")))
            } else {
                schedule(c, cfg, System.currentTimeMillis() + 61_000L)
            }
        }
        DayflowAlarms.enqueuePendingAction(c, "ALARM_DISMISS", ref, JSONObject().put("title", alarm.optString("label")))
    }

    fun rescheduleAll(c: Context): Int {
        val a = all(c)
        var count = 0
        for (i in 0 until a.length()) {
            if (schedule(c, a.getJSONObject(i)) > 0L) count++
        }
        return count
    }
}

/**
 * Astronomical prayer times — Egyptian General Authority of Survey:
 *   Fajr 19.5° below horizon · Isha 17.5° · Asr Shafi'i (shadow ratio 1) ·
 *   Sunrise/Maghrib 0.833° (atmospheric refraction + solar disc).
 * Respects device timezone including Egyptian summer DST automatically.
 * Bit-for-bit identical algorithm to src/lib/prayer.ts.
 */
object PrayerTimes {
    val NAMES = listOf("fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha")
    val FARD = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")
    private fun dtr(d: Double) = d * PI / 180.0
    private fun rtd(r: Double) = r * 180.0 / PI
    private fun fix(a: Double, b: Double) = (a - b * floor(a / b)).let { if (it < 0) it + b else it }

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0; var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0); val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private fun sun(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fix(357.529 + 0.98560028 * d, 360.0)
        val q = fix(280.459 + 0.98564736 * d, 360.0)
        val l = fix(q + 1.915 * sin(dtr(g)) + 0.020 * sin(dtr(2 * g)), 360.0)
        val e = 23.439 - 0.00000036 * d
        val ra = fix(rtd(atan2(cos(dtr(e)) * sin(dtr(l)), cos(dtr(l)))) / 15.0, 24.0)
        val eqt = q / 15.0 - ra
        val decl = rtd(asin(sin(dtr(e)) * sin(dtr(l))))
        return decl to eqt
    }

    fun compute(cal: Calendar, lat: Double, lng: Double, adjust: JSONObject? = null): Map<String, Int> {
        val y = cal.get(Calendar.YEAR); val m = cal.get(Calendar.MONTH) + 1; val dd = cal.get(Calendar.DAY_OF_MONTH)
        val noon = (cal.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0) }
        val tz = TimeZone.getDefault().getOffset(noon.timeInMillis) / 3600000.0
        val jd = julian(y, m, dd) - lng / (15.0 * 24.0)
        fun midDay(t: Double) = fix(12 - sun(jd + t).second, 24.0)
        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sun(jd + t).first; val noonT = midDay(t)
            val v = (-sin(dtr(angle)) - sin(dtr(decl)) * sin(dtr(lat))) / (cos(dtr(decl)) * cos(dtr(lat)))
            val tt = rtd(acos(v.coerceIn(-1.0, 1.0))) / 15.0
            return noonT + if (ccw) -tt else tt
        }
        fun asr(t: Double): Double {
            val decl = sun(jd + t).first
            val angle = -rtd(atan(1.0 / (1.0 + tan(dtr(abs(lat - decl))))))
            return angleTime(angle, t, false)
        }
        var times = doubleArrayOf(5.0, 6.0, 12.0, 13.0, 18.0, 18.0).map { it / 24.0 }.toDoubleArray()
        repeat(2) {
            times = doubleArrayOf(
                angleTime(19.5, times[0], true), angleTime(0.833, times[1], true), midDay(times[2]),
                asr(times[3]), angleTime(0.833, times[4], false), angleTime(17.5, times[5], false)
            ).map { it / 24.0 }.toDoubleArray()
        }
        val out = LinkedHashMap<String, Int>()
        NAMES.forEachIndexed { i, n ->
            val h = times[i] * 24.0 + tz - lng / 15.0
            out[n] = (floor(fix(h, 24.0) * 60.0 + 0.5)).toInt() + (adjust?.optInt(n, 0) ?: 0)
        }
        return out
    }
}

data class NextPrayerInfo(val name: String, val at: Long, val prevName: String, val prevAt: Long, val progressPermille: Int)

object PrayerScheduler {
    private val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun cfg(c: Context): JSONObject? =
        DayflowAlarms.prefs(c).getString("prayer_cfg", null)?.let { try { JSONObject(it) } catch (_: Exception) { null } }

    private fun startOfDay(offsetDays: Int): Calendar = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, offsetDays)
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }

    private fun fmtMin(c: Context, min: Int): String {
        val m = ((min % 1440) + 1440) % 1440
        val h = m / 60; val mm = m % 60
        return if (DayflowAlarms.prefs(c).getBoolean("hour12", false)) {
            val h12 = if (h % 12 == 0) 12 else h % 12
            val ap = if (L10n.lang(c) == "en") (if (h >= 12) "PM" else "AM") else (if (h >= 12) "م" else "ص")
            String.format(Locale.US, "%d:%02d %s", h12, mm, ap)
        } else String.format(Locale.US, "%02d:%02d", h, mm)
    }

    /** Arms today + tomorrow prayer alerts and optional pre-adhan alerts; cancels stale ones. */
    fun reschedule(c: Context): Int {
        val cfg = cfg(c)
        if (cfg == null || !cfg.optBoolean("enabled", false)) {
            DayflowAlarms.cancelStale(c, setOf("prayer"), emptySet())
            return 0
        }
        val keep = HashSet<String>()
        val on = cfg.optJSONObject("on") ?: JSONObject()
        val pre = cfg.optInt("preMin", 0).coerceIn(0, 60)
        val lat = cfg.optDouble("lat", 30.0444)
        val lng = cfg.optDouble("lng", 31.2357)
        val place = cfg.optString("place", "القاهرة")
        val adjust = cfg.optJSONObject("adjust")
        val now = System.currentTimeMillis()
        var armed = 0

        for (d in 0..1) {
            val day = startOfDay(d)
            val date = df.format(day.time)
            val times = PrayerTimes.compute(day, lat, lng, adjust)
            for ((name, min) in times) {
                if (!on.optBoolean(name, name != "sunrise")) continue
                val at = day.timeInMillis + min * 60_000L
                val pname = L10n.t(c, name)
                val hm = fmtMin(c, min)
                if (at > now) {
                    val id = "prayer:$name:$date"
                    keep.add(id)
                    val res = DayflowAlarms.schedule(c, JSONObject()
                        .put("id", id).put("refId", id).put("kind", "prayer").put("phase", "adhan")
                        .put("prayer", name).put("date", date)
                        .put("triggerAtMillis", at).put("startAtMillis", at)
                        .put("title", if (name == "sunrise") "🌅 $pname · $hm" else "🕌 ${L10n.t(c, "prayer_title", pname)}")
                        .put("body", "$hm · $place")
                        .put("sound", if (name == "sunrise") "default" else cfg.optString("sound", "alarm"))
                        .put("toneUri", if (name == "sunrise") "" else cfg.optString("toneUri"))
                        .put("repeatCount", 1).put("gradual", false).put("vibrate", true)
                        .put("label", L10n.t(c, "prayer_title", pname))
                        .put("speakLabel", name != "sunrise" && cfg.optBoolean("speak", false))
                        .put("snoozeMin", 10))
                    if (res != "past") armed++
                }
                if (pre > 0 && name != "sunrise" && at - pre * 60_000L > now) {
                    val id = "prayer:$name:$date:pre"
                    keep.add(id)
                    val res = DayflowAlarms.schedule(c, JSONObject()
                        .put("id", id).put("refId", id).put("kind", "prayer").put("phase", "pre")
                        .put("prayer", name).put("date", date)
                        .put("triggerAtMillis", at - pre * 60_000L).put("startAtMillis", at)
                        .put("title", "⏳ ${L10n.t(c, "prayer_pre", pre, pname)}")
                        .put("body", "$hm · $place")
                        .put("sound", "default").put("vibrate", true).put("snoozeMin", 5))
                    if (res != "past") armed++
                }
            }
        }
        DayflowAlarms.cancelStale(c, setOf("prayer"), keep)
        return armed
    }

    fun markPrayed(c: Context, name: String, date: String = df.format(Date())) {
        if (name !in PrayerTimes.FARD) return
        val key = "prayed:$date"
        val p = DayflowAlarms.prefs(c)
        val set = HashSet(p.getStringSet(key, emptySet()) ?: emptySet())
        set.add(name)
        p.edit().putStringSet(key, set).apply()
        DayflowAlarms.writePrayerLogDirect(c, date, name)
    }

    fun prayedSetToday(c: Context): Set<String> =
        HashSet(DayflowAlarms.prefs(c).getStringSet("prayed:" + df.format(Date()), emptySet()) ?: emptySet())

    fun prayedCountToday(c: Context): Int = prayedSetToday(c).size

    /** Exact previous-to-next prayer span — includes yesterday's Isha right after midnight! */
    fun next(c: Context, now: Long = System.currentTimeMillis()): NextPrayerInfo? {
        val cfg = cfg(c)
        val lat = cfg?.optDouble("lat", 30.0444) ?: 30.0444
        val lng = cfg?.optDouble("lng", 31.2357) ?: 31.2357
        val adjust = cfg?.optJSONObject("adjust")

        val yDay = startOfDay(-1)
        val yTimes = PrayerTimes.compute(yDay, lat, lng, adjust)
        var prevName = "isha"
        var prevAt = yDay.timeInMillis + (yTimes["isha"] ?: (19 * 60)) * 60_000L

        for (d in 0..1) {
            val day = startOfDay(d)
            val times = PrayerTimes.compute(day, lat, lng, adjust)
            for (n in PrayerTimes.FARD) {
                val at = day.timeInMillis + (times[n] ?: 0) * 60_000L
                if (at > now) {
                    val span = (at - prevAt).coerceAtLeast(1L)
                    val pct = (((now - prevAt).coerceIn(0L, span) * 1000L) / span).toInt()
                    return NextPrayerInfo(n, at, prevName, prevAt, pct)
                }
                prevName = n; prevAt = at
            }
        }
        return null
    }
}
