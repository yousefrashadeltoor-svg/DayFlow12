package com.dayflow.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.app.KeyguardManager
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Native alarm & adhan audio foreground service.
 * Fallback order:
 *   1. Custom activity/alarm/prayer audio URI (honouring exact [clipStartMs, clipEndMs])
 *   2. Device Text-to-Speech (Arabic Egyptian / Arabic / English)
 *   3. Selected system default alarm tone
 *   4. System notification sound fallback
 * Full AudioFocus lifecycle (pauses cleanly on phone calls/focus loss), gradual volume ramp,
 * vibration pattern, safety WakeLock with hard timeout, and capped maximum ring time (never infinite).
 */
class AlarmAudioService : Service() {
    companion object {
        private const val FG_ID = 0x0DA1
        fun start(c: Context, alarm: JSONObject) {
            val i = Intent(c, AlarmAudioService::class.java).putExtra("alarm", alarm.toString())
            try {
                ContextCompat.startForegroundService(c, i)
            } catch (_: Exception) {
                // On strict Android 12+ states if FGS start throws, fall back to a brief single ringtone
                try {
                    val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    val rt = RingtoneManager.getRingtone(c, uri)
                    if (Build.VERSION.SDK_INT >= 28) rt?.isLooping = false
                    rt?.play()
                } catch (_: Exception) {}
            }
        }
        fun stop(c: Context) {
            c.stopService(Intent(c, AlarmAudioService::class.java))
        }
    }

    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private var loops = 0
    private var maxLoops = 1
    private var repeatGapMs = 0L
    private var clipStart = 0
    private var clipEnd = 0
    private var targetVol = 1f
    private var currentVol = 1f
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioFocusReq: AudioFocusRequest? = null
    private var pausedByFocus = false

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        val mp = player ?: return@OnAudioFocusChangeListener
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                try { if (mp.isPlaying) { mp.pause(); pausedByFocus = true } } catch (_: Exception) {}
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                val duck = (currentVol * 0.25f).coerceAtLeast(0.05f)
                try { mp.setVolume(duck, duck) } catch (_: Exception) {}
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                try {
                    mp.setVolume(currentVol, currentVol)
                    if (pausedByFocus) { mp.start(); pausedByFocus = false }
                } catch (_: Exception) {}
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val alarm = try { JSONObject(intent?.getStringExtra("alarm") ?: "{}") } catch (_: Exception) { JSONObject() }
        val stopPi = PendingIntent.getBroadcast(
            this, 77,
            Intent(this, AlarmStopReceiver::class.java).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, DayflowApplication.CHANNEL_MISC)
            .setSmallIcon(R.drawable.ic_stat_dayflow)
            .setContentTitle(alarm.optString("title", "DAYFLOW"))
            .setContentText(L10n.t(this, "audio_playing"))
            .addAction(0, L10n.t(this, "stop_audio"), stopPi)
            .setOngoing(true).setSilent(true).build()
        ServiceCompat.startForeground(
            this, FG_ID, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )
        releaseAll()

        val kind = alarm.optString("kind")
        val capMs = when (kind) {
            "user_alarm" -> 5 * 60_000L   // hard 5 min safety cap — never an unlimited loop
            "prayer" -> 4 * 60_000L       // fits full adhan comfortably
            else -> 90_000L
        }
        acquireWakeLock(capMs + 5_000L)
        requestFocus()
        play(alarm)
        h.postDelayed({ stopSelf() }, capMs)
        return START_NOT_STICKY
    }

    private fun alarmAttrs(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private fun requestFocus() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(alarmAttrs())
                .setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener(focusListener, h)
                .build()
            audioFocusReq = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(focusListener, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
        }
    }

    private fun abandonFocus() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            audioFocusReq?.let { am.abandonAudioFocusRequest(it) }
            audioFocusReq = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(focusListener)
        }
    }

    private fun acquireWakeLock(timeoutMs: Long) {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dayflow:alarm_audio").apply {
                setReferenceCounted(false)
                acquire(timeoutMs)
            }
        } catch (_: Exception) {}
    }

    private fun play(alarm: JSONObject) {
        val kind = alarm.optString("kind")
        val defaultMax = if (kind == "user_alarm") 30 else alarm.optInt("repeatCount", 1)
        maxLoops = alarm.optInt("repeatCount", defaultMax).coerceIn(1, 30)
        repeatGapMs = alarm.optLong("repeatGapMs", if (kind == "block") 1200L else 0L).coerceIn(0L, 15_000L)
        clipStart = alarm.optInt("clipStartMs", 0).coerceAtLeast(0)
        clipEnd = alarm.optInt("clipEndMs", 0).coerceAtLeast(0)
        targetVol = alarm.optDouble("volume", 1.0).toFloat().coerceIn(0.1f, 1f)
        val label = alarm.optString("label").ifBlank { alarm.optString("title") }
        val custom = alarm.optString("toneUri").ifEmpty {
            alarm.optString("sound").takeIf { it.startsWith("content://") || it.startsWith("file://") } ?: ""
        }
        val ttsAllowed = DayflowAlarms.prefs(this).getBoolean("tts_fallback", true)
        val speakFirst = alarm.optBoolean("speakLabel", false) || alarm.optString("sound") == "tts"
        val gradual = alarm.optBoolean("gradual", kind == "user_alarm")

        if (alarm.optBoolean("vibrate", true) && (kind == "user_alarm" || kind == "prayer")) vibrate(kind == "user_alarm")

        val startSound = {
            when {
                custom.isNotEmpty() && startPlayer(Uri.parse(custom), gradual) -> Unit
                ttsAllowed && !speakFirst && label.isNotBlank() && kind == "block" ->
                    speak(label) { if (!startDefault(gradual)) stopSelf() }
                startDefault(gradual) -> Unit
                else -> stopSelf()
            }
        }
        if (speakFirst && label.isNotBlank()) speak(label) { startSound() } else startSound()
    }

    private fun startDefault(gradual: Boolean): Boolean {
        val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        if (alarmUri != null && startPlayer(alarmUri, gradual)) return true
        val notifUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        return startPlayer(notifUri, false)
    }

    private fun startPlayer(uri: Uri?, gradual: Boolean): Boolean {
        if (uri == null) return false
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(alarmAttrs())
            mp.setDataSource(this, uri)
            mp.prepare()
            val dur = mp.duration
            if (dur > 0 && clipStart in 1 until dur) mp.seekTo(clipStart)
            if (clipEnd > dur && dur > 0) clipEnd = dur
            currentVol = if (gradual) (targetVol * 0.1f).coerceAtLeast(0.06f) else targetVol
            mp.setVolume(currentVol, currentVol)
            mp.setOnCompletionListener { onLoopEnd() }
            mp.setOnErrorListener { _, _, _ -> stopSelf(); true }
            mp.start()
            player = mp
            if (gradual) rampVolume()
            if (clipEnd > clipStart + 500) watchClip()
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun onLoopEnd() {
        loops++
        val p = player ?: return
        if (loops >= maxLoops) { stopSelf(); return }
        val restart = Runnable {
            val mp = player ?: return@Runnable
            try {
                mp.seekTo(clipStart)
                mp.start()
            } catch (_: Exception) { stopSelf() }
        }
        if (repeatGapMs > 0) {
            try { if (mpIsPlaying(p)) p.pause() } catch (_: Exception) {}
            h.postDelayed(restart, repeatGapMs)
        } else restart.run()
    }

    private fun mpIsPlaying(p: MediaPlayer) = try { p.isPlaying } catch (_: Exception) { false }

    private fun watchClip() {
        h.postDelayed(object : Runnable {
            override fun run() {
                val p = player ?: return
                try {
                    if (p.isPlaying && p.currentPosition >= clipEnd) {
                        onLoopEnd()
                    }
                } catch (_: Exception) { return }
                h.postDelayed(this, 120)
            }
        }, 120)
    }

    private fun rampVolume() {
        val step = targetVol / 18f
        h.postDelayed(object : Runnable {
            override fun run() {
                val p = player ?: return
                currentVol = (currentVol + step).coerceAtMost(targetVol)
                if (!pausedByFocus) try { p.setVolume(currentVol, currentVol) } catch (_: Exception) {}
                if (currentVol < targetVol) h.postDelayed(this, 1000)
            }
        }, 1000)
    }

    private fun speak(text: String, then: () -> Unit) {
        val clean = text.replace(Regex("[⏰🔔🕌💧✨📌✅⏳]"), "").trim()
        if (clean.isEmpty()) { then(); return }
        tts = TextToSpeech(this) { status ->
            val t = tts ?: return@TextToSpeech
            if (status != TextToSpeech.SUCCESS) { then(); return@TextToSpeech }
            val isEn = L10n.lang(this) == "en"
            val r = t.setLanguage(if (isEn) Locale.US else Locale("ar", "EG"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                val r2 = if (isEn) r else t.setLanguage(Locale("ar"))
                if (r2 == TextToSpeech.LANG_MISSING_DATA || r2 == TextToSpeech.LANG_NOT_SUPPORTED) { then(); return@TextToSpeech }
            }
            t.setAudioAttributes(alarmAttrs())
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { h.post { then() } }
                @Deprecated("Deprecated in Java") override fun onError(id: String?) { h.post { then() } }
            })
            t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "dayflow-label")
        }
    }

    private fun vibrate(continuous: Boolean) {
        vibrator = if (Build.VERSION.SDK_INT >= 31) (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as Vibrator)
        val pattern = if (continuous) longArrayOf(0, 550, 350, 550, 850) else longArrayOf(0, 350, 200, 350)
        val repeat = if (continuous) 0 else -1
        try {
            if (Build.VERSION.SDK_INT >= 26) vibrator?.vibrate(VibrationEffect.createWaveform(pattern, repeat))
            else @Suppress("DEPRECATION") vibrator?.vibrate(pattern, repeat)
        } catch (_: Exception) {}
    }

    private fun releaseAll() {
        h.removeCallbacksAndMessages(null)
        pausedByFocus = false
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null; loops = 0
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        try { vibrator?.cancel() } catch (_: Exception) {}
        vibrator = null
        abandonFocus()
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    override fun onDestroy() { releaseAll(); super.onDestroy() }
}

/**
 * Decodes real audio amplitude peaks across an audio file (MP3, M4A, OGG, WAV, FLAC)
 * using Android's native MediaExtractor + MediaCodec — runs on a background thread and
 * skips sparsely so even a 6-minute track completes in ~300 ms offline.
 */
object WaveformExtractor {
    fun extract(context: Context, uri: Uri, bars: Int = 64): Pair<JSONArray, Boolean> {
        val count = bars.coerceIn(16, 120)
        val out = JSONArray()
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        return try {
            extractor.setDataSource(context, uri, null)
            var trackIdx = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) { trackIdx = i; format = f; break }
            }
            if (trackIdx < 0 || format == null) return Pair(out, false)
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
            if (durationUs <= 0L) return Pair(out, false)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            extractor.selectTrack(trackIdx)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val peaks = DoubleArray(count)
            val info = MediaCodec.BufferInfo()
            val stepUs = durationUs / count
            for (slot in 0 until count) {
                val target = slot * stepUs
                extractor.seekTo(target, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                codec.flush()
                var sumSq = 0.0
                var samples = 0
                var tries = 0
                while (tries < 6 && samples < 1024) {
                    tries++
                    val inIdx = codec.dequeueInputBuffer(8_000)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val sz = extractor.readSampleData(buf, 0)
                        if (sz < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        } else {
                            codec.queueInputBuffer(inIdx, 0, sz, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                    val outIdx = codec.dequeueOutputBuffer(info, 8_000)
                    if (outIdx >= 0) {
                        val ob = codec.getOutputBuffer(outIdx)
                        if (ob != null && info.size >= 2) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            val n = sb.remaining().coerceAtMost(2048)
                            var k = 0
                            while (k < n) {
                                val v = sb.get(k) / 32768.0
                                sumSq += v * v
                                samples++
                                k += 2
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
                peaks[slot] = if (samples > 0) sqrt(sumSq / samples) else 0.0
            }
            val hi = peaks.maxOrNull()?.takeIf { it > 0.001 } ?: 1.0
            for (v in peaks) out.put(((abs(v) / hi).coerceIn(0.08, 1.0) * 100.0).toInt() / 100.0)
            Pair(out, true)
        } catch (_: Exception) {
            Pair(JSONArray(), false)
        } finally {
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }
}

/**
 * Native full-screen lock-screen alarm UI.
 * Live clock updates every second, dual animated glow rings, auto-closes cleanly when
 * dismissed or snoozed from the notification shade via package-scoped CLOSE_RING broadcast.
 */
class AlarmRingActivity : Activity() {
    private var alarm: JSONObject = JSONObject()
    private val h = Handler(Looper.getMainLooper())
    private var timeView: TextView? = null
    private val anims = mutableListOf<ObjectAnimator>()
    private var registered = false

    private val closeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { finishSafe() }
    }

    private val clockTick = object : Runnable {
        override fun run() {
            val is12 = DayflowAlarms.prefs(this@AlarmRingActivity).getBoolean("hour12", false)
            val pat = if (is12) "hh:mm" else "HH:mm"
            timeView?.text = SimpleDateFormat(pat, Locale.US).format(Date())
            h.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            km.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_alarm_ring)

        alarm = try { JSONObject(intent.getStringExtra("alarm") ?: "{}") } catch (_: Exception) { JSONObject() }
        timeView = findViewById(R.id.ring_time)
        clockTick.run()

        val loc = if (L10n.lang(this) == "en") Locale.ENGLISH else Locale("ar", "EG")
        findViewById<TextView>(R.id.ring_date)?.text = SimpleDateFormat("EEEE، d MMMM", loc).format(Date())
        findViewById<TextView>(R.id.ring_label).text = alarm.optString("label").ifBlank { alarm.optString("title", "DAYFLOW") }

        val ref = alarm.optString("refId")
        val used = UserAlarms.snoozeCount(this, ref)
        val maxSn = alarm.optInt("maxSnoozes", 3)
        val leftSn = max(0, maxSn - used)
        val snMin = alarm.optInt("snoozeMin", 10)
        val snooze = findViewById<Button>(R.id.ring_snooze)
        snooze.text = if (leftSn > 0) "${L10n.t(this, "alarm_snooze", snMin)} ($leftSn)" else L10n.t(this, "alarm_no_snooze")
        snooze.isEnabled = leftSn > 0
        snooze.alpha = if (leftSn > 0) 1f else 0.35f
        snooze.setOnClickListener { UserAlarms.snooze(this, alarm); finishSafe() }

        findViewById<Button>(R.id.ring_dismiss).apply {
            text = L10n.t(this@AlarmRingActivity, "alarm_dismiss")
            setOnClickListener { UserAlarms.dismiss(this@AlarmRingActivity, alarm); finishSafe() }
        }

        // Smooth paired pulse ripples
        listOf(R.id.ring_pulse to 0L, R.id.ring_pulse2 to 700L).forEach { (id, delay) ->
            findViewById<View>(id)?.let { v ->
                anims += ObjectAnimator.ofPropertyValuesHolder(
                    v,
                    PropertyValuesHolder.ofFloat("scaleX", 0.9f, 1.48f),
                    PropertyValuesHolder.ofFloat("scaleY", 0.9f, 1.48f),
                    PropertyValuesHolder.ofFloat("alpha", 0.6f, 0f)
                ).apply { duration = 1600; startDelay = delay; repeatCount = ObjectAnimator.INFINITE; start() }
            }
        }

        val filter = IntentFilter(DayflowAlarms.ACTION_CLOSE_RING)
        ContextCompat.registerReceiver(this, closeReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true
    }

    private fun finishSafe() {
        if (!isFinishing) {
            if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask() else finish()
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        anims.forEach { it.cancel() }
        if (registered) {
            try { unregisterReceiver(closeReceiver) } catch (_: Exception) {}
            registered = false
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* Deliberately ignore: alarm needs an explicit Snooze or Dismiss. */ }
}
