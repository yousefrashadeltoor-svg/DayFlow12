package com.dayflow.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/**
 * Egyptian colloquial Arabic + clean English copy for every native notification
 * and home-screen widget — obeys the in-app chosen language directly.
 */
object L10n {
    private val ar = mapOf(
        "start_now" to "ابدأ دلوقتي",
        "snooze" to "أجّل %d د",
        "skip" to "تخطّي",
        "done" to "خلصت ✓",
        "partial" to "خلصت جزء",
        "dismiss" to "تمام",
        "prayed" to "صلّيت ✓",
        "stop_audio" to "وقّف الصوت",
        "log_water" to "شربت كوباية 💧",
        "alarm_dismiss" to "إيقاف المنبه",
        "alarm_snooze" to "غفوة %d د",
        "alarm_no_snooze" to "خلصت الغفوات",
        "prayer_title" to "حان دلوقتي موعد صلاة %s",
        "prayer_pre" to "فاضل %d دقيقة على صلاة %s",
        "prayer_stats" to "صلّيت النهارده %d من 5",
        "water_title" to "وقت كوباية مية 💧",
        "water_body" to "شربت النهارده %d مل من هدفك %d مل",
        "fajr" to "الفجر", "dhuhr" to "الظهر", "asr" to "العصر",
        "maghrib" to "المغرب", "isha" to "العشاء", "sunrise" to "الشروق",
        "fajr_s" to "فجر", "dhuhr_s" to "ظهر", "asr_s" to "عصر",
        "maghrib_s" to "مغرب", "isha_s" to "عشاء",
        "audio_playing" to "الصوت شغّال — اضغط للإيقاف",
        "no_activity" to "مفيش نشاط شغّال دلوقتي",
        "next" to "اللي جاي",
        "progress" to "إنجاز النهارده",
        "next_prayer" to "الصلاة الجاية",
        "free_day" to "يومك فاضي — ضيف أول نشاط",
        "official_holiday" to "إجازة رسمية ✓",
        "prayed_done" to "صلّيت %d/5"
    )
    private val en = mapOf(
        "start_now" to "Start now",
        "snooze" to "Snooze %d m",
        "skip" to "Skip",
        "done" to "Done ✓",
        "partial" to "Partial",
        "dismiss" to "OK",
        "prayed" to "Prayed ✓",
        "stop_audio" to "Stop sound",
        "log_water" to "Drank a cup 💧",
        "alarm_dismiss" to "Dismiss",
        "alarm_snooze" to "Snooze %d m",
        "alarm_no_snooze" to "No snoozes left",
        "prayer_title" to "Time for %s prayer",
        "prayer_pre" to "%d min until %s prayer",
        "prayer_stats" to "Prayed today: %d of 5",
        "water_title" to "Drink some water 💧",
        "water_body" to "%d ml of %d ml logged today",
        "fajr" to "Fajr", "dhuhr" to "Dhuhr", "asr" to "Asr",
        "maghrib" to "Maghrib", "isha" to "Isha", "sunrise" to "Sunrise",
        "fajr_s" to "Fajr", "dhuhr_s" to "Dhuhr", "asr_s" to "Asr",
        "maghrib_s" to "Maghrib", "isha_s" to "Isha",
        "audio_playing" to "Alarm ringing — tap to stop",
        "no_activity" to "Nothing active right now",
        "next" to "Up next",
        "progress" to "Today",
        "next_prayer" to "Next prayer",
        "free_day" to "Free day — add your first block",
        "official_holiday" to "Official holiday ✓",
        "prayed_done" to "Prayed %d/5"
    )
    fun lang(c: Context) = DayflowAlarms.prefs(c).getString("lang", "ar") ?: "ar"
    fun t(c: Context, key: String, vararg args: Any): String {
        val m = if (lang(c) == "en") en else ar
        val s = m[key] ?: en[key] ?: key
        return if (args.isEmpty()) s else String.format(Locale.US, s, *args)
    }
}

/**
 * Posts rich, honest, grouped Android notifications with up to 3 real native actions
 * (platform ceiling), respecting quiet hours, zero double-sound coordination with
 * AlarmAudioService, prayer stats progress bar, and safety exclusion of Christian/Jewish dates.
 */
object Notifier {
    const val GROUP = "com.dayflow.app.TODAY"

    fun cancel(c: Context, id: String) {
        NotificationManagerCompat.from(c).cancel(DayflowAlarms.notificationId(id))
    }

    fun inQuietHours(c: Context): Boolean {
        val p = DayflowAlarms.prefs(c)
        if (!p.getBoolean("quiet_enabled", false)) return false
        val s = p.getInt("quiet_start", 23 * 60)
        val e = p.getInt("quiet_end", 390)
        val cal = Calendar.getInstance()
        val m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (s <= e) m in s until e else (m >= s || m < e)
    }

    private fun action(c: Context, alarm: JSONObject, act: String): PendingIntent {
        val i = Intent(c, NotificationActionReceiver::class.java).apply {
            action = "com.dayflow.app.NOTIF_ACTION.$act"
            setPackage(c.packageName)
            putExtra("act", act)
            putExtra("alarm", alarm.toString())
        }
        return PendingIntent.getBroadcast(
            c, (alarm.optString("id") + ":" + act).hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun openApp(c: Context, id: String): PendingIntent = PendingIntent.getActivity(
        c, ("open:$id").hashCode(),
        Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun usesAudioService(alarm: JSONObject, quiet: Boolean): Boolean {
        if (quiet) return false
        val kind = alarm.optString("kind", "block")
        val sound = alarm.optString("sound", "default")
        val phase = alarm.optString("phase", "")
        if (sound == "none") return false
        if (kind == "user_alarm") return true
        if (kind == "prayer" && phase != "pre" && alarm.optString("prayer") != "sunrise") {
            return sound == "alarm" || sound == "custom" || sound.startsWith("content://") || sound.startsWith("file://") || alarm.optBoolean("speakLabel")
        }
        return sound == "alarm" || sound == "tts" || sound.startsWith("content://") || sound.startsWith("file://")
    }

    fun post(c: Context, alarm: JSONObject) {
        if (DayflowAlarms.isExcludedReligion(alarm)) return
        if (Build.VERSION.SDK_INT >= 33 && !NotificationManagerCompat.from(c).areNotificationsEnabled()) {
            log(c, alarm, "blocked_no_permission")
            return
        }
        val kind = alarm.optString("kind", "block")
        val id = alarm.optString("id")
        val critical = alarm.optBoolean("isCritical") || kind == "user_alarm" || kind == "prayer"
        val quiet = !critical && inQuietHours(c)
        val withService = usesAudioService(alarm, quiet)
        val silentSound = quiet || alarm.optString("sound") == "none"

        // Critical bug fix: when AlarmAudioService plays audio, use silent high-importance channel
        // so the user never hears default notification sound clashing with their song / adhan!
        val channel = when {
            silentSound -> DayflowApplication.CHANNEL_MISC
            kind == "user_alarm" -> DayflowApplication.CHANNEL_ALARM
            kind == "prayer" -> if (withService) DayflowApplication.CHANNEL_PRAYER else DayflowApplication.CHANNEL_BLOCKS
            withService -> DayflowApplication.CHANNEL_ALARM
            else -> DayflowApplication.CHANNEL_BLOCKS
        }

        val accent = when (kind) {
            "prayer" -> 0xFF0DA271.toInt()
            "water" -> 0xFF0EA5E9.toInt()
            "occasion", "event" -> 0xFFD97706.toInt()
            "user_alarm" -> 0xFF7C3AED.toInt()
            else -> 0xFF5856D6.toInt()
        }
        val snooze = alarm.optInt("snoozeMin", DayflowAlarms.prefs(c).getInt("snooze_default", 10)).coerceIn(1, 120)

        val b = NotificationCompat.Builder(c, channel)
            .setSmallIcon(R.drawable.ic_stat_dayflow)
            .setContentTitle(alarm.optString("title"))
            .setContentText(alarm.optString("body"))
            .setStyle(NotificationCompat.BigTextStyle().bigText(alarm.optString("body")))
            .setContentIntent(openApp(c, id))
            .setAutoCancel(kind != "user_alarm")
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setGroup(GROUP)
            .setColor(accent)
            .setColorized(kind == "user_alarm")
            .setWhen(alarm.optLong("startAtMillis", System.currentTimeMillis()))
            .setShowWhen(true)
            .setPriority(if (silentSound) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .setCategory(
                when (kind) {
                    "user_alarm" -> NotificationCompat.CATEGORY_ALARM
                    "event", "occasion" -> NotificationCompat.CATEGORY_EVENT
                    else -> NotificationCompat.CATEGORY_REMINDER
                }
            )
            .setSilent(silentSound)

        when (kind) {
            "block" -> if (alarm.optString("phase") == "end") {
                b.addAction(0, L10n.t(c, "done"), action(c, alarm, "DONE"))
                b.addAction(0, L10n.t(c, "partial"), action(c, alarm, "PARTIAL"))
                b.addAction(0, L10n.t(c, "snooze", snooze), action(c, alarm, "SNOOZE"))
            } else {
                b.addAction(0, L10n.t(c, "start_now"), action(c, alarm, "START_NOW"))
                b.addAction(0, L10n.t(c, "done"), action(c, alarm, "DONE"))
                b.addAction(0, L10n.t(c, "snooze", snooze), action(c, alarm, "SNOOZE"))
            }
            "task" -> {
                b.addAction(0, L10n.t(c, "done"), action(c, alarm, "DONE"))
                b.addAction(0, L10n.t(c, "snooze", snooze), action(c, alarm, "SNOOZE"))
                b.addAction(0, L10n.t(c, "skip"), action(c, alarm, "DISMISS"))
            }
            "prayer" -> {
                val prayedCount = PrayerScheduler.prayedCountToday(c)
                val isAdhan = alarm.optString("phase") != "pre" && alarm.optString("prayer") != "sunrise"
                b.setProgress(5, prayedCount.coerceIn(0, 5), false)
                if (isAdhan) b.addAction(0, L10n.t(c, "prayed"), action(c, alarm, "PRAYED"))
                b.addAction(0, L10n.t(c, "snooze", snooze), action(c, alarm, "SNOOZE"))
                if (withService) b.addAction(0, L10n.t(c, "stop_audio"), action(c, alarm, "STOP_AUDIO"))
                else b.addAction(0, L10n.t(c, "dismiss"), action(c, alarm, "DISMISS"))
            }
            "water" -> {
                val p = DayflowAlarms.prefs(c)
                val ml = DayflowAlarms.getWaterTodayMl(c)
                val target = p.getInt("water_target_ml", 2500).coerceAtLeast(1)
                b.setProgress(target, ml.coerceAtMost(target), false)
                b.addAction(0, L10n.t(c, "log_water"), action(c, alarm, "LOG_WATER"))
                b.addAction(0, L10n.t(c, "snooze", snooze), action(c, alarm, "SNOOZE"))
                b.addAction(0, L10n.t(c, "dismiss"), action(c, alarm, "DISMISS"))
            }
            "user_alarm" -> {
                val fsIntent = Intent(c, AlarmRingActivity::class.java)
                    .putExtra("alarm", alarm.toString())
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
                val fs = PendingIntent.getActivity(
                    c, ("ring:$id").hashCode(), fsIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                b.setFullScreenIntent(fs, true).setOngoing(true).setContentIntent(fs)
                if (UserAlarms.canSnooze(c, alarm)) {
                    b.addAction(0, L10n.t(c, "alarm_snooze", snooze), action(c, alarm, "ALARM_SNOOZE"))
                }
                b.addAction(0, L10n.t(c, "alarm_dismiss"), action(c, alarm, "ALARM_DISMISS"))
            }
            else -> { // occasion / personal event / test
                b.addAction(0, L10n.t(c, "snooze", snooze), action(c, alarm, "SNOOZE"))
                b.addAction(0, L10n.t(c, "dismiss"), action(c, alarm, "DISMISS"))
            }
        }

        if (!withService && !silentSound && alarm.optBoolean("vibrate", true)) {
            b.setVibrate(longArrayOf(0, 220, 140, 220))
        }

        try {
            NotificationManagerCompat.from(c).notify(DayflowAlarms.notificationId(id), b.build())
            if (kind != "user_alarm") postGroupSummary(c)
            log(c, alarm, "sent")
        } catch (_: SecurityException) {
            log(c, alarm, "blocked_security")
        }

        if (withService) AlarmAudioService.start(c, alarm)
    }

    private fun postGroupSummary(c: Context) {
        val s = NotificationCompat.Builder(c, DayflowApplication.CHANNEL_MISC)
            .setSmallIcon(R.drawable.ic_stat_dayflow)
            .setGroup(GROUP).setGroupSummary(true).setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
            .setAutoCancel(true).setSilent(true)
            .setContentTitle(c.getString(R.string.app_name))
            .build()
        try { NotificationManagerCompat.from(c).notify(0x0DAF, s) } catch (_: SecurityException) {}
    }

    /** Append every genuine notification emission and action into durable log (300 entries). */
    @Synchronized fun log(c: Context, alarm: JSONObject, status: String) {
        val p = DayflowAlarms.prefs(c)
        val arr = try { JSONArray(p.getString("notif_log", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        arr.put(
            JSONObject()
                .put("id", "${alarm.optString("id")}:$status:$now")
                .put("refId", alarm.optString("refId", alarm.optString("id")))
                .put("title", alarm.optString("title"))
                .put("body", alarm.optString("body"))
                .put("kind", alarm.optString("kind"))
                .put("status", status)
                .put("triggerAt", now)
        )
        val trimmed = JSONArray()
        val from = maxOf(0, arr.length() - 300)
        for (i in from until arr.length()) trimmed.put(arr.get(i))
        p.edit().putString("notif_log", trimmed.toString()).apply()
    }
}

/* ====================== Alarm trigger receiver ====================== */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        DayflowApplication.createChannels(context)
        val id = intent.getStringExtra("alarm_id") ?: return
        val alarm = DayflowAlarms.find(context, id) ?: return // stale or cancelled → safe ignore
        val kind = alarm.optString("kind")
        if (kind != "user_alarm") DayflowAlarms.remove(context, id)

        if (kind == "prayer") {
            val prayer = alarm.optString("prayer")
            val count = PrayerScheduler.prayedCountToday(context)
            val set = PrayerScheduler.prayedSetToday(context)
            val checkLine = PrayerTimes.FARD.joinToString(" · ") { n ->
                val lbl = L10n.t(context, "${n}_s")
                if (n in set) "$lbl✓" else lbl
            }
            if (alarm.optString("phase") != "pre" && prayer != "sunrise") {
                val base = alarm.optString("body")
                alarm.put("body", "$base\n${L10n.t(context, "prayer_stats", count)} ($checkLine)")
            }
            if (prayer == "sunrise") alarm.put("sound", "default")
        } else if (kind == "water") {
            val ml = DayflowAlarms.getWaterTodayMl(context)
            val target = DayflowAlarms.prefs(context).getInt("water_target_ml", 2500)
            alarm.put("body", L10n.t(context, "water_body", ml, target))
        }

        Notifier.post(context, alarm)
        if (kind == "prayer") PrayerScheduler.reschedule(context)
        WidgetRenderer.refreshAll(context)
    }
}

/* ============ Interactive notification buttons (app stays completely closed) ============ */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val act = intent.getStringExtra("act") ?: return
        val alarm = try { JSONObject(intent.getStringExtra("alarm") ?: return) } catch (_: Exception) { return }
        val id = alarm.optString("id")
        val ref = alarm.optString("refId", id)
        val kind = alarm.optString("kind", "block")
        val p = DayflowAlarms.prefs(context)

        // Idempotency against duplicate or stale notification button taps
        if (act != "SNOOZE" && act != "ALARM_SNOOZE") {
            val token = "$id@${alarm.optLong("triggerAtMillis")}:$act"
            val handled = HashSet(p.getStringSet("handled_tokens", emptySet()) ?: emptySet())
            if (!handled.add(token)) { Notifier.cancel(context, id); return }
            if (handled.size > 400) handled.clear()
            p.edit().putStringSet("handled_tokens", handled).apply()
        }

        when (act) {
            "DONE", "PARTIAL", "SKIP", "START_NOW" -> {
                val status = mapOf(
                    "DONE" to "done", "PARTIAL" to "partial",
                    "SKIP" to "skipped", "START_NOW" to "in_progress"
                )[act]!!
                when (kind) {
                    "block" -> {
                        DayflowAlarms.patchBlockStatusDirect(context, ref, status)
                        if (act == "DONE" || act == "SKIP") {
                            DayflowAlarms.cancel(context, "$ref:end")
                            WidgetRenderer.patchBlockStatus(context, ref, status)
                        } else if (act == "START_NOW") {
                            WidgetRenderer.patchBlockStatus(context, ref, "in_progress")
                        }
                    }
                    "task" -> if (act == "DONE") DayflowAlarms.patchTaskDoneDirect(context, ref)
                }
                DayflowAlarms.enqueuePendingAction(
                    context, act, ref,
                    JSONObject().put("kind", kind).put("title", alarm.optString("title"))
                )
                Notifier.cancel(context, id)
            }
            "SNOOZE" -> {
                val minutes = alarm.optInt("snoozeMin", p.getInt("snooze_default", 10)).coerceIn(1, 120)
                val snoozeId = "$id:snz"
                val again = JSONObject(alarm.toString())
                    .put("id", snoozeId)
                    .put("triggerAtMillis", System.currentTimeMillis() + minutes * 60_000L)
                DayflowAlarms.schedule(context, again)
                DayflowAlarms.enqueuePendingAction(
                    context, "SNOOZE", ref,
                    JSONObject().put("minutes", minutes).put("kind", kind).put("title", alarm.optString("title"))
                )
                Notifier.cancel(context, id)
            }
            "PRAYED" -> {
                val pr = alarm.optString("prayer")
                val dt = alarm.optString("date").ifBlank { DayflowAlarms.todayStr() }
                PrayerScheduler.markPrayed(context, pr, dt)
                DayflowAlarms.enqueuePendingAction(
                    context, "PRAYED", ref,
                    JSONObject().put("prayer", pr).put("date", dt).put("title", alarm.optString("title"))
                )
                Notifier.cancel(context, id)
            }
            "LOG_WATER" -> {
                val ml = p.getInt("water_cup_ml", 250).coerceAtLeast(50)
                DayflowAlarms.addWaterTodayMl(context, ml)
                DayflowAlarms.writeWaterLogDirect(context, ml)
                DayflowAlarms.enqueuePendingAction(
                    context, "WATER", "notif",
                    JSONObject().put("ml", ml).put("title", alarm.optString("title"))
                )
                Notifier.cancel(context, id)
            }
            "ALARM_SNOOZE" -> UserAlarms.snooze(context, alarm)
            "ALARM_DISMISS" -> UserAlarms.dismiss(context, alarm)
            "STOP_AUDIO" -> AlarmAudioService.stop(context)
            "DISMISS" -> Notifier.cancel(context, id)
        }
        AlarmAudioService.stop(context)
        Notifier.log(context, alarm, act.lowercase(Locale.US))
        WidgetRenderer.refreshAll(context)
    }
}

/* ============ Reboot / app update / time / timezone / exact-alarm recovery ============ */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        Thread {
            try {
                DayflowApplication.createChannels(context)
                val n = DayflowAlarms.rearmAll(context)
                val shortAct = intent.action?.substringAfterLast('.') ?: "UNKNOWN"
                DayflowAlarms.markBootRecovery(context, "done:$n:$shortAct")
                WidgetRenderer.refreshAll(context)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

class AlarmStopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmAudioService.stop(context)
    }
}

/** Fires silently at the next block boundary / midnight to keep home-screen widgets always fresh. */
class WidgetTickReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        WidgetRenderer.refreshAll(context)
    }
}

/* ============ Interactive home-screen widget buttons ============ */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = DayflowAlarms.prefs(context)
        when (intent.getStringExtra("w_act")) {
            "DONE" -> intent.getStringExtra("block_id")?.let { bid ->
                DayflowAlarms.patchBlockStatusDirect(context, bid, "done")
                DayflowAlarms.cancel(context, bid)
                DayflowAlarms.cancel(context, "$bid:end")
                DayflowAlarms.enqueuePendingAction(
                    context, "DONE", bid,
                    JSONObject().put("kind", "block").put("source", "widget")
                )
                WidgetRenderer.patchBlockStatus(context, bid, "done")
            }
            "WATER" -> {
                val ml = p.getInt("water_cup_ml", 250).coerceAtLeast(50)
                DayflowAlarms.addWaterTodayMl(context, ml)
                DayflowAlarms.writeWaterLogDirect(context, ml)
                DayflowAlarms.enqueuePendingAction(
                    context, "WATER", "widget",
                    JSONObject().put("ml", ml).put("source", "widget")
                )
            }
            "PRAYED" -> intent.getStringExtra("prayer")?.let { pr ->
                val date = DayflowAlarms.todayStr()
                PrayerScheduler.markPrayed(context, pr, date)
                DayflowAlarms.enqueuePendingAction(
                    context, "PRAYED", "prayer:$pr:$date",
                    JSONObject().put("prayer", pr).put("date", date).put("source", "widget")
                )
            }
        }
        WidgetRenderer.refreshAll(context)
    }
}
