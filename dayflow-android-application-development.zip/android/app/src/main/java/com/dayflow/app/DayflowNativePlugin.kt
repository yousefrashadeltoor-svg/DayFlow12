package com.dayflow.app

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.activity.result.ActivityResult
import androidx.core.app.NotificationManagerCompat
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.TimeZone

/**
 * DayflowNativePlugin — complete, strictly honest native bridge.
 * Every call inspects actual Android OS state, persists reliably,
 * rejects cleanly on failure, and never fakes success.
 */
@CapacitorPlugin(
    name = "DayflowNative",
    permissions = [Permission(alias = "notifications", strings = [Manifest.permission.POST_NOTIFICATIONS])]
)
class DayflowNativePlugin : Plugin() {

    private var preview: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private val ctx: Context get() = context

    private fun ok(extra: JSObject.() -> Unit = {}): JSObject = JSObject().apply { put("ok", true); extra() }
    private fun notifGranted() = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    /* ---------------- lifecycle & synced config ---------------- */
    @PluginMethod
    fun initialize(call: PluginCall) {
        DayflowApplication.createChannels(ctx)
        val p = DayflowAlarms.prefs(ctx).edit()
        call.getString("lang")?.let { p.putString("lang", it) }
        call.getBoolean("hour12")?.let { p.putBoolean("hour12", it) }
        call.getBoolean("quietEnabled")?.let { p.putBoolean("quiet_enabled", it) }
        call.getInt("quietStart")?.let { p.putInt("quiet_start", it) }
        call.getInt("quietEnd")?.let { p.putInt("quiet_end", it) }
        call.getInt("snoozeDefault")?.let { p.putInt("snooze_default", it) }
        call.getBoolean("ttsFallback")?.let { p.putBoolean("tts_fallback", it) }
        call.getInt("waterCupMl")?.let { p.putInt("water_cup_ml", it) }
        call.getInt("waterTargetMl")?.let { p.putInt("water_target_ml", it) }
        p.apply()
        call.getInt("waterTodayMl")?.let { DayflowAlarms.setWaterTodayMl(ctx, it, call.getInt("waterTargetMl")) }
        call.resolve(ok {
            put("notifications", notifGranted())
            put("exactAlarms", DayflowAlarms.canExact(ctx))
            put("sdk", Build.VERSION.SDK_INT)
        })
    }

    @PluginMethod
    fun getPlatformCapabilities(call: PluginCall) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        call.resolve(ok {
            put("platform", "android")
            put("sdk", Build.VERSION.SDK_INT)
            put("release", Build.VERSION.RELEASE)
            put("manufacturer", Build.MANUFACTURER)
            put("model", Build.MODEL)
            put("notifications", notifGranted())
            put("exactAlarms", DayflowAlarms.canExact(ctx))
            put("fullScreenIntent", if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true)
            put("ignoringBattery", pm.isIgnoringBatteryOptimizations(ctx.packageName))
            put("widgets", true)
            put("tts", true)
            put("waveformDecode", true)
            put("maxNotificationActions", 3)
            put("timeZone", TimeZone.getDefault().id)
        })
    }

    /* ---------------- real permissions ---------------- */
    @PluginMethod
    fun checkNotificationPermission(call: PluginCall) { call.resolve(ok { put("granted", notifGranted()) }) }

    @PluginMethod
    fun requestNotificationPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED) {
            call.resolve(ok { put("granted", notifGranted()) })
            return
        }
        requestPermissionForAlias("notifications", call, "notifPermCallback")
    }

    @PermissionCallback
    private fun notifPermCallback(call: PluginCall) { call.resolve(ok { put("granted", notifGranted()) }) }

    @PluginMethod
    fun checkExactAlarmPermission(call: PluginCall) { call.resolve(ok { put("granted", DayflowAlarms.canExact(ctx)) }) }

    @PluginMethod
    fun requestExactAlarmPermission(call: PluginCall) {
        if (DayflowAlarms.canExact(ctx)) { call.resolve(ok { put("granted", true) }); return }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                activity.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
                call.resolve(ok { put("granted", false); put("openedSettings", true) })
            } catch (e: Exception) { call.reject("cannot-open-settings", e) }
        } else {
            call.resolve(ok { put("granted", true) })
        }
    }

    @PluginMethod
    fun requestFullScreenPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT < 34) { call.resolve(ok { put("granted", true) }); return }
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.canUseFullScreenIntent()) { call.resolve(ok { put("granted", true) }); return }
        try {
            activity.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + ctx.packageName)))
            call.resolve(ok { put("granted", false); put("openedSettings", true) })
        } catch (e: Exception) { call.reject("cannot-open-settings", e) }
    }

    @PluginMethod
    fun getBatteryOptimizationStatus(call: PluginCall) {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val ignoring = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        call.resolve(ok { put("ignoring", ignoring); put("status", if (ignoring) "unrestricted" else "optimized") })
    }

    @PluginMethod
    fun requestBatterySettings(call: PluginCall) {
        try {
            activity.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
            call.resolve(ok())
        } catch (_: Exception) {
            try { activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); call.resolve(ok()) }
            catch (e: Exception) { call.reject("cannot-open-settings", e) }
        }
    }

    @PluginMethod
    fun getDeviceTimeZone(call: PluginCall) { call.resolve(ok { put("timeZone", TimeZone.getDefault().id) }) }

    /* ---------------- alarm & notification scheduling ---------------- */
    @PluginMethod
    fun scheduleBlockAlarm(call: PluginCall) {
        val alarm = JSONObject(call.data.toString())
        if (!alarm.has("kind")) alarm.put("kind", "block")
        if (alarm.optString("id").isEmpty()) { call.reject("missing-id"); return }
        when (val res = DayflowAlarms.schedule(ctx, alarm)) {
            "past" -> call.resolve(JSObject().put("ok", false).put("error", "trigger-in-past"))
            "excluded" -> call.resolve(JSObject().put("ok", false).put("error", "excluded-occasion"))
            else -> call.resolve(ok { put("delivery", res); put("exact", res != "inexact"); put("notificationsAllowed", notifGranted()) })
        }
    }

    /** Schedule a genuine short-delay test (notification OR real lock-screen alarm ring). */
    @PluginMethod
    fun triggerTestAlarm(call: PluginCall) {
        val mode = call.getString("mode", "notification") ?: "notification"
        val delaySec = (call.getInt("delaySec", 10) ?: 10).coerceIn(3, 60)
        val at = System.currentTimeMillis() + delaySec * 1000L
        val isEn = L10n.lang(ctx) == "en"
        val payload = if (mode == "alarm") {
            JSONObject()
                .put("id", "ualarm:test-$at").put("refId", "test-$at").put("kind", "user_alarm")
                .put("triggerAtMillis", at).put("startAtMillis", at)
                .put("title", if (isEn) "⏰ DAYFLOW test alarm" else "⏰ تجربة منبه مدير اليوم")
                .put("label", if (isEn) "Alarm works properly ✓" else "المنبه شغّال تمام فوق شاشة القفل ✓")
                .put("body", if (isEn) "Press Dismiss or Snooze to verify" else "دوس إيقاف أو غفوة عشان تتأكد")
                .put("sound", "alarm").put("toneUri", call.getString("toneUri") ?: "")
                .put("repeatCount", 2).put("volume", 0.75).put("gradual", true)
                .put("vibrate", true).put("snoozeMin", 1).put("maxSnoozes", 1).put("isCritical", true)
        } else {
            JSONObject()
                .put("id", "test-$at").put("refId", "test-$at").put("kind", "block").put("phase", "start")
                .put("triggerAtMillis", at).put("startAtMillis", at)
                .put("title", if (isEn) "🔔 DAYFLOW reminder check" else "🔔 تجربة إشعار مدير اليوم")
                .put("body", if (isEn) "Real AlarmManager delivery succeeded! Try any button below." else "الإشعار وصلك من أندرويد مباشرة! جرّب الأزرار اللي تحت للتأكيد.")
                .put("sound", "default").put("vibrate", true).put("snoozeMin", 5)
        }
        val res = DayflowAlarms.schedule(ctx, payload)
        call.resolve(ok { put("delivery", res); put("triggerAt", at); put("notificationsAllowed", notifGranted()); put("delaySec", delaySec) })
    }

    /** Idempotent batch sync of all active activities, tasks, water & allowed occasions. */
    @PluginMethod
    fun syncSchedule(call: PluginCall) {
        val items = call.getArray("items") ?: JSArray()
        val kindsArr = call.getArray("kinds") ?: JSArray()
        val kinds = (0 until kindsArr.length()).map { kindsArr.getString(it) }.toSet()
        val keep = HashSet<String>()
        var exact = 0; var inexact = 0; var past = 0; var excluded = 0
        for (i in 0 until items.length()) {
            val a = items.getJSONObject(i)
            val id = a.optString("id")
            when (DayflowAlarms.schedule(ctx, a)) {
                "exact", "alarm_clock" -> { exact++; keep.add(id) }
                "inexact" -> { inexact++; keep.add(id) }
                "excluded" -> excluded++
                else -> past++
            }
        }
        val removed = DayflowAlarms.cancelStale(ctx, kinds, keep)
        call.resolve(ok {
            put("scheduled", exact + inexact)
            put("exact", exact); put("inexact", inexact)
            put("skippedPast", past); put("excluded", excluded); put("removed", removed)
            put("notificationsAllowed", notifGranted())
        })
    }

    @PluginMethod
    fun rescheduleUpcomingAlarms(call: PluginCall) {
        val n = DayflowAlarms.rearmAll(ctx)
        WidgetRenderer.refreshAll(ctx)
        call.resolve(ok { put("scheduled", n) })
    }

    @PluginMethod
    fun cancelAlarm(call: PluginCall) {
        val id = call.getString("id") ?: run { call.reject("missing-id"); return }
        DayflowAlarms.cancel(ctx, id)
        DayflowAlarms.cancel(ctx, "$id:end")
        DayflowAlarms.cancel(ctx, "$id:snz")
        call.resolve(ok())
    }

    @PluginMethod
    fun cancelBlockAlarms(call: PluginCall) {
        val n = DayflowAlarms.cancelStale(ctx, setOf("block", "task", "event", "occasion", "water"), emptySet())
        call.resolve(ok { put("removed", n) })
    }

    @PluginMethod
    fun getScheduledAlarmStatus(call: PluginCall) {
        val p = DayflowAlarms.prefs(ctx)
        val next = DayflowAlarms.nextPending(ctx)
        call.resolve(ok {
            put("pendingCount", DayflowAlarms.readRegistry(ctx).length())
            put("nextTriggerAt", next?.optLong("triggerAtMillis") ?: 0L)
            put("nextTitle", next?.optString("title") ?: "")
            put("lastScheduleResult", p.getString("last_schedule_result", "") ?: "")
            put("lastScheduleAt", p.getLong("last_schedule_at", 0L))
            put("bootRecovery", p.getString("boot_recovery", "registered") ?: "registered")
            put("bootRecoveryAt", p.getLong("boot_recovery_at", 0L))
            put("exact", DayflowAlarms.canExact(ctx))
            put("notificationsAllowed", notifGranted())
        })
    }

    @PluginMethod
    fun drainPendingActions(call: PluginCall) {
        call.resolve(ok { put("actions", JSArray(DayflowAlarms.drainPendingActions(ctx).toString())) })
    }

    @PluginMethod
    fun markPendingActionApplied(call: PluginCall) { call.resolve(ok()) }

    @PluginMethod
    fun getNotificationLog(call: PluginCall) {
        val raw = DayflowAlarms.prefs(ctx).getString("notif_log", "[]") ?: "[]"
        call.resolve(ok { put("items", JSArray(raw)) })
    }

    /* ---------------- user alarm clocks ---------------- */
    @PluginMethod
    fun setUserAlarm(call: PluginCall) {
        val cfg = call.getObject("alarm") ?: run { call.reject("missing-alarm"); return }
        val at = UserAlarms.upsert(ctx, JSONObject(cfg.toString()))
        call.resolve(ok { put("nextAt", at); put("exact", DayflowAlarms.canExact(ctx)); put("notificationsAllowed", notifGranted()) })
    }

    @PluginMethod
    fun deleteUserAlarm(call: PluginCall) {
        UserAlarms.delete(ctx, call.getString("id") ?: "")
        call.resolve(ok())
    }

    /* ---------------- prayer scheduler ---------------- */
    @PluginMethod
    fun configurePrayers(call: PluginCall) {
        val cfg = call.getObject("config") ?: run { call.reject("missing-config"); return }
        DayflowAlarms.prefs(ctx).edit().putString("prayer_cfg", cfg.toString()).apply()
        val count = PrayerScheduler.reschedule(ctx)
        WidgetRenderer.refreshAll(ctx)
        call.resolve(ok { put("scheduled", count); put("prayedToday", PrayerScheduler.prayedCountToday(ctx)) })
    }

    @PluginMethod
    fun syncPrayed(call: PluginCall) {
        val date = call.getString("date") ?: DayflowAlarms.todayStr()
        val names = call.getArray("names") ?: JSArray()
        val set = HashSet<String>()
        for (i in 0 until names.length()) set.add(names.getString(i))
        DayflowAlarms.prefs(ctx).edit().putStringSet("prayed:$date", set).apply()
        WidgetRenderer.refreshAll(ctx)
        call.resolve(ok { put("count", set.size) })
    }

    /* ---------------- audio pickers: system tones, default music picker, real waveform ---------------- */
    @PluginMethod
    fun pickSystemTone(call: PluginCall) {
        val kind = call.getString("type", "alarm") ?: "alarm"
        val type = when (kind) {
            "ringtone" -> RingtoneManager.TYPE_RINGTONE
            "notification" -> RingtoneManager.TYPE_NOTIFICATION
            else -> RingtoneManager.TYPE_ALARM
        }
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, type)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(type))
            call.getString("current")?.takeIf { it.isNotEmpty() }?.let {
                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it))
            }
        }
        startActivityForResult(call, i, "systemToneResult")
    }

    @ActivityCallback
    private fun systemToneResult(call: PluginCall, result: ActivityResult) {
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
            result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        } else {
            @Suppress("DEPRECATION") result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        }
        if (uri == null) { call.resolve(JSObject().put("ok", false).put("cancelled", true)); return }
        val title = try { RingtoneManager.getRingtone(ctx, uri)?.getTitle(ctx) ?: "" } catch (_: Exception) { "" }
        call.resolve(ok { put("uri", uri.toString()); put("name", title); put("durationMs", durationOf(uri)) })
    }

    /**
     * Opens the device's default Music / Sound Picker app directly via MediaStore audio URI
     * (never launches the raw generic file manager unless the device has no installed audio picker).
     */
    @PluginMethod
    fun pickMusicTone(call: PluginCall) {
        val pm = ctx.packageManager
        val mediaPick = Intent(Intent.ACTION_PICK, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
        val audioPick = Intent(Intent.ACTION_PICK).apply { setDataAndType(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio/*") }
        val fallback = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "audio/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/mpeg", "audio/mp4", "audio/x-m4a", "audio/ogg", "audio/wav", "audio/flac", "audio/*"))
        }
        val target = when {
            mediaPick.resolveActivity(pm) != null -> mediaPick
            audioPick.resolveActivity(pm) != null -> audioPick
            else -> fallback
        }
        startActivityForResult(call, target, "musicToneResult")
    }

    /** Direct document picker for importing MP3 / OGG / M4A manually if desired. */
    @PluginMethod
    fun importNativeFile(call: PluginCall) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/mpeg", "audio/ogg", "audio/mp4", "audio/x-m4a", "audio/wav", "audio/*"))
        }
        startActivityForResult(call, i, "musicToneResult")
    }

    @ActivityCallback
    private fun musicToneResult(call: PluginCall, result: ActivityResult) {
        val src = result.data?.data ?: run { call.resolve(JSObject().put("ok", false).put("cancelled", true)); return }
        Thread {
            try {
                var name = "music_tone"
                ctx.contentResolver.query(src, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0)?.takeIf { it.isNotBlank() } ?: name
                }
                // Copy into private app storage so scoped-storage URI permissions never expire after reboot
                val dir = File(ctx.filesDir, "tones").apply { mkdirs() }
                val safe = name.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").take(80)
                val out = File(dir, "${System.currentTimeMillis()}_$safe")
                ctx.contentResolver.openInputStream(src)?.use { input ->
                    out.outputStream().use { output -> input.copyTo(output) }
                } ?: throw IllegalStateException("cannot-read-audio")
                val uri = Uri.fromFile(out)
                val dur = durationOf(uri)
                val (peaks, real) = WaveformExtractor.extract(ctx, uri, 64)
                call.resolve(ok {
                    put("uri", uri.toString())
                    put("name", name.substringBeforeLast('.'))
                    put("durationMs", dur)
                    put("sizeBytes", out.length())
                    put("peaks", JSArray(peaks.toString()))
                    put("realWaveform", real)
                })
            } catch (e: Exception) {
                call.reject("import-failed", e)
            }
        }.start()
    }

    /** Extract genuine decoded audio waveform peaks for trimming any already-saved audio file. */
    @PluginMethod
    fun extractWaveform(call: PluginCall) {
        val raw = call.getString("uri") ?: run { call.reject("missing-uri"); return }
        val bars = call.getInt("bars", 64) ?: 64
        Thread {
            val (peaks, real) = WaveformExtractor.extract(ctx, Uri.parse(raw), bars)
            call.resolve(ok { put("peaks", JSArray(peaks.toString())); put("realWaveform", real) })
        }.start()
    }

    private fun durationOf(uri: Uri): Long {
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(ctx, uri)
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) { 0L } finally { try { mmr.release() } catch (_: Exception) {} }
    }

    @PluginMethod
    fun getAudioInfo(call: PluginCall) {
        val u = call.getString("uri") ?: run { call.reject("missing-uri"); return }
        call.resolve(ok { put("durationMs", durationOf(Uri.parse(u))) })
    }

    /** Preview exact cut segment [startMs, endMs] over the alarm audio channel. */
    @PluginMethod
    fun playCustomAlarmAudio(call: PluginCall) {
        stopPreview()
        val raw = call.getString("uri")
        val uri = if (raw.isNullOrEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) else Uri.parse(raw)
        val start = (call.getInt("startMs", 0) ?: 0).coerceAtLeast(0)
        val end = (call.getInt("endMs", 0) ?: 0).coerceAtLeast(0)
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(ctx, uri)
            mp.prepare()
            val vol = (call.getFloat("volume", 1f) ?: 1f).coerceIn(0.05f, 1f)
            mp.setVolume(vol, vol)
            if (start > 0 && (mp.duration <= 0 || start < mp.duration)) mp.seekTo(start)
            mp.setOnCompletionListener { stopPreview() }
            mp.start()
            preview = mp
            val playFor = (if (end > start + 200) (end - start).toLong() else 15_000L).coerceAtMost(45_000L)
            h.postDelayed({ stopPreview() }, playFor)
            call.resolve(ok { put("playingMs", playFor) })
        } catch (e: Exception) {
            call.reject("playback-failed", e)
        }
    }

    @PluginMethod
    fun stopAlarmAudio(call: PluginCall) {
        stopPreview()
        AlarmAudioService.stop(ctx)
        call.resolve(ok())
    }

    private fun stopPreview() {
        h.removeCallbacksAndMessages(null)
        try { preview?.stop() } catch (_: Exception) {}
        try { preview?.release() } catch (_: Exception) {}
        preview = null
    }

    @PluginMethod
    fun speakText(call: PluginCall) {
        val text = call.getString("text") ?: run { call.reject("missing-text"); return }
        val lang = call.getString("lang", L10n.lang(ctx)) ?: "ar"
        tts?.shutdown()
        tts = TextToSpeech(ctx) { status ->
            if (status != TextToSpeech.SUCCESS) {
                call.resolve(JSObject().put("ok", false).put("error", "tts-unavailable"))
                return@TextToSpeech
            }
            val t = tts ?: return@TextToSpeech
            val isEn = lang.startsWith("en")
            val r = t.setLanguage(if (isEn) Locale.US else Locale("ar", "EG"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                val r2 = if (isEn) r else t.setLanguage(Locale("ar"))
                if (r2 == TextToSpeech.LANG_MISSING_DATA || r2 == TextToSpeech.LANG_NOT_SUPPORTED) {
                    call.resolve(JSObject().put("ok", false).put("error", "tts-language-missing"))
                    return@TextToSpeech
                }
            }
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dayflow-say")
            call.resolve(ok())
        }
    }

    /* ---------------- home-screen widgets ---------------- */
    @PluginMethod
    fun updateWidget(call: PluginCall) {
        val snap = call.getString("snapshot") ?: run { call.reject("missing-snapshot"); return }
        WidgetRenderer.saveSnapshot(ctx, snap)
        call.resolve(ok())
    }

    override fun handleOnDestroy() {
        stopPreview()
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
        super.handleOnDestroy()
    }
}
