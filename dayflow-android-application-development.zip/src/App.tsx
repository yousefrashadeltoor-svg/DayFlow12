/* DAYFLOW — App shell: bottom navigation · quick-add FAB · screen router */
import { useEffect, useState } from 'react';
import {
  Sun, CalendarDays, CalendarRange, LayoutGrid, Plus, X, Zap, ListTodo, StickyNote, Droplets, Loader2, AlarmClock, NotebookPen,
} from 'lucide-react';
import CalendarScreen from '@/screens/CalendarScreen';
import JournalModule from '@/modules/JournalModule';
import AlarmsModule from '@/modules/AlarmsModule';
import PrayerModule from '@/modules/PrayerModule';
import Onboarding from '@/screens/Onboarding';
import { SeasonalLayer } from '@/components/Seasonal';
import { Bot } from 'lucide-react';
import { AppProvider, useApp, type ScreenName } from '@/lib/store';
import { db, todayKey, nowMin } from '@/lib/db';
import Today from '@/screens/Today';
import Plan from '@/screens/Plan';
import Focus from '@/screens/Focus';
import Progress from '@/screens/Progress';
import More from '@/screens/More';
import CommandPalette from '@/screens/CommandPalette';
import TasksModule from '@/modules/TasksModule';
import StudyModule from '@/modules/StudyModule';
import WorkoutsModule from '@/modules/WorkoutsModule';
import HabitsModule from '@/modules/HabitsModule';
import GoalsNotesModule from '@/modules/GoalsNotesModule';
import SettingsModule from '@/modules/SettingsModule';
import NotificationsModule from '@/modules/NotificationsModule';
import ErrorBoundary from '@/components/ErrorBoundary';
import ActivityEditor from '@/components/ActivityEditor';
import AssistantScreen from '@/screens/AssistantScreen';
import DecorGallery from '@/screens/DecorGallery';
import { haptic } from '@/lib/platform';
import { cn } from '@/utils/cn';

const NAV: Array<{ name: ScreenName; icon: any; key: string }> = [
  { name: 'today', icon: Sun, key: 'today' },
  { name: 'plan', icon: CalendarDays, key: 'plan' },
  { name: 'calendar', icon: CalendarRange, key: 'calendar' },
  { name: 'more', icon: LayoutGrid, key: 'more' },
];

function Shell() {
  const { ready, screen, goTab, lang, t, settings, toast, bump, navigate } = useApp();
  const [quickAdd, setQuickAdd] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);

  /* Ctrl/Cmd+K global shortcut for the command center */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); goTab('search'); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [goTab]);

  if (!ready) {
    return (
      <div className="h-full grid place-items-center ambient">
        <div className="flex flex-col items-center gap-4">
          <img src="/icons/icon-512.png" alt="DAYFLOW" className="w-24 h-24 rounded-3xl shadow-lg" draggable={false} />
          <div className="flex items-center gap-2 text-2"><Loader2 className="w-4 h-4 animate-spin" /><span className="text-sm font-bold">{lang === 'ar' ? 'يُجهّز يومك…' : 'Preparing your day…'}</span></div>
        </div>
      </div>
    );
  }

  const isModalScreen = ['tasks', 'study', 'workouts', 'habits', 'goals', 'notes', 'settings', 'notifications', 'journal', 'alarms', 'prayer', 'focus', 'progress'].includes(screen.name);
  const isSearch = screen.name === 'search';
  const isAssistant = screen.name === 'assistant';

  const renderScreen = () => {
    switch (screen.name) {
      case 'today': return <Today />;
      case 'plan': return <Plan params={screen.params} />;
      case 'focus': return <Focus />;
      case 'progress': return <Progress />;
      case 'more': return <More />;
      case 'tasks': return <TasksModule params={screen.params} />;
      case 'study': return <StudyModule />;
      case 'workouts': return <WorkoutsModule />;
      case 'habits': return <HabitsModule params={screen.params} />;
      case 'goals': return <GoalsNotesModule params={screen.params} />;
      case 'notes': return <GoalsNotesModule params={{ tab: 'notes' }} />;
      case 'settings': return <SettingsModule params={screen.params} />;
      case 'assistant': return <AssistantScreen />;
      case 'decorGallery': return <DecorGallery />;
      case 'notifications': return <NotificationsModule />;
      case 'calendar': return <CalendarScreen />;
      case 'journal': return <JournalModule />;
      case 'alarms': return <AlarmsModule />;
      case 'prayer': return <PrayerModule />;
      default: return <Today />;
    }
  };

  return (
    <div className="h-full ambient flex">
      {/* desktop ambient brand gutter */}
      <div aria-hidden className="hidden lg:flex flex-col justify-center items-center flex-1 select-none overflow-hidden">
        <p className="num text-[7rem] font-black tracking-tighter leading-none" style={{ WebkitTextStroke: '1.5px color-mix(in srgb, var(--accent) 35%, transparent)', color: 'transparent' }}>𝐃α𝗒 𝐅ᥣⱺω</p>
        <p className="mt-2 text-sm font-bold text-2">Plan your day. Execute your priorities.<br />Understand your progress. Adapt intelligently.</p>
      </div>

      {/* the app device */}
      <div data-decor-below={settings.decorLayer === 'below' ? 'true' : 'false'} className="app-surface relative flex flex-col h-full w-full lg:w-[26.5rem] lg:my-4 lg:rounded-[2.4rem] lg:border lg:hairline lg:shadow-2xl overflow-hidden">
        <SeasonalLayer />
        {!settings.onboarded && <Onboarding onDone={() => goTab('today')} />}
        <main className={cn('relative z-[6] flex-1 min-h-0 overflow-x-hidden', isAssistant ? 'overflow-hidden flex flex-col' : 'overflow-y-auto no-scrollbar')} key={screen.name + JSON.stringify(screen.params ?? '')}>
          {isSearch ? <CommandPalette /> : (
            <div className={cn('anim-screen', isModalScreen && 'pb-2', isAssistant && 'flex-1 min-h-0 flex flex-col')}>
              {renderScreen()}
            </div>
          )}
        </main>

        {/* back for module screens */}
        {isModalScreen && <BackPill />}

        {/* bottom navigation */}
        <nav className="relative z-[7] glass border-t hairline flex items-stretch justify-around px-1.5 pb-[max(env(safe-area-inset-bottom),0.4rem)] pt-1.5 z-30" aria-label="main navigation">
          {NAV.slice(0, 2).map(item => <NavButton key={item.name} item={item} active={screen.name === item.name} />)}
          <button className="relative -top-4 w-14 h-14 rounded-2xl grid place-items-center text-[var(--on-accent)] shadow-lg transition-transform active:scale-90"
            style={{ background: 'linear-gradient(160deg, var(--accent), var(--accent-deep))', boxShadow: '0 12px 28px color-mix(in srgb, var(--accent) 45%, transparent)' }}
            onClick={() => { setQuickAdd(true); haptic('light'); }} aria-label={t('quickActions')}>
            <Plus className="w-7 h-7" strokeWidth={2.4} />
          </button>
          {NAV.slice(2).map(item => <NavButton key={item.name} item={item} active={screen.name === item.name} />)}
        </nav>

        {/* quick add sheet */}
        {quickAdd && (
          <>
            <div className="sheet-backdrop" onClick={() => setQuickAdd(false)} />
            <div className="sheet-panel anim-sheet" role="dialog" aria-modal="true" aria-label={t('quickActions')}>
              <div className="sheet-handle" />
              <div className="flex items-center justify-between px-5 pt-1 pb-2"><h2 className="font-bold text-lg">{t('quickActions')}</h2><button className="icon-btn" onClick={() => setQuickAdd(false)} aria-label="Close"><X className="w-5 h-5" /></button></div>
              <div className="grid grid-cols-4 gap-2 px-5 pb-5">
                {[
                  { icon: Zap, label: t('addActivity'), run: () => { setQuickAdd(false); setEditorOpen(true); } },
                  { icon: ListTodo, label: t('addTask'), run: () => { setQuickAdd(false); goTab('tasks'); } },
                  { icon: StickyNote, label: t('addNote'), run: () => { setQuickAdd(false); goTab('notes'); } },
                  { icon: CalendarRange, label: lang === 'ar' ? 'مناسبة' : 'Occasion', run: () => { setQuickAdd(false); goTab('calendar'); } },
                  { icon: AlarmClock, label: lang === 'ar' ? 'منبه' : 'Alarm', run: () => { setQuickAdd(false); navigate('alarms'); } },
                  { icon: NotebookPen, label: lang === 'ar' ? 'يومياتي' : 'Journal', run: () => { setQuickAdd(false); navigate('journal'); } },
                  { icon: Bot, label: lang === 'ar' ? 'المساعد' : 'Assistant', run: () => { setQuickAdd(false); goTab('assistant'); } },
                  { icon: Droplets, label: `+${settings.waterCupMl}ml`, run: async () => { await db.put('water_logs', { id: crypto.randomUUID(), date: todayKey(), timeMin: Math.round(nowMin()), amountMl: settings.waterCupMl, createdAt: Date.now() }); setQuickAdd(false); haptic('medium'); toast(lang === 'ar' ? 'أُضيف الماء' : 'Water logged'); bump(); } },
                ].map((a, i) => (
                  <button key={i} onClick={a.run} className="flex flex-col items-center gap-1.5 rounded-2xl py-4 hover:bg-[var(--surface-2)] transition-colors">
                    <span className="w-12 h-12 rounded-2xl grid place-items-center bg-[var(--accent-soft)] text-[var(--accent)]"><a.icon className="w-6 h-6" strokeWidth={1.9} /></span>
                    <span className="text-[0.62rem] font-bold text-center leading-tight">{a.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
        <ActivityEditor open={editorOpen} onClose={() => setEditorOpen(false)} />
      </div>

      {/* desktop right gutter */}
      <div aria-hidden className="hidden lg:block flex-1" />
    </div>
  );
}

function NavButton({ item, active }: { item: { name: ScreenName; icon: any; key: string }; active: boolean }) {
  const { t, goTab, lang } = useApp();
  const label = item.key === 'calendar' ? (lang === 'ar' ? 'التقويم' : 'Calendar') : t(item.key as any);
  const Icon = item.icon;
  return (
    <button className="flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-2xl transition-colors" onClick={() => goTab(item.name)} aria-current={active ? 'page' : undefined} aria-label={label}>
      <Icon className={cn('w-6 h-6 transition-all', active ? 'accent scale-110' : 'text-3')} strokeWidth={active ? 2.2 : 1.7} />
      <span className={cn('text-[0.58rem] font-bold', active ? 'accent' : 'text-3')}>{label}</span>
    </button>
  );
}

function BackPill() {
  const { back, lang } = useApp();
  return (
    <button onClick={back} className="absolute top-3 start-3 z-40 glass border hairline shadow-md rounded-full ps-2 pe-3.5 py-1.5 flex items-center gap-1 text-[0.72rem] font-extrabold" aria-label={lang === 'ar' ? 'رجوع' : 'Back'}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" className="rtl:rotate-180"><path d="M15 18l-6-6 6-6" /></svg>
      {lang === 'ar' ? 'رجوع' : 'Back'}
    </button>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <Shell />
      </AppProvider>
    </ErrorBoundary>
  );
}
