/* DAYFLOW — Focus: persistent Pomodoro/deep-work timer + distraction tracking */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Play, Pause, RotateCcw, SkipForward, Octagon, Brain, Hourglass, Zap, Infinity as InfinityIcon,
  CloudLightning, Flame, Target,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, nowMin, newId } from '@/lib/db';
import { fmtMinutes } from '@/lib/stats';
import { playChime, haptic } from '@/lib/platform';
import { ProgressRing, EmptyState, Sheet, Field, HelpTip } from '@/components/ui';
import type { FocusSession, DistractionLog } from '@/lib/types';
import { cn } from '@/utils/cn';

type Mode = 'pomodoro' | 'extended' | 'deep' | 'open' | 'countdown';
const MODES: Array<{ id: Mode; icon: any; labelAr: string; labelEn: string; work: number; breakMin: number }> = [
  { id: 'pomodoro', icon: Brain, labelAr: 'بومودورو ٢٥/٥', labelEn: 'Pomodoro 25/5', work: 25, breakMin: 5 },
  { id: 'extended', icon: Zap, labelAr: 'موسع ٥٠/١٠', labelEn: 'Extended 50/10', work: 50, breakMin: 10 },
  { id: 'deep', icon: Flame, labelAr: 'عمل عميق ٩٠', labelEn: 'Deep work 90', work: 90, breakMin: 15 },
  { id: 'countdown', icon: Hourglass, labelAr: 'عد تنازلي', labelEn: 'Countdown', work: 30, breakMin: 0 },
  { id: 'open', icon: InfinityIcon, labelAr: 'مؤقت مفتوح', labelEn: 'Open timer', work: 0, breakMin: 0 },
];

interface TimerState {
  mode: Mode; phase: 'work' | 'break'; running: boolean;
  startedAt: number | null; accumulatedSec: number; // for pause/resume
  cycles: number; workMin: number; breakMin: number; totalPlannedMin: number; taskTitle: string;
}
const DEFAULT_TIMER: TimerState = { mode: 'pomodoro', phase: 'work', running: false, startedAt: null, accumulatedSec: 0, cycles: 0, workMin: 25, breakMin: 5, totalPlannedMin: 0, taskTitle: '' };

const REASONS = [
  { id: 'phone', ar: 'الهاتف', en: 'Phone' }, { id: 'social', ar: 'التواصل الاجتماعي', en: 'Social media' },
  { id: 'noise', ar: 'ضجيج', en: 'Noise' }, { id: 'hunger', ar: 'جوع/عطش', en: 'Hunger/thirst' },
  { id: 'thoughts', ar: 'أفكار متداخلة', en: 'Racing thoughts' }, { id: 'other', ar: 'أخرى', en: 'Other' },
];

export default function Focus() {
  const { t, lang, tick, toast, bump } = useApp();
  const [timer, setTimer] = useState<TimerState>(DEFAULT_TIMER);
  const [nowSec, setNowSec] = useState(Math.floor(Date.now() / 1000));
  const [sessions, setSessions] = useState<FocusSession[]>([]);
  const [distractions, setDistractions] = useState<DistractionLog[]>([]);
  const [distractionOpen, setDistractionOpen] = useState(false);
  const [reason, setReason] = useState('phone');
  const [minutesLost, setMinutesLost] = useState(5);
  const [distractionNote, setDistractionNote] = useState('');
  const [customCountdown, setCustomCountdown] = useState(30);
  const [taskTitle, setTaskTitle] = useState('');
  const loaded = useRef(false);

  useEffect(() => { const id = setInterval(() => setNowSec(Math.floor(Date.now() / 1000)), 1000); return () => clearInterval(id); }, []);

  /* persist + restore timer so app restarts never lose or fabricate time */
  useEffect(() => {
    (async () => {
      const saved = await db.settingGet<TimerState>('focusTimer');
      if (saved) setTimer(saved);
      loaded.current = true;
    })();
  }, []);
  useEffect(() => { if (loaded.current) db.settingSet('focusTimer', timer); }, [timer]);

  const reload = useCallback(async () => {
    const [s, d] = await Promise.all([db.all<FocusSession>('focus_sessions'), db.all<DistractionLog>('distraction_logs')]);
    setSessions(s); setDistractions(d);
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const elapsedSec = useMemo(() => {
    if (!timer.running || !timer.startedAt) return timer.accumulatedSec;
    return timer.accumulatedSec + Math.floor(Date.now() / 1000) - timer.startedAt;
  }, [timer.running, timer.startedAt, timer.accumulatedSec, nowSec]);

  const planSec = timer.mode === 'open' ? 0 : (timer.phase === 'work' ? timer.workMin : timer.breakMin) * 60;
  const remainingSec = planSec > 0 ? Math.max(0, planSec - elapsedSec) : elapsedSec;
  const progress = planSec > 0 ? (elapsedSec / planSec) * 100 : 100;

  /* phase completion */
  useEffect(() => {
    if (!timer.running || planSec === 0) return;
    if (elapsedSec >= planSec) {
      (async () => {
        if (timer.phase === 'work') {
          await db.put('focus_sessions', {
            id: newId(), date: todayKey(), startedAt: Date.now() - elapsedSec * 1000, endedAt: Date.now(),
            plannedMin: timer.workMin, actualMin: Math.round(elapsedSec / 60), mode: timer.mode === 'countdown' ? 'countdown' : timer.mode,
            completed: true, taskTitle: timer.taskTitle || undefined, notes: '',
          } satisfies FocusSession);
          playChime('complete'); haptic('heavy');
          toast(lang === 'ar' ? 'عاش يا بطل! جلسة التركيز خلصت 🎉' : 'Focus session complete — well done');
          setTimer(tm => ({ ...tm, phase: 'break', running: tm.breakMin > 0, startedAt: Date.now() / 1000 | 0, accumulatedSec: 0, cycles: tm.cycles + 1, totalPlannedMin: tm.totalPlannedMin + tm.workMin }));
        } else {
          playChime('break');
          toast(lang === 'ar' ? 'الراحة خلصت — يلا نكمّل جولة جديدة 💪' : 'Break over — ready for another round?');
          setTimer(tm => ({ ...tm, phase: 'work', running: false, startedAt: null, accumulatedSec: 0 }));
        }
        bump(); reload();
      })();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [elapsedSec >= planSec, timer.running]);

  const startPause = () => setTimer(tm => tm.running
    ? { ...tm, running: false, startedAt: null, accumulatedSec: elapsedSec }
    : { ...tm, running: true, startedAt: Math.floor(Date.now() / 1000) });
  const restart = () => setTimer(tm => ({ ...tm, running: false, startedAt: null, accumulatedSec: 0 }));
  const skipPhase = () => setTimer(tm => ({ ...tm, phase: tm.phase === 'work' ? 'break' : 'work', running: false, startedAt: null, accumulatedSec: 0 }));
  const endSession = async () => {
    const minutes = Math.round(elapsedSec / 60);
    if (timer.phase === 'work' && minutes >= 1) {
      await db.put('focus_sessions', {
        id: newId(), date: todayKey(), startedAt: Date.now() - elapsedSec * 1000, endedAt: Date.now(),
        plannedMin: timer.workMin, actualMin: minutes, mode: timer.mode === 'countdown' ? 'countdown' : timer.mode,
        completed: false, taskTitle: timer.taskTitle || undefined, notes: '',
      } satisfies FocusSession);
      toast(lang === 'ar' ? `سُجلت ${minutes} دقيقة تركيز` : `${minutes} focus minutes logged`);
    }
    setTimer(tm => ({ ...tm, phase: 'work', running: false, startedAt: null, accumulatedSec: 0, cycles: 0 }));
    bump(); reload();
  };
  const pickMode = (m: Mode) => {
    const def = MODES.find(x => x.id === m)!;
    setTimer({ ...DEFAULT_TIMER, mode: m, workMin: m === 'countdown' ? customCountdown : def.work, breakMin: def.breakMin });
  };

  const saveDistraction = async () => {
    await db.put('distraction_logs', {
      id: newId(), date: todayKey(), timeMin: Math.round(nowMin()), reason: REASONS.find(r => r.id === reason)?.[lang === 'ar' ? 'ar' : 'en'] ?? reason,
      minutesLost, note: distractionNote.trim(), createdAt: Date.now(),
    } satisfies DistractionLog);
    setDistractionOpen(false); setDistractionNote(''); setMinutesLost(5);
    toast(lang === 'ar' ? 'اتسجّل — ولا يهمك، ارجع ركّز تاني 💪' : 'Distraction logged — back to work');
    bump(); reload();
  };

  const todaySessions = sessions.filter(s => s.date === todayKey());
  const todayMin = todaySessions.reduce((s, x) => s + x.actualMin, 0);
  const todayDistractions = distractions.filter(d => d.date === todayKey());

  const mm = Math.floor(remainingSec / 60), ss = remainingSec % 60;
  const timeStr = timer.mode === 'open'
    ? `${String(Math.floor(elapsedSec / 3600)).padStart(2, '0')}:${String(Math.floor((elapsedSec % 3600) / 60)).padStart(2, '0')}:${String(elapsedSec % 60).padStart(2, '0')}`
    : `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;

  return (
    <div className="pb-6 px-4 pt-14">
      <h1 className="skin-title font-extrabold flex items-center gap-2">{t('focus')}<HelpTip title="مؤقت التركيز (بومودورو)"><p><b>بومودورو 25/5:</b> تركز 25 دقيقة وبعدين ترتاح 5 دقايق — أسهل طريقة تنجز بيها من غير ما تزهق.</p><p><b>موسّع 50/10</b> و<b>عمل عميق 90:</b> للمذاكرة والشغل التقيل. حتى لو قفلت التطبيق ورجعت، المؤقت بيفضل حافظ وقتك بالظبط!</p></HelpTip></h1>

      {/* mode picker */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mt-3 pb-1">
        {MODES.map(m => {
          const Icon = m.icon; const active = timer.mode === m.id;
          return (
            <button key={m.id} onClick={() => pickMode(m.id)} aria-pressed={active}
              className={cn('flex-none flex flex-col items-center gap-1.5 rounded-2xl border px-3 py-2.5 w-[5.2rem] transition-all', active ? 'border-[var(--accent)] bg-[var(--accent-soft)]' : 'border-[var(--border)]')}>
              <Icon className={cn('w-5 h-5', active ? 'accent' : 'text-2')} />
              <span className="text-[0.55rem] font-bold leading-tight text-center">{lang === 'ar' ? m.labelAr : m.labelEn}</span>
            </button>
          );
        })}
      </div>

      {/* countdown config */}
      {timer.mode === 'countdown' && !timer.running && timer.accumulatedSec === 0 && (
        <label className="flex items-center gap-2 mt-2 text-sm">
          <span className="text-2 font-semibold">{lang === 'ar' ? 'المدة (دقيقة):' : 'Duration (min):'}</span>
          <input type="number" min={1} max={240} className="input w-24 num" value={customCountdown} onChange={e => { const v = Math.max(1, Math.min(240, Number(e.target.value) || 1)); setCustomCountdown(v); setTimer(tm => ({ ...tm, workMin: v })); }} />
        </label>
      )}

      {/* the timer */}
      <div className="card mt-3 p-6 flex flex-col items-center relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(600px 300px at 50% -20%, var(--accent-soft), transparent 60%)' }} />
        <span className="text-[0.65rem] font-extrabold tracking-[0.2em] text-2 uppercase">{timer.phase === 'work' ? (lang === 'ar' ? 'وقت التركيز' : 'Focus') : (lang === 'ar' ? 'راحة' : 'Break')}{timer.cycles > 0 ? ` · ${lang === 'ar' ? 'الجولة' : 'Round'} ${timer.cycles + 1}` : ''}</span>
        <ProgressRing size={196} stroke={14} progress={timer.mode === 'open' ? 100 : Math.min(100, progress)}>
          <div className="text-center">
            <div className="num text-[2.6rem] font-extrabold leading-none tracking-tight" dir="ltr">{timeStr}</div>
            <input value={taskTitle} onChange={e => { setTaskTitle(e.target.value); setTimer(tm => ({ ...tm, taskTitle: e.target.value })); }}
              placeholder={lang === 'ar' ? 'هتركّز في إيه؟' : 'What will you finish?'}
              className="mt-2 bg-transparent text-center text-[0.75rem] font-semibold text-2 outline-none w-40 placeholder:text-[var(--text-3)]" aria-label="task" />
          </div>
        </ProgressRing>
        <div className="flex items-center gap-3 mt-5">
          <button className="icon-btn" onClick={restart} aria-label={t('restart')}><RotateCcw className="w-5 h-5" /></button>
          <button className="w-[4.5rem] h-[4.5rem] rounded-full grid place-items-center text-[var(--on-accent)] shadow-lg transition-transform active:scale-95" style={{ background: 'linear-gradient(160deg, var(--accent), var(--accent-deep))', boxShadow: '0 12px 30px color-mix(in srgb, var(--accent) 45%, transparent)' }} onClick={startPause} aria-label={timer.running ? t('pause') : t('start')}>
            {timer.running ? <Pause className="w-7 h-7" fill="currentColor" /> : <Play className="w-7 h-7 translate-x-[1px]" fill="currentColor" />}
          </button>
          <button className="icon-btn" onClick={skipPhase} aria-label={t('skipPhase')}><SkipForward className="w-5 h-5" /></button>
        </div>
        <button className="btn btn-ghost btn-sm mt-3" onClick={endSession}><Octagon className="w-4 h-4" />{t('endSession')}</button>
      </div>

      {/* distraction button */}
      <button onClick={() => setDistractionOpen(true)} className="btn w-full justify-center mt-3 py-3 font-extrabold text-[var(--danger)]" style={{ background: 'var(--danger-soft)', borderColor: 'transparent' }}>
        <CloudLightning className="w-5 h-5" />{t('iGotDistracted')}
      </button>

      {/* stats */}
      <div className="grid grid-cols-3 gap-2 mt-4">
        <div className="card-flat p-3"><p className="text-[0.6rem] font-bold text-2">{lang === 'ar' ? 'تركيز النهارده' : "Today's focus"}</p><p className="num text-lg font-extrabold">{fmtMinutes(todayMin, lang)}</p></div>
        <div className="card-flat p-3"><p className="text-[0.6rem] font-bold text-2">{lang === 'ar' ? 'جلسات النهارده' : "Today's sessions"}</p><p className="num text-lg font-extrabold">{todaySessions.length}</p></div>
        <div className="card-flat p-3"><p className="text-[0.6rem] font-bold text-2">{lang === 'ar' ? 'مرات التشتت' : "Today's distractions"}</p><p className="num text-lg font-extrabold text-[var(--warn)]">{todayDistractions.length}</p></div>
      </div>

      {/* today log */}
      <p className="text-[0.7rem] font-extrabold text-2 uppercase tracking-wide mt-4 mb-1 flex items-center gap-1.5"><Target className="w-4 h-4" />{lang === 'ar' ? 'سجل اليوم' : "Today's log"}</p>
      {todaySessions.length === 0 && <EmptyState icon={<Brain className="w-7 h-7" />} title={lang === 'ar' ? 'لسه مبدأتش جلسات النهارده' : 'No sessions yet'} hint={lang === 'ar' ? 'اختار نظام الوقت وابدأ — الجلسة بتتحفظ حتى لو قفلت التطبيق' : 'Start your first session — it persists even across app restarts'} />}
      <div className="space-y-1.5">
        {todaySessions.map(s => (
          <div key={s.id} className="card-flat px-3 py-2 flex items-center gap-2">
            <div className={cn('w-2 h-8 rounded-full', s.completed ? 'bg-[var(--ok)]' : 'bg-[var(--warn)]')} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold truncate">{s.taskTitle || (lang === 'ar' ? 'جلسة تركيز' : 'Focus session')}</p>
              <p className="text-[0.62rem] text-2">{new Date(s.startedAt).toLocaleTimeString(lang === 'ar' ? 'ar' : 'en-GB', { hour: '2-digit', minute: '2-digit' })} · {s.completed ? (lang === 'ar' ? 'مكتملة' : 'completed') : (lang === 'ar' ? 'جزئية' : 'partial')}</p>
            </div>
            <span className="num text-sm font-extrabold">{fmtMinutes(s.actualMin, lang)}</span>
          </div>
        ))}
      </div>

      {/* distraction sheet */}
      <Sheet open={distractionOpen} onClose={() => setDistractionOpen(false)} title={t('iGotDistracted')}>
        <span className="label">{t('distractionReason')}</span>
        <div className="flex flex-wrap gap-1.5 mb-3">
          {REASONS.map(r => <button key={r.id} className={cn('chip', reason === r.id && 'chip-active')} onClick={() => setReason(r.id)}>{lang === 'ar' ? r.ar : r.en}</button>)}
        </div>
        <Field label={`${t('minutesLost')}: ${minutesLost}`}>
          <input type="range" min={1} max={60} value={minutesLost} onChange={e => setMinutesLost(Number(e.target.value))} className="w-full accent-[var(--accent)]" />
        </Field>
        <Field label={lang === 'ar' ? 'ملاحظة (اختياري)' : 'Note (optional)'}><input className="input" value={distractionNote} onChange={e => setDistractionNote(e.target.value)} placeholder="…" /></Field>
        <button className="btn btn-primary w-full justify-center" onClick={saveDistraction}>{t('saveDistraction')}</button>
      </Sheet>
    </div>
  );
}
