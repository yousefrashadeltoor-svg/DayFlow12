/* DAYFLOW — Full Interactive Calendar with Egyptian occasions, Hijri dates, real unique photos,
   strict red (!) alert badges + religion names for Christian/Jewish occasions (never in notifications/widgets),
   official holiday badges, green (?) full details, personal occasion/task/block scheduling for any date. */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ChevronLeft, ChevronRight, Plus, CalendarPlus, ListTodo, Clock, Trash2,
  BellRing, BellOff, PartyPopper, Search, CheckCircle2,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, newId, minToTime } from '@/lib/db';
import {
  occasionsInRange, occasionsForYear, personalToOccasions, hijriOf, hijriLabel,
  KIND_LABEL, type Occasion, type PersonalOccasion,
} from '@/lib/occasions';
import { Sheet, Field, HelpTip, Toggle, EmptyState } from '@/components/ui';
import ActivityEditor from '@/components/ActivityEditor';
import { haptic } from '@/lib/platform';
import type { ActivityBlock, TaskItem } from '@/lib/types';
import { cn } from '@/utils/cn';

type FilterKind = 'all' | 'official' | 'personal' | 'year';

export function OccasionBadges({ o, lang }: { o: Occasion; lang: 'ar' | 'en' }) {
  return (
    <span className="inline-flex flex-wrap items-center gap-1.5">
      {o.religion ? (
        <span className="religion-badge" role="note" aria-label={`ديانة ${o.religion}`}>
          <i aria-hidden>!</i>
          {lang === 'ar' ? `الديانة: ${o.religion}` : (o.kind === 'jewish' ? 'Religion: Jewish' : 'Religion: Christian')}
        </span>
      ) : (
        <span
          className="chip !py-0.5 !text-[0.6rem]"
          style={{
            color: KIND_LABEL[o.kind].color,
            borderColor: 'transparent',
            background: `color-mix(in srgb, ${KIND_LABEL[o.kind].color} 13%, transparent)`,
          }}
        >
          {lang === 'ar' ? KIND_LABEL[o.kind].ar : KIND_LABEL[o.kind].en}
        </span>
      )}

      {o.kind !== 'personal' && (
        <span className={cn(
          'chip !py-0.5 !text-[0.6rem]',
          o.official
            ? '!text-[var(--ok)] !bg-[var(--ok-soft)] !border-transparent font-extrabold'
            : '!text-2'
        )}>
          {o.official
            ? (lang === 'ar' ? 'إجازة رسمية ✓' : 'Official holiday ✓')
            : (lang === 'ar' ? 'مش إجازة رسمية' : 'Not an official holiday')}
        </span>
      )}

      {o.kind === 'personal' && (
        <span className="chip !py-0.5 !text-[0.58rem] !text-[var(--accent)] !bg-[var(--accent-soft)] !border-transparent">
          <BellRing className="w-3 h-3" />{lang === 'ar' ? 'في الإشعارات والويدجيت' : 'Notified'}
        </span>
      )}

      {!o.notify && (
        <span className="chip !py-0.5 !text-[0.56rem] opacity-75">
          <BellOff className="w-2.5 h-2.5" />{lang === 'ar' ? 'بدون إشعار أو ويدجيت' : 'No alert/widget'}
        </span>
      )}
    </span>
  );
}

export function OccasionCard({ o, lang, onDelete }: { o: Occasion; lang: 'ar' | 'en'; onDelete?: () => void }) {
  return (
    <div className={cn('card overflow-hidden', o.religion && 'border-[rgba(220,38,38,.28)]')}>
      <div className="relative h-32">
        <img src={o.image} alt={lang === 'ar' ? o.nameAr : o.nameEn} className="absolute inset-0 w-full h-full object-cover" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/78 via-black/22 to-black/10" />
        {o.decor && <img src={`/decor/${o.decor}.png`} alt="" className="decor-float absolute top-2 end-2 w-11 h-11 object-contain" />}
        {o.religion && (
          <span className="absolute top-2 start-2 bg-[#dc2626] text-white text-[0.6rem] font-extrabold rounded-full ps-1.5 pe-2.5 py-0.5 flex items-center gap-1 shadow">
            <span className="w-3.5 h-3.5 rounded-full bg-white text-[#dc2626] font-black text-[10px] grid place-items-center">!</span>
            {o.religion}
          </span>
        )}
        <div className="absolute bottom-2.5 start-3 end-3 text-white">
          <p className="font-extrabold text-[1rem] leading-snug drop-shadow">{lang === 'ar' ? o.nameAr : o.nameEn}</p>
          {o.time != null && (
            <p className="text-[0.66rem] font-bold opacity-90 flex items-center gap-1 mt-0.5 num">
              <Clock className="w-3 h-3" />{minToTime(o.time)}
            </p>
          )}
        </div>
      </div>

      <div className="p-3 flex items-center gap-2">
        <div className="flex-1 min-w-0"><OccasionBadges o={o} lang={lang} /></div>
        <HelpTip title={lang === 'ar' ? o.nameAr : o.nameEn}>
          <img src={o.image} alt="" className="w-full h-44 object-cover rounded-2xl shadow-sm" />
          <div className="flex flex-wrap gap-1.5"><OccasionBadges o={o} lang={lang} /></div>
          <p className="leading-[1.9]">{lang === 'ar' ? o.detailsAr : o.detailsEn}</p>
          <ul>
            <li><b>التاريخ:</b> {new Intl.DateTimeFormat('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(o.date + 'T12:00:00'))} ({hijriLabel(new Date(o.date + 'T12:00:00'), 'ar')})</li>
            <li><b>حالة الإجازة:</b> {o.official ? 'إجازة رسمية مدفوعة الأجر في مصر ✓' : 'يوم عمل عادي (مش إجازة رسمية)'}{o.officialNote ? ` — ${o.officialNote}` : ''}</li>
            {o.religion && <li><b>الديانة:</b> مناسبة <b>{o.religion}</b> — محذوفة تماماً من الإشعارات والويدجيت ومعروضة في التقويم للمعرفة فقط.</li>}
            {!o.religion && <li><b>التنبيه:</b> بتظهر تلقائياً في الإشعارات والويدجيت على الشاشة الرئيسية في يومها ✓.</li>}
            {o.kind === 'islamic' && <li><b>تنويه:</b> التاريخ الهجري محسوب بتقويم أم القرى، وممكن يفرق يوم حسب رؤية الهلال في مصر — تقدر تظبطه من الإعدادات ← اللغة والوقت.</li>}
          </ul>
        </HelpTip>
        {onDelete && (
          <button
            className="icon-btn !w-8 !h-8 text-[var(--danger)]"
            onClick={e => { e.stopPropagation(); onDelete(); }}
            aria-label="امسح المناسبة"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}

export default function CalendarScreen() {
  const { lang, locale, hour12, settings, tick, bump, toast, confirm } = useApp();
  const [cursor, setCursor] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  const [selected, setSelected] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterKind>('all');
  const [query, setQuery] = useState('');
  const [personal, setPersonal] = useState<PersonalOccasion[]>([]);
  const [blocks, setBlocks] = useState<ActivityBlock[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [occOpen, setOccOpen] = useState(false);
  const [taskOpen, setTaskOpen] = useState(false);
  const [blockOpen, setBlockOpen] = useState(false);

  const reload = useCallback(async () => {
    const [p, b, t] = await Promise.all([
      db.all<PersonalOccasion>('personal_occasions'),
      db.all<ActivityBlock>('activity_blocks'),
      db.all<TaskItem>('tasks'),
    ]);
    setPersonal(p); setBlocks(b); setTasks(t);
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const cells = useMemo(() => {
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const off = (first.getDay() - settings.weekStart + 7) % 7;
    return Array.from({ length: 42 }, (_, i) => { const d = new Date(first); d.setDate(1 - off + i); return d; });
  }, [cursor, settings.weekStart]);

  const from = todayKey(cells[0]), to = todayKey(cells[41]);
  const occ = useMemo(() => occasionsInRange(from, to, settings.hijriOffset, personal), [from, to, settings.hijriOffset, personal]);
  const yearOcc = useMemo(() => {
    const y = cursor.getFullYear();
    return [...occasionsForYear(y, settings.hijriOffset), ...personalToOccasions(personal, y)].sort((a, b) => a.date.localeCompare(b.date));
  }, [cursor, settings.hijriOffset, personal]);
  const byDate = useMemo(() => {
    const m = new Map<string, Occasion[]>();
    for (const o of occ) (m.get(o.date) ?? m.set(o.date, []).get(o.date)!).push(o);
    return m;
  }, [occ]);

  const weekdays = useMemo(
    () => Array.from({ length: 7 }, (_, i) => new Intl.DateTimeFormat(locale, { weekday: 'short' }).format(new Date(2024, 5, 2 + ((settings.weekStart + i) % 7)))),
    [locale, settings.weekStart]
  );

  const listOcc = useMemo(() => {
    const ym = todayKey(cursor).slice(0, 7);
    const base = (filter === 'year' || query.trim()) ? yearOcc : occ.filter(o => o.date.slice(0, 7) === ym);
    return base
      .filter(o => filter === 'official' ? o.official : filter === 'personal' ? o.kind === 'personal' : true)
      .filter(o => !query.trim() || (o.nameAr + ' ' + o.nameEn + ' ' + o.detailsAr).toLowerCase().includes(query.trim().toLowerCase()));
  }, [cursor, filter, query, occ, yearOcc]);

  const h1 = hijriOf(cells[7], settings.hijriOffset), h2 = hijriOf(cells[35], settings.hijriOffset);
  const hMonth = (d: Date) => hijriLabel(d, lang, settings.hijriOffset).replace(/^\d+\s/, '');

  const dayOcc = selected ? byDate.get(selected) ?? [] : [];
  const dayBlocks = selected ? blocks.filter(b => b.date === selected && b.status !== 'cancelled').sort((a, b) => a.startMin - b.startMin) : [];
  const dayTasks = selected ? tasks.filter(t => t.dueDate === selected) : [];

  /* ---- Add personal occasion ---- */
  const [oTitle, setOTitle] = useState('');
  const [oTime, setOTime] = useState('09:00');
  const [oHasTime, setOHasTime] = useState(true);
  const [oYearly, setOYearly] = useState(false);
  const [oPre, setOPre] = useState(1);
  const [oNote, setONote] = useState('');
  const [oColor, setOColor] = useState('#7c3aed');

  const saveOccasion = async () => {
    const target = selected ?? todayKey();
    if (!oTitle.trim()) { toast(lang === 'ar' ? 'اكتب اسم المناسبة الأول' : 'Enter a title'); return; }
    const [hh, mm] = oTime.split(':').map(Number);
    await db.put('personal_occasions', {
      id: newId(), title: oTitle.trim(), date: target, yearly: oYearly,
      timeMin: oHasTime ? hh * 60 + mm : null, remindDaysBefore: oPre,
      color: oColor, note: oNote.trim(), createdAt: Date.now(),
    } satisfies PersonalOccasion);
    haptic('medium');
    setOccOpen(false); setOTitle(''); setONote(''); bump();
    toast(lang === 'ar' ? 'اتضافت المناسبة ✓ وهتوصلك في الإشعارات والويدجيت' : 'Occasion added — appears in notifications & widgets');
  };

  /* ---- Add task directly on specific day ---- */
  const [tTitle, setTTitle] = useState('');
  const [tEst, setTEst] = useState(30);
  const [tPri, setTPri] = useState<1 | 2 | 3 | 4>(2);
  const [tNote, setTNote] = useState('');
  const saveTask = async () => {
    if (!tTitle.trim() || !selected) { toast(lang === 'ar' ? 'اكتب عنوان المهمة' : 'Enter a task title'); return; }
    await db.put('tasks', {
      id: newId(), title: tTitle.trim(), description: '', dueDate: selected, startDate: null,
      priority: tPri, status: 'todo', estimatedMin: tEst, trackedMin: 0, categoryId: 'work',
      tags: [], checklist: [], starred: false, projectId: null, goalId: null,
      recurrence: 'none', reminderAt: null, notes: tNote.trim(), createdAt: Date.now(), updatedAt: Date.now(),
    } satisfies TaskItem);
    haptic('medium');
    setTaskOpen(false); setTTitle(''); setTNote(''); bump();
    toast(lang === 'ar' ? 'اتضافت المهمة ليومها وهتفكرك في الإشعار ✓' : 'Task scheduled on this day ✓');
  };

  const toggleDayTask = async (tk: TaskItem) => {
    await db.put('tasks', { ...tk, status: tk.status === 'done' ? 'todo' : 'done', updatedAt: Date.now() });
    haptic('light'); bump();
  };

  return (
    <div className="pb-6 px-4 pt-5">
      <div className="flex items-center justify-between gap-2">
        <h1 className="skin-title font-extrabold flex items-center gap-2 grad-text">
          <img src="/decor/calendar-spiral.png" alt="" className="w-8 h-8 decor-float" />
          {lang === 'ar' ? 'التقويم والمناسبات' : 'Calendar'}
          <HelpTip title="التقويم والمناسبات">
            <p>كل أيام السنة بالتاريخ الميلادي والهجري، ومناسبات مصر الرسمية والدينية بصور حقيقية وتفاصيل كاملة:</p>
            <ul>
              <li>دوس على <b>أي يوم</b> عشان تشوف مناسبته، وتضيف فيه <b>مناسبة خاصة</b> أو <b>مهمة</b> أو <b>نشاط بساعة</b>.</li>
              <li><b>الرقم الأحمر</b> = إجازة رسمية في مصر.</li>
              <li><b>دائرة حمراء (!)</b> = مناسبة مسيحية أو يهودية مع اسم الديانة — معروضة للعلم فقط <b>ومحذوفة تلقائياً</b> من الإشعارات والويدجيت.</li>
              <li>أي مناسبة تانية أو مناسبتك الخاصة بتظهر أوتوماتيك في الإشعارات والويدجيت.</li>
            </ul>
          </HelpTip>
        </h1>
        <div className="flex items-center gap-1.5">
          <button className="btn btn-soft btn-sm" onClick={() => { const n = new Date(); setCursor(new Date(n.getFullYear(), n.getMonth(), 1)); setSelected(todayKey()); }}>
            {lang === 'ar' ? 'النهارده' : 'Today'}
          </button>
          <button className="icon-btn bg-[var(--accent)] !text-[var(--on-accent)]" onClick={() => { if (!selected) setSelected(todayKey()); setOccOpen(true); }} aria-label="ضيف مناسبة">
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Month grid */}
      <div className="card p-3 mt-3">
        <div className="flex items-center justify-between pb-2">
          <button className="icon-btn" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))} aria-label="الشهر اللي فات">
            <ChevronRight className="w-5 h-5 ltr:rotate-180" />
          </button>
          <div className="text-center">
            <p className="font-extrabold text-base">{new Intl.DateTimeFormat(locale, { month: 'long', year: 'numeric' }).format(cursor)}</p>
            {h1 && h2 && (
              <p className="text-[0.64rem] text-2 font-bold">
                {hMonth(cells[10])}{h1.m !== h2.m ? ` · ${hMonth(cells[33])}` : ''}
              </p>
            )}
          </div>
          <button className="icon-btn" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))} aria-label="الشهر الجاي">
            <ChevronLeft className="w-5 h-5 ltr:rotate-180" />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1">
          {weekdays.map((w, i) => <div key={i} className="text-center text-[0.58rem] font-extrabold text-3 pb-1">{w}</div>)}
          {cells.map(d => {
            const k = todayKey(d);
            const inMonth = d.getMonth() === cursor.getMonth();
            const isToday = k === todayKey();
            const os = byDate.get(k) ?? [];
            const top = os.find(o => o.notify) ?? os[0];
            const nB = blocks.filter(b => b.date === k && b.status !== 'cancelled').length;
            const nT = tasks.filter(t => t.dueDate === k && t.status !== 'done').length;
            const hd = hijriOf(d, settings.hijriOffset)?.d;
            const holiday = os.some(o => o.official);
            const hasFlag = os.some(o => !!o.religion);
            return (
              <button
                key={k}
                onClick={() => { haptic('light'); setSelected(k); }}
                className={cn(
                  'relative rounded-xl min-h-[4rem] p-1 flex flex-col items-center overflow-hidden transition-transform active:scale-95 border',
                  isToday ? 'border-[var(--accent)] ring-1 ring-[var(--accent)]' : 'border-transparent',
                  !inMonth && 'opacity-35'
                )}
                style={{ background: top ? `color-mix(in srgb, ${KIND_LABEL[top.kind].color} 11%, var(--surface-2))` : 'var(--surface-2)' }}
                aria-label={`${k}${top ? ` ${top.nameAr}` : ''}`}
              >
                <span className={cn('num text-[0.82rem] font-extrabold leading-none', holiday && 'text-[var(--danger)]', isToday && 'accent')}>
                  {d.getDate()}
                </span>
                <span className="num text-[0.5rem] text-3 leading-none mt-0.5">{hd}</span>
                {top && (
                  <>
                    <img src={top.decor ? `/decor/${top.decor}.png` : top.image} alt="" className="w-5 h-5 mt-0.5 object-contain" loading="lazy" />
                    <span className="text-[0.44rem] font-bold leading-none truncate w-full text-center opacity-80 mt-0.5">
                      {(lang === 'ar' ? top.nameAr : top.nameEn).slice(0, 10)}
                    </span>
                  </>
                )}
                {hasFlag && (
                  <span className="absolute top-0.5 start-0.5 w-3.5 h-3.5 rounded-full bg-[#dc2626] text-white text-[9px] font-black grid place-items-center shadow" title={os.find(o => o.religion)?.religion}>!</span>
                )}
                {(nB > 0 || nT > 0) && (
                  <span className="flex gap-0.5 mt-auto pt-0.5">
                    {nB > 0 && <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)]" />}
                    {nT > 0 && <span className="w-1.5 h-1.5 rounded-full bg-[var(--warn)]" />}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2.5 text-[0.58rem] text-2 font-bold">
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)]" />أنشطة</span>
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[var(--warn)]" />مهام</span>
          <span className="flex items-center gap-1"><span className="text-[var(--danger)] font-black">12</span>إجازة رسمية</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-[#dc2626] text-white text-[8px] font-black inline-grid place-items-center">!</span>مسيحية/يهودية (للعلم)</span>
        </div>
      </div>

      {/* Filter & search across month or full year */}
      <div className="mt-4 flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {([
          ['all', lang === 'ar' ? 'مناسبات الشهر' : 'This month'],
          ['year', lang === 'ar' ? `السنة كلها (${cursor.getFullYear()})` : `All ${cursor.getFullYear()}`],
          ['official', lang === 'ar' ? 'الإجازات الرسمية' : 'Holidays'],
          ['personal', lang === 'ar' ? `مناسباتي (${personal.length})` : 'Mine'],
        ] as const).map(([id, label]) => (
          <button key={id} className={cn('chip flex-none', filter === id && 'chip-active')} onClick={() => setFilter(id)}>{label}</button>
        ))}
      </div>

      <div className="relative mt-2">
        <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-3" />
        <input className="input ps-9 !py-2 text-sm" value={query} onChange={e => setQuery(e.target.value)} placeholder={lang === 'ar' ? 'دوّر على أي مناسبة في السنة (رمضان، شم النسيم، أكتوبر…)' : 'Search any occasion…'} />
      </div>

      <h3 className="text-[0.76rem] font-extrabold text-2 mt-4 mb-2 flex items-center gap-1.5">
        <PartyPopper className="w-4 h-4 accent" />
        {lang === 'ar' ? `النتايج (${listOcc.length})` : `Occasions (${listOcc.length})`}
      </h3>
      <div className="space-y-3">
        {listOcc.map(o => (
          <div key={o.id}>
            <button className="text-[0.65rem] font-bold text-2 mb-1 block hover:underline" onClick={() => setSelected(o.date)}>
              {new Intl.DateTimeFormat(locale, { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(o.date + 'T12:00:00'))}
              {' · '}
              <span className="text-3">{hijriLabel(new Date(o.date + 'T12:00:00'), lang, settings.hijriOffset)}</span>
            </button>
            <OccasionCard
              o={o} lang={lang}
              onDelete={o.personalId ? async () => {
                if (await confirm({ title: 'تمسح المناسبة دي؟', danger: true, confirmLabel: 'امسح' })) {
                  await db.del('personal_occasions', o.personalId!); bump(); toast('اتمسحت');
                }
              } : undefined}
            />
          </div>
        ))}
        {listOcc.length === 0 && (
          <EmptyState
            icon={<CalendarPlus className="w-7 h-7" />}
            title={lang === 'ar' ? 'مفيش مناسبات هنا' : 'No occasions found'}
            hint={lang === 'ar' ? 'دوس على أي يوم في التقويم وضيف مناسبتك الخاصة أو مهمتك' : 'Tap any date to add a personal occasion or task'}
            action={<button className="btn btn-primary btn-sm" onClick={() => { setSelected(todayKey()); setOccOpen(true); }}><CalendarPlus className="w-4 h-4" />ضيف مناسبة</button>}
          />
        )}
      </div>

      {/* Selected Day Full Sheet */}
      <Sheet
        open={!!selected}
        onClose={() => setSelected(null)}
        title={selected ? new Intl.DateTimeFormat(locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(selected + 'T12:00:00')) : ''}
      >
        {selected && (
          <div className="space-y-3">
            <p className="text-[0.72rem] font-bold accent -mt-2">{hijriLabel(new Date(selected + 'T12:00:00'), lang, settings.hijriOffset)}</p>
            <div className="grid grid-cols-3 gap-2">
              <button className="btn btn-soft justify-center !px-2 !text-[0.72rem]" onClick={() => setOccOpen(true)}>
                <CalendarPlus className="w-4 h-4" />{lang === 'ar' ? 'ضيف مناسبة' : 'Occasion'}
              </button>
              <button className="btn btn-soft justify-center !px-2 !text-[0.72rem]" onClick={() => setTaskOpen(true)}>
                <ListTodo className="w-4 h-4" />{lang === 'ar' ? 'ضيف مهمة' : 'Task'}
              </button>
              <button className="btn btn-primary justify-center !px-2 !text-[0.72rem]" onClick={() => setBlockOpen(true)}>
                <Plus className="w-4 h-4" />{lang === 'ar' ? 'ضيف نشاط' : 'Block'}
              </button>
            </div>

            {dayOcc.map(o => (
              <OccasionCard key={o.id} o={o} lang={lang} onDelete={o.personalId ? async () => {
                if (await confirm({ title: 'تمسح المناسبة؟', danger: true, confirmLabel: 'امسح' })) {
                  await db.del('personal_occasions', o.personalId!); bump();
                }
              } : undefined} />
            ))}

            {dayTasks.length > 0 && (
              <div className="card-flat p-3">
                <p className="text-[0.7rem] font-extrabold text-2 mb-1.5">{lang === 'ar' ? `مهام اليوم (${dayTasks.length})` : 'Tasks'}</p>
                {dayTasks.map(tk => (
                  <button key={tk.id} onClick={() => toggleDayTask(tk)} className="w-full text-start text-sm py-1.5 flex items-center gap-2 hover:bg-[var(--surface-2)] px-1.5 rounded-lg">
                    <CheckCircle2 className={cn('w-4 h-4 shrink-0', tk.status === 'done' ? 'text-[var(--ok)]' : 'text-[var(--warn)]')} />
                    <span className={cn('flex-1 font-semibold', tk.status === 'done' && 'line-through opacity-60')}>{tk.title}</span>
                    <span className="num text-[0.62rem] text-3">~{tk.estimatedMin}د</span>
                  </button>
                ))}
              </div>
            )}

            {dayBlocks.length > 0 && (
              <div className="card-flat p-3">
                <p className="text-[0.7rem] font-extrabold text-2 mb-1.5">{lang === 'ar' ? `جدول اليوم (${dayBlocks.length})` : 'Scheduled blocks'}</p>
                {dayBlocks.map(b => (
                  <div key={b.id} className="py-1.5 border-b hairline last:border-0">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="num text-[0.68rem] font-bold accent shrink-0" dir="ltr">{minToTime(b.startMin, hour12)}–{minToTime(b.endMin, hour12)}</span>
                      <span className={cn('flex-1 font-bold truncate', b.status === 'done' && 'line-through opacity-60')}>{b.title}</span>
                      {b.reminderMin >= 0 && <BellRing className="w-3.5 h-3.5 text-3 shrink-0" />}
                    </div>
                    {b.notes && !b.notes.startsWith('tpl:') && <p className="text-[0.65rem] text-2 mt-0.5">📝 {b.notes}</p>}
                  </div>
                ))}
              </div>
            )}

            {!dayOcc.length && !dayTasks.length && !dayBlocks.length && (
              <p className="text-sm text-2 text-center py-5">{lang === 'ar' ? 'اليوم ده فاضي — تقدر تضيفله مناسبة أو مهمة أو نشاط من فوق 👆' : 'Free day — tap any button above'}</p>
            )}
          </div>
        )}
      </Sheet>

      {/* Create personal occasion */}
      <Sheet open={occOpen} onClose={() => setOccOpen(false)} title={lang === 'ar' ? 'ضيف مناسبة جديدة' : 'New occasion'}>
        <Field label="اسم المناسبة">
          <input autoFocus className="input" value={oTitle} onChange={e => setOTitle(e.target.value)} placeholder="مثلاً: عيد ميلاد ماما، ذكرى الجواز، ميعاد دكتور…" />
        </Field>
        <div className="flex items-center justify-between py-2">
          <span className="text-sm font-bold">ليها ساعة محددة</span>
          <Toggle on={oHasTime} onChange={setOHasTime} />
        </div>
        {oHasTime && (
          <Field label="الساعة"><input type="time" className="input num" value={oTime} onChange={e => setOTime(e.target.value)} /></Field>
        )}
        <div className="flex items-center justify-between py-2">
          <span className="text-sm font-bold flex items-center gap-1.5">تتكرر كل سنة<HelpTip title="تكرار سنوي">مثالية لأعياد الميلاد والذكريات — المناسبة هتظهر وتنبهك في نفس اليوم كل سنة من غير ما تضيفها تاني.</HelpTip></span>
          <Toggle on={oYearly} onChange={setOYearly} />
        </div>
        <Field label="فكّرني قبلها بـ">
          <select className="input" value={oPre} onChange={e => setOPre(Number(e.target.value))}>
            <option value={0}>في يومها بس</option>
            <option value={1}>قبلها بيوم</option>
            <option value={2}>قبلها بيومين</option>
            <option value={3}>قبلها بـ 3 أيام</option>
            <option value={7}>قبلها بأسبوع</option>
          </select>
        </Field>
        <Field label="تفاصيل / ملاحظة (تظهر في الإشعار)"><input className="input" value={oNote} onChange={e => setONote(e.target.value)} placeholder="أشتري الهدية، أحجز مكان…" /></Field>
        <div className="flex gap-2 mb-4">
          {['#7c3aed', '#e0356a', '#0e8a94', '#d97706', '#16a34a', '#2563eb'].map(c => (
            <button key={c} onClick={() => setOColor(c)} className={cn('w-8 h-8 rounded-full transition-transform', oColor === c && 'scale-115 ring-2 ring-offset-2 ring-[var(--accent)]')} style={{ background: c }} aria-label={c} />
          ))}
        </div>
        <button className="btn btn-primary w-full justify-center !py-3" onClick={saveOccasion}>احفظ المناسبة 🔔</button>
      </Sheet>

      {/* Create task for exact date */}
      <Sheet open={taskOpen} onClose={() => setTaskOpen(false)} title={`مهمة ليوم ${selected ?? ''}`}>
        <Field label="عنوان المهمة"><input autoFocus className="input" value={tTitle} onChange={e => setTTitle(e.target.value)} placeholder="مثلاً: أدفع فاتورة النت / أسلم المشروع…" /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="تقدير الوقت (دقيقة)"><input type="number" min={5} step={5} className="input num" value={tEst} onChange={e => setTEst(Math.max(5, Number(e.target.value) || 5))} /></Field>
          <Field label="الأهمية">
            <select className="input" value={tPri} onChange={e => setTPri(Number(e.target.value) as any)}>
              <option value={1}>مهمة جداً 🔥</option>
              <option value={2}>مهمة</option>
              <option value={3}>عادية</option>
              <option value={4}>مش مستعجلة</option>
            </select>
          </Field>
        </div>
        <Field label="ملاحظة (اختياري)"><input className="input" value={tNote} onChange={e => setTNote(e.target.value)} placeholder="تفاصيل صغيرة…" /></Field>
        <button className="btn btn-primary w-full justify-center !py-3" onClick={saveTask}>احفظ المهمة ✓</button>
      </Sheet>

      <ActivityEditor open={blockOpen} onClose={() => { setBlockOpen(false); reload(); }} defaultDate={selected ?? todayKey()} />
    </div>
  );
}
