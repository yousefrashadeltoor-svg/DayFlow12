/* DAYFLOW — Progress: real analytics, weekly smart report, exports */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  TrendingUp, Brain, CheckCheck, XCircle, FileSpreadsheet, FileJson, FileDown, Award, AlertCircle,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, addDays } from '@/lib/db';
import { completionSeries, categoryDistribution, workloadBars, focusMinutes, weeklyReport, fmtMinutes, lastNDays } from '@/lib/stats';
import { LineChart, BarChart, DonutChart, Heatmap } from '@/components/charts';
import { Segmented, SectionTitle, LinearProgress, HelpTip } from '@/components/ui';
import { exportCsvDataset, exportXlsx, downloadTextFile, createJsonBackup } from '@/lib/backup';
import type { ActivityBlock, FocusSession, WaterLog, HabitLog, Habit, TaskItem, ActivityCategory } from '@/lib/types';

export default function Progress() {
  const { t, lang, locale, tick, toast } = useApp();
  const [range, setRange] = useState<'7' | '30' | '90'>('7');
  const [blocks, setBlocks] = useState<ActivityBlock[]>([]);
  const [sessions, setSessions] = useState<FocusSession[]>([]);
  const [water, setWater] = useState<WaterLog[]>([]);
  const [habitLogs, setHabitLogs] = useState<HabitLog[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [changes, setChanges] = useState(0);
  const [cats, setCats] = useState<ActivityCategory[]>([]);

  const reload = useCallback(async () => {
    const cutoff = addDays(todayKey(), -90);
    const [b, s, w, hl, h, tk, ch, c] = await Promise.all([
      db.all<ActivityBlock>('activity_blocks'), db.all<FocusSession>('focus_sessions'),
      db.all<WaterLog>('water_logs'), db.all<HabitLog>('habit_logs'), db.all<Habit>('habits'),
      db.all<TaskItem>('tasks'), db.all<any>('schedule_changes'), db.all<ActivityCategory>('activity_categories'),
    ]);
    setBlocks(b); setSessions(s); setWater(w); setHabitLogs(hl); setHabits(h); setTasks(tk);
    setChanges(ch.filter((x: any) => x.createdAt >= Date.parse(cutoff)).length); setCats(c);
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const n = Number(range);
  const cutoff = addDays(todayKey(), -n);
  const scoped = blocks.filter(b => b.date >= cutoff && b.status !== 'cancelled');
  const doneMin = scoped.filter(b => b.status === 'done').reduce((s, b) => s + (b.endMin - b.startMin), 0);
  const missed = scoped.filter(b => b.status === 'missed' || b.status === 'skipped').length;
  const series = useMemo(() => completionSeries(blocks, 7), [blocks]);
  const bars = useMemo(() => workloadBars(blocks, 14).map(d => ({ label: new Intl.DateTimeFormat(locale, { day: 'numeric' }).format(new Date(d.date + 'T12:00:00')), value: d.hours })), [blocks, locale]);
  const dist = useMemo(() => categoryDistribution(blocks, 30).slice(0, 5).map(d => ({ label: (cats.find(c => c.id === d.categoryId)?.[lang === 'ar' ? 'nameAr' : 'nameEn']) ?? d.categoryId, value: d.minutes, color: catColor(d.categoryId) })), [blocks, cats, lang]);
  const heat = useMemo(() => {
    const days = lastNDays(84);
    const doneByDate = new Map<string, number>();
    for (const b of blocks) if (b.status === 'done') doneByDate.set(b.date, (doneByDate.get(b.date) ?? 0) + (b.endMin - b.startMin));
    const level = (mins: number): 0 | 1 | 2 | 3 | 4 => mins <= 0 ? 0 : mins < 30 ? 1 : mins < 90 ? 2 : mins < 180 ? 3 : 4;
    const weeks: Array<Array<{ date: string; level: 0 | 1 | 2 | 3 | 4 }>> = [];
    for (let i = 0; i < days.length; i += 7) weeks.push(days.slice(i, i + 7).map(date => ({ date, level: level(doneByDate.get(date) ?? 0) })));
    return weeks;
  }, [blocks]);

  const studyMin = scoped.filter(b => b.categoryId === 'study' && b.status === 'done').reduce((s, b) => s + (b.endMin - b.startMin), 0);
  const exerciseMin = scoped.filter(b => b.categoryId === 'exercise' && b.status === 'done').reduce((s, b) => s + (b.endMin - b.startMin), 0);
  const deadlines = tasks.filter(t => t.status !== 'done' && t.dueDate && t.dueDate >= todayKey() && t.dueDate <= addDays(todayKey(), 7)).length;
  const bestHabit = useMemo(() => {
    if (!habits.length) return null;
    let best: { name: string; rate: number } | null = null;
    for (const h of habits) {
      const logs = habitLogs.filter(l => l.habitId === h.id);
      const daysDone = new Set(logs.filter(l => l.count > 0).map(l => l.date)).size;
      const rate = daysDone;
      if (!best || rate > best.rate) best = { name: h.name, rate };
    }
    return best?.name ?? null;
  }, [habits, habitLogs]);
  const report = useMemo(() => weeklyReport({ blocks, sessions, water, scheduleChanges: changes, studyMin, exerciseMin, upcomingDeadlines: deadlines, habitBest: bestHabit }), [blocks, sessions, water, changes, studyMin, exerciseMin, deadlines, bestHabit]);

  const doExport = async (kind: 'blocks' | 'tasks' | 'water' | 'habits') => {
    const csv = await exportCsvDataset(kind);
    downloadTextFile(`dayflow-${kind}-${todayKey()}.csv`, csv, 'text/csv;charset=utf-8');
    toast(lang === 'ar' ? 'تم تصدير CSV' : 'CSV exported');
  };
  const doJson = async () => {
    const json = await createJsonBackup();
    downloadTextFile(`dayflow-backup-${todayKey()}.json`, json, 'application/json');
    toast(lang === 'ar' ? 'تم تصدير النسخة الاحتياطية' : 'Backup exported');
  };
  const doXlsx = async () => { await exportXlsx(); toast(lang === 'ar' ? 'تم تصدير Excel' : 'Excel exported'); };

  const reportRows: Array<{ label: string; value: string }> = [
    { label: lang === 'ar' ? 'أولويات مكتملة' : 'Priorities completed', value: String(report.completed) },
    { label: lang === 'ar' ? 'كتل فائتة' : 'Missed blocks', value: String(report.missed) },
    { label: lang === 'ar' ? 'دقة الالتزام' : 'Schedule accuracy', value: `${report.completionRate}%` },
    { label: lang === 'ar' ? 'وقت الدراسة' : 'Study time', value: fmtMinutes(report.studyMin, lang) },
    { label: lang === 'ar' ? 'وقت الرياضة' : 'Exercise time', value: fmtMinutes(report.exerciseMin, lang) },
    { label: lang === 'ar' ? 'دقائق التركيز' : 'Focus minutes', value: fmtMinutes(report.focusMin, lang) },
    { label: lang === 'ar' ? 'متوسط الماء/يوم' : 'Avg water/day', value: `${report.waterAvgMl} ml` },
    { label: lang === 'ar' ? 'إعادات الجدولة (٩٠ يوم)' : 'Reschedules (90d)', value: String(report.rescheduled) },
    { label: lang === 'ar' ? 'مواعيد نهائية قادمة' : 'Upcoming deadlines', value: String(report.upcomingDeadlines) },
    { label: lang === 'ar' ? 'أكتر عادة منتظم فيها' : 'Most consistent habit', value: report.mostConsistentHabit ?? '—' },
  ];

  return (
    <div className="pb-6 px-4 pt-14">
      <div className="flex items-center justify-between">
        <h1 className="skin-title font-extrabold flex items-center gap-1.5">{t('progress')}<HelpTip title="الإحصائيات والتقرير"><p>كل رقم ورسم هنا محسوب <b>من شغلك الحقيقي بس</b> — مفيش أي أرقام وهمية. الخريطة الحرارية بتورّيك أيام التزامك: كل ما المربع يغمق، يومك كان أنجح!</p></HelpTip></h1>
        <Segmented size="sm" value={range} onChange={v => setRange(v as any)} options={[{ value: '7', label: lang === 'ar' ? 'أسبوع' : 'Week' }, { value: '30', label: lang === 'ar' ? 'شهر' : 'Month' }, { value: '90', label: lang === 'ar' ? '٣ أشهر' : '90d' }]} />
      </div>

      {/* headline stats */}
      <div className="grid grid-cols-4 gap-2 mt-3">
        <div className="card-flat p-2.5"><TrendingUp className="w-4 h-4 accent mb-1" /><p className="num text-base font-extrabold leading-none">{scoped.length ? Math.round((scoped.filter(b => b.status === 'done').length / scoped.length) * 100) : 0}%</p><p className="text-[0.52rem] font-bold text-2 mt-1">{t('completionRate')}</p></div>
        <div className="card-flat p-2.5"><Brain className="w-4 h-4 accent mb-1" /><p className="num text-base font-extrabold leading-none">{Math.round(focusMinutes(sessions, n) / 60 * 10) / 10}</p><p className="text-[0.52rem] font-bold text-2 mt-1">{lang === 'ar' ? 'ساعات تركيز' : 'Focus hrs'}</p></div>
        <div className="card-flat p-2.5"><CheckCheck className="w-4 h-4 text-[var(--ok)] mb-1" /><p className="num text-base font-extrabold leading-none">{Math.round(doneMin / 60 * 10) / 10}</p><p className="text-[0.52rem] font-bold text-2 mt-1">{lang === 'ar' ? 'ساعات منجزة' : 'Done hrs'}</p></div>
        <div className="card-flat p-2.5"><XCircle className="w-4 h-4 text-[var(--danger)] mb-1" /><p className="num text-base font-extrabold leading-none">{missed}</p><p className="text-[0.52rem] font-bold text-2 mt-1">{t('blocksMissed')}</p></div>
      </div>

      {/* completion trend */}
      <SectionTitle>{lang === 'ar' ? 'اتجاه الإنجاز — ٧ أيام' : 'Completion trend — 7 days'}</SectionTitle>
      <div className="card p-4">
        <LineChart data={series.map(d => ({ label: new Intl.DateTimeFormat(locale, { weekday: 'short' }).format(new Date(d.date + 'T12:00:00')), value: d.rate }))} formatY={v => `${Math.round(v)}%`} />
        <div className="flex justify-between mt-1">{series.map((d, i) => <span key={i} className="text-[0.55rem] text-3 num">{new Date(d.date + 'T12:00:00').getDate()}</span>)}</div>
      </div>

      {/* workload + distribution */}
      <div className="grid grid-cols-1 gap-3 mt-4">
        <div className="card p-4">
          <p className="text-[0.7rem] font-extrabold text-2 mb-1">{lang === 'ar' ? 'ساعات العمل المخطط لها — ١٤ يوم' : 'Planned hours — 14 days'}</p>
          <BarChart data={bars} formatY={v => `${v}h`} />
        </div>
        <div className="card p-4 flex items-center gap-4">
          <DonutChart segments={dist.length ? dist : [{ label: '—', value: 1, color: 'var(--surface-3)' }]} size={118} stroke={18}
            centerValue={`${Math.round(doneMin / 60)}h`} centerLabel={lang === 'ar' ? 'منجز' : 'done'} />
          <div className="flex-1 space-y-1">
            <p className="text-[0.7rem] font-extrabold text-2">{lang === 'ar' ? 'توزيع الوقت — ٣٠ يوم' : 'Time distribution — 30d'}</p>
            {dist.map((d, i) => (
              <div key={i} className="flex items-center gap-1.5 text-[0.68rem]">
                <span className="w-2.5 h-2.5 rounded-sm flex-none" style={{ background: d.color }} />
                <span className="flex-1 truncate font-semibold">{d.label}</span>
                <span className="num text-2">{Math.round(d.value / 60 * 10) / 10}h</span>
              </div>
            ))}
            {!dist.length && <p className="text-[0.68rem] text-3">{lang === 'ar' ? 'لسه مفيش أنشطة خلصت' : 'No completed blocks yet'}</p>}
          </div>
        </div>
      </div>

      {/* heatmap */}
      <SectionTitle>{lang === 'ar' ? 'كثافة النشاط — ١٢ أسبوعاً' : 'Activity heatmap — 12 weeks'}</SectionTitle>
      <div className="card p-4"><Heatmap weeks={heat} today={todayKey()} /></div>

      {/* weekly smart report */}
      <SectionTitle action={<Award className="w-4 h-4 accent" />}>{t('weeklyReport')}</SectionTitle>
      <div className="card p-4">
        <div className="grid grid-cols-2 gap-x-4 gap-y-2">
          {reportRows.map((r, i) => (
            <div key={i} className="flex flex-col border-b hairline pb-1.5">
              <span className="text-[0.58rem] font-bold text-2">{r.label}</span>
              <span className="num text-[0.85rem] font-extrabold">{r.value}</span>
            </div>
          ))}
        </div>
        <p className="text-[0.6rem] text-3 mt-2 flex items-center gap-1"><AlertCircle className="w-3.5 h-3.5" />{lang === 'ar' ? 'كل رقم هنا حقيقي 100% من سجلاتك على موبايلك بس.' : 'Every number is computed from your real on-device records.'}</p>
        <div className="flex flex-wrap gap-2 mt-3">
          <button className="btn btn-ghost btn-sm" onClick={() => doExport('blocks')}><FileDown className="w-4 h-4" />CSV</button>
          <button className="btn btn-ghost btn-sm" onClick={doXlsx}><FileSpreadsheet className="w-4 h-4" />Excel</button>
          <button className="btn btn-ghost btn-sm" onClick={doJson}><FileJson className="w-4 h-4" />JSON</button>
        </div>
      </div>

      {/* adherence bar */}
      <SectionTitle>{lang === 'ar' ? 'دقة الالتزام هذا الأسبوع' : 'Weekly adherence'}</SectionTitle>
      <div className="card p-4 space-y-2">
        {series.map((d, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="num text-[0.62rem] font-bold text-2 w-7">{new Intl.DateTimeFormat(locale, { weekday: 'short' }).format(new Date(d.date + 'T12:00:00'))}</span>
            <LinearProgress value={d.rate} className="flex-1" tone={d.rate >= 70 ? 'var(--ok)' : d.rate >= 40 ? 'var(--warn)' : 'var(--danger)'} />
            <span className="num text-[0.62rem] font-bold w-9 text-end">{d.rate}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function catColor(id: string): string {
  const map: Record<string, string> = {
    study: 'var(--cat-study)', work: 'var(--cat-work)', exercise: 'var(--cat-exercise)', rest: 'var(--cat-rest)',
    meal: 'var(--cat-meal)', sleep: 'var(--cat-sleep)', water: 'var(--cat-water)', personal: 'var(--cat-personal)',
    prayer: 'var(--cat-prayer)', health: 'var(--cat-health)', social: 'var(--cat-social)', other: 'var(--cat-other)',
  };
  return map[id] ?? 'var(--accent)';
}
