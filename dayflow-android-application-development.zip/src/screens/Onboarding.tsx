/* DAYFLOW — First-run welcoming walkthrough (Egyptian colloquial · real bundled photography · live theme selector · honest permissions) */
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Check, Bell, AlarmClock, BatteryCharging, MonitorSmartphone } from 'lucide-react';
import { useApp } from '@/lib/store';
import { isNative } from '@/lib/db';
import { platform } from '@/lib/platform';
import { GOVERNORATES } from '@/lib/prayer';
import ThemePreview, { SKINS } from '@/components/ThemePreview';
import { cn } from '@/utils/cn';

const SLIDES = [
  {
    img: '/media/onb-1.jpg', decor: '/decor/rocket.png',
    title: 'أهلاً بيك في مدير اليوم 👋',
    body: 'تطبيقك اللي بينظّم يومك كله في مكان واحد: خطتك، مهامك، مذاكرتك، تمرينك، منبهاتك، يومياتك، صلاتك، ومناسباتك. شغّال بدون نت 100% ومن غير أي حساب أو إعلانات، وبياناتك على موبايلك بس.',
    tip: '💡 تقدر تدوس على أي علامة ? خضراء جوه التطبيق عشان تشرحلك الميزة ببساطة بالمصري.',
  },
  {
    img: '/media/onb-2.jpg', decor: '/decor/calendar-spiral.png',
    title: 'اسحب خطتك وطبّقها بضغطة 🗓️',
    body: 'في صفحة «الخطة» اسحب أي نشاط لميعاده وشدّه لتغيير مدته، وكل مربع بيظهر فيه الساعة والملاحظة كاملة حتى لو المربعات جنب بعض. ودوس «طبّق الخطة» عشان يتجدول كل تنبيه، يتحدّث الويدجيت، وتتحفظ في يومياتك.',
    tip: '📅 وفي زر «التقويم» تلاقي كل المناسبات والإجازات الرسمية بصورها، وتقدر تضيف مناسباتك ومهام أي يوم.',
  },
  {
    img: '/media/occ-ramadan3.jpg', decor: '/decor/mosque.png',
    title: 'صلاتك ومنبهاتك في ميعادها 🕌⏰',
    body: 'مواقيت الصلاة دقيقة لكل الـ27 محافظة في مصر مع دايرة تقدم وإحصائياتك في الإشعارات والويدجيت. وكمان منبه احترافي تختارله أغنية من تطبيق الموسيقى وتقصّ الجزء اللي تحبه تصحى عليه!',
    tip: '✨ التطبيق بيتزيّن لوحده في رمضان والأعياد والخريف والشتا ورأس السنة والربيع بصور وزينة 3D أوفلاين.',
  },
  {
    img: '/media/bg-morning.jpg', decor: '/decor/alarm.png',
    title: 'إشعارات وويدجيت حقيقية 100% 🔔',
    body: 'الإشعارات بتوصلك في الدقيقة بالظبط حتى والتطبيق مقفول أو شاشة الموبايل مطفية، وفيها زراير «خلصت ✓ / أجّل / ابدأ / صلّيت / شربت مية» بتشتغل من غير ما تفتح التطبيق — والويدجيت على شاشتك الرئيسية بتتحرك وبتتحدث فوراً.',
    tip: '✍️ ومعاه نظام يوميات متكامل بيسجل مودك وامتنانك وملخص يومك الحقيقي كل يوم.',
  },
];

export default function Onboarding({ onDone }: { onDone: () => void }) {
  const { settings, saveSettings } = useApp();
  const [i, setI] = useState(0);
  const [name, setName] = useState(settings.userName);
  const [perm, setPerm] = useState<Record<string, boolean | null>>({ notif: null, exact: null, battery: null, fs: null });
  const total = SLIDES.length + 2;

  const check = async () => {
    if (!isNative()) return;
    const [n, e, b, caps]: any[] = await Promise.all([
      platform.checkNotificationPermission(), platform.checkExactAlarm(),
      platform.batteryStatus(), platform.capabilities(),
    ]);
    setPerm({ notif: !!n.granted, exact: !!e.granted, battery: !!b.ignoring, fs: caps.fullScreenIntent !== false });
  };

  return (
    <div className="fixed inset-0 z-[90] app-surface flex flex-col" style={{ background: 'var(--app-bg, var(--bg))' }}>
      {/* Progress dots */}
      <div className="flex items-center justify-between px-4 pt-[max(env(safe-area-inset-top),0.9rem)] pb-2">
        <button
          className={cn('icon-btn', i === 0 && 'opacity-0 pointer-events-none')}
          onClick={() => setI(x => Math.max(0, x - 1))}
          aria-label="اللي فات"
        >
          <ChevronRight className="w-5 h-5 ltr:rotate-180" />
        </button>
        <div className="flex gap-1.5">
          {Array.from({ length: total }, (_, k) => (
            <span key={k} className={cn('h-1.5 rounded-full transition-all duration-500', k === i ? 'w-7 bg-[var(--accent)]' : k < i ? 'w-2 bg-[var(--accent)]/45' : 'w-1.5 bg-[var(--border-strong)]')} />
          ))}
        </div>
        <button className="text-xs font-bold text-2 px-2 py-1" onClick={async () => { await saveSettings({ onboarded: true, userName: name.trim() }); onDone(); }}>
          تخطّي
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-5 no-scrollbar" key={i}>
        {i < SLIDES.length && (
          <div className="anim-screen flex flex-col pb-4">
            <div className="relative rounded-[2rem] overflow-hidden mt-1 shadow-lg border hairline" style={{ height: '40vh' }}>
              <img src={SLIDES[i].img} alt="" className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/15 to-transparent" />
              <img src={SLIDES[i].decor} alt="" className="decor-float absolute bottom-4 left-1/2 -translate-x-1/2 w-24 h-24 object-contain" />
            </div>
            <h1 className="text-[1.55rem] font-extrabold mt-5 leading-snug grad-text">{SLIDES[i].title}</h1>
            <p className="text-[0.9rem] text-2 mt-2.5 leading-[1.88]">{SLIDES[i].body}</p>
            <div className="mt-3.5 rounded-2xl px-3.5 py-2.5 text-[0.76rem] font-semibold leading-relaxed" style={{ background: 'var(--accent-soft)', color: 'var(--text)' }}>
              {SLIDES[i].tip}
            </div>
            <p className="by-joseph mt-5 mb-1">By,Joseph</p>
          </div>
        )}

        {i === SLIDES.length && (
          <div className="anim-screen pt-1 pb-4 space-y-4">
            <div>
              <h1 className="text-2xl font-extrabold grad-text">خصّص التطبيق على مزاجك 🎨</h1>
              <p className="text-xs text-2 mt-0.5">تقدر تغيّر أي حاجة منهم في أي وقت من الإعدادات.</p>
            </div>
            <label className="block">
              <span className="label">اسمك (اختياري — عشان نرحّب بيك)</span>
              <input className="input" value={name} onChange={e => setName(e.target.value)} placeholder="مثلاً: محمد، سارة…" />
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <label className="block">
                <span className="label">محافظتك (للصلاة)</span>
                <select className="input" value={settings.governorate} onChange={e => saveSettings({ governorate: e.target.value })}>
                  {GOVERNORATES.map(g => <option key={g.id} value={g.id}>{g.ar}</option>)}
                </select>
              </label>
              <div>
                <span className="label">الوضع</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {([['light', 'فاتح ☀️'], ['dark', 'داكن 🌙']] as const).map(([v, lbl]) => (
                    <button key={v} onClick={() => saveSettings({ theme: v })} className={cn('rounded-xl border py-2.5 text-xs font-extrabold', settings.theme === v ? 'border-[var(--accent)] bg-[var(--accent-soft)] accent' : 'border-[var(--border)]')}>
                      {lbl}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div>
              <span className="label">اختار الثيم اللي يعجبك (12 تصميم مختلف)</span>
              <div className="grid grid-cols-3 gap-2">
                {SKINS.map(s => (
                  <button key={s.id} onClick={() => saveSettings({ skin: s.id })} className="text-center">
                    <ThemePreview skin={s.id} theme={settings.theme === 'dark' ? 'dark' : 'light'} accent={settings.accent} selected={settings.skin === s.id} />
                    <span className="text-[0.6rem] font-extrabold block mt-1 leading-tight truncate">{s.ar}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {i === SLIDES.length + 1 && (
          <div className="anim-screen pt-1 pb-4 space-y-3">
            <h1 className="text-2xl font-extrabold grad-text">آخر خطوة: صلاحيات التنبيه 🔐</h1>
            <p className="text-[0.82rem] text-2 leading-relaxed">
              عشان المنبهات والأذان وتذكيرات خطتك توصل في ميعادها بالظبط حتى والتطبيق مقفول. مش بنطلب أي صلاحية زيادة — <b>ولا إنترنت، ولا موقع، ولا صور، ولا جهات اتصال.</b>
            </p>
            {!isNative() && (
              <div className="card-flat p-3 text-[0.74rem] text-2 leading-relaxed">
                ℹ️ انت حالياً في <b>معاينة الويب</b> — الصلاحيات دي بتشتغل جوه تطبيق الأندرويد الفعلي. تقدر تبدأ دلوقتي وتجرّب كل الشاشات بحرية!
              </div>
            )}
            {[
              { k: 'notif', icon: Bell, t: 'الإشعارات', d: 'عشان توصلك تذكيرات الأنشطة والصلاة والمناسبات بالأزرار التفاعلية.', run: () => platform.requestNotificationPermission() },
              { k: 'exact', icon: AlarmClock, t: 'المنبهات الدقيقة', d: 'عشان كل تنبيه يرن في نفس الدقيقة مش متأخر.', run: () => platform.requestExactAlarm() },
              { k: 'fs', icon: MonitorSmartphone, t: 'شاشة المنبه الكاملة', d: 'عشان المنبه يفتح بشاشة كاملة فوق شاشة القفل (أندرويد 14+).', run: () => platform.requestFullScreen() },
              { k: 'battery', icon: BatteryCharging, t: 'استثناء البطارية', d: 'ضروري على شاومي / أوبو / ريلمي / سامسونج عشان الموبايل ما يقفلش التنبيهات.', run: () => platform.openBatterySettings() },
            ].map(p => (
              <div key={p.k} className="card p-3 flex items-center gap-3">
                <span className="w-11 h-11 rounded-2xl grid place-items-center bg-[var(--accent-soft)] accent shrink-0"><p.icon className="w-5 h-5" /></span>
                <div className="flex-1 min-w-0">
                  <p className="font-extrabold text-sm">{p.t}</p>
                  <p className="text-[0.65rem] text-2 leading-snug mt-0.5">{p.d}</p>
                </div>
                {perm[p.k]
                  ? <span className="w-8 h-8 rounded-full bg-[var(--ok)] text-white grid place-items-center shrink-0"><Check className="w-4 h-4" /></span>
                  : <button className="btn btn-soft btn-sm shrink-0" disabled={!isNative()} onClick={async () => { await p.run(); setTimeout(check, 1000); }}>اسمح</button>}
              </div>
            ))}
            {isNative() && <button className="text-[0.75rem] font-extrabold accent" onClick={check}>اتأكد من الحالة الفعلية دلوقتي ↻</button>}
          </div>
        )}
      </div>

      {/* Bottom primary button */}
      <div className="p-4 pt-2 pb-[max(env(safe-area-inset-bottom),1.1rem)]">
        <p className="by-joseph mb-3">By,Joseph</p>
        <button
          className="btn btn-primary w-full justify-center !py-3.5 text-base"
          onClick={async () => {
            if (i === total - 1) {
              await saveSettings({ onboarded: true, userName: name.trim() });
              onDone();
            } else {
              if (i === SLIDES.length) await saveSettings({ userName: name.trim() });
              const nxt = i + 1;
              setI(nxt);
              if (nxt === total - 1) setTimeout(check, 250);
            }
          }}
        >
          {i === total - 1 ? 'يلا نبدأ يومنا 🚀' : 'كمّل'}
          {i < total - 1 && <ChevronLeft className="w-5 h-5 ltr:rotate-180" />}
        </button>
      </div>
    </div>
  );
}
