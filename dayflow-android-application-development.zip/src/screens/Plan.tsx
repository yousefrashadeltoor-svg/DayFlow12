/* DAYFLOW — Plan: calendar views · catch-up engine · what-if · templates · routines */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ChevronLeft, ChevronRight, Plus, Wand2, FlaskConical, CalendarDays, ListChecks,
  Check, X, Copy, Trash2, AlertTriangle, CheckCircle2, Pin, Bell, Sunrise, MoonStar,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, addDays, minToTime, newId } from '@/lib/db';
import { durationOf, detectConflicts, buildCatchUpPlan, simulateWhatIf, evaluateRules, dayCapacity, type Proposal } from '@/lib/scheduler';
import { Segmented, EmptyState, Sheet, Field, CategoryIcon, LinearProgress } from '@/components/ui';
import ActivityEditor from '@/components/ActivityEditor';
import DayBoard from '@/components/DayBoard';
import { syncNative } from '@/lib/sync';
import { HelpTip } from '@/components/ui';
import { Rocket } from 'lucide-react';
import { haptic } from '@/lib/platform';
import type { ActivityBlock, ActivityCategory, DayTemplate, Routine, ScheduleChange, ScheduleRule } from '@/lib/types';
import { cn } from '@/utils/cn';

type PlanTab = 'board' | 'schedule' | 'templates' | 'routines';
type CalView = 'month' | 'week' | 'agenda';

export default function Plan({ params }: { params?: any }) {
  const { t, lang, locale, hour12, tick, toast, confirm, settings, bump } = useApp();
  const [tab, setTab] = useState<PlanTab>(params?.tab ?? 'board');
  const [createAt, setCreateAt] = useState<number | null>(null);
  const [applying, setApplying] = useState(false);
  const [view, setView] = useState<CalView>('month');
  const [selected, setSelected] = useState(todayKey());
  const [monthCursor, setMonthCursor] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  const [blocks, setBlocks] = useState<ActivityBlock[]>([]);
  const [cats, setCats] = useState<ActivityCategory[]>([]);
  const [templates, setTemplates] = useState<DayTemplate[]>([]);
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [rules, setRules] = useState<ScheduleRule[]>([]);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<ActivityBlock | null>(null);
  const [proposals, setProposals] = useState<Proposal[] | null>(null);
  const [whatIfBlockId, setWhatIfBlockId] = useState('');
  const [whatIfDelta, setWhatIfDelta] = useState(60);
  const [whatIfResult, setWhatIfResult] = useState<ReturnType<typeof simulateWhatIf> | null>(null);

  const catMap = useMemo(() => Object.fromEntries(cats.map(c => [c.id, c])), [cats]);
  const reload = useCallback(async () => {
    const [b, c, tpl, rt, rl] = await Promise.all([
      db.all<ActivityBlock>('activity_blocks'), db.all<ActivityCategory>('activity_categories'),
      db.all<DayTemplate>('day_templates'), db.all<Routine>('routines'), db.all<ScheduleRule>('schedule_rules'),
    ]);
    setBlocks(b); setCats(c); setTemplates(tpl); setRoutines(rt); setRules(rl);
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const dayBlocks = useMemo(() => blocks.filter(b => b.date === selected).sort((a, b) => a.startMin - b.startMin), [blocks, selected]);
  const dayConflicts = useMemo(() => detectConflicts(dayBlocks), [dayBlocks]);
  const capacity = useMemo(() => dayCapacity(dayBlocks), [dayBlocks]);
  const ruleFindings = useMemo(() => evaluateRules(rules, { blocks: dayBlocks, sleepWindow: { start: settings.quietHoursStartMin, end: settings.quietHoursEndMin } }), [rules, dayBlocks, settings]);

  /* ---------- month grid ---------- */
  const monthCells = useMemo(() => {
    const first = new Date(monthCursor.getFullYear(), monthCursor.getMonth(), 1);
    const startOffset = (first.getDay() - settings.weekStart + 7) % 7;
    const gridStart = new Date(first); gridStart.setDate(1 - startOffset);
    return Array.from({ length: 42 }, (_, i) => { const d = new Date(gridStart); d.setDate(gridStart.getDate() + i);
      return { key: todayKey(d), day: d.getDate(), inMonth: d.getMonth() === monthCursor.getMonth() }; });
  }, [monthCursor, settings.weekStart]);
  const weekdayShort = useMemo(() => Array.from({ length: 7 }, (_, i) => { const d = new Date(2024, 5, 2 + i); return new Intl.DateTimeFormat(locale, { weekday: 'narrow' }).format(d); }), [locale]); // 2024-06-02 is a Sunday
  const orderedWeekdays = useMemo(() => Array.from({ length: 7 }, (_, i) => weekdayShort[(settings.weekStart + i) % 7]), [weekdayShort, settings.weekStart]);

  const blocksByDate = useMemo(() => { const m = new Map<string, ActivityBlock[]>(); for (const b of blocks) { (m.get(b.date) ?? m.set(b.date, []).get(b.date)!).push(b); } return m; }, [blocks]);

  /* ---------- catch-up engine ---------- */
  const runCatchUp = () => {
    const missed = dayBlocks.filter(b => b.status === 'missed' || b.status === 'skipped' || (b.status === 'planned' && b.endMin < (selected === todayKey() ? new Date().getHours() * 60 + new Date().getMinutes() : 0)));
    const fixed = dayBlocks.filter(b => b.fixed && b.status !== 'done' && b.status !== 'cancelled');
    const flexible = dayBlocks.filter(b => !b.fixed && b.status !== 'done' && b.status !== 'cancelled');
    const nowM = new Date().getHours() * 60 + new Date().getMinutes();
    setProposals(buildCatchUpPlan({
      missed, fixed, flexible,
      remainingDayMin: selected === todayKey() ? Math.max(0, 1440 - nowM) : 0,
      preferredHours: settings.preferredHours,
      bufferMin: settings.defaultBufferMin,
    }));
  };
  const applyProposal = async (p: Proposal) => {
    if (!p.blockId || p.kind === 'advisory') { setProposals(ps => ps?.filter(x => x.id !== p.id) ?? null); return; }
    const b = blocks.find(x => x.id === p.blockId); if (!b) return;
    const change: ScheduleChange = {
      id: newId(), blockId: b.id, date: b.date, reason: lang === 'ar' ? p.titleAr : p.titleEn,
      original: { startMin: b.startMin, endMin: b.endMin }, proposed: p.after ?? { startMin: b.startMin, endMin: b.endMin },
      applied: true, createdAt: Date.now(),
    };
    if (p.kind === 'move' && p.after) {
      await db.put('activity_blocks', { ...b, startMin: p.after.startMin, endMin: p.after.endMin, status: 'planned', updatedAt: Date.now() });
    } else if (p.kind === 'split' && p.splitParts) {
      await db.del('activity_blocks', b.id);
      let i = 1;
      for (const part of p.splitParts) {
        await db.put('activity_blocks', { ...b, id: newId(), title: `${b.title} (${i++})`, startMin: part.startMin, endMin: part.endMin, status: 'planned', createdAt: Date.now(), updatedAt: Date.now() });
      }
    } else if (p.kind === 'tomorrow') {
      await db.put('activity_blocks', { ...b, date: addDays(b.date, 1), status: 'planned', updatedAt: Date.now() });
      change.proposed = { startMin: b.startMin, endMin: b.endMin };
    }
    await db.put('schedule_changes', change);
    haptic('medium');
    toast(lang === 'ar' ? 'طُبّق الاقتراح وسُجّل في سجل التغييرات' : 'Proposal applied and logged in change history');
    setProposals(ps => ps?.filter(x => x.id !== p.id) ?? null);
    bump();
  };

  /* ---------- what-if ---------- */
  const runWhatIf = () => {
    const b = blocks.find(x => x.id === whatIfBlockId); if (!b) return;
    setWhatIfResult(simulateWhatIf(blocks.filter(x => x.date === b.date), { blockId: b.id, newStartMin: b.startMin + whatIfDelta }));
  };
  const applyWhatIf = async () => {
    const b = blocks.find(x => x.id === whatIfBlockId); if (!b || !whatIfResult) return;
    const dur = durationOf(b);
    await db.put('activity_blocks', { ...b, startMin: b.startMin + whatIfDelta, endMin: b.startMin + whatIfDelta + dur, updatedAt: Date.now() });
    await db.put('schedule_changes', { id: newId(), blockId: b.id, date: b.date, reason: lang === 'ar' ? 'محاكاة "ماذا لو" مطبّقة' : 'What-if simulation applied', original: { startMin: b.startMin, endMin: b.endMin }, proposed: { startMin: b.startMin + whatIfDelta, endMin: b.startMin + whatIfDelta + dur }, applied: true, createdAt: Date.now() });
    setWhatIfResult(null); setWhatIfBlockId('');
    toast(t('saved')); bump();
  };

  /* ---------- templates ---------- */
  const applyTemplate = async (tpl: DayTemplate) => {
    const ok = await confirm({ title: lang === 'ar' ? `تطبيق «${lang === 'ar' ? tpl.nameAr : tpl.nameEn}» على ${selected}؟` : `Apply "${tpl.nameEn}" to ${selected}?`, body: lang === 'ar' ? 'ستُضاف كل كتل القالب لليوم المحدد.' : 'All template blocks will be added to the selected day.' });
    if (!ok) return;
    const rows = tpl.items.map(item => ({
      id: newId(), title: item.title, description: '', categoryId: item.categoryId, date: selected,
      startMin: item.startMin, endMin: item.endMin, fixed: item.fixed, priority: 3 as const, energy: 'medium' as const,
      difficulty: 3 as const, status: 'planned' as const, recurrence: 'none' as const, reminderMin: 10, sound: 'default',
      repeatCount: 1, isCritical: false, splitAllowed: true, earliestStartMin: null, latestEndMin: null,
      linkedTaskId: null, linkedGoalId: null, linkedSubjectId: null, tags: [], notes: `tpl:${tpl.id}`,
      actualStartMin: null, actualEndMin: null, createdAt: Date.now(), updatedAt: Date.now(),
    }));
    await db.bulkPut('activity_blocks', rows);
    toast(lang === 'ar' ? `أُضيفت ${rows.length} كتل من القالب` : `${rows.length} template blocks added`);
    bump();
  };
  const [tplEditor, setTplEditor] = useState(false);
  const [tplName, setTplName] = useState('');
  const [tplItems, setTplItems] = useState<Array<{ title: string; categoryId: string; start: string; end: string; fixed: boolean }>>([{ title: '', categoryId: 'personal', start: '09:00', end: '09:45', fixed: false }]);
  const saveTemplate = async () => {
    const valid = tplItems.filter(i => i.title.trim() && i.end > i.start);
    if (!tplName.trim() || !valid.length) { toast(lang === 'ar' ? 'أكمل الاسم وعناصراً صالحة' : 'Provide a name and valid items'); return; }
    const toMin = (s: string) => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
    await db.put('day_templates', { id: newId(), nameAr: tplName.trim(), nameEn: tplName.trim(), icon: 'sun', createdAt: Date.now(),
      items: valid.map(i => ({ title: i.title.trim(), categoryId: i.categoryId, startMin: toMin(i.start), endMin: toMin(i.end), fixed: i.fixed })) });
    setTplEditor(false); setTplName(''); setTplItems([{ title: '', categoryId: 'personal', start: '09:00', end: '09:45', fixed: false }]);
    toast(t('saved')); bump();
  };

  /* ---------- routines ---------- */
  const toggleStep = async (rt: Routine, stepId: string) => {
    const updated = { ...rt, steps: rt.steps.map(s => s.id === stepId ? { ...s, done: !s.done } : s) };
    await db.put('routines', updated); bump();
  };
  const resetRoutine = async (rt: Routine) => { await db.put('routines', { ...rt, steps: rt.steps.map(s => ({ ...s, done: false })) }); bump(); };
  const addRoutine = async () => {
    const name = lang === 'ar' ? 'روتين جديد' : 'New routine';
    await db.put('routines', { id: newId(), nameAr: name, nameEn: name, icon: 'sparkles', timeOfDay: 'morning', steps: [
      { id: newId(), title: lang === 'ar' ? 'كوب ماء' : 'Glass of water', durationMin: 2, done: false },
      { id: newId(), title: lang === 'ar' ? 'تمدد وتنفس' : 'Stretch & breathe', durationMin: 5, done: false },
    ] });
    bump();
  };

  const agendaGroups = dayBlocks;

  return (
    <div className="pb-6">
      <header className="px-4 pt-5 pb-2 flex items-center justify-between">
        <h1 className="skin-title font-extrabold grad-text">{t('plan')}</h1>
        <div className="flex items-center gap-1.5">
          <button className="btn btn-soft btn-sm" onClick={runCatchUp}><Wand2 className="w-4 h-4" />{lang === 'ar' ? 'رتّب اللي فات' : 'Catch-up'}</button>
          <button className="icon-btn" onClick={() => { setEditing(null); setEditorOpen(true); }} aria-label={t('addActivity')}><Plus className="w-6 h-6" /></button>
        </div>
      </header>

      <div className="px-4"><Segmented value={tab} onChange={v => setTab(v as PlanTab)} options={[
        { value: 'board', label: lang === 'ar' ? 'اللوحة' : 'Board' }, { value: 'schedule', label: t('schedule') }, { value: 'templates', label: t('templates') }, { value: 'routines', label: t('routines') },
      ]} /></div>

      {tab === 'board' && (
        <div className="px-4 mt-3 anim-fade space-y-2">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
            {Array.from({ length: 10 }, (_, i) => addDays(todayKey(), i - 1)).map(k => (
              <button key={k} onClick={() => setSelected(k)} className={cn('flex-none rounded-2xl px-3 py-1.5 text-center border transition-colors', k === selected ? 'bg-[var(--accent)] text-[var(--on-accent)] border-transparent' : 'border-[var(--border)]')}>
                <span className="block text-[0.58rem] font-bold opacity-80">{new Intl.DateTimeFormat(locale, { weekday: 'short' }).format(new Date(k + 'T12:00:00'))}</span>
                <span className="num block text-sm font-extrabold">{Number(k.slice(-2))}</span>
              </button>
            ))}
            <input type="date" className="input w-auto !py-1.5 text-xs num flex-none" value={selected} onChange={e => setSelected(e.target.value)} aria-label="date" />
          </div>
          <div className="flex items-center gap-2">
            <button className="btn btn-primary flex-1 justify-center" disabled={applying} onClick={async () => {
              setApplying(true);
              const res = await syncNative();
              const n = dayBlocks.filter(b => b.status === 'planned').length;
              await db.put('journal_entries', { id: `auto-${selected}-${Date.now()}`, date: selected, kind: 'auto', title: lang === 'ar' ? 'طبّقت خطة اليوم' : 'Plan applied', body: lang === 'ar' ? `اتجدولت ${n} أنشطة: ${dayBlocks.map(b => `${minToTime(b.startMin)} ${b.title}`).join('، ')}` : `${n} blocks scheduled`, mood: null, gratitude: [], tags: ['خطة'], createdAt: Date.now(), updatedAt: Date.now() });
              await db.put('schedule_changes', { id: newId(), blockId: 'plan', date: selected, reason: 'apply-plan', original: { startMin: 0, endMin: 0 }, proposed: { startMin: 0, endMin: 0 }, applied: true, createdAt: Date.now() });
              setApplying(false); bump();
              toast(res.unsupported ? (lang === 'ar' ? 'الخطة اتحفظت واتسجلت في اليوميات — التنبيهات الحقيقية بتشتغل في تطبيق الأندرويد' : 'Plan saved & journaled — native alarms run in the Android app')
                : res.ok ? (lang === 'ar' ? `تم ✓ اتجدول ${res.scheduled} تنبيه (${res.exact} دقيق) والويدجيت اتحدث` : `Done ✓ ${res.scheduled} alarms (${res.exact} exact), widgets updated`)
                : (lang === 'ar' ? `حصلت مشكلة: ${res.error ?? ''} — افتح مركز الموثوقية` : `Failed: ${res.error ?? ''}`));
            }}><Rocket className="w-4 h-4" />{applying ? '…' : (lang === 'ar' ? 'طبّق الخطة' : 'Apply plan')}</button>
            <HelpTip title="يعني إيه «طبّق الخطة»؟">
              <p>لما تدوس <b>طبّق الخطة</b> التطبيق بيعمل 3 حاجات حقيقية:</p>
              <ul><li>بيجدول تنبيه في ميعاد كل نشاط بالظبط (وتنبيه تاني لما وقته يخلص يسألك خلصته ولا لأ) — حتى لو التطبيق مقفول أو الموبايل مقفول.</li>
              <li>بيحدّث الويدجيت على الشاشة الرئيسية بالخطة الجديدة.</li>
              <li>بيسجّل الخطة في <b>اليوميات</b> عشان ترجعلها بعدين.</li></ul>
              <p>ولو عدّلت أي حاجة بعدها، التنبيهات بتتظبط لوحدها من غير تكرار.</p>
            </HelpTip>
          </div>
          <DayBoard blocks={dayBlocks} cats={cats} date={selected} onEdit={b => { setEditing(b); setEditorOpen(true); }} onCreateAt={m => { setEditing(null); setCreateAt(m); setEditorOpen(true); }} />
        </div>
      )}

      {/* ============ SCHEDULE TAB ============ */}
      {tab === 'schedule' && (
        <div className="px-4 mt-3 anim-fade">
          <div className="flex items-center justify-between mb-2">
            <Segmented size="sm" value={view} onChange={v => setView(v as CalView)} options={[
              { value: 'month', label: t('month') }, { value: 'week', label: t('week') }, { value: 'agenda', label: t('agenda') },
            ]} />
            <input type="date" className="input w-auto !py-1.5 text-sm num" value={selected} onChange={e => setSelected(e.target.value)} aria-label="date" />
          </div>

          {view === 'month' && (
            <div className="card p-3">
              <div className="flex items-center justify-between px-1 pb-2">
                <button className="icon-btn" onClick={() => setMonthCursor(new Date(monthCursor.getFullYear(), monthCursor.getMonth() - 1, 1))} aria-label="prev month"><ChevronRight className="w-5 h-5" /></button>
                <p className="font-extrabold">{new Intl.DateTimeFormat(locale, { month: 'long', year: 'numeric' }).format(monthCursor)}</p>
                <button className="icon-btn" onClick={() => setMonthCursor(new Date(monthCursor.getFullYear(), monthCursor.getMonth() + 1, 1))} aria-label="next month"><ChevronLeft className="w-5 h-5" /></button>
              </div>
              <div className="grid grid-cols-7 gap-1 text-center">
                {orderedWeekdays.map((w, i) => <div key={i} className="text-[0.6rem] font-bold text-3 py-1">{w}</div>)}
                {monthCells.map(cell => {
                  const dayBlocksForCell = blocksByDate.get(cell.key) ?? [];
                  const done = dayBlocksForCell.filter(b => b.status === 'done').length;
                  const isSel = cell.key === selected, isToday = cell.key === todayKey();
                  return (
                    <button key={cell.key} onClick={() => setSelected(cell.key)}
                      className={cn('rounded-xl py-1.5 flex flex-col items-center gap-0.5 transition-colors min-h-[2.9rem]',
                        isSel ? 'bg-[var(--accent)] text-[var(--on-accent)]' : isToday ? 'bg-[var(--accent-soft)]' : 'hover:bg-[var(--surface-2)]', !cell.inMonth && 'opacity-35')}>
                      <span className="num text-[0.78rem] font-bold leading-none">{cell.day}</span>
                      <span className="flex gap-0.5 h-1.5">{dayBlocksForCell.slice(0, 4).map((b, i) => <span key={i} className="w-1 h-1 rounded-full" style={{ background: b.status === 'done' ? 'var(--ok)' : isSel ? '#fff' : 'var(--accent)' }} />)}</span>
                      {dayBlocksForCell.length > 0 && <span className={cn('text-[0.5rem] num', isSel ? 'opacity-90' : 'text-3')}>{done}/{dayBlocksForCell.length}</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {view === 'week' && (
            <div className="card p-3 overflow-x-auto no-scrollbar">
              <div className="flex gap-2 min-w-[42rem]">
                {Array.from({ length: 7 }, (_, i) => {
                  const d = new Date(selected + 'T12:00:00');
                  const start = new Date(d); start.setDate(d.getDate() - ((d.getDay() - settings.weekStart + 7) % 7) + i);
                  const key = todayKey(start); const list = (blocksByDate.get(key) ?? []).slice().sort((a, b) => a.startMin - b.startMin);
                  return (
                    <div key={key} className={cn('flex-1 rounded-2xl p-2 border', key === selected ? 'border-[var(--accent)] bg-[var(--accent-soft)]' : 'border-[var(--border)]')}>
                      <button className="w-full text-center mb-1.5" onClick={() => setSelected(key)}>
                        <p className="text-[0.58rem] font-bold text-2">{new Intl.DateTimeFormat(locale, { weekday: 'short' }).format(start)}</p>
                        <p className="num font-extrabold">{start.getDate()}</p>
                      </button>
                      <div className="space-y-1">
                        {list.map(b => (
                          <button key={b.id} onClick={() => { setEditing(b); setEditorOpen(true); }}
                            className="w-full text-start rounded-lg px-1.5 py-1 text-[0.58rem] leading-tight" style={{ background: b.fixed ? 'var(--warn-soft)' : 'var(--surface-2)', opacity: b.status === 'done' ? 0.6 : 1 }}>
                            <span className="num font-bold block">{minToTime(b.startMin, hour12)}</span>
                            <span className="font-semibold line-clamp-2">{b.title}</span>
                          </button>
                        ))}
                        {list.length === 0 && <p className="text-[0.55rem] text-3 text-center py-2">—</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* capacity + conflicts + rules for the selected day */}
          <div className="grid grid-cols-3 gap-2 mt-2">
            <div className="card-flat p-2 text-center"><p className="num text-lg font-extrabold">{Math.round(capacity.plannedMin / 60 * 10) / 10}</p><p className="text-[0.55rem] font-bold text-2">{lang === 'ar' ? 'ساعات الخطة' : 'Planned hrs'}</p></div>
            <div className="card-flat p-2 text-center"><p className={cn('num text-lg font-extrabold', capacity.overlaps > 0 && 'text-[var(--warn)]')}>{capacity.overlaps}</p><p className="text-[0.55rem] font-bold text-2">{lang === 'ar' ? 'تعارضات' : 'Conflicts'}</p></div>
            <div className="card-flat p-2 text-center"><p className={cn('num text-lg font-extrabold', capacity.overload && 'text-[var(--danger)]')}>{capacity.impossible ? '!' : capacity.overload ? '~' : '✓'}</p><p className="text-[0.55rem] font-bold text-2">{lang === 'ar' ? 'توازن اليوم' : 'Feasibility'}</p></div>
          </div>
          {(dayConflicts.length > 0 || ruleFindings.some(f => f.severity === 'warn')) && (
            <div className="card-flat p-2.5 mt-2 border" style={{ borderColor: 'var(--warn)', background: 'var(--warn-soft)' }}>
              <p className="text-[0.7rem] font-extrabold flex items-center gap-1.5 text-[var(--warn)]"><AlertTriangle className="w-4 h-4" />{lang === 'ar' ? 'خلي بالك — فيه تعارض أو مفيش راحة' : 'Needs attention'}</p>
              <ul className="mt-1 space-y-0.5">
                {dayConflicts.map((c, i) => <li key={'c' + i} className="text-[0.68rem] text-2">· {c.aTitle} ↔ {c.bTitle} ({c.overlapMin} {lang === 'ar' ? 'د' : 'min'})</li>)}
                {ruleFindings.filter(f => f.severity === 'warn').slice(0, 3).map((f, i) => <li key={'r' + i} className="text-[0.68rem] text-2">· {lang === 'ar' ? f.messageAr : f.messageEn}</li>)}
              </ul>
            </div>
          )}

          {/* what-if */}
          <div className="card p-3 mt-2">
            <p className="text-[0.7rem] font-extrabold flex items-center gap-1.5"><FlaskConical className="w-4 h-4 accent" />{lang === 'ar' ? 'تجربة «لو أجّلت؟»' : 'What-if simulator'} <HelpTip title="تجربة «لو أجّلت؟»"><p>تجرب تحريك أي نشاط وتعرف قبل ما تحفظ هل هيتعارض مع ميعاد تاني أو هيزحم يومك ولا لأ — ومفيش حاجة بتتغيّر إلا لما تدوس موافق.</p></HelpTip></p>
            <div className="flex gap-2 mt-2">
              <select className="input flex-1" value={whatIfBlockId} onChange={e => { setWhatIfBlockId(e.target.value); setWhatIfResult(null); }}>
                <option value="">{lang === 'ar' ? 'اختر كتلة…' : 'Pick a block…'}</option>
                {dayBlocks.map(b => <option key={b.id} value={b.id}>{minToTime(b.startMin, hour12)} — {b.title}</option>)}
              </select>
              <select className="input w-28" value={whatIfDelta} onChange={e => { setWhatIfDelta(Number(e.target.value)); setWhatIfResult(null); }}>
                {[30, 45, 60, 90, 120].map(d => <option key={d} value={d}>+{d} {lang === 'ar' ? 'د' : 'min'}</option>)}
              </select>
              <button className="btn btn-soft btn-sm" onClick={runWhatIf} disabled={!whatIfBlockId}>{lang === 'ar' ? 'حاكِ' : 'Simulate'}</button>
            </div>
            {whatIfResult && (
              <div className="mt-2 fade">
                <p className={cn('text-[0.72rem] font-bold flex items-center gap-1.5', whatIfResult.feasible ? 'text-[var(--ok)]' : 'text-[var(--danger)]')}>
                  {whatIfResult.feasible ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                  {whatIfResult.feasible ? (lang === 'ar' ? 'ممكن — لا تعارضات بعد التأخير' : 'Feasible — no conflicts after the shift') : (lang === 'ar' ? 'غير ممكن — تظهر تعارضات أو تجاوزات' : 'Infeasible — conflicts or overflow appear')}
                </p>
                {whatIfResult.warnings.length > 0 && <p className="text-[0.65rem] text-2 mt-1">{whatIfResult.warnings.join(' · ')}</p>}
                {whatIfResult.conflicts.length > 0 && <ul className="text-[0.65rem] text-2 mt-1">{whatIfResult.conflicts.map((c, i) => <li key={i}>· {c.aTitle} ↔ {c.bTitle}</li>)}</ul>}
                <div className="flex gap-2 mt-2">
                  <button className="btn btn-primary btn-sm" onClick={applyWhatIf} disabled={!whatIfResult.feasible}><Check className="w-4 h-4" />{lang === 'ar' ? 'تطبيق التأخير' : 'Apply shift'}</button>
                  <button className="btn btn-ghost btn-sm" onClick={() => setWhatIfResult(null)}>{t('cancel')}</button>
                </div>
              </div>
            )}
          </div>

          {/* agenda list */}
          <div className="card mt-2 overflow-hidden">
            <p className="text-[0.7rem] font-extrabold px-4 pt-3 pb-1 text-2 flex items-center gap-1.5"><CalendarDays className="w-4 h-4" />{lang === 'ar' ? 'أجندة اليوم' : "Day's agenda"} — {selected}</p>
            {agendaGroups.map(b => (
              <button key={b.id} className="w-full flex items-center gap-3 px-4 py-2.5 border-t hairline hover:bg-[var(--surface-2)] text-start" onClick={() => { setEditing(b); setEditorOpen(true); }}>
                <span className="num text-[0.72rem] font-bold text-2 w-11" dir="ltr">{minToTime(b.startMin, hour12)}</span>
                <CategoryIcon icon={catMap[b.categoryId]?.icon} className="w-4 h-4 text-2" />
                <span className={cn('flex-1 truncate text-sm font-semibold', b.status === 'done' && 'line-through opacity-60')}>{b.title}</span>
                <span className="flex items-center gap-1">{b.fixed && <Pin className="w-3.5 h-3.5 text-2" />}{b.reminderMin >= 0 && <Bell className="w-3.5 h-3.5 text-2" />}</span>
              </button>
            ))}
            {agendaGroups.length === 0 && <p className="text-sm text-2 text-center py-6">{t('nothingScheduled')}</p>}
          </div>
        </div>
      )}

      {/* ============ TEMPLATES TAB ============ */}
      {tab === 'templates' && (
        <div className="px-4 mt-3 anim-fade space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold text-2">{templates.length} {lang === 'ar' ? 'قالب جاهز' : 'templates'}</p>
            <button className="btn btn-soft btn-sm" onClick={() => setTplEditor(true)}><Plus className="w-4 h-4" />{t('newTemplate')}</button>
          </div>
          {templates.map(tpl => (
            <div key={tpl.id} className="card p-3 flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl grid place-items-center text-[var(--accent)] bg-[var(--accent-soft)] shrink-0"><CategoryIcon icon={tpl.icon} className="w-6 h-6" /></div>
              <div className="flex-1 min-w-0">
                <p className="font-bold truncate">{lang === 'ar' ? tpl.nameAr : tpl.nameEn}</p>
                <p className="text-[0.65rem] text-2">{tpl.items.length} {lang === 'ar' ? 'كتلة' : 'blocks'} · {(tpl.items.reduce((s, i) => s + (i.endMin - i.startMin), 0) / 60).toFixed(1)} {lang === 'ar' ? 'ساعة' : 'hrs'}</p>
              </div>
              <button className="btn btn-primary btn-sm" onClick={() => applyTemplate(tpl)}>{t('applyTemplate')}</button>
              <button className="icon-btn" aria-label={t('duplicate')} onClick={async () => { await db.put('day_templates', { ...tpl, id: newId(), nameAr: tpl.nameAr + ' ٢', nameEn: tpl.nameEn + ' copy', createdAt: Date.now() }); bump(); toast(t('saved')); }}><Copy className="w-4 h-4" /></button>
              <button className="icon-btn text-[var(--danger)]" aria-label={t('delete')} onClick={async () => { if (await confirm({ title: lang === 'ar' ? 'حذف القالب؟' : 'Delete template?', danger: true, confirmLabel: t('delete') })) { await db.del('day_templates', tpl.id); bump(); } }}><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
      )}

      {/* ============ ROUTINES TAB ============ */}
      {tab === 'routines' && (
        <div className="px-4 mt-3 anim-fade space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold text-2">{routines.length} {lang === 'ar' ? 'روتين' : 'routines'}</p>
            <button className="btn btn-soft btn-sm" onClick={addRoutine}><Plus className="w-4 h-4" />{lang === 'ar' ? 'روتين' : 'Routine'}</button>
          </div>
          {routines.map(rt => {
            const done = rt.steps.filter(s => s.done).length, total = rt.steps.length;
            return (
              <div key={rt.id} className="card p-3">
                <div className="flex items-center gap-2">
                  {rt.timeOfDay === 'morning' || rt.timeOfDay === 'pre_study' ? <Sunrise className="w-5 h-5 text-[var(--warn)]" /> : <MoonStar className="w-5 h-5 text-[var(--cat-sleep)]" />}
                  <p className="font-bold flex-1">{lang === 'ar' ? rt.nameAr : rt.nameEn}</p>
                  <span className="num text-[0.7rem] font-bold text-2">{done}/{total}</span>
                  <button className="text-[0.65rem] font-bold text-3 hover:text-[var(--text)]" onClick={() => resetRoutine(rt)}>{lang === 'ar' ? 'إعادة' : 'Reset'}</button>
                </div>
                <LinearProgress value={total ? (done / total) * 100 : 0} className="my-2" />
                <div className="space-y-1">
                  {rt.steps.map(s => (
                    <button key={s.id} onClick={() => toggleStep(rt, s.id)} className="w-full flex items-center gap-2 py-1.5 px-2 rounded-xl hover:bg-[var(--surface-2)] text-start">
                      <span className={cn('w-5 h-5 rounded-md border grid place-items-center shrink-0 transition-colors', s.done ? 'bg-[var(--accent)] border-transparent text-[var(--on-accent)]' : 'border-[var(--border-strong)]')}>{s.done && <Check className="w-3.5 h-3.5" />}</span>
                      <span className={cn('flex-1 text-sm', s.done && 'line-through opacity-60')}>{s.title}</span>
                      <span className="num text-[0.62rem] text-3">{s.durationMin}{lang === 'ar' ? ' د' : 'm'}</span>
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
          {routines.length === 0 && <EmptyState icon={<ListChecks className="w-7 h-7" />} title={lang === 'ar' ? 'لا توجد روتينات بعد' : 'No routines yet'} hint={lang === 'ar' ? 'اعمل روتين الصبح أو بالليل خطوة بخطوة وعلّم عليها كل يوم' : 'Add your morning or evening routine with ordered steps'} action={<button className="btn btn-primary" onClick={addRoutine}><Plus className="w-4 h-4" />{lang === 'ar' ? 'أضف روتيناً' : 'Add routine'}</button>} />}
        </div>
      )}

      {/* ===== Catch-up proposals sheet ===== */}
      <Sheet open={!!proposals} onClose={() => setProposals(null)} title={lang === 'ar' ? 'اقتراحات التعويض' : 'Catch-up proposals'}>
        <p className="text-[0.72rem] text-2 -mt-1 mb-2">{lang === 'ar' ? 'مفيش حاجة هتتغيّر لوحدها — راجع كل اقتراح واقبل اللي يريحك بس.' : 'Nothing changes without your approval — review each proposal.'}</p>
        <div className="space-y-2 max-h-[55vh] overflow-y-auto">
          {proposals?.map(p => (
            <div key={p.id} className="card-flat p-3">
              <p className="font-bold text-sm">{lang === 'ar' ? p.titleAr : p.titleEn}</p>
              <p className="text-[0.68rem] text-2 mt-0.5">{lang === 'ar' ? p.reasonAr : p.reasonEn}</p>
              {p.before && p.after && (
                <p className="num text-[0.7rem] mt-1.5 flex items-center gap-2"><span className="chip">{minToTime(p.before.startMin, hour12)}–{minToTime(p.before.endMin, hour12)}</span><span>→</span><span className="chip chip-active">{minToTime(p.after.startMin, hour12)}–{minToTime(p.after.endMin, hour12)}</span></p>
              )}
              {p.splitParts && <p className="num text-[0.7rem] mt-1.5">{p.splitParts.map((s, i) => <span key={i} className="chip me-1">{minToTime(s.startMin, hour12)}–{minToTime(s.endMin, hour12)}</span>)}</p>}
              <p className="text-[0.62rem] text-3 mt-1">{lang === 'ar' ? 'الأثر المتوقع: ' : 'Expected effect: '}{lang === 'ar' ? p.expectedEffectAr : p.expectedEffectEn}</p>
              <div className="flex gap-2 mt-2">
                {p.kind !== 'advisory' && <button className="btn btn-primary btn-sm" onClick={() => applyProposal(p)}><Check className="w-4 h-4" />{lang === 'ar' ? 'قبول' : 'Accept'}</button>}
                <button className="btn btn-ghost btn-sm" onClick={() => setProposals(ps => ps?.filter(x => x.id !== p.id) ?? null)}><X className="w-4 h-4" />{lang === 'ar' ? 'رفض' : 'Reject'}</button>
              </div>
            </div>
          ))}
        </div>
      </Sheet>

      {/* ===== Template creator ===== */}
      <Sheet open={tplEditor} onClose={() => setTplEditor(false)} title={t('newTemplate')}>
        <Field label={lang === 'ar' ? 'اسم القالب' : 'Template name'}><input autoFocus className="input" value={tplName} onChange={e => setTplName(e.target.value)} placeholder={lang === 'ar' ? 'يوم الاختبار التجريبي…' : 'Mock exam day…'} /></Field>
        <span className="label">{lang === 'ar' ? 'الكتل' : 'Blocks'}</span>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {tplItems.map((item, i) => (
            <div key={i} className="flex gap-1.5 items-center">
              <input className="input flex-1 !py-1.5 text-sm" placeholder={lang === 'ar' ? 'العنوان' : 'Title'} value={item.title} onChange={e => setTplItems(arr => arr.map((x, j) => j === i ? { ...x, title: e.target.value } : x))} />
              <input type="time" className="input w-[5.2rem] !py-1.5 text-sm num" value={item.start} onChange={e => setTplItems(arr => arr.map((x, j) => j === i ? { ...x, start: e.target.value } : x))} />
              <input type="time" className="input w-[5.2rem] !py-1.5 text-sm num" value={item.end} onChange={e => setTplItems(arr => arr.map((x, j) => j === i ? { ...x, end: e.target.value } : x))} />
              <button className="icon-btn" onClick={() => setTplItems(arr => arr.filter((_, j) => j !== i))} aria-label="remove"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
        <button className="btn btn-ghost btn-sm mt-2" onClick={() => setTplItems(arr => [...arr, { title: '', categoryId: 'personal', start: '09:00', end: '09:45', fixed: false }])}><Plus className="w-4 h-4" />{lang === 'ar' ? 'كتلة' : 'Block'}</button>
        <button className="btn btn-primary w-full justify-center mt-3" onClick={saveTemplate}>{t('save')}</button>
      </Sheet>

      <ActivityEditor open={editorOpen} onClose={() => { setEditorOpen(false); setCreateAt(null); reload(); }} initial={editing} defaultDate={selected} defaultStartMin={createAt} />
    </div>
  );
}
