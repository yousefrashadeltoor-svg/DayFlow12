/* DAYFLOW — Today dashboard: overview · current block · live timeline · quick actions */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell, ChevronLeft, ChevronRight, Pin, Flame, Plus, Droplets, Check, Play, Pause,
  SkipForward, AlarmClock, ListTodo, Hourglass, Timer, CheckCheck, XCircle,
  CalendarDays, Eye, EyeOff, Crosshair, Pencil, StickyNote as NoteIcon, Trash2, Coffee, Target,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, addDays, nowMin, minToTime } from '@/lib/db';
import { summarizeDay, fmtMinutes } from '@/lib/stats';
import { platform, haptic } from '@/lib/platform';
import { ProgressRing, CategoryIcon, LinearProgress, Sheet, EmptyState, HelpTip } from '@/components/ui';
import { detectConflicts, durationOf } from '@/lib/scheduler';
import ActivityEditor from '@/components/ActivityEditor';
import type { ActivityBlock, ActivityCategory } from '@/lib/types';
import { cn } from '@/utils/cn';
import { SeasonalHeader } from '@/components/Seasonal';
import { prayerSummary } from '@/lib/sync';
import { occasionsInRange } from '@/lib/occasions';
import { OccasionCard } from '@/screens/CalendarScreen';

export default function Today() {
  const { t, lang, locale, hour12, tick, toast, confirm, navigate, settings, applyBlockMutation, bump } = useApp();
  const [dayOffset, setDayOffset] = useState(0);
  const [now, setNow] = useState(() => new Date());
  const [blocks, setBlocks] = useState<ActivityBlock[]>([]);
  const [cats, setCats] = useState<ActivityCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDone, setShowDone] = useState(false);
  const [filterCat, setFilterCat] = useState<string | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<ActivityBlock | null>(null);
  const [actionFor, setActionFor] = useState<ActivityBlock | null>(null);
  const [noteFor, setNoteFor] = useState<ActivityBlock | null>(null);
  const [noteText, setNoteText] = useState('');
  const [freeSheet, setFreeSheet] = useState(false);
  const timelineRef = useRef<HTMLDivElement>(null);
  const currentRef = useRef<HTMLDivElement>(null);

  const selectedDate = addDays(todayKey(), dayOffset);
  const isToday = dayOffset === 0;
  const catMap = useMemo(() => Object.fromEntries(cats.map(c => [c.id, c])), [cats]);

  useEffect(() => { const id = setInterval(() => setNow(new Date()), 15000); return () => clearInterval(id); }, []);

  const reload = useCallback(async () => {
    const [b, c] = await Promise.all([db.all<ActivityBlock>('activity_blocks'), db.all<ActivityCategory>('activity_categories')]);
    setBlocks(b); setCats(c); setLoading(false);
  }, []);
  useEffect(() => { reload(); }, [reload, tick, selectedDate]);

  const dayBlocks = useMemo(() => blocks.filter(b => b.date === selectedDate).sort((a, b) => a.startMin - b.startMin || a.endMin - b.endMin), [blocks, selectedDate]);
  const summary = useMemo(() => summarizeDay(dayBlocks, now), [dayBlocks, now]);
  const conflicts = useMemo(() => detectConflicts(dayBlocks), [dayBlocks]);
  const current = dayBlocks.find(b => b.status === 'in_progress') ?? null;
  const nowM = now.getHours() * 60 + now.getMinutes();
  const nextUp = isToday ? dayBlocks.find(b => b.status === 'planned' && b.endMin > nowM) ?? null : null;
  const hero = current ?? nextUp;

  const visibleBlocks = dayBlocks.filter(b =>
    (showDone || !(b.status === 'done' && true)) &&
    (!filterCat || b.categoryId === filterCat)
  );

  const greeting = (() => { const h = now.getHours(); const g = h < 5 ? t('goodNight') : h < 12 ? t('goodMorning') : h < 17 ? t('goodAfternoon') : h < 21 ? t('goodEvening') : t('goodNight'); return settings.userName ? `${g} يا ${settings.userName}` : g; })();
  const dateLine = new Intl.DateTimeFormat(locale, { weekday: 'long', day: 'numeric', month: 'long' }).format(isToday ? now : new Date(selectedDate + 'T12:00:00'));

  /* ----- mutations (all real writes) ----- */
  const setStatus = async (b: ActivityBlock, status: ActivityBlock['status'], extra: Partial<ActivityBlock> = {}) => {
    const updated: ActivityBlock = {
      ...b, status, ...extra, updatedAt: Date.now(),
      actualStartMin: status === 'in_progress' && b.actualStartMin == null ? nowMin() : b.actualStartMin,
      actualEndMin: status === 'done' || status === 'partial' ? nowMin() : b.actualEndMin,
    };
    await db.put('activity_blocks', updated);
    if (status === 'done' || status === 'skipped') await platform.cancelAlarm(b.id);
    setActionFor(null);
    haptic('light');
    await applyBlockMutation();
  };
  const snooze = async (b: ActivityBlock, minutes: number) => {
    const res = await platform.scheduleBlockAlarm({ ...b, date: todayKey(), startMin: nowMin() + minutes, reminderMin: 0 }, lang === 'ar' ? `مؤجل: ${b.title}` : `Snoozed: ${b.title}`);
    setActionFor(null);
    if (res.ok) toast(lang === 'ar' ? `سيُذكَّر بعد ${minutes} دقيقة` : `Reminder in ${minutes} min`);
    else toast(res.unsupported ? (lang === 'ar' ? 'التأجيل الأصلي يعمل داخل Android فقط' : 'Native snooze works inside Android only') : (lang === 'ar' ? 'تعذر الجدولة — تحقق من الصلاحيات' : 'Schedule failed — check permissions'));
  };
  const logNote = async () => {
    if (!noteFor) return;
    await db.put('activity_blocks', { ...noteFor, notes: noteText.trim(), updatedAt: Date.now() });
    setNoteFor(null); bump(); toast(t('saved'));
  };
  const logWater = async () => {
    await db.put('water_logs', { id: crypto.randomUUID(), date: todayKey(), timeMin: Math.round(nowMin()), amountMl: settings.waterCupMl, createdAt: Date.now() });
    haptic('medium');
    toast(lang === 'ar' ? `أُضيف ${settings.waterCupMl} مل — أحسنت` : `+${settings.waterCupMl} ml logged`);
  };
  const startBreak = async () => {
    const s = Math.ceil(nowMin() / 5) * 5;
    await db.put('activity_blocks', {
      id: crypto.randomUUID(), title: lang === 'ar' ? 'استراحة قصيرة' : 'Short break', description: '', categoryId: 'rest',
      date: todayKey(), startMin: s, endMin: s + 10, fixed: false, priority: 3, energy: 'low', difficulty: 1,
      status: 'planned', recurrence: 'none', reminderMin: 0, sound: 'default', repeatCount: 1, isCritical: false,
      splitAllowed: false, earliestStartMin: null, latestEndMin: null, linkedTaskId: null, linkedGoalId: null,
      linkedSubjectId: null, tags: ['break'], notes: '', actualStartMin: null, actualEndMin: null,
      createdAt: Date.now(), updatedAt: Date.now(),
    } satisfies ActivityBlock);
    await applyBlockMutation();
    toast(lang === 'ar' ? 'اتضافت استراحة 10 دقايق — ارتاح شوية ☕' : '10-minute break added to your schedule');
  };

  /* ----- week strip ----- */
  const weekDays = useMemo(() => {
    const base = new Date(selectedDate + 'T12:00:00');
    const startOffset = (base.getDay() - settings.weekStart + 7) % 7;
    const first = new Date(base); first.setDate(base.getDate() - startOffset);
    return Array.from({ length: 7 }, (_, i) => { const d = new Date(first); d.setDate(first.getDate() + i); return todayKey(d); });
  }, [selectedDate, settings.weekStart]);
  const weekdayName = (key: string) => new Intl.DateTimeFormat(locale, { weekday: 'short' }).format(new Date(key + 'T12:00:00'));

  const statusStyle = (b: ActivityBlock) => {
    if (b.status === 'done') return { bar: 'var(--ok)', chip: 'text-[var(--ok)] bg-[var(--ok-soft)]', label: lang === 'ar' ? 'خلصت' : 'Done' };
    if (b.status === 'partial') return { bar: 'var(--warn)', chip: 'text-[var(--warn)] bg-[var(--warn-soft)]', label: lang === 'ar' ? 'جزء منها' : 'Partial' };
    if (b.status === 'missed' || b.status === 'skipped') return { bar: 'var(--danger)', chip: 'text-[var(--danger)] bg-[var(--danger-soft)]', label: b.status === 'missed' ? (lang === 'ar' ? 'فاتت' : 'Missed') : (lang === 'ar' ? 'اتخطّيتها' : 'Skipped') };
    if (b.status === 'in_progress') return { bar: 'var(--accent)', chip: 'text-[var(--accent)] bg-[var(--accent-soft)]', label: lang === 'ar' ? 'دلوقتي' : 'Now' };
    if (b.status === 'paused') return { bar: 'var(--warn)', chip: 'text-[var(--warn)] bg-[var(--warn-soft)]', label: lang === 'ar' ? 'متوقفة' : 'Paused' };
    return { bar: 'var(--border-strong)', chip: 'text-2 bg-[var(--surface-2)]', label: lang === 'ar' ? 'جاية' : 'Planned' };
  };

  const nowMarkerAt = isToday && visibleBlocks.length
    ? visibleBlocks.findIndex(b => b.endMin > nowM && b.status !== 'done')
    : -1;

  return (
    <div className="pb-6">
      {/* ===== Header ===== */}
      <SeasonalHeader><header className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[0.72rem] font-bold text-2">{dateLine}</p>
          <h1 className="text-[1.35rem] leading-snug font-extrabold drop-shadow">{greeting} 👋</h1>
          <LiveClock locale={locale} hour12={hour12} lang={lang} />
        </div>
        <div className="flex items-center gap-1.5">
          <button className="icon-btn relative" onClick={() => navigate('notifications')} aria-label={t('notifications')}>
            <Bell className="w-5 h-5" />
            {summary.missed > 0 && <span className="absolute top-1 end-1 w-2.5 h-2.5 rounded-full bg-[var(--danger)] ring-2 ring-[var(--bg)]" />}
          </button>
          <button className="w-10 h-10 rounded-full grid place-items-center text-white font-extrabold" style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-deep))' }} onClick={() => navigate('settings')} aria-label={t('settings')}>
            {(settings.userName || (lang === 'ar' ? 'أنا' : 'ME')).slice(0, 2)}
          </button>
        </div>
      </header></SeasonalHeader>

      {/* ===== Next prayer + today's occasion ===== */}
      {(() => { const np = prayerSummary(settings); const occ = occasionsInRange(todayKey(), todayKey(), settings.hijriOffset).find(o => o.notify && !o.religion); return (
        <section className="mx-4 mt-3 space-y-3">
          <button onClick={() => navigate('prayer')} className="card w-full p-3 flex items-center gap-3 text-start">
            <ProgressRing size={54} stroke={6} progress={np.progress}><img src="/decor/mosque.png" alt="" className="w-6 h-6" /></ProgressRing>
            <div className="flex-1 min-w-0"><p className="text-[0.62rem] font-bold text-2">{lang === 'ar' ? `الصلاة الجاية · ${np.gov.ar}` : `Next prayer · ${np.gov.en}`}</p><p className="font-extrabold">{np.label} <span className="num text-sm text-2">{String(np.at.getHours()).padStart(2, '0')}:{String(np.at.getMinutes()).padStart(2, '0')}</span></p></div>
            <span className="num text-[0.8rem] font-extrabold accent">{lang === 'ar' ? `بعد ${Math.floor(np.minutesLeft / 60) ? `${Math.floor(np.minutesLeft / 60)}س ` : ''}${np.minutesLeft % 60}د` : `in ${np.minutesLeft}m`}</span>
          </button>
          {occ && <OccasionCard o={occ} lang={lang} />}
        </section>); })()}

      {/* ===== Overview card ===== */}
      <section className="mx-4 mt-2 card p-4 relative overflow-hidden">
        <div aria-hidden className="absolute -top-16 -end-16 w-48 h-48 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle, var(--accent-soft), transparent 70%)' }} />
        <div className="flex items-center gap-4">
          <ProgressRing size={104} stroke={10} progress={summary.completionRate}>
            <div className="text-center">
              <div className="num text-[1.35rem] font-extrabold leading-none">{summary.completionRate}<span className="text-[0.7rem]">%</span></div>
              <div className="text-[0.55rem] font-bold text-2 mt-1">{t('completionRate')}</div>
            </div>
          </ProgressRing>
          <div className="grid grid-cols-2 gap-2 flex-1">
            <div className="card-inset px-3 py-2"><p className="text-[0.6rem] font-bold text-2">{t('planned')}</p><p className="num font-bold">{fmtMinutes(summary.plannedMin, lang)}</p></div>
            <div className="card-inset px-3 py-2"><p className="text-[0.6rem] font-bold text-2">{t('completed')}</p><p className="num font-bold text-[var(--ok)]">{fmtMinutes(summary.doneMin, lang)}</p></div>
            <div className="card-inset px-3 py-2"><p className="text-[0.6rem] font-bold text-2">{t('remaining')}</p><p className="num font-bold">{fmtMinutes(Math.max(0, summary.remainingMin), lang)}</p></div>
            <button className="card-inset px-3 py-2 text-start" onClick={() => setFreeSheet(true)}><p className="text-[0.6rem] font-bold text-2">{t('freeTimeNow')}</p><p className="num font-bold accent">{fmtMinutes(summary.freeMinNow, lang)}</p></button>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-3 flex-wrap">
          <span className="chip"><CheckCheck className="w-3.5 h-3.5 text-[var(--ok)]" />{summary.completed} {t('blocksDone')}</span>
          <span className="chip"><Timer className="w-3.5 h-3.5 accent" />{summary.pending + summary.inProgress} {t('blocksPending')}</span>
          <span className="chip"><XCircle className="w-3.5 h-3.5 text-[var(--danger)]" />{summary.missed} {t('blocksMissed')}</span>
          <HelpTip title="ملخص النهارده"><p>النسبة دي محسوبة من <b>الدقايق اللي خلصتها فعلاً ÷ مجموع دقايق خطة النهارده</b> — النشاط «الجزئي» بيتحسب نص مدته. و«فاضي» هو الوقت اللي لسه متاح قدامك من دلوقتي لآخر اليوم بعيد عن الأنشطة المجدولة.</p></HelpTip>
          {conflicts.length > 0 && <button className="chip" style={{ borderColor: 'var(--warn)', color: 'var(--warn)' }} onClick={() => navigate('plan', { tab: 'schedule' })}>⚠ {conflicts.length} {lang === 'ar' ? 'تعارض — دوس تشوفه' : 'conflicts — tap to review'}</button>}
        </div>
      </section>

      {/* ===== Current / next activity hero ===== */}
      {hero && (
        <section className="mx-4 mt-3 rounded-3xl p-[1.5px] shadow-md" style={{ background: 'linear-gradient(140deg, color-mix(in srgb, var(--accent) 65%, transparent), transparent 45%, color-mix(in srgb, var(--cat-water) 55%, transparent))' }}>
          <div className="rounded-[calc(1.5rem-1.5px)] p-4" style={{ background: 'linear-gradient(160deg, var(--surface) 0%, color-mix(in srgb, var(--accent-soft) 55%, var(--surface)) 100%)' }}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[0.65rem] font-extrabold tracking-widest accent flex items-center gap-1.5">
                {current && <span className="w-2 h-2 rounded-full bg-[var(--accent)] live-dot" />}
                {current ? t('currentActivity') : t('upNext')}
              </span>
              <span className="num text-[0.78rem] font-bold text-2" dir="ltr">{minToTime(hero.startMin, hour12)} – {minToTime(hero.endMin, hour12)}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl grid place-items-center shrink-0" style={{ background: catMap[hero.categoryId]?.color ? `color-mix(in srgb, ${catMap[hero.categoryId].color.startsWith('var') ? catMap[hero.categoryId].color : catMap[hero.categoryId].color} 18%, transparent)` : 'var(--surface-2)', color: catMap[hero.categoryId]?.color ?? 'var(--accent)' }}>
                <CategoryIcon icon={catMap[hero.categoryId]?.icon} className="w-7 h-7" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-extrabold text-[1.05rem] leading-snug truncate">{hero.title}</p>
                <p className="text-[0.7rem] text-2 font-semibold">{lang === 'ar' ? catMap[hero.categoryId]?.nameAr : catMap[hero.categoryId]?.nameEn} · {fmtMinutes(durationOf(hero), lang)}{hero.fixed ? (lang === 'ar' ? ' · ثابتة' : ' · Fixed') : ''}</p>
              </div>
            </div>
            {hero.status === 'in_progress' && (
              <div className="mt-2.5"><LinearProgress value={Math.min(100, Math.max(2, ((nowM - hero.startMin) / Math.max(1, hero.endMin - hero.startMin)) * 100))} /></div>
            )}
            <div className="flex items-center gap-1.5 mt-3 flex-wrap">
              {hero.status !== 'in_progress' && <button className="btn btn-primary btn-sm" onClick={() => setStatus(hero, 'in_progress')}><Play className="w-4 h-4" />{t('start')}</button>}
              {hero.status === 'in_progress' && <button className="btn btn-ghost btn-sm" onClick={() => setStatus(hero, 'paused')}><Pause className="w-4 h-4" />{t('pause')}</button>}
              {hero.status === 'paused' && <button className="btn btn-primary btn-sm" onClick={() => setStatus(hero, 'in_progress')}><Play className="w-4 h-4" />{t('resume')}</button>}
              <button className="btn btn-soft btn-sm" onClick={() => setStatus(hero, 'done')}><Check className="w-4 h-4" />{t('complete')}</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setStatus(hero, 'partial')}>{t('partial')}</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setActionFor(hero)}><AlarmClock className="w-4 h-4" />{t('snooze')}</button>
              <button className="btn btn-quiet btn-sm" onClick={() => { setEditing(hero); setEditorOpen(true); }}><Pencil className="w-4 h-4" /></button>
            </div>
          </div>
        </section>
      )}

      {/* ===== Quick actions ===== */}
      <section className="px-4 mt-4">
        <div className="grid grid-cols-6 gap-2">
          {[
            { icon: Plus, label: t('addActivity'), onClick: () => { setEditing(null); setEditorOpen(true); }, accent: true },
            { icon: Timer, label: t('focus'), onClick: () => navigate('focus') },
            { icon: Droplets, label: `+${settings.waterCupMl}ml`, onClick: logWater },
            { icon: ListTodo, label: t('addTask'), onClick: () => navigate('tasks') },
            { icon: NoteIcon, label: lang === 'ar' ? 'يومياتي' : 'Journal', onClick: () => navigate('journal') },
            { icon: Coffee, label: lang === 'ar' ? 'استراحة' : 'Break', onClick: startBreak },
          ].map((a, i) => (
            <button key={i} onClick={a.onClick} className="flex flex-col items-center gap-1.5 group" aria-label={a.label}>
              <span className={cn('w-12 h-12 rounded-2xl grid place-items-center transition-transform group-active:scale-90', a.accent ? 'text-[var(--on-accent)]' : 'text-[var(--accent)] bg-[var(--accent-soft)]')} style={a.accent ? { background: 'var(--accent)' } : undefined}>
                <a.icon className="w-5 h-5" strokeWidth={2} />
              </span>
              <span className="text-[0.58rem] font-semibold text-2 leading-tight text-center">{a.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* ===== Timeline ===== */}
      <section className="mx-4 mt-4 card">
        <div className="flex items-center justify-between px-4 pt-3 pb-2 border-b hairline">
          <div className="flex items-center gap-1">
            <button className="icon-btn" onClick={() => setDayOffset(d => d - 1)} aria-label="previous day"><ChevronRight className="w-5 h-5" /></button>
            <button className="flex items-center gap-1.5 px-2 py-1.5 rounded-xl hover:bg-[var(--surface-2)]" onClick={() => setDayOffset(0)}>
              <CalendarDays className="w-4 h-4 accent" />
              <span className="text-sm font-extrabold min-w-[6ch] text-center">{isToday ? (lang === 'ar' ? 'النهارده' : 'Today') : new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'short' }).format(new Date(selectedDate + 'T12:00:00'))}</span>
            </button>
            <button className="icon-btn" onClick={() => setDayOffset(d => d + 1)} aria-label="next day"><ChevronLeft className="w-5 h-5" /></button>
          </div>
          <div className="flex items-center gap-1">
            <button className="icon-btn" onClick={() => currentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })} title={lang === 'ar' ? 'الانتقال للآن' : 'Jump to now'} aria-label="jump to now"><Crosshair className="w-5 h-5" /></button>
            <button className="icon-btn" onClick={() => setShowDone(v => !v)} title={showDone ? t('hideDone') : t('showDone')} aria-pressed={showDone}>{showDone ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}</button>
          </div>
        </div>

        {/* week strip */}
        <div className="flex gap-1 px-3 pt-2.5 pb-1 overflow-x-auto no-scrollbar border-b hairline">
          {weekDays.map(key => {
            const selected = key === selectedDate;
            const count = blocks.filter(b => b.date === key && b.status !== 'cancelled').length;
            const doneCount = blocks.filter(b => b.date === key && b.status === 'done').length;
            return (
              <button key={key} onClick={() => setDayOffset(Math.round((new Date(key + 'T12:00:00').getTime() - new Date(todayKey() + 'T12:00:00').getTime()) / 86400000))}
                className={cn('flex-1 min-w-[3rem] rounded-2xl py-1.5 flex flex-col items-center gap-0.5 transition-colors', selected ? 'bg-[var(--accent)] text-[var(--on-accent)]' : 'hover:bg-[var(--surface-2)]')} aria-pressed={selected}>
                <span className={cn('text-[0.6rem] font-bold', selected ? 'opacity-90' : 'text-2')}>{weekdayName(key)}</span>
                <span className="num text-sm font-extrabold">{Number(key.slice(-2))}</span>
                <span className={cn('w-1.5 h-1.5 rounded-full', count === 0 ? 'opacity-0' : selected ? 'bg-white/80' : doneCount === count ? 'bg-[var(--ok)]' : 'bg-[var(--accent)]')} />
              </button>
            );
          })}
        </div>

        {/* category filter */}
        <div className="flex gap-1.5 px-3 pt-2 overflow-x-auto no-scrollbar">
          <button className={cn('chip', !filterCat && 'chip-active')} onClick={() => setFilterCat(null)}>{t('all')}</button>
          {cats.filter(c => dayBlocks.some(b => b.categoryId === c.id)).map(c => (
            <button key={c.id} className={cn('chip', filterCat === c.id && 'chip-active')} onClick={() => setFilterCat(filterCat === c.id ? null : c.id)}>
              <CategoryIcon icon={c.icon} className="w-3.5 h-3.5" />{lang === 'ar' ? c.nameAr : c.nameEn}
            </button>
          ))}
        </div>

        {/* blocks */}
        <div ref={timelineRef} className="px-3 py-2">
          {loading && <div className="py-6 text-center text-sm text-2">…</div>}
          {!loading && visibleBlocks.length === 0 && (
            <EmptyState icon={<Target className="w-7 h-7" />} title={t('nothingScheduled')} hint={t('addFirstActivity')}
              action={<button className="btn btn-primary" onClick={() => { setEditing(null); setEditorOpen(true); }}><Plus className="w-4 h-4" />{t('addActivity')}</button>} />
          )}
          {visibleBlocks.map((b, idx) => {
            const s = statusStyle(b);
            const isCurrent = b.status === 'in_progress';
            const density = settings.timelineDensity === 'compact';
            const showNowMarker = nowMarkerAt === idx && b.endMin > nowM;
            return (
              <div key={b.id}>
                {showNowMarker && (
                  <div className="flex items-center gap-2 py-1" aria-hidden>
                    <span className="num text-[0.62rem] font-extrabold accent w-11">{minToTime(nowM, hour12)}</span>
                    <span className="flex-1 h-px" style={{ background: 'var(--accent)' }} />
                    <span className="w-2.5 h-2.5 rounded-full bg-[var(--accent)] live-dot" />
                  </div>
                )}
                <div ref={isCurrent ? currentRef : undefined} id={`block-${b.id}`}
                  className={cn('flex gap-2.5 rounded-2xl border transition-colors cursor-pointer active:scale-[0.99]', density ? 'py-1.5 px-2 mb-1' : 'py-2.5 px-2.5 mb-1.5', isCurrent ? 'border-[var(--accent)] bg-[var(--accent-soft)]' : 'border-transparent hover:bg-[var(--surface-2)]')}
                  style={{ borderInlineStart: `4px solid ${s.bar}` }}
                  onClick={() => setActionFor(b)} role="button" tabIndex={0}
                  onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setActionFor(b); } }}
                  aria-label={`${b.title}, ${minToTime(b.startMin, hour12)}`}>
                  <div className="w-12 shrink-0 pt-0.5">
                    <p className="num text-[0.7rem] font-extrabold leading-tight" dir="ltr">{minToTime(b.startMin, hour12)}</p>
                    <p className="num text-[0.58rem] text-3" dir="ltr">{minToTime(b.endMin, hour12)}</p>
                    {!density && <p className="num text-[0.55rem] text-2 mt-0.5">{fmtMinutes(durationOf(b), lang)}</p>}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <CategoryIcon icon={catMap[b.categoryId]?.icon} className="w-4 h-4 shrink-0 text-2" />
                      <p className={cn('font-bold truncate', density ? 'text-[0.8rem]' : 'text-[0.85rem]', b.status === 'done' && 'line-through opacity-60')}>{b.title}</p>
                    </div>
                    {b.notes && !b.notes.startsWith('tpl:') && <p className="text-[0.65rem] text-2 truncate mt-0.5">📝 {b.notes}</p>}
                    <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                      <span className={cn('text-[0.55rem] font-extrabold rounded-full px-1.5 py-0.5', s.chip)}>{s.label}</span>
                      {b.fixed && <Pin className="w-3 h-3 text-2" aria-label="fixed" />}
                      {b.reminderMin >= 0 && <Bell className="w-3 h-3 text-2" aria-label="reminder" />}
                      {b.priority === 1 && <Flame className="w-3 h-3 text-[var(--danger)]" aria-label="critical" />}
                    </div>
                  </div>
                  {b.status === 'done'
                    ? <CheckCheck className="w-5 h-5 self-center shrink-0 text-[var(--ok)]" />
                    : isCurrent ? <div className="self-center shrink-0"><span className="w-3 h-3 rounded-full bg-[var(--accent)] live-dot block" /></div>
                    : <ChevronRight className="w-4 h-4 self-center shrink-0 text-3 rtl:rotate-180" />}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ===== Action sheet ===== */}
      <Sheet open={!!actionFor} onClose={() => setActionFor(null)} title={actionFor?.title}>
        {actionFor && (
          <div className="grid grid-cols-4 gap-2">
            {[
              { icon: Play, label: t('start'), onClick: () => setStatus(actionFor, 'in_progress') },
              { icon: Check, label: t('complete'), onClick: () => setStatus(actionFor, 'done') },
              { icon: SkipForward, label: t('skip'), onClick: () => setStatus(actionFor, 'skipped') },
              { icon: AlarmClock, label: `+5`, onClick: () => snooze(actionFor, 5) },
              { icon: AlarmClock, label: `+10`, onClick: () => snooze(actionFor, 10) },
              { icon: AlarmClock, label: `+15`, onClick: () => snooze(actionFor, 15) },
              { icon: Hourglass, label: t('partial'), onClick: () => setStatus(actionFor, 'partial') },
              { icon: NoteIcon, label: t('note'), onClick: () => { setNoteFor(actionFor); setNoteText(actionFor.notes ?? ''); setActionFor(null); } },
              { icon: Pencil, label: t('edit'), onClick: () => { setEditing(actionFor); setEditorOpen(true); setActionFor(null); } },
              { icon: XCircle, label: lang === 'ar' ? 'إلغاء الكتلة' : 'Cancel block', onClick: () => setStatus(actionFor, 'cancelled') },
              { icon: Trash2, label: t('delete'), danger: true, onClick: async () => {
                  const ok = await confirm({ title: lang === 'ar' ? 'حذف الكتلة؟' : 'Delete block?', danger: true, confirmLabel: t('delete') });
                  if (ok) { const stash = actionFor; await db.del('activity_blocks', stash.id); await platform.cancelAlarm(stash.id); setActionFor(null); await applyBlockMutation(); toast(t('deleted'), { actionLabel: t('undo'), onAction: async () => { await db.put('activity_blocks', stash); await applyBlockMutation(); } }); }
                } },
            ].map((a: any, i) => (
              <button key={i} onClick={a.onClick} className={cn('flex flex-col items-center gap-1.5 rounded-2xl py-3 px-1 transition-colors', a.danger ? 'hover:bg-[var(--danger-soft)] text-[var(--danger)]' : 'hover:bg-[var(--surface-2)]')}>
                <a.icon className="w-5 h-5" strokeWidth={1.8} />
                <span className="text-[0.65rem] font-bold text-center leading-tight">{a.label}</span>
              </button>
            ))}
          </div>
        )}
      </Sheet>

      {/* note sheet */}
      <Sheet open={!!noteFor} onClose={() => setNoteFor(null)} title={t('note')}>
        <textarea autoFocus className="input min-h-[120px]" value={noteText} onChange={e => setNoteText(e.target.value)} placeholder={lang === 'ar' ? 'اكتب ملاحظتك…' : 'Write your note…'} />
        <button className="btn btn-primary w-full justify-center mt-3" onClick={logNote}>{t('save')}</button>
      </Sheet>

      {/* free time sheet */}
      <Sheet open={freeSheet} onClose={() => setFreeSheet(false)} title={t('freeTimeNow')}>
        <p className="num text-5xl font-extrabold accent text-center py-4">{fmtMinutes(summary.freeMinNow, lang)}</p>
        <p className="text-center text-sm text-2">{lang === 'ar' ? 'المتبقي من يومك بعد الفراغ الحالي للكتل المجدولة' : 'What remains of your day after scheduled blocks'}</p>
      </Sheet>

      <ActivityEditor open={editorOpen} onClose={() => { setEditorOpen(false); reload(); }} initial={editing} defaultDate={selectedDate} />
    </div>
  );
}


/* Isolated 1-second clock: only this tiny component re-renders every second,
   keeping the whole dashboard smooth on low-end devices. */
function LiveClock({ locale, hour12, lang }: { locale: string; hour12: boolean; lang: 'ar' | 'en' }) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => { const id = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(id); }, []);
  const line = new Intl.DateTimeFormat(locale, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12 }).format(now);
  return <p className="num text-[0.8rem] text-3 mt-0.5" dir="ltr" style={{ textAlign: lang === 'ar' ? 'right' : 'left' }}>{line}</p>;
}
