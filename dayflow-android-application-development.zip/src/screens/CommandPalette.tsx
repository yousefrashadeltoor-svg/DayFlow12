/* DAYFLOW — Global command center: search everything + quick commands (Ctrl/⌘K) */
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Search, X, ListTodo, CalendarClock, Droplets, CheckCheck, Sun, Moon, Languages, Zap, GraduationCap, StickyNote, Flame, Target, BookOpen, CornerDownLeft,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, nowMin } from '@/lib/db';
import ActivityEditor from '@/components/ActivityEditor';
import { haptic } from '@/lib/platform';
import type { TaskItem, NoteItem, ActivityBlock } from '@/lib/types';

export default function CommandPalette() {
  const { lang, navigate, back, toast, bump, saveSettings, settings } = useApp();
  const [q, setQ] = useState('');
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [blocks, setBlocks] = useState<ActivityBlock[]>([]);
  const [habits, setHabits] = useState<any[]>([]);
  const [goals, setGoals] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [editorOpen, setEditorOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    (async () => {
      const [t2, n, b, h, g, s] = await Promise.all([
        db.all<TaskItem>('tasks'), db.all<NoteItem>('notes'), db.all<ActivityBlock>('activity_blocks'),
        db.all('habits'), db.all('goals'), db.all('study_subjects'),
      ]);
      setTasks(t2); setNotes(n); setBlocks(b); setHabits(h); setGoals(g); setSubjects(s);
    })();
  }, []);

  const query = q.trim().toLowerCase();
  const match = (s?: string) => !!s && s.toLowerCase().includes(query);

  const commands = useMemo(() => {
    const list = [
      { id: 'add-activity', icon: CalendarClock, ar: 'إضافة نشاط لجدولك', en: 'Add activity to your schedule', run: () => setEditorOpen(true) },
      { id: 'add-task', icon: ListTodo, ar: 'إضافة مهمة', en: 'Add a task', run: () => navigate('tasks', { create: true }) },
      { id: 'start-focus', icon: Zap, ar: 'بدء جلسة تركيز', en: 'Start a focus session', run: () => navigate('focus') },
      { id: 'log-water', icon: Droplets, ar: 'تسجيل كوب ماء', en: 'Log a cup of water', run: async () => {
          await db.put('water_logs', { id: crypto.randomUUID(), date: todayKey(), timeMin: Math.round(nowMin()), amountMl: settings.waterCupMl, createdAt: Date.now() });
          haptic('medium'); toast(lang === 'ar' ? `أُضيف ${settings.waterCupMl} مل` : `+${settings.waterCupMl} ml`); bump();
        } },
      { id: 'complete-current', icon: CheckCheck, ar: 'إكمال الكتلة الحالية', en: 'Complete current block', run: async () => {
          const todays = (await db.all<ActivityBlock>('activity_blocks')).filter(b => b.date === todayKey());
          const cur = todays.find(b => b.status === 'in_progress') ?? todays.find(b => b.status === 'planned' && b.endMin > nowMin());
          if (!cur) { toast(lang === 'ar' ? 'لا توجد كتلة نشطة الآن' : 'No active block right now'); return; }
          await db.put('activity_blocks', { ...cur, status: 'done', actualEndMin: nowMin(), updatedAt: Date.now() }); bump();
          toast(lang === 'ar' ? `أُنجزت «${cur.title}»` : `"${cur.title}" completed`);
        } },
      { id: 'toggle-theme', icon: settings.theme === 'dark' ? Sun : Moon, ar: 'تبديل السمة فاتح/داكن', en: 'Toggle light/dark theme', run: () => saveSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' }) },
      { id: 'toggle-lang', icon: Languages, ar: 'التبديل إلى English', en: 'Switch to العربية', run: () => saveSettings({ language: lang === 'ar' ? 'en' : 'ar' }) },
      { id: 'open-today', icon: CalendarClock, ar: 'فتح جدول اليوم', en: "Open today's schedule", run: () => navigate('today') },
    ];
    return query ? list.filter(c => (c.ar + ' ' + c.en).toLowerCase().includes(query)) : list;
  }, [query, lang, navigate, toast, bump, settings.theme, settings.waterCupMl, saveSettings]);

  const results = useMemo(() => {
    if (!query) return [] as Array<{ icon: any; title: string; sub: string; go: string }>;
    const out: Array<{ icon: any; title: string; sub: string; go: string }> = [];
    for (const b of blocks) if (match(b.title) || match(b.notes)) { out.push({ icon: CalendarClock, title: b.title, sub: `${b.date} · ${Math.floor(b.startMin / 60)}:${String(b.startMin % 60).padStart(2, '0')}`, go: 'today' }); if (out.length > 24) break; }
    for (const t2 of tasks) if (match(t2.title)) out.push({ icon: ListTodo, title: t2.title, sub: lang === 'ar' ? 'مهمة' : 'Task', go: 'tasks' });
    for (const n of notes) if (match(n.title) || match(n.body)) out.push({ icon: StickyNote, title: n.title || (lang === 'ar' ? '(بدون عنوان)' : '(untitled)'), sub: lang === 'ar' ? 'ملاحظة' : 'Note', go: 'notes' });
    for (const h of habits) if (match(h.name)) out.push({ icon: Flame, title: h.name, sub: lang === 'ar' ? 'عادة' : 'Habit', go: 'habits' });
    for (const g of goals) if (match(g.title)) out.push({ icon: Target, title: g.title, sub: lang === 'ar' ? 'هدف' : 'Goal', go: 'goals' });
    for (const s of subjects) if (match(s.title)) out.push({ icon: BookOpen, title: s.title, sub: lang === 'ar' ? 'مادة' : 'Subject', go: 'study' });
    return out.slice(0, 24);
  }, [query, blocks, tasks, notes, habits, goals, subjects, lang]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') back(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [back]);

  return (
    <div className="fixed inset-0 z-[75] flex flex-col" role="dialog" aria-modal="true" aria-label={lang === 'ar' ? 'البحث والأوامر' : 'Search & commands'}>
      <div className="absolute inset-0 bg-black/55 backdrop-blur-sm anim-fade" onClick={back} />
      <div className="relative mx-auto mt-16 sm:mt-24 w-[min(94vw,36rem)] card overflow-hidden anim-pop">
        <div className="flex items-center gap-2 px-4 border-b hairline">
          <Search className="w-5 h-5 text-2 shrink-0" />
          <input ref={inputRef} value={q} onChange={e => setQ(e.target.value)}
            placeholder={lang === 'ar' ? 'ابحث في كل شيء، أو اكتب أمراً…' : 'Search everything, or type a command…'}
            className="flex-1 bg-transparent py-4 outline-none text-[1.05rem] font-medium" aria-label="search" />
          <button className="icon-btn" onClick={back} aria-label="Close"><X className="w-5 h-5" /></button>
        </div>
        <div className="max-h-[62vh] overflow-y-auto p-2">
          {commands.length > 0 && (<>
            <p className="px-3 pt-1 pb-1 text-[0.6rem] font-extrabold text-3 uppercase tracking-widest flex items-center gap-1"><Zap className="w-3.5 h-3.5" />{lang === 'ar' ? 'أوامر' : 'Commands'}</p>
            {commands.map(c => (
              <button key={c.id} onClick={() => { c.run(); if (c.id !== 'add-activity') back(); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-[var(--surface-2)] text-start">
                <c.icon className="w-5 h-5 accent shrink-0" />
                <span className="text-sm font-semibold flex-1">{lang === 'ar' ? c.ar : c.en}</span>
                <CornerDownLeft className="w-4 h-4 text-3" />
              </button>
            ))}
          </>)}
          {results.length > 0 && (<>
            <p className="px-3 pt-2 pb-1 text-[0.6rem] font-extrabold text-3 uppercase tracking-widest flex items-center gap-1"><GraduationCap className="w-3.5 h-3.5" />{lang === 'ar' ? 'نتائج' : 'Results'}</p>
            {results.map((r, i) => (
              <button key={i} onClick={() => { navigate(r.go as any); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-[var(--surface-2)] text-start">
                <r.icon className="w-5 h-5 text-2 shrink-0" />
                <span className="flex-1 min-w-0"><span className="block text-sm font-semibold truncate">{r.title}</span><span className="block text-[0.62rem] text-3 font-num num">{r.sub}</span></span>
              </button>
            ))}
          </>)}
          {query && commands.length === 0 && results.length === 0 && (
            <p className="text-center text-sm text-2 py-8">{lang === 'ar' ? 'لا توجد نتائج مطابقة' : 'No matches found'}</p>
          )}
        </div>
      </div>
      <ActivityEditor open={editorOpen} onClose={() => { setEditorOpen(false); back(); }} />
    </div>
  );
}
