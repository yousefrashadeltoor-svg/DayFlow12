/* DAYFLOW — AI Assistant (agent) page: multi-provider chat, real in-app actions, rich live previews in chat,
   model picker with brand logos & real free/credit/paid sorting, saved conversations, confirmations for deletes. */
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  Plus, Send, Menu, ChevronDown, Search, Check, X, Copy, RotateCcw, Trash2, Sparkles, Settings as SettingsIcon, Loader2,
  CheckCircle2, XCircle, Lock, Zap, Wand2, AlertTriangle, Bot,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { Sheet, HelpTip, EmptyState, ProgressRing, LinearProgress } from '@/components/ui';
import { BrandLogo, FamilyLogo } from '@/components/BrandLogo';
import { PROVIDERS, TIER_LABEL, providerById, type ModelInfo, type Tier } from '@/lib/ai/providers';
import { getAIConfig, saveAIConfig, modelsFor, catalogIsLive, listChats, saveChat, deleteChat, newChat, titleFrom, PROMPT_SUGGESTIONS_AR, PROMPT_SUGGESTIONS_EN, type AIConfig, type ChatRow, type ChatMessageRow } from '@/lib/ai/config';
import { verifyModel, type CatalogEntry } from '@/lib/ai/liveCatalog';
import { markVerification } from '@/lib/ai/config';
import { runAgent } from '@/lib/ai/agent';
import { AIError } from '@/lib/ai/client';
import { executePending, type AssistantCard, type ActionLog, type PendingAction, type ToolContext } from '@/lib/ai/tools';
import { SCENES, sceneFor } from '@/components/Seasonal';
import { cn } from '@/utils/cn';
import { haptic } from '@/lib/platform';

export default function AssistantScreen() {
  const { lang, settings, navigate: appNavigate, bump, toast, tick } = useApp();
  const navigate = (n: string, p?: any) => appNavigate(n as any, p);
  const ar = lang === 'ar';
  const [cfg, setCfg] = useState<AIConfig | null>(null);
  const [chats, setChats] = useState<ChatRow[]>([]);
  const [active, setActive] = useState<ChatRow | null>(null);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [modelOpen, setModelOpen] = useState(false);
  const [convOpen, setConvOpen] = useState(false);
  const [progress, setProgress] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const reloadAll = async () => {
    setCfg(await getAIConfig());
    const list = await listChats();
    setChats(list);
    setActive(prev => prev ? (list.find(c => c.id === prev.id) ?? prev) : (list[0] ?? null));
  };
  useEffect(() => { reloadAll(); /* eslint-disable-next-line */ }, [tick]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (typeof el.scrollTo === 'function') el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
    else el.scrollTop = el.scrollHeight;
  }, [active?.messages.length, busy]);

  const provider = cfg ? providerById(cfg.providerId) : undefined;
  const modelInfo: ModelInfo | undefined = cfg && provider ? modelsFor(provider.id, cfg).find(m => m.id === cfg.model) : undefined;
  const hasKey = !!(cfg && provider && cfg.keys[provider.id]);
  const suggestions = ar ? PROMPT_SUGGESTIONS_AR : PROMPT_SUGGESTIONS_EN;

  const ctxFor = (): ToolContext => ({
    settings, allowActions: cfg?.allowActions !== false,
    navigate: (n: string, p?: any) => navigate(n, p), bump,
  });

  const persist = async (chat: ChatRow) => { await saveChat(chat); setChats(await listChats()); setActive(chat); };

  const newConversation = async () => {
    const c = newChat(ar ? 'محادثة جديدة' : 'New chat');
    await persist(c);
    setConvOpen(false);
    haptic('light');
  };

  const send = async (raw?: string) => {
    const text = (raw ?? input).trim();
    if (!text || busy || !cfg) return;
    if (!cfg.enabled) { toast(ar ? 'فعّل المساعد الأول من الإعدادات' : 'Enable the assistant first'); return; }
    if (!provider) return;
    if (!hasKey) { toast(ar ? `ضيف مفتاح ${provider.name} من الإعدادات` : `Add ${provider.name} key in settings`); return; }
    const model = cfg.model;
    setInput('');
    const base: ChatRow = active ?? newChat(titleFrom(text));
    const userMsg: ChatMessageRow = { id: crypto.randomUUID(), role: 'user', content: text, createdAt: Date.now() };
    const withUser: ChatRow = { ...base, title: base.messages.length ? base.title : titleFrom(text), messages: [...base.messages, userMsg] };
    await persist(withUser);
    setBusy(true);
    setProgress(ar ? 'بفكّر…' : 'Thinking…');
    try {
      const history = withUser.messages.filter(m => m.role !== 'error').map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));
      const supportsTools = cfg.supportsTools[provider.id] !== false && (modelInfo?.tools ?? true);
      const res = await runAgent({
        provider, apiKey: cfg.keys[provider.id], model, history: history.slice(0, -1), userText: text,
        ctx: { ...ctxFor(), navigate: (n: string, p?: any) => { setProgress(ar ? `بفتح ${n}…` : `Opening ${n}…`); navigate(n, p); } },
        shareContext: cfg.shareContext, supportsTools,
      });
      if (!supportsTools && cfg.supportsTools[provider.id] === undefined) { /* first run without tools: nothing to store */ }
      const assistantMsg: ChatMessageRow = {
        id: crypto.randomUUID(), role: 'assistant', content: res.reply, createdAt: Date.now(),
        providerId: provider.id, model, actions: res.actions, cards: res.cards, pending: res.pending,
      };
      await persist({ ...withUser, messages: [...withUser.messages, assistantMsg] });
      bump();
      haptic('light');
    } catch (e: any) {
      const msg = e instanceof AIError ? e.message : (ar ? `حصلت مشكلة غير متوقعة: ${e?.message ?? e}` : `Unexpected: ${e?.message ?? e}`);
      await persist({ ...withUser, messages: [...withUser.messages, { id: crypto.randomUUID(), role: 'error', content: msg, createdAt: Date.now() }] });
    } finally {
      setBusy(false);
      setProgress('');
    }
  };

  const regenerate = async () => {
    if (!active || busy) return;
    const lastUser = [...active.messages].reverse().find(m => m.role === 'user');
    if (!lastUser) return;
    const idx = active.messages.lastIndexOf(lastUser);
    const trimmed: ChatRow = { ...active, messages: active.messages.slice(0, idx) };
    await persist(trimmed);
    setInput(lastUser.content);
    setTimeout(() => send(lastUser.content), 0);
  };

  const confirmPending = async (msgId: string, p: PendingAction) => {
    if (!active) return;
    const out = await executePending(p, ctxFor());
    const res: ActionLog = { tool: p.kind, ok: out.ok, summary: out.summary };
    const msgs = active.messages.map(m => m.id === msgId ? { ...m, pending: (m.pending ?? []).filter(x => x.id !== p.id) } : m);
    await persist({ ...active, messages: [...msgs, { id: crypto.randomUUID(), role: 'assistant', content: out.summary, createdAt: Date.now(), actions: [res] }] });
    bump();
  };
  const cancelPending = async (msgId: string, p: PendingAction) => {
    if (!active) return;
    await persist({ ...active, messages: active.messages.map(m => m.id === msgId ? { ...m, pending: (m.pending ?? []).filter(x => x.id !== p.id) } : m) });
    toast(ar ? 'تمام، ملغيش حاجة' : 'Cancelled');
  };

  const removeMessage = async (id: string) => {
    if (!active) return;
    await persist({ ...active, messages: active.messages.filter(m => m.id !== id) });
  };

  const clearAll = async () => {
    if (!active) return;
    await deleteChat(active.id);
    setActive(null);
    setChats(await listChats());
  };

  const enabled = !!cfg?.enabled;

  return (
    <div className="flex flex-col h-full min-h-0 pt-12">
      {/* ===== Top bar ===== */}
      <header className="flex items-center gap-2 px-3 pb-2 border-b hairline glass z-10">
        <button className="icon-btn" onClick={() => setConvOpen(true)} aria-label={ar ? 'المحادثات' : 'Chats'}><Menu className="w-5 h-5" /></button>
        <button onClick={() => setModelOpen(true)} className="flex-1 min-w-0 flex items-center gap-2 rounded-2xl px-2 py-1.5 hover:bg-[var(--surface-2)] transition-colors text-start" aria-label={ar ? 'اختار الموديل' : 'Choose model'}>
          {provider ? <BrandLogo icon={provider.icon} mono={provider.mono} color={provider.color} size={30} rounded="lg" /> : <span className="w-[30px] h-[30px] rounded-lg bg-[var(--surface-2)]" />}
          <span className="min-w-0 flex-1">
            <span className="block text-[0.82rem] font-extrabold truncate flex items-center gap-1.5">
              {modelInfo?.name ?? cfg?.model ?? '—'}
              <ChevronDown className="w-3.5 h-3.5 text-3" />
            </span>
            <span className="block text-[0.6rem] text-2 font-semibold truncate">
              {provider?.name ?? ''} {modelInfo ? <TierBadge tier={modelInfo.tier} ar={ar} inline /> : null}
            </span>
          </span>
        </button>
        <button className="icon-btn" onClick={newConversation} aria-label={ar ? 'محادثة جديدة' : 'New chat'}><Plus className="w-5 h-5" /></button>
        <button className="icon-btn" onClick={() => navigate('settings' as any, { page: 'assistant' })} aria-label={ar ? 'إعدادات المساعد' : 'Assistant settings'}><SettingsIcon className="w-4.5 h-4.5" /></button>
      </header>

      {/* ===== Body ===== */}
      <div ref={scrollRef} className="flex-1 min-h-0 overflow-y-auto no-scrollbar px-3 pt-3 pb-2">
        {!enabled && (
          <div className="card p-4 mb-3 text-center">
            <Lock className="w-7 h-7 mx-auto text-2" />
            <p className="font-extrabold mt-2">{ar ? 'المساعد الذكي مقفول لحد ما تفعّله' : 'Assistant is off'}</p>
            <p className="text-[0.72rem] text-2 mt-1 leading-relaxed">{ar ? 'المساعد ميزة اختيارية. فعّلها من الإعدادات، وضيف مفتاح واحد من أي مزوّد عنده رصيد مجاني، وهيقدر ينفّذ طلباتك في التطبيق.' : 'Opt-in. Enable it in settings and add one free-tier key.'}</p>
            <button className="btn btn-primary btn-sm mt-3" onClick={() => navigate('settings' as any, { page: 'assistant' })}><SettingsIcon className="w-4 h-4" />{ar ? 'افتح إعدادات المساعد' : 'Open settings'}</button>
          </div>
        )}

        {enabled && !hasKey && (
          <div className="card-flat p-3 mb-3 flex items-start gap-2 border" style={{ borderColor: 'var(--warn)' }}>
            <AlertTriangle className="w-4 h-4 text-[var(--warn)] shrink-0 mt-0.5" />
            <p className="text-[0.72rem] leading-relaxed">{ar ? `مفيش مفتاح لـ ${provider?.name}. ضيفه من الإعدادات أو اختار مزوّد تاني.` : `No key for ${provider?.name}.`}</p>
          </div>
        )}

        {(!active || active.messages.length === 0) && (
          <Welcome ar={ar} suggestions={suggestions} onPick={t => send(t)} disabled={!enabled || busy} />
        )}

        <div className="space-y-4">
          {active?.messages.map(m => (
            <MessageView
              key={m.id}
              m={m}
              ar={ar}
              provider={m.providerId ? providerById(m.providerId) : provider}
              isLastAssistant={!!active && active.messages.filter(x => x.role === 'assistant').slice(-1)[0]?.id === m.id}
              onRegenerate={regenerate}
              onDelete={() => removeMessage(m.id)}
              onConfirm={p => confirmPending(m.id, p)}
              onCancel={p => cancelPending(m.id, p)}
              confirmDeletes={cfg?.confirmDeletes !== false}
              navigate={navigate}
            />
          ))}
          {busy && <TypingBubble ar={ar} label={progress} provider={provider} />}
        </div>
      </div>

      {/* ===== Composer ===== */}
      <div className="px-3 pb-[max(env(safe-area-inset-bottom),0.6rem)] pt-2 border-t hairline glass">
        {active && active.messages.length > 0 && (
          <div className="flex items-center gap-1.5 mb-2 overflow-x-auto no-scrollbar">
            {[
              { t: ar ? 'جدول النهارده' : "Today's plan", p: ar ? 'اعرضلي جدول النهارده' : 'Show today schedule' },
              { t: ar ? 'ملخص يومي' : 'Summary', p: ar ? 'ملخص يومي' : 'Give me today summary' },
              { t: ar ? 'المناسبات الجاية' : 'Occasions', p: ar ? 'وريني المناسبات الجاية' : 'Show upcoming occasions' },
            ].map(x => <button key={x.t} className="chip flex-none" onClick={() => send(x.p)} disabled={busy || !enabled}>{x.t}</button>)}
            <button className="chip flex-none" onClick={clearAll} aria-label="delete chat"><Trash2 className="w-3.5 h-3.5" />{ar ? 'امسح المحادثة' : 'Delete chat'}</button>
          </div>
        )}
        <div className="flex items-end gap-2">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
            rows={1}
            placeholder={ar ? 'اكتب طلبك… زي: صحّيني ٧ الصبح، أو ضيف مذاكرة بكرة' : 'Ask me to do anything…'}
            className="input !py-2.5 !rounded-2xl resize-none max-h-32 min-h-[44px] flex-1 leading-relaxed"
            disabled={!enabled}
            aria-label={ar ? 'اكتب رسالتك' : 'Message'}
          />
          <button
            onClick={() => send()}
            disabled={!input.trim() || busy || !enabled}
            className="w-11 h-11 rounded-2xl grid place-items-center shrink-0 text-[var(--on-accent)] transition-transform active:scale-90 disabled:opacity-40"
            style={{ background: 'linear-gradient(160deg, var(--accent), var(--accent-deep))' }}
            aria-label={ar ? 'ابعت' : 'Send'}
          >
            <Send className={cn('w-5 h-5', ar && 'rotate-180')} />
          </button>
        </div>
        <p className="text-[0.55rem] text-3 mt-1.5 text-center">{ar ? 'المساعد بيكلّم المزوّد اللي اخترته بس، وبياناتك على جهازك. الأخطاء بتتعرض لك بوضوح.' : 'Only the selected provider receives your messages.'}</p>
      </div>

      {/* ===== Model picker ===== */}
      <ModelPicker open={modelOpen} onClose={() => setModelOpen(false)} cfg={cfg} onPicked={async (pid, model) => { await saveAIConfig({ providerId: pid, model, enabled: true }); setModelOpen(false); reloadAll(); toast(ar ? 'الموديل اتغيّر ✓' : 'Model changed ✓'); }} ar={ar} />

      {/* ===== Conversations ===== */}
      <Sheet open={convOpen} onClose={() => setConvOpen(false)} title={ar ? 'محادثاتك' : 'Your chats'}>
        <button className="btn btn-primary w-full justify-center mb-3" onClick={newConversation}><Plus className="w-4 h-4" />{ar ? 'محادثة جديدة' : 'New chat'}</button>
        <div className="space-y-1.5">
          {chats.map(c => (
            <div key={c.id} className={cn('card-flat p-3 flex items-center gap-2', active?.id === c.id && 'ring-2 ring-[var(--accent)]')}>
              <button className="flex-1 min-w-0 text-start" onClick={() => { setActive(c); setConvOpen(false); }}>
                <p className="font-bold text-sm truncate">{c.title}</p>
                <p className="text-[0.6rem] text-2 num">{new Date(c.updatedAt).toLocaleString(ar ? 'ar-EG' : 'en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} · {c.messages.length} {ar ? 'رسالة' : 'msgs'}</p>
              </button>
              <button className="icon-btn !w-8 !h-8 text-[var(--danger)]" aria-label="delete" onClick={async () => { await deleteChat(c.id); const list = await listChats(); setChats(list); if (active?.id === c.id) setActive(list[0] ?? null); }}><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
          {chats.length === 0 && <p className="text-sm text-2 text-center py-6">{ar ? 'لسه مفيش محادثات' : 'No chats yet'}</p>}
        </div>
      </Sheet>
      {cfg && <span className="hidden">{String(tick)}</span>}
    </div>
  );
}

/* ================= Welcome hero ================= */
function Welcome({ ar, suggestions, onPick, disabled }: { ar: boolean; suggestions: string[]; onPick: (t: string) => void; disabled: boolean }) {
  return (
    <div className="anim-screen">
      <div className="relative rounded-[1.8rem] overflow-hidden p-5 mb-4 border hairline" style={{ background: 'linear-gradient(150deg, var(--accent-soft), var(--surface) 70%)' }}>
        <div aria-hidden className="absolute -top-10 -end-10 w-40 h-40 rounded-full" style={{ background: 'radial-gradient(circle, var(--accent-soft), transparent 70%)' }} />
        <img src="/decor/robot.png" alt="" className="decor-float absolute top-3 end-3 w-16 h-16 object-contain" />
        <img src="/decor/sparkles.png" alt="" className="decor-twinkle absolute bottom-3 start-4 w-7 h-7" />
        <p className="text-[0.66rem] font-extrabold accent tracking-wider">DAYFLOW AGENT</p>
        <h2 className="text-[1.25rem] font-extrabold mt-1 leading-snug grad-text pe-14">{ar ? 'أنا مساعدك الذكي 👋' : 'Your smart agent 👋'}</h2>
        <p className="text-[0.78rem] text-2 mt-2 leading-[1.85] pe-10">
          {ar ? 'قولّي عايز إيه بالكلام العادي: أضبطلك منبه، أضيفلك نشاط أو مهمة، أكتبلك في يومياتك، أعرضلك المناسبات، أغيّر الثيم والزينة، أو أبدأ تركيز. وكل حاجة بتتنفذ فعلاً في التطبيق.' : 'Tell me what you want: alarms, activities, tasks, journal, occasions, themes… and I do it in the app.'}
        </p>
        <div className="flex flex-wrap gap-1.5 mt-3">
          {[ar ? 'منبهات' : 'Alarms', ar ? 'جدول' : 'Schedule', ar ? 'يوميات' : 'Journal', ar ? 'مناسبات' : 'Occasions', ar ? 'زينة' : 'Decor'].map(x => <span key={x} className="chip !text-[0.6rem]">{x}</span>)}
        </div>
      </div>
      <p className="text-[0.66rem] font-extrabold text-2 mb-2 flex items-center gap-1.5"><Wand2 className="w-3.5 h-3.5" />{ar ? 'جرّب تقول…' : 'Try saying…'}</p>
      <div className="grid grid-cols-1 gap-1.5">
        {suggestions.map(s => (
          <button key={s} disabled={disabled} onClick={() => onPick(s)} className="card-flat text-start px-3 py-2.5 text-[0.8rem] font-semibold hover:bg-[var(--surface-2)] transition-colors disabled:opacity-50 active:scale-[0.99]">{s}</button>
        ))}
      </div>
    </div>
  );
}

/* ================= Messages ================= */
function MessageView({ m, ar, provider, isLastAssistant, onRegenerate, onDelete, onConfirm, onCancel, confirmDeletes, navigate }: {
  m: ChatMessageRow; ar: boolean; provider?: { icon?: string; mono: string; color: string; name: string };
  isLastAssistant: boolean; onRegenerate: () => void; onDelete: () => void;
  onConfirm: (p: PendingAction) => void; onCancel: (p: PendingAction) => void; confirmDeletes: boolean; navigate: (n: string, p?: any) => void;
}) {
  const mine = m.role === 'user';
  const isErr = m.role === 'error';
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(m.content); setCopied(true); setTimeout(() => setCopied(false), 1400); } catch { /* ignore */ }
  };
  return (
    <div className={cn('flex gap-2 anim-pop', mine ? 'flex-row-reverse' : 'flex-row')}>
      {!mine && (
        <div className="shrink-0 mt-1">
          {isErr ? <span className="w-8 h-8 rounded-xl grid place-items-center bg-[var(--danger-soft)] text-[var(--danger)]"><XCircle className="w-4.5 h-4.5" /></span>
            : provider ? <BrandLogo icon={provider.icon} mono={provider.mono} color={provider.color} size={32} rounded="lg" label={provider.name} />
            : <span className="w-8 h-8 rounded-xl grid place-items-center bg-[var(--accent-soft)] accent"><Bot className="w-4.5 h-4.5" /></span>}
        </div>
      )}
      <div className={cn('min-w-0 max-w-[86%] flex flex-col', mine ? 'items-end' : 'items-start')}>
        <div
          className={cn('rounded-[1.3rem] px-3.5 py-2.5 text-[0.85rem] leading-[1.85] shadow-sm', mine ? 'rounded-ee-md text-[var(--on-accent)]' : isErr ? 'rounded-es-md border' : 'rounded-es-md border hairline')}
          style={mine ? { background: 'linear-gradient(160deg, var(--accent), var(--accent-deep))' } : isErr ? { background: 'var(--danger-soft)', borderColor: 'var(--danger)' } : { background: 'var(--surface)' }}
        >
          <Rich text={m.content} />
        </div>

        {/* actions executed */}
        {m.actions && m.actions.length > 0 && (
          <div className="mt-1.5 w-full space-y-1">
            {m.actions.map((a, i) => (
              <div key={i} className={cn('flex items-center gap-1.5 text-[0.68rem] font-bold rounded-xl px-2.5 py-1.5 border', a.ok ? 'text-[var(--ok)]' : 'text-[var(--danger)]')}
                style={{ background: a.ok ? 'var(--ok-soft)' : 'var(--danger-soft)', borderColor: 'transparent' }}>
                {a.ok ? <CheckCircle2 className="w-3.5 h-3.5 shrink-0" /> : <XCircle className="w-3.5 h-3.5 shrink-0" />}
                <span className="flex-1 min-w-0 leading-snug">{a.summary}</span>
              </div>
            ))}
          </div>
        )}

        {/* pending confirmations */}
        {m.pending && m.pending.map(p => (
          <div key={p.id} className="mt-2 w-full card-flat p-3 border" style={{ borderColor: 'var(--warn)' }}>
            <p className="text-[0.75rem] font-extrabold flex items-center gap-1.5"><AlertTriangle className="w-4 h-4 text-[var(--warn)]" />{ar ? 'محتاج تأكيدك' : 'Confirmation needed'}</p>
            <p className="text-[0.72rem] text-2 mt-1">{ar ? `هتمسح: ${p.label}. ده مش هيتراجع.` : `Delete: ${p.label}.`}</p>
            <div className="flex gap-2 mt-2">
              <button className="btn btn-danger btn-sm flex-1 justify-center" onClick={() => onConfirm(p)}><Check className="w-4 h-4" />{ar ? 'أكيد امسح' : 'Confirm'}</button>
              <button className="btn btn-ghost btn-sm flex-1 justify-center" onClick={() => onCancel(p)}><X className="w-4 h-4" />{ar ? 'لأ' : 'Cancel'}</button>
            </div>
            {!confirmDeletes && <p className="text-[0.55rem] text-3 mt-1">{ar ? 'تأكيد الحذف مقفول في الإعدادات — لكن الحذف دايماً بيحتاج ضغطة منك.' : ''}</p>}
          </div>
        ))}

        {/* live previews */}
        {m.cards && m.cards.map((c, i) => <div key={i} className="mt-2 w-full"><CardView card={c} ar={ar} navigate={navigate} /></div>)}

        {/* toolbar */}
        <div className="flex items-center gap-1 mt-1 px-1">
          {!mine && !isErr && <button className="icon-btn !w-7 !h-7" onClick={copy} aria-label="copy">{copied ? <Check className="w-3.5 h-3.5 text-[var(--ok)]" /> : <Copy className="w-3.5 h-3.5" />}</button>}
          {!mine && isLastAssistant && <button className="icon-btn !w-7 !h-7" onClick={onRegenerate} aria-label="regenerate"><RotateCcw className="w-3.5 h-3.5" /></button>}
          <button className="icon-btn !w-7 !h-7" onClick={onDelete} aria-label="remove"><X className="w-3.5 h-3.5" /></button>
          <span className="text-[0.55rem] text-3 num ms-1">{new Date(m.createdAt).toLocaleTimeString(ar ? 'ar-EG' : 'en-GB', { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
      </div>
    </div>
  );
}

function Rich({ text }: { text: string }) {
  const lines = text.split('\n');
  return (
    <div className="space-y-1">
      {lines.map((ln, i) => {
        if (!ln.trim()) return <div key={i} className="h-1" />;
        const bullet = /^\s*[-•*]\s+/.test(ln);
        const body = ln.replace(/^\s*[-•*]\s+/, '');
        const parts = body.split(/(\*\*[^*]+\*\*)/g);
        return (
          <p key={i} className={cn(bullet && 'ps-3 relative before:content-["•"] before:absolute before:start-0 before:opacity-60')}>
            {parts.map((p, j) => p.startsWith('**') && p.endsWith('**') ? <b key={j} className="font-extrabold">{p.slice(2, -2)}</b> : <span key={j}>{p}</span>)}
          </p>
        );
      })}
    </div>
  );
}

function TypingBubble({ ar, label, provider }: { ar: boolean; label: string; provider?: { icon?: string; mono: string; color: string } }) {
  return (
    <div className="flex gap-2 anim-pop">
      {provider ? <BrandLogo icon={provider.icon} mono={provider.mono} color={provider.color} size={32} rounded="lg" /> : null}
      <div className="rounded-[1.2rem] rounded-es-md px-4 py-3 border hairline flex items-center gap-2" style={{ background: 'var(--surface)' }}>
        <span className="flex gap-1">{[0, 1, 2].map(i => <span key={i} className="w-1.5 h-1.5 rounded-full bg-[var(--accent)] live-dot" style={{ animationDelay: `${i * 0.18}s` }} />)}</span>
        <span className="text-[0.7rem] text-2 font-bold">{label || (ar ? 'بفكّر…' : 'Thinking…')}</span>
      </div>
    </div>
  );
}

/* ================= Rich in-chat previews (real data) ================= */
function CardView({ card, ar, navigate }: { card: AssistantCard; ar: boolean; navigate: (n: string, p?: any) => void }) {
  const wrap = (title: string, children: ReactNode, action?: ReactNode) => (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between px-3.5 pt-3 pb-1.5">
        <p className="text-[0.72rem] font-extrabold flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5 accent" />{title}</p>
        {action}
      </div>
      <div className="px-3.5 pb-3">{children}</div>
    </div>
  );
  switch (card.type) {
    case 'occasions':
      return wrap(card.title, (
        <div className="space-y-2">
          {card.items.slice(0, 8).map((o, i) => (
            <div key={i} className="flex items-center gap-2.5 rounded-2xl overflow-hidden border hairline" style={{ background: 'var(--surface-2)' }}>
              <div className="relative w-16 h-16 shrink-0">
                <img src={o.image} alt="" className="absolute inset-0 w-full h-full object-cover" loading="lazy" />
                {o.decor && <img src={`/decor/${o.decor}.png`} alt="" className="absolute bottom-0 end-0 w-6 h-6" />}
              </div>
              <div className="flex-1 min-w-0 py-1.5 pe-2">
                <p className="text-[0.8rem] font-extrabold truncate">{o.name}</p>
                <p className="num text-[0.6rem] text-2">{o.date}</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {o.religion ? <span className="religion-badge"><i>!</i>{ar ? `الديانة: ${o.religion}` : o.religion}</span> : null}
                  <span className={cn('chip !py-0 !text-[0.55rem]', o.official ? '!text-[var(--ok)] !bg-[var(--ok-soft)] !border-transparent' : '')}>{o.official ? (ar ? 'إجازة رسمية ✓' : 'Official ✓') : (ar ? 'مش إجازة رسمية' : 'Not official')}</span>
                  {!o.notify && <span className="chip !py-0 !text-[0.52rem]">{ar ? 'بدون إشعار' : 'no alert'}</span>}
                </div>
              </div>
              <div className="pe-2"><HelpTip title={o.name}><p>{o.details}</p></HelpTip></div>
            </div>
          ))}
          {card.items.length === 0 && <p className="text-xs text-2">{ar ? 'مفيش مناسبات في الفترة دي' : 'None'}</p>}
        </div>
      ), <button className="chip !py-0.5 !text-[0.6rem]" onClick={() => navigate('calendar')}>{ar ? 'التقويم' : 'Calendar'}</button>);

    case 'schedule':
      return wrap(card.title, (
        <div className="space-y-1.5">
          {card.items.map((b, i) => (
            <div key={i} className="flex items-center gap-2 rounded-xl px-2.5 py-2" style={{ background: 'var(--surface-2)', borderInlineStart: '3px solid var(--accent)' }}>
              <span className="num text-[0.66rem] font-extrabold accent w-[5.2rem]" dir="ltr">{b.start}–{b.end}</span>
              <div className="flex-1 min-w-0">
                <p className={cn('text-[0.8rem] font-bold truncate', b.status === 'done' && 'line-through opacity-60')}>{b.title}</p>
                {b.note && <p className="text-[0.6rem] text-2 truncate">📝 {b.note}</p>}
              </div>
              {b.status === 'done' ? <CheckCircle2 className="w-4 h-4 text-[var(--ok)]" /> : b.fixed ? <span className="text-[0.55rem] font-bold text-2">📌</span> : null}
            </div>
          ))}
          {card.items.length === 0 && <p className="text-xs text-2">{ar ? 'اليوم ده فاضي' : 'Empty day'}</p>}
        </div>
      ), <button className="chip !py-0.5 !text-[0.6rem]" onClick={() => navigate('plan')}>{ar ? 'الخطة' : 'Plan'}</button>);

    case 'prayer':
      return wrap(card.title, (
        <div className="grid grid-cols-3 gap-1.5">
          {card.times.map(t => (
            <div key={t.name} className="rounded-xl px-2 py-2 text-center" style={{ background: 'var(--surface-2)' }}>
              <p className="text-[0.6rem] font-bold text-2">{t.label}</p>
              <p className="num text-[0.85rem] font-extrabold" dir="ltr">{t.time}</p>
            </div>
          ))}
        </div>
      ), <span className="text-[0.6rem] text-2 font-bold">{card.governorate}</span>);

    case 'alarms':
      return wrap(card.title, (
        <div className="space-y-1.5">
          {card.items.map((a, i) => (
            <div key={i} className="flex items-center gap-2.5 rounded-xl px-2.5 py-2" style={{ background: 'var(--surface-2)' }}>
              <span className="num text-lg font-extrabold" dir="ltr">{a.time}</span>
              <div className="flex-1 min-w-0"><p className="text-[0.75rem] font-bold truncate">{a.label}</p><p className="text-[0.58rem] text-2 truncate">{a.days}</p></div>
              <span className={cn('chip !py-0 !text-[0.55rem]', a.enabled ? '!text-[var(--ok)]' : '')}>{a.enabled ? (ar ? 'شغال' : 'On') : (ar ? 'مقفول' : 'Off')}</span>
            </div>
          ))}
          {card.items.length === 0 && <p className="text-xs text-2">{ar ? 'مفيش منبهات' : 'No alarms'}</p>}
        </div>
      ), <button className="chip !py-0.5 !text-[0.6rem]" onClick={() => navigate('alarms')}>{ar ? 'المنبهات' : 'Alarms'}</button>);

    case 'tasks':
      return wrap(card.title, (
        <div className="space-y-1.5">
          {card.items.map((t, i) => (
            <div key={i} className="flex items-center gap-2 py-1">
              <span className={cn('w-4 h-4 rounded-full border-2 grid place-items-center shrink-0', t.done ? 'bg-[var(--ok)] border-transparent' : 'border-[var(--border-strong)]')}>{t.done && <Check className="w-2.5 h-2.5 text-white" />}</span>
              <p className={cn('flex-1 text-[0.8rem] font-semibold truncate', t.done && 'line-through opacity-60')}>{t.title}</p>
              <span className="num text-[0.6rem] text-2">{t.due}</span>
            </div>
          ))}
          {card.items.length === 0 && <p className="text-xs text-2">{ar ? 'مفيش مهام' : 'No tasks'}</p>}
        </div>
      ), <button className="chip !py-0.5 !text-[0.6rem]" onClick={() => navigate('tasks')}>{ar ? 'المهام' : 'Tasks'}</button>);

    case 'journal':
      return wrap(card.title, (
        <div className="space-y-2">
          {card.items.map((e, i) => (
            <div key={i} className="rounded-xl px-3 py-2" style={{ background: 'var(--surface-2)' }}>
              <p className="text-[0.78rem] font-extrabold">{e.title} {e.mood ? <span className="text-[0.7rem]">{['', '😞', '😕', '😐', '🙂', '😄'][e.mood]}</span> : null}</p>
              <p className="text-[0.7rem] text-2 mt-0.5 line-clamp-3 leading-relaxed">{e.body}</p>
              <p className="num text-[0.55rem] text-3 mt-1">{e.date}</p>
            </div>
          ))}
        </div>
      ), <button className="chip !py-0.5 !text-[0.6rem]" onClick={() => navigate('journal')}>{ar ? 'يومياتي' : 'Journal'}</button>);

    case 'water': {
      const pct = card.target ? Math.min(100, Math.round((card.ml / card.target) * 100)) : 0;
      return wrap(ar ? 'المية النهارده' : 'Water today', (
        <div className="flex items-center gap-3">
          <ProgressRing size={68} stroke={7} progress={pct}><span className="num text-[0.7rem] font-extrabold">{pct}%</span></ProgressRing>
          <div className="flex-1"><p className="num text-lg font-extrabold">{card.ml} <span className="text-xs text-2">/ {card.target} ml</span></p><LinearProgress value={pct} tone="var(--cat-water)" className="mt-1.5" /></div>
        </div>
      ));
    }

    case 'decor': {
      const sc = card.scene === 'auto' ? sceneFor(new Date(), 0, 'auto') : (SCENES[card.scene] ?? sceneFor(new Date(), 0, 'auto'));
      return (
        <div className="relative rounded-2xl overflow-hidden h-40 text-white">
          <img src={sc.photos[0]} alt="" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, ${sc.tint}, rgba(0,0,0,.72))` }} />
          <div className="absolute top-2 inset-x-2 flex justify-around">{sc.hang.slice(0, 6).map((h, i) => <img key={i} src={h} alt="" className="decor-twinkle w-6 h-6 object-contain" />)}</div>
          {sc.corner && <img src={sc.corner} alt="" className="decor-float absolute bottom-2 end-2 w-14 h-14 object-contain" />}
          <div className="absolute bottom-2.5 start-3 end-20">
            <p className="font-extrabold text-sm">{ar ? sc.ar : sc.en}</p>
            <p className="text-[0.66rem] text-white/85">{ar ? sc.greetingAr : sc.greetingEn}</p>
          </div>
        </div>
      );
    }

    case 'summary':
      return wrap(card.title, (
        <ul className="space-y-1.5">
          {card.lines.map((l, i) => <li key={i} className="text-[0.78rem] leading-relaxed flex gap-2"><Zap className="w-3.5 h-3.5 accent shrink-0 mt-1" /><span>{l}</span></li>)}
        </ul>
      ));
    default:
      return null;
  }
}

/* ================= Model picker: brands, logos, real free/credit/paid sorting ================= */
function TierBadge({ tier, ar, inline }: { tier: Tier; ar: boolean; inline?: boolean }) {
  const t = TIER_LABEL[tier];
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full font-extrabold', inline ? 'text-[0.55rem] px-1.5 py-0 ms-1' : 'text-[0.6rem] px-2 py-0.5')} style={{ color: t.color, background: `color-mix(in srgb, ${t.color} 14%, transparent)` }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: t.color }} />{ar ? t.ar : t.en}
    </span>
  );
}

function ModelPicker({ open, onClose, cfg, onPicked, ar }: { open: boolean; onClose: () => void; cfg: AIConfig | null; onPicked: (pid: string, model: string) => void; ar: boolean }) {
  const [q, setQ] = useState('');
  const [tab, setTab] = useState<'all' | Tier>('all');
  const [onlyKeyed, setOnlyKeyed] = useState(false);
  const [testingModel, setTestingModel] = useState<string | null>(null);
  const { toast } = useApp();

  const groups = useMemo(() => {
    if (!cfg) return [];
    return PROVIDERS.map(p => {
      const list = modelsFor(p.id, cfg).filter(m => tab === 'all' || m.tier === tab).filter(m => !q.trim() || (m.name + ' ' + m.id).toLowerCase().includes(q.trim().toLowerCase()));
      return { p, list, keyed: !!cfg.keys[p.id] };
    })
      .filter(g => g.list.length > 0)
      .filter(g => !onlyKeyed || g.keyed)
      .sort((a, b) => {
        const rank = { free: 0, credit: 1, paid: 2 } as const;
        return rank[a.p.tier] - rank[b.p.tier] || Number(b.keyed) - Number(a.keyed);
      });
  }, [cfg, q, tab, onlyKeyed]);

  const freeCount = cfg ? PROVIDERS.reduce((n, p) => n + modelsFor(p.id, cfg).filter(m => m.tier === 'free').length, 0) : 0;
  const testOne = async (pid: string, id: string) => {
    if (!cfg?.keys[pid]) { toast(ar ? 'ضيف المفتاح الأول' : 'Add key first'); return; }
    setTestingModel(id);
    const r = await verifyModel(pid, id, cfg.keys[pid]);
    const cur = await getAIConfig();
    const list: CatalogEntry[] = cur.catalog.byProvider[pid] ?? [];
    const entry = list.find(m => m.id === id);
    if (!entry) {
      const p = PROVIDERS.find(x => x.id === pid)!;
      const hint = p.models.find(m => m.id === id);
      if (hint) await saveAIConfig({ catalog: { ...cur.catalog, byProvider: { ...cur.catalog.byProvider, [pid]: [{ ...hint, verification: r.ok ? 'working' : 'broken', error: r.error, checkedAt: Date.now(), source: 'live' }] } } });
    } else await markVerification(pid, id, r.ok, r.error);
    setTestingModel(null);
    toast(r.ok ? (ar ? 'الموديل شغال فعلاً ✓' : 'Model works ✓') : (ar ? `مش شغال: ${r.error}` : `Broken: ${r.error}`));
  };

  return (
    <Sheet open={open} onClose={onClose} title={ar ? 'اختار الموديل' : 'Choose a model'}>
      <div className="flex items-center gap-2 mb-2">
        <div className="relative flex-1"><Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-3" /><input className="input ps-9 !py-2" value={q} onChange={e => setQ(e.target.value)} placeholder={ar ? 'دوّر على موديل أو مزوّد…' : 'Search…'} /></div>
      </div>
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar mb-2">
        {([['all', ar ? 'الكل' : 'All'], ['free', ar ? `مجاني (${freeCount})` : `Free (${freeCount})`], ['credit', ar ? 'رصيد مجاني' : 'Credit'], ['paid', ar ? 'مدفوع' : 'Paid']] as const).map(([v, l]) => (
          <button key={v} className={cn('chip flex-none', tab === v && 'chip-active')} onClick={() => setTab(v)}>{l}</button>
        ))}
        <button className={cn('chip flex-none', onlyKeyed && 'chip-active')} onClick={() => setOnlyKeyed(x => !x)}><Check className="w-3 h-3" />{ar ? 'اللي عندي مفتاح' : 'Keyed only'}</button>
      </div>
      <div className="space-y-3 max-h-[62vh] overflow-y-auto no-scrollbar pb-2">
        {groups.map(({ p, list, keyed }) => (
          <div key={p.id} className="card-flat p-2.5">
            <div className="flex items-center gap-2.5 px-1 pb-2">
              <BrandLogo icon={p.icon} mono={p.mono} color={p.color} size={36} rounded="lg" />
              <div className="flex-1 min-w-0">
                <p className="font-extrabold text-[0.85rem] flex items-center gap-1.5">{p.name} <TierBadge tier={p.tier} ar={ar} inline /></p>
                <p className="text-[0.6rem] text-2 leading-snug">{p.freeSummary}</p>
                <p className={cn('text-[0.55rem] font-bold mt-0.5', cfg && catalogIsLive(p.id, cfg) ? 'text-[var(--ok)]' : 'text-[var(--warn)]')}>{cfg && catalogIsLive(p.id, cfg) ? (ar ? '● قائمة حية من الـ API' : '● Live API catalogue') : (ar ? '● قايمة مقترحة غير مؤكدة — اضغط «اختبر» للتأكد' : '● Unverified hints — press Test')}</p>
              </div>
              {keyed ? <span className="chip !py-0 !text-[0.55rem] !text-[var(--ok)] !bg-[var(--ok-soft)] !border-transparent">{ar ? 'مفتاح ✓' : 'key ✓'}</span> : <span className="chip !py-0 !text-[0.55rem]">{ar ? 'مفيش مفتاح' : 'no key'}</span>}
            </div>
            <div className="space-y-1">
              {list.map(m => {
                const selected = cfg?.providerId === p.id && cfg?.model === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => { if (!keyed) { toast(ar ? `ضيف مفتاح ${p.name} من الإعدادات الأول` : `Add ${p.name} key first`); return; } onPicked(p.id, m.id); }}
                    className={cn('w-full flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-start transition-colors', selected ? 'bg-[var(--accent-soft)] ring-1 ring-[var(--accent)]' : 'hover:bg-[var(--surface-2)]', !keyed && 'opacity-60')}
                    aria-pressed={selected}
                  >
                    <FamilyLogo family={m.family} size={30} />
                    <span className="flex-1 min-w-0">
                      <span className="block text-[0.82rem] font-bold truncate">{m.name}</span>
                      <span className="block text-[0.55rem] text-3 num truncate" dir="ltr">{m.id}</span>
                    </span>
                    <span className="flex flex-col items-end gap-1 shrink-0">
                      <TierBadge tier={m.tier} ar={ar} />
                      <span className="flex gap-1">
                        {m.context && <span className="chip !py-0 !text-[0.5rem] num">{m.context}</span>}
                        {m.tools && <span className="chip !py-0 !text-[0.5rem]">{ar ? 'أدوات ✓' : 'tools ✓'}</span>}
                        {(m as CatalogEntry).verification === 'working' && <CheckCircle2 className="w-3.5 h-3.5 text-[var(--ok)]" />}
                      </span>
                    </span>
                    <button className="chip !py-0.5 !text-[0.52rem] shrink-0" onClick={e => { e.stopPropagation(); testOne(p.id, m.id); }} disabled={testingModel === m.id || !keyed} title={ar ? 'اختبر الموديل بطلب حقيقي' : 'Real test request'}>
                      {testingModel === m.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}{ar ? 'اختبر' : 'Test'}
                    </button>
                    {selected && <Check className="w-4 h-4 accent shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
        {groups.length === 0 && <EmptyState icon={<Search className="w-6 h-6" />} title={ar ? 'مفيش موديلات مطابقة' : 'No models'} />}
      </div>
      <p className="text-[0.56rem] text-3 mt-2 leading-relaxed">{ar ? 'المجاني = مفيش دفع أبداً. رصيد مجاني = رصيد ترحيبي أو شهري. مدفوع = بيتحاسب على الاستخدام. الموديلات بتتصنّف من بيانات المزوّد نفسه.' : 'Free = never paid. Credit = trial/monthly credit. Paid = billed per use.'}</p>
    </Sheet>
  );
}
