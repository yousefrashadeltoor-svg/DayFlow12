/* DAYFLOW — Decoration Gallery: a dedicated full page like the Themes page.
   · Every decoration shows a REAL miniature Home screen with that decoration active.
   · Up to 3 simultaneous decorations; a 4th attempt shows an honest performance warning.
   · Any single decoration can be previewed alone in a large sheet.
   · Auto mode always follows the real season / occasion / date. */
import { useMemo, useState } from 'react';
import {
  Sparkles, AlertTriangle, X, Eye, Zap, Gauge, Layers, Clock3, CalendarDays, RotateCcw,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { Sheet, HelpTip, Segmented, Toggle, LinearProgress } from '@/components/ui';
import DecorPreview from '@/components/DecorPreview';
import { SCENES, sceneFor } from '@/components/Seasonal';
import { cn } from '@/utils/cn';

const MAX_MIX = 3;

export default function DecorGallery() {
  const { lang, settings, saveSettings, toast, bump } = useApp();
  const ar = lang === 'ar';
  const [preview, setPreview] = useState<string | 'auto' | null>(null);
  const [exceeded, setExceeded] = useState(false);

  const mix: string[] = Array.isArray(settings.decorMix) ? settings.decorMix.slice(0, MAX_MIX) : [];
  const autoScene = useMemo(() => sceneFor(new Date(), settings.hijriOffset, 'auto'), [settings.hijriOffset]);
  const activeIds = useMemo(() => {
    if (settings.decorOverride !== 'auto' && SCENES[settings.decorOverride]) return [settings.decorOverride];
    if (mix.length) return mix;
    return [autoScene.id];
  }, [settings.decorOverride, mix, autoScene.id]);

  const isActive = (id: string | 'auto') => {
    if (id === 'auto') return settings.decorOverride === 'auto' && mix.length === 0;
    return activeIds.includes(id);
  };

  const toggleMix = async (id: string) => {
    const current = [...mix];
    const idx = current.indexOf(id);
    if (idx >= 0) {
      current.splice(idx, 1);
      await saveSettings({ decorMix: current });
      bump();
      return;
    }
    if (current.length >= MAX_MIX) { setExceeded(true); return; }
    current.push(id);
    await saveSettings({ decorMix: current, decorOverride: 'auto' });
    bump();
    toast(ar ? `اتضافت ${SCENES[id]?.ar} — ${current.length} من ${MAX_MIX} زينة شغالة مع بعض` : `${current.length}/${MAX_MIX} decorations`);
  };

  const previewScene = preview && preview !== 'auto' ? SCENES[preview] : preview === 'auto' ? sceneFor(new Date(), settings.hijriOffset, settings.decorOverride) : null;
  const scenes = Object.values(SCENES);

  return (
    <div className="pb-8 px-4 pt-14">
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <h1 className="skin-title font-extrabold grad-text flex items-center gap-2">
            <img src="/decor/sparkles.png" alt="" className="w-8 h-8 decor-float" />
            {ar ? 'معرض الزينة والتأثيرات' : 'Decoration gallery'}
          </h1>
          <p className="text-[0.7rem] text-2 mt-0.5">{ar ? `${scenes.length} زينة جاهزة أوفلاين · كل واحدة بمعاينة الشاشة الرئيسية` : `${scenes.length} offline scenes`}</p>
        </div>
        <HelpTip title={ar ? 'إزاي المعرض ده شغال؟' : 'How the gallery works'}>
          <p>كل كارت قدامك هو <b>صورة حقيقية لشاشة رئيسية مصغّرة والزينة مفعّلة فيها فعلاً</b> — مش مجرد صورة للموسم.</p>
          <ul>
            <li>دوس على الكارت = ضيف الزينة للمجموعة الشغالة (لحد <b>3</b> مع بعض).</li>
            <li>دوس على زر العين 👁 = اعمل <b>معاينة كبيرة لوحدها</b> من غير ما تفعّلها.</li>
            <li>لو حاولت تضيف رابع هيظهرلك تحذير صريح إن التطبيق هيبقى تقيل على المعالج.</li>
            <li>«تلقائي» = التطبيق يبدّل لوحده مع كل موسم أو مناسبة أو تاريخ، من غير أي تدخل منك.</li>
          </ul>
        </HelpTip>
      </div>

      {/* Active strip */}
      <div className="card p-3 mt-3">
        <div className="flex items-center justify-between gap-2">
          <p className="text-[0.76rem] font-extrabold flex items-center gap-1.5"><Sparkles className="w-4 h-4 accent" />{ar ? 'الزينة الشغالة دلوقتي' : 'Active now'}</p>
          <span className="chip num">{mix.length}/{MAX_MIX}</span>
        </div>
        <div className="flex flex-wrap gap-1.5 mt-2">
          {activeIds.map(id => (
            <span key={id} className="chip chip-active !text-[0.62rem]">{SCENES[id]?.ar ?? id}</span>
          ))}
          {settings.decorOverride === 'auto' && mix.length === 0 && (
            <span className="chip !text-[0.62rem]"><CalendarDays className="w-3 h-3" />{ar ? `تلقائي ← ${autoScene.ar}` : `Auto → ${autoScene.en}`}</span>
          )}
        </div>
        {mix.length > 0 && (
          <button className="btn btn-ghost btn-sm mt-2" onClick={async () => { await saveSettings({ decorMix: [], decorOverride: 'auto' }); bump(); toast(ar ? 'رجع للتفعيل التلقائي حسب التاريخ ✨' : 'Back to auto'); }}>
            <RotateCcw className="w-4 h-4" />{ar ? 'رجّع التلقائي' : 'Reset to auto'}
          </button>
        )}
        <div className="mt-2"><LinearProgress value={(mix.length / MAX_MIX) * 100} tone={mix.length >= MAX_MIX ? 'var(--warn)' : 'var(--accent)'} /></div>
      </div>

      {/* Controls */}
      <div className="card px-4 py-2 mt-3">
        <div className="flex items-center justify-between gap-2 py-2 border-b hairline">
          <span className="text-[0.78rem] font-bold flex items-center gap-1.5"><Layers className="w-4 h-4 text-2" />{ar ? 'موضع الزينة' : 'Layer'}</span>
          <Segmented size="sm" value={settings.decorLayer} onChange={v => saveSettings({ decorLayer: v as any })}
            options={[{ value: 'below', label: ar ? 'خلف المحتوى' : 'Behind' }, { value: 'above', label: ar ? 'فوق المحتوى' : 'Above' }]} />
        </div>
        <div className="flex items-center justify-between gap-2 py-2 border-b hairline">
          <span className="text-[0.78rem] font-bold flex items-center gap-1.5"><Gauge className="w-4 h-4 text-2" />{ar ? 'السرعة' : 'Speed'}</span>
          <Segmented size="sm" value={settings.decorSpeed} onChange={v => saveSettings({ decorSpeed: v as any })}
            options={[{ value: 'slow', label: ar ? 'بطيء' : 'Slow' }, { value: 'normal', label: ar ? 'عادي' : 'Normal' }, { value: 'fast', label: ar ? 'سريع' : 'Fast' }]} />
        </div>
        <div className="flex items-center justify-between gap-2 py-2 border-b hairline">
          <span className="text-[0.78rem] font-bold flex items-center gap-1.5"><Zap className="w-4 h-4 text-2" />{ar ? 'الكثافة' : 'Density'}</span>
          <Segmented size="sm" value={settings.decorDensity} onChange={v => saveSettings({ decorDensity: v as any })}
            options={[{ value: 'light', label: ar ? 'خفيفة' : 'Light' }, { value: 'normal', label: ar ? 'متوازنة' : 'Normal' }, { value: 'dense', label: ar ? 'كثيفة' : 'Dense' }]} />
        </div>
        <div className="flex items-center justify-between gap-2 py-2 border-b hairline">
          <span className="text-[0.78rem] font-bold flex items-center gap-1.5"><Eye className="w-4 h-4 text-2" />{ar ? 'الشفافية' : 'Opacity'} <span className="num text-[0.62rem] text-2">{Math.round((settings.decorOpacity ?? 0.9) * 100)}%</span></span>
          <input type="range" min={0.15} max={1} step={0.05} value={settings.decorOpacity ?? 0.9} onChange={e => saveSettings({ decorOpacity: Number(e.target.value) })} className="w-28 accent-[var(--accent)]" dir="ltr" />
        </div>
        <div className="flex items-center justify-between gap-2 py-2">
          <span className="text-[0.78rem] font-bold flex items-center gap-1.5"><Clock3 className="w-4 h-4 text-2" />{ar ? 'العناصر المتحركة' : 'Motion'}</span>
          <Toggle on={settings.particles} onChange={v => saveSettings({ particles: v })} />
        </div>
      </div>

      {/* Grid */}
      <p className="label mt-4 mb-2 flex items-center gap-1.5">{ar ? 'كل الزينة — دوس على أي واحدة تضيفها، أو 👁 للمعاينة' : 'All scenes — tap to combine, 👁 to preview'}</p>
      <div className="grid grid-cols-2 gap-3">
        {/* Auto card */}
        <button
          onClick={async () => { await saveSettings({ decorMix: [], decorOverride: 'auto' }); bump(); toast(ar ? 'تم ✓ التبديل التلقائي حسب التاريخ شغال' : 'Auto by date enabled'); }}
          className={`decor-gallery-card card p-2 text-start transition-all ${isActive('auto') ? 'ring-2 ring-[var(--accent)]' : ''}`}
        >
          <div className="relative">
            <DecorPreview scene={autoScene} selected={isActive('auto')} active layer={settings.decorLayer} />
          </div>
          <div className="flex items-center justify-between gap-1 mt-2">
            <p className="font-extrabold text-[0.78rem] truncate">{ar ? 'تلقائي (حسب التاريخ)' : 'Auto (by date)'}</p>
            {isActive('auto') && <span className="chip !py-0 !text-[0.52rem] !text-[var(--ok)]">✓</span>}
          </div>
          <p className="text-[0.58rem] text-2 leading-snug mt-0.5">{ar ? 'رمضان والعيد والخريف والشتا والامتحانات… كل واحدة تيجي في وقتها' : 'Seasons & occasions switch automatically'}</p>
        </button>

        {scenes.map(sc => {
          const picked = mix.includes(sc.id);
          return (
            <div key={sc.id} className={cn('decor-gallery-card card p-2 transition-all', picked && 'ring-2 ring-[var(--accent)]')}>
              <button className="w-full text-start relative" onClick={() => toggleMix(sc.id)} aria-pressed={picked}>
                <DecorPreview scene={sc} selected={picked} active={isActive(sc.id)} layer={settings.decorLayer} speed={settings.decorSpeed} intensity={settings.decorDensity === 'light' ? 0.55 : settings.decorDensity === 'dense' ? 1.5 : 1} />
              </button>
              <div className="flex items-center justify-between gap-1 mt-2">
                <p className="font-extrabold text-[0.78rem] truncate flex-1">{ar ? sc.ar : sc.en}</p>
                <button className="icon-btn !w-7 !h-7" onClick={() => setPreview(sc.id)} aria-label={ar ? 'معاينة' : 'Preview'} title={ar ? 'معاينة لوحدها' : 'Preview alone'}><Eye className="w-4 h-4" /></button>
              </div>
              <p className="text-[0.58rem] text-2 leading-snug line-clamp-2 mt-0.5">{ar ? sc.greetingAr : sc.greetingEn}</p>
              <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                <span className="chip !py-0 !text-[0.5rem] num">{sc.particles.length} {ar ? 'أشكال' : 'shapes'}</span>
                <span className="chip !py-0 !text-[0.5rem] num">{sc.hang.length} {ar ? 'معلّقة' : 'hanging'}</span>
              </div>
            </div>
          );
        })}
      </div>

      <p className="text-[0.6rem] text-3 mt-4 leading-relaxed text-center">{ar ? 'كل الزينة والصور محفوظة جوه التطبيق — أوفلاين 100%، ومفيش أي تحميل من الإنترنت.' : 'All assets bundled offline.'}</p>

      {/* Single scene preview */}
      <Sheet open={!!previewScene} onClose={() => setPreview(null)} title={previewScene ? (ar ? `معاينة: ${previewScene.ar}` : `Preview: ${previewScene.en}`) : ''}
        actions={previewScene ? <button className="btn btn-primary btn-sm" onClick={() => { toggleMix(previewScene.id); setPreview(null); }}>{mix.includes(previewScene.id) ? (ar ? 'شيلها' : 'Remove') : (ar ? 'فعّلها' : 'Activate')}</button> : undefined}>
        {previewScene && (
          <div className="flex flex-col items-center">
            <div className="w-[70%] max-w-[15rem]"><DecorPreview scene={previewScene} large active speed={settings.decorSpeed} layer={settings.decorLayer} intensity={settings.decorDensity === 'light' ? 0.55 : settings.decorDensity === 'dense' ? 1.5 : 1} /></div>
            <h3 className="font-extrabold text-lg mt-4">{ar ? previewScene.ar : previewScene.en}</h3>
            <p className="text-sm text-2 text-center mt-1 leading-relaxed">{ar ? previewScene.greetingAr : previewScene.greetingEn}</p>
            <div className="grid grid-cols-3 gap-2 w-full mt-4">
              <div className="card-inset p-2 text-center"><p className="num text-base font-extrabold">{previewScene.photos.length}</p><p className="text-[0.55rem] font-bold text-2">{ar ? 'صور حقيقية' : 'Photos'}</p></div>
              <div className="card-inset p-2 text-center"><p className="num text-base font-extrabold">{previewScene.particles.length}</p><p className="text-[0.55rem] font-bold text-2">{ar ? 'زخارف 3D' : '3D shapes'}</p></div>
              <div className="card-inset p-2 text-center"><p className="num text-base font-extrabold">{previewScene.hang.length}</p><p className="text-[0.55rem] font-bold text-2">{ar ? 'زينة معلّقة' : 'Hanging'}</p></div>
            </div>
            <div className="flex flex-wrap gap-1.5 justify-center mt-3">
              {[...new Set([...previewScene.particles, ...previewScene.hang, previewScene.corner, previewScene.corner2, previewScene.corner3].filter(Boolean))].slice(0, 12).map((src, i) => (
                <img key={i} src={src as string} alt="" className="w-9 h-9 object-contain decor-float" style={{ animationDelay: `${i * 0.15}s` }} />
              ))}
            </div>
          </div>
        )}
      </Sheet>

      {/* Honest performance warning on the 4th selection */}
      <Sheet open={exceeded} onClose={() => setExceeded(false)} title={ar ? '⚠️ الزينة كتير شوية' : '⚠️ Too many effects'}>
        <div className="text-start">
          <div className="w-14 h-14 rounded-2xl grid place-items-center mx-auto mb-3" style={{ background: 'var(--warn-soft)', color: 'var(--warn)' }}><AlertTriangle className="w-7 h-7" /></div>
          <p className="font-extrabold text-center">{ar ? 'اختارت 3 زينة بالفعل — ده الحد الآمن' : '3 decorations is the safe limit'}</p>
          <p className="text-[0.82rem] text-2 leading-[1.9] mt-3">{ar ? 'لو زوّدت أكتر من 3 زينة مع بعض، التطبيق هيحتاج يرسم عشرات الصور المتحركة في نفس الوقت، وده ممكن يجهد المعالج ويخلّي التنقل أبطأ خصوصاً على الموبايلات المتوسطة والقديمة، وكمان بيستهلك بطارية أكتر.' : 'More than 3 simultaneous effects means dozens of animated images at once; it can strain the CPU and slow navigation on mid-range phones.'}</p>
          <p className="text-[0.75rem] font-bold accent mt-2">{ar ? 'الحل: شيل واحدة من التلاتة الأول، وبعدين ضيف اللي عايزها.' : 'Remove one first, then add the one you want.'}</p>
          <div className="flex gap-2 mt-4">
            <button className="btn btn-ghost flex-1 justify-center" onClick={() => setExceeded(false)}><X className="w-4 h-4" />{ar ? 'تمام، فهمت' : 'Got it'}</button>
            <button className="btn btn-primary flex-1 justify-center" onClick={async () => { await saveSettings({ decorMix: [], decorOverride: 'auto' }); bump(); setExceeded(false); toast(ar ? 'اتصفّرت — التلقائي شغال' : 'Reset'); }}><RotateCcw className="w-4 h-4" />{ar ? 'صفّر الكل' : 'Reset all'}</button>
          </div>
        </div>
      </Sheet>
    </div>
  );
}
