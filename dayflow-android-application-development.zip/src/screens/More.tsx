/* DAYFLOW — More hub */
import { useEffect, useState } from 'react';
import {
  ListTodo, GraduationCap, Dumbbell, Flame, Target, StickyNote, Bell, Settings, Search,
  ChevronLeft, Database, Info, ShieldCheck, Command, BookOpenCheck, BedDouble,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db } from '@/lib/db';

export default function More() {
  const { t, lang, navigate } = useApp();
  const [storage, setStorage] = useState<{ tables: number; rows: number; backend: string } | null>(null);
  useEffect(() => { db.storageInfo().then(setStorage).catch(() => setStorage(null)); }, []);

  const items = [
    { icon: Command, labelAr: 'معرض الزينة', labelEn: 'Decoration gallery', descAr: '١٥ زينة بمعاينة حية ودمج ٣ مع بعض', descEn: '15 live previews, mix 3', go: 'decorGallery' as const, tone: '#d97706', img: '/decor/sparkles.png' },
    { icon: Command, labelAr: 'المساعد الذكي', labelEn: 'AI assistant', descAr: 'اطلب أي حاجة وأنا أنفذها في التطبيق', descEn: 'Ask anything, it runs in the app', go: 'assistant' as const, tone: '#7c3aed', img: '/decor/robot.png' },
    { icon: Command, labelAr: 'التقويم والمناسبات', labelEn: 'Calendar', descAr: 'مناسبات مصر بالصور + مناسباتك', descEn: 'Occasions & events', go: 'calendar' as const, tone: '#2563eb', img: '/decor/calendar-spiral.png' },
    { icon: Command, labelAr: 'مواقيت الصلاة', labelEn: 'Prayer times', descAr: 'كل المحافظات + منبه الأذان', descEn: 'All governorates + adhan', go: 'prayer' as const, tone: '#0da271', img: '/decor/mosque.png' },
    { icon: Command, labelAr: 'المنبهات', labelEn: 'Alarms', descAr: 'صحّي على أغنيتك المفضلة', descEn: 'Wake to your song', go: 'alarms' as const, tone: '#0e8a94', img: '/decor/alarm.png' },
    { icon: Command, labelAr: 'يومياتي', labelEn: 'Journal', descAr: 'مود، امتنان، وملخص يومك', descEn: 'Mood, gratitude, summary', go: 'journal' as const, tone: '#a16207', img: '/decor/notebook.png' },
    { icon: Command, labelAr: 'التركيز', labelEn: 'Focus', descAr: 'بومودورو وتتبع التشتت', descEn: 'Pomodoro & distractions', go: 'focus' as const, tone: '#7c3aed', img: '/decor/target.png' },
    { icon: Command, labelAr: 'التقدم والإحصائيات', labelEn: 'Progress', descAr: 'رسوم بيانية من سجلك الحقيقي', descEn: 'Real analytics', go: 'progress' as const, tone: '#e0356a', img: '/decor/rocket.png' },
    { icon: ListTodo, labelAr: 'المهام والمشاريع', labelEn: 'Tasks & projects', descAr: 'وارد · أولويات · قوائم · مشاريع', descEn: 'Inbox · priorities · lists · projects', go: 'tasks' as const, tone: 'var(--cat-work)' },
    { icon: GraduationCap, labelAr: 'الدراسة', labelEn: 'Study', descAr: 'مواد · دروس · بطاقات · اختبارات', descEn: 'Subjects · lessons · flashcards · exams', go: 'study' as const, tone: 'var(--cat-study)' },
    { icon: Dumbbell, labelAr: 'التمارين', labelEn: 'Workouts', descAr: 'خطة أسبوعية · تنفيذ · سجل', descEn: 'Weekly plan · execution · history', go: 'workouts' as const, tone: 'var(--cat-exercise)' },
    { icon: Flame, labelAr: 'العادات', labelEn: 'Habits', descAr: 'سلاسل · خريطة حرارية · التزام', descEn: 'Streaks · heatmap · consistency', go: 'habits' as const, tone: 'var(--warn)' },
    { icon: BedDouble, labelAr: 'النوم والماء والوجبات', labelEn: 'Sleep, water & meals', descAr: 'أهدافك اليومية تحت سيطرتك', descEn: 'Your daily targets, your control', go: 'habits' as const, tone: 'var(--cat-sleep)', params: { tab: 'sleep' } },
    { icon: Target, labelAr: 'الأهداف', labelEn: 'Goals', descAr: 'قصيرة · شهرية · طويلة المدى + معالم', descEn: 'Short · monthly · long-term + milestones', go: 'goals' as const, tone: 'var(--accent)' },
    { icon: StickyNote, labelAr: 'الملاحظات', labelEn: 'Notes', descAr: 'ملاحظات · يوميات · قوائم تحقق', descEn: 'Notes · journals · checklists', go: 'notes' as const, tone: 'var(--cat-meal)' },
    { icon: Bell, labelAr: 'مركز الإشعارات', labelEn: 'Notification center', descAr: 'القادمة · المكتملة · الفائتة', descEn: 'Upcoming · done · missed', go: 'notifications' as const, tone: 'var(--info)' },
    { icon: BookOpenCheck, labelAr: 'التقرير الأسبوعي', labelEn: 'Weekly report', descAr: 'أرقامك الحقيقية من سجلك', descEn: 'Your real numbers, weekly', go: 'progress' as const, tone: 'var(--cat-rest)' },
    { icon: Settings, labelAr: 'الإعدادات', labelEn: 'Settings', descAr: 'المظهر · اللغة · الإشعارات · القواعد · النسخ الاحتياطي', descEn: 'Appearance · language · alarms · rules · backup', go: 'settings' as const, tone: 'var(--text-2)' },
  ];

  return (
    <div className="pb-6 px-4 pt-5">
      <div className="flex items-center justify-between">
        <h1 className="skin-title font-extrabold">{t('more')}</h1>
        <button className="btn btn-soft btn-sm" onClick={() => navigate('search')}><Search className="w-4 h-4" />{t('search')}</button>
      </div>

      {/* command palette hint */}
      <button className="card w-full mt-3 px-4 py-3 flex items-center gap-3 text-start hover:bg-[var(--surface-2)] transition-colors" onClick={() => navigate('search')} aria-label={t('search')}>
        <Command className="w-5 h-5 accent shrink-0" />
        <span className="flex-1 text-sm text-2">{lang === 'ar' ? 'ابحث في كل شيء أو نفّذ أمراً…' : 'Search everything or run a command…'}</span>
        <kbd className="text-[0.62rem] font-bold text-3 border hairline rounded-md px-1.5 py-0.5" dir="ltr">Ctrl K</kbd>
      </button>

      <div className="grid grid-cols-2 gap-2.5 mt-3">
        {items.map((item, i) => (
          <button key={i} onClick={() => navigate(item.go, item.params)}
            className="card p-3 flex flex-col items-start gap-2 text-start hover:shadow-md transition-shadow active:scale-[0.98]">
            <span className="w-11 h-11 rounded-xl grid place-items-center" style={{ background: `color-mix(in srgb, ${item.tone} 15%, transparent)`, color: item.tone }}>
              {(item as any).img ? <img src={(item as any).img} alt="" className="w-8 h-8 decor-float" /> : <item.icon className="w-5.5 h-5.5" strokeWidth={1.7} />}
            </span>
            <span className="text-[0.8rem] font-extrabold leading-tight">{lang === 'ar' ? item.labelAr : item.labelEn}</span>
            <span className="text-[0.58rem] text-2 leading-snug">{lang === 'ar' ? item.descAr : item.descEn}</span>
          </button>
        ))}
      </div>

      {/* trust & storage footer */}
      <div className="card-flat mt-4 p-4 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-[var(--ok)] shrink-0 mt-0.5" />
        <div className="text-[0.68rem] text-2 leading-relaxed">
          <p className="font-extrabold text-[var(--text)] text-[0.72rem]">{lang === 'ar' ? 'بياناتك ملكك على موبايلك بس — أوفلاين 100%' : 'Your data stays on your device'}</p>
          <p className="mt-0.5">{lang === 'ar' ? 'مفيش حساب ولا تتبع ولا إعلانات ولا حتى صلاحية إنترنت — كله محفوظ محلياً على جهازك.' : 'No account, no tracking, no forced cloud. Works offline.'}</p>
          {storage && (
            <p className="mt-1.5 flex items-center gap-1 num text-[0.62rem] text-3"><Database className="w-3.5 h-3.5" />{storage.backend} · {storage.rows} {lang === 'ar' ? 'سجل' : 'records'} · {storage.tables} {lang === 'ar' ? 'جدول' : 'tables'}</p>
          )}
        </div>
      </div>

      <button className="w-full flex items-center justify-center gap-2 mt-4 text-[0.62rem] text-3" onClick={() => navigate('settings')}>
        <Info className="w-4 h-4" />DAYFLOW 1.0.0 · {lang === 'ar' ? 'معمول عشان يرتّب يومك الحقيقي' : 'Built for your real day'}<ChevronLeft className="w-4 h-4 rtl:rotate-180" />
      </button>
      <p className="text-center text-[0.6rem] text-3 mt-1.5">Plan your day. Execute your priorities. Understand your progress. Adapt intelligently.</p>
    </div>
  );
}
