/* DAYFLOW — Journal: mood · gratitude · prompts · auto day-summary from real records · timeline */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Search, Sparkles, Flame, Trash2, Wand2, NotebookPen, Bot } from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, addDays, newId } from '@/lib/db';
import { lastNDays, fmtMinutes } from '@/lib/stats';
import { BarChart } from '@/components/charts';
import { EmptyState, HelpTip } from '@/components/ui';
import type { ActivityBlock, FocusSession, WaterLog } from '@/lib/types';
import { cn } from '@/utils/cn';

export interface JournalEntry { id: string; date: string; kind: 'entry' | 'auto'; title: string; body: string; mood: 1 | 2 | 3 | 4 | 5 | null; gratitude: string[]; tags: string[]; summary?: string; createdAt: number; updatedAt: number }

const MOODS = [
  { v: 1, img: '/decor/mood1.png', ar: 'زعلان', en: 'Sad' }, { v: 2, img: '/decor/mood2.png', ar: 'مش أحسن حاجة', en: 'Low' },
  { v: 3, img: '/decor/mood3.png', ar: 'عادي', en: 'Okay' }, { v: 4, img: '/decor/mood4.png', ar: 'كويس', en: 'Good' }, { v: 5, img: '/decor/mood5.png', ar: 'مبسوط جدًا', en: 'Great' },
] as const;
const PROMPTS = ['إيه أحلى حاجة حصلت النهارده؟', 'إيه اللي اتعلمته النهارده؟', 'إيه الحاجة اللي لو عملتها بكرة هتفرق معاك؟', 'مين الشخص اللي فرّحك النهارده وليه؟', 'إيه اللي ضايقك وتقدر تعمل فيه إيه؟', 'لو اليوم ده فيلم، اسمه هيبقى إيه؟'];

export default function JournalModule() {
  const { lang, tick, bump, toast, confirm } = useApp();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [q, setQ] = useState('');
  const today = todayKey();
  const [mood, setMood] = useState<JournalEntry['mood']>(null);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [grat, setGrat] = useState(['', '', '']);
  const [tags, setTags] = useState('');
  const [prompt, setPrompt] = useState(() => PROMPTS[new Date().getDate() % PROMPTS.length]);
  const [summary, setSummary] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const reload = useCallback(async () => setEntries((await db.all<JournalEntry>('journal_entries')).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt)), []);
  useEffect(() => { reload(); }, [reload, tick]);

  const buildSummary = useCallback(async () => {
    const [blocks, focus, water, prayers] = await Promise.all([db.all<ActivityBlock>('activity_blocks'), db.all<FocusSession>('focus_sessions'), db.all<WaterLog>('water_logs'), db.all<any>('prayer_logs')]);
    const done = blocks.filter(b => b.date === today && b.status === 'done');
    const missed = blocks.filter(b => b.date === today && (b.status === 'missed' || b.status === 'skipped'));
    const fMin = focus.filter(f => f.date === today).reduce((s, f) => s + f.actualMin, 0);
    const wMl = water.filter(w => w.date === today).reduce((s, w) => s + w.amountMl, 0);
    const pr = prayers.filter(p => p.date === today).length;
    const lines = [
      `✅ خلصت ${done.length} نشاط${done.length ? `: ${done.slice(0, 5).map(b => b.title).join('، ')}` : ''}`,
      missed.length ? `⏭️ فاتك ${missed.length}` : '',
      fMin ? `🧠 ركزت ${fmtMinutes(fMin, 'ar')}` : '', wMl ? `💧 شربت ${wMl} مل` : '', pr ? `🕌 صليت ${pr} من 5` : '',
    ].filter(Boolean);
    setSummary(lines.join('\n'));
  }, [today]);
  useEffect(() => { buildSummary(); }, [buildSummary, tick]);

  const save = async () => {
    if (!body.trim() && !title.trim() && !mood) { toast('اكتب حاجة أو اختار مودك الأول'); return; }
    const old = editingId ? entries.find(e => e.id === editingId) : null;
    await db.put('journal_entries', { id: editingId ?? newId(), date: old?.date ?? today, kind: 'entry', title: title.trim() || (lang === 'ar' ? 'يومياتي' : 'Journal'), body: body.trim(), mood, gratitude: grat.map(g => g.trim()).filter(Boolean), tags: tags.split(/[,،]/).map(s => s.trim()).filter(Boolean), summary, createdAt: old?.createdAt ?? Date.now(), updatedAt: Date.now() } satisfies JournalEntry);
    setTitle(''); setBody(''); setGrat(['', '', '']); setTags(''); setMood(null); setEditingId(null); bump();
    toast(lang === 'ar' ? 'اتحفظت يومياتك ✍️' : 'Journal saved');
  };

  const writtenDays = useMemo(() => new Set(entries.filter(e => e.kind === 'entry').map(e => e.date)), [entries]);
  const streak = useMemo(() => { let n = 0, d = writtenDays.has(today) ? today : addDays(today, -1); while (writtenDays.has(d)) { n++; d = addDays(d, -1); } return n; }, [writtenDays, today]);
  const moodSeries = useMemo(() => lastNDays(30).map(d => { const m = entries.filter(e => e.date === d && e.mood).map(e => e.mood!); return { label: d.slice(-2), value: m.length ? m.reduce((a, b) => a + b, 0) / m.length : 0 }; }), [entries]);
  const filtered = entries.filter(e => !q.trim() || (e.title + ' ' + e.body + ' ' + e.tags.join(' ')).toLowerCase().includes(q.trim().toLowerCase()));

  return (
    <div className="pb-6 px-4 pt-14">
      <h1 className="skin-title font-extrabold flex items-center gap-2"><img src="/decor/notebook.png" alt="" className="w-8 h-8 decor-float" />{lang === 'ar' ? 'يومياتي' : 'Journal'}</h1>
      <div className="grid grid-cols-3 gap-2 mt-3">
        <div className="card-flat p-2.5 text-center"><p className="num text-xl font-extrabold text-[var(--warn)] flex items-center justify-center gap-1"><Flame className="w-4 h-4" />{streak}</p><p className="text-[0.58rem] font-bold text-2">{lang === 'ar' ? 'أيام ورا بعض' : 'Day streak'}</p></div>
        <div className="card-flat p-2.5 text-center"><p className="num text-xl font-extrabold">{writtenDays.size}</p><p className="text-[0.58rem] font-bold text-2">{lang === 'ar' ? 'يوم كتبت فيه' : 'Days written'}</p></div>
        <div className="card-flat p-2.5 text-center"><p className="num text-xl font-extrabold">{entries.length}</p><p className="text-[0.58rem] font-bold text-2">{lang === 'ar' ? 'كل التدوينات' : 'Entries'}</p></div>
      </div>

      {/* composer */}
      <div className="card p-4 mt-3">
        <p className="text-[0.72rem] font-extrabold text-2 flex items-center gap-1.5">{lang === 'ar' ? 'مودك النهارده عامل إزاي؟' : 'How do you feel today?'}</p>
        <div className="flex justify-between mt-2">
          {MOODS.map(m => (
            <button key={m.v} onClick={() => setMood(m.v as any)} className={cn('flex flex-col items-center gap-1 rounded-2xl p-1.5 transition-all', mood === m.v ? 'bg-[var(--accent-soft)] scale-110' : 'opacity-70 hover:opacity-100')} aria-pressed={mood === m.v}>
              <img src={m.img} alt="" className={cn('w-10 h-10', mood === m.v && 'decor-float')} /><span className="text-[0.55rem] font-bold">{lang === 'ar' ? m.ar : m.en}</span>
            </button>
          ))}
        </div>
        <input className="input mt-3 font-bold" value={title} onChange={e => setTitle(e.target.value)} placeholder={lang === 'ar' ? 'عنوان (اختياري)' : 'Title (optional)'} />
        <button className="text-[0.68rem] font-bold accent mt-2 flex items-center gap-1" onClick={() => setPrompt(PROMPTS[(PROMPTS.indexOf(prompt) + 1) % PROMPTS.length])}><Wand2 className="w-3.5 h-3.5" />{prompt}</button>
        <textarea className="input mt-1.5 min-h-[120px] leading-relaxed" value={body} onChange={e => setBody(e.target.value)} placeholder={lang === 'ar' ? 'اكتب براحتك… محدش هيشوفها غيرك، كله على موبايلك' : 'Write freely… private, on-device'} />
        <p className="text-[0.7rem] font-extrabold text-2 mt-3 flex items-center gap-1.5">🙏 {lang === 'ar' ? '3 حاجات ممتن ليها' : '3 things I’m grateful for'}<HelpTip title="ليه الامتنان؟">كتابة 3 حاجات حلوة كل يوم — حتى لو صغيرة زي «كوباية شاي حلوة» — بتساعد عقلك يلاحظ الحاجات الكويسة وبتحسّن المود مع الوقت. جرّبها أسبوع وشوف 😊</HelpTip></p>
        {grat.map((g, i) => <input key={i} className="input mt-1.5 !py-2" value={g} onChange={e => setGrat(arr => arr.map((x, j) => j === i ? e.target.value : x))} placeholder={`${i + 1}.`} />)}
        <input className="input mt-2 !py-2" value={tags} onChange={e => setTags(e.target.value)} placeholder={lang === 'ar' ? 'وسوم: شغل، عيلة، مذاكرة' : 'Tags: work, family'} />
        {summary && (
          <div className="mt-3 rounded-2xl p-3 text-[0.72rem] leading-relaxed whitespace-pre-line" style={{ background: 'var(--accent-soft)' }}>
            <p className="font-extrabold accent flex items-center gap-1 mb-1"><Bot className="w-4 h-4" />{lang === 'ar' ? 'ملخص يومك (من سجلك الحقيقي)' : 'Your day (from real records)'}</p>{summary}
          </div>
        )}
        <button className="btn btn-primary w-full justify-center !py-3 mt-3" onClick={save}><NotebookPen className="w-4 h-4" />{editingId ? (lang === 'ar' ? 'احفظ التعديل' : 'Save changes') : (lang === 'ar' ? 'احفظ يومياتي' : 'Save entry')}</button>
      </div>

      <p className="text-[0.75rem] font-extrabold text-2 mt-5 mb-1">{lang === 'ar' ? 'مودك آخر 30 يوم' : 'Mood — 30 days'}</p>
      <div className="card p-3"><BarChart data={moodSeries} height={70} formatY={v => (v ? v.toFixed(1) : '—')} /></div>

      <div className="relative mt-4"><Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-3" /><input className="input ps-9" value={q} onChange={e => setQ(e.target.value)} placeholder={lang === 'ar' ? 'دوّر في يومياتك…' : 'Search journal…'} /></div>
      <div className="mt-3 space-y-2">
        {filtered.map(e => {
          const m = MOODS.find(x => x.v === e.mood);
          return (
            <div key={e.id} className={cn('card p-3', e.kind === 'auto' && 'opacity-90')} style={e.kind === 'auto' ? { borderStyle: 'dashed' } : undefined}>
              <div className="flex items-center gap-2">
                {m ? <img src={m.img} alt="" className="w-8 h-8" /> : <span className="w-8 h-8 rounded-xl grid place-items-center bg-[var(--accent-soft)] accent">{e.kind === 'auto' ? <Sparkles className="w-4 h-4" /> : <NotebookPen className="w-4 h-4" />}</span>}
                <div className="flex-1 min-w-0"><p className="font-extrabold text-sm truncate">{e.title}</p><p className="num text-[0.6rem] text-3">{new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(e.date + 'T12:00:00'))}{e.kind === 'auto' ? (lang === 'ar' ? ' · سجل أوتوماتيك' : ' · auto log') : ''}</p></div>
                {e.kind === 'entry' && <button className="text-[0.65rem] font-bold accent" onClick={() => { setEditingId(e.id); setTitle(e.title); setBody(e.body); setMood(e.mood); setGrat([...e.gratitude, '', '', ''].slice(0, 3)); setTags(e.tags.join(', ')); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>{lang === 'ar' ? 'تعديل' : 'Edit'}</button>}
                <button className="icon-btn !w-8 !h-8" onClick={async () => { if (await confirm({ title: 'تمسح التدوينة؟', danger: true, confirmLabel: 'امسح' })) { await db.del('journal_entries', e.id); bump(); } }} aria-label="delete"><Trash2 className="w-4 h-4" /></button>
              </div>
              {e.body && <p className="text-[0.78rem] mt-2 whitespace-pre-line leading-relaxed">{e.body}</p>}
              {e.gratitude.length > 0 && <ul className="mt-2 text-[0.72rem] text-2 space-y-0.5">{e.gratitude.map((g, i) => <li key={i}>🙏 {g}</li>)}</ul>}
              {e.summary && <p className="mt-2 text-[0.68rem] text-2 whitespace-pre-line rounded-xl p-2 bg-[var(--surface-2)]">{e.summary}</p>}
              {e.tags.length > 0 && <div className="flex flex-wrap gap-1 mt-2">{e.tags.map(t => <span key={t} className="chip !text-[0.58rem] !py-0.5">#{t}</span>)}</div>}
            </div>
          );
        })}
        {filtered.length === 0 && <EmptyState icon={<NotebookPen className="w-7 h-7" />} title={lang === 'ar' ? 'لسه مكتبتش حاجة' : 'No entries yet'} hint={lang === 'ar' ? 'ابدأ بسطر واحد بس النهارده ✍️' : 'Start with one line today'} />}
      </div>
    </div>
  );
}
