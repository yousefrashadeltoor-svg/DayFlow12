/* DAYFLOW — Prayer module (all 27 Egyptian governorates · exact survey method · offline Qibla · adhan alarms · full stats) */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { MapPin, Check, BellRing, BellOff, Music2, Smartphone, Flame, Compass, Award } from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, addDays, isNative } from '@/lib/db';
import { platform, haptic } from '@/lib/platform';
import {
  GOVERNORATES, govById, computePrayerTimes, nextPrayer, qiblaAngle,
  PRAYER_ORDER, FARD, PRAYER_AR, PRAYER_EN, fmtHM, type PrayerName,
} from '@/lib/prayer';
import { hijriLabel } from '@/lib/occasions';
import { ProgressRing, LinearProgress, HelpTip, SettingRow, Toggle } from '@/components/ui';
import { BarChart } from '@/components/charts';
import { lastNDays } from '@/lib/stats';
import { cn } from '@/utils/cn';

interface PrayerLog { id: string; date: string; prayer: PrayerName; prayedAt: number; source: string }

export default function PrayerModule() {
  const { lang, settings, saveSettings, tick, bump, toast, hour12 } = useApp();
  const [now, setNow] = useState(new Date());
  const [logs, setLogs] = useState<PrayerLog[]>([]);

  useEffect(() => { const id = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(id); }, []);
  const reload = useCallback(async () => setLogs(await db.all<PrayerLog>('prayer_logs')), []);
  useEffect(() => { reload(); }, [reload, tick]);

  const g = govById(settings.governorate);
  const times = useMemo(() => computePrayerTimes(now, g.lat, g.lng, settings.prayerAdjust as any), [g, settings.prayerAdjust, now.toDateString()]);
  const np = nextPrayer(g.lat, g.lng, settings.prayerAdjust as any, now);
  const qibla = useMemo(() => qiblaAngle(g.lat, g.lng), [g]);
  const left = Math.max(0, np.at.getTime() - now.getTime());
  const hh = Math.floor(left / 3600000), mm = Math.floor((left % 3600000) / 60000), ss = Math.floor((left % 60000) / 1000);
  const today = todayKey();
  const prayedToday = new Set(logs.filter(l => l.date === today).map(l => l.prayer));
  const nowMin = now.getHours() * 60 + now.getMinutes();

  const togglePrayed = async (p: PrayerName) => {
    const id = `${today}:${p}`;
    const adding = !prayedToday.has(p);
    if (adding) {
      await db.put('prayer_logs', { id, date: today, prayer: p, prayedAt: Date.now(), source: 'app' });
      haptic('medium');
    } else {
      await db.del('prayer_logs', id);
    }
    const names = FARD.filter(x => (x === p ? adding : prayedToday.has(x)));
    await platform.syncPrayed(today, names);
    bump();
    if (adding && names.length === 5) toast(lang === 'ar' ? 'ما شاء الله! صلّيت الـ5 صلوات النهارده 🕌✨' : 'All 5 prayers logged today!');
  };

  const week = useMemo(() => lastNDays(7).map(d => ({
    label: new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-GB', { weekday: 'narrow' }).format(new Date(d + 'T12:00:00')),
    value: logs.filter(l => l.date === d).length,
  })), [logs, lang]);
  const weekTotal = week.reduce((s, w) => s + w.value, 0);

  const month30 = useMemo(() => {
    const cut = addDays(today, -29);
    const recent = logs.filter(l => l.date >= cut);
    const rate = Math.round((recent.length / (30 * 5)) * 100);
    const byPrayer = FARD.map(p => ({ p, count: recent.filter(l => l.prayer === p).length }));
    return { total: recent.length, rate, byPrayer };
  }, [logs, today]);

  const streak = useMemo(() => {
    let n = 0;
    let d = prayedToday.size >= 5 ? today : addDays(today, -1);
    while (logs.filter(l => l.date === d).length >= 5) { n++; d = addDays(d, -1); }
    return n;
  }, [logs, today, prayedToday.size]);

  const pickTone = async (kind: 'system' | 'music') => {
    if (!isNative()) { toast('اختيار صوت الأذان شغال جوه تطبيق الأندرويد'); return; }
    const res: any = kind === 'system'
      ? await platform.pickSystemTone('alarm', settings.prayerToneUri)
      : await platform.pickMusicTone();
    if (res.ok) {
      await saveSettings({ prayerSound: 'custom', prayerToneUri: res.uri, prayerToneName: res.name });
      toast(`تم اختيار صوت الأذان: ${res.name} ✓`);
    }
  };

  const pname = (p: PrayerName) => (lang === 'ar' ? PRAYER_AR[p] : PRAYER_EN[p]);

  return (
    <div className="pb-6 px-4 pt-14">
      <h1 className="skin-title font-extrabold flex items-center gap-2">
        <img src="/decor/mosque.png" alt="" className="w-8 h-8 decor-float" />
        {lang === 'ar' ? 'مواقيت الصلاة' : 'Prayer times'}
      </h1>

      {/* All 27 Egyptian Governorates selector */}
      <div className="flex items-center gap-2 mt-2.5">
        <MapPin className="w-4 h-4 accent shrink-0" />
        <select
          className="input !py-2 flex-1 font-bold"
          value={settings.governorate}
          onChange={e => saveSettings({ governorate: e.target.value })}
          aria-label="اختار محافظتك"
        >
          {GOVERNORATES.map(x => <option key={x.id} value={x.id}>{lang === 'ar' ? `${x.ar} (${x.city})` : `${x.en} — ${x.ar}`}</option>)}
        </select>
        <HelpTip title="المواقيت بتتحسب إزاي؟">
          <p>المواقيت بتتحسب <b>فلكيًا على موبايلك أوفلاين 100%</b> بطريقة <b>الهيئة المصرية العامة للمساحة</b> المعتمدة رسميًا في مصر كلها (27 محافظة):</p>
          <ul>
            <li><b>الفجر:</b> زاوية الشمس 19.5° تحت الأفق.</li>
            <li><b>العشاء:</b> زاوية الشمس 17.5° تحت الأفق.</li>
            <li><b>العصر:</b> المذهب الشافعي (ظل الشيء مثله).</li>
            <li><b>التوقيت الصيفي:</b> بيتظبط تلقائياً حسب ساعة جهازك.</li>
          </ul>
          <p>لو مسجد منطقتك بيفرّق دقيقة أو اتنين، عدّلها من «تصحيح يدوي» في آخر الصفحة، وهتتطبق على الإشعارات والويدجيت كمان.</p>
        </HelpTip>
      </div>

      {/* Live next prayer hero with circular progress ring */}
      <div className="card p-5 mt-3 flex items-center gap-4 relative overflow-hidden">
        <img src="/media/occ-islamic.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-[.13]" />
        <ProgressRing size={132} stroke={11} progress={np.progress}>
          <div className="text-center">
            <p className="text-[0.58rem] font-bold text-2">{lang === 'ar' ? 'الجاية' : 'Next'}</p>
            <p className="text-[1.15rem] font-extrabold accent leading-tight">{pname(np.name)}</p>
            <p className="num text-[0.72rem] font-bold mt-0.5" dir="ltr">{fmtHM(np.at.getHours() * 60 + np.at.getMinutes(), hour12)}</p>
          </div>
        </ProgressRing>
        <div className="relative flex-1 min-w-0">
          <p className="text-[0.68rem] font-bold text-2">{lang === 'ar' ? 'فاضل على الأذان' : 'Time remaining'}</p>
          <p className="num text-[1.95rem] font-extrabold tracking-tight leading-tight" dir="ltr" style={{ textAlign: lang === 'ar' ? 'right' : 'left' }}>
            {String(hh).padStart(2, '0')}:{String(mm).padStart(2, '0')}:{String(ss).padStart(2, '0')}
          </p>
          <p className="text-[0.65rem] text-2 mt-1">{hijriLabel(now, lang, settings.hijriOffset)}</p>
          <div className="flex items-center gap-1.5 mt-2 flex-wrap">
            <span className="chip !py-0.5 !text-[0.62rem] !text-[var(--ok)] !bg-[var(--ok-soft)] !border-transparent">
              <Check className="w-3 h-3" />{lang === 'ar' ? `${prayedToday.size} من 5 النهارده` : `${prayedToday.size}/5 today`}
            </span>
            <span className="chip !py-0.5 !text-[0.62rem] num" title="اتجاه القبلة">
              <Compass className="w-3 h-3 accent" />{lang === 'ar' ? `القبلة ${qibla}°` : `Qibla ${qibla}°`}
            </span>
          </div>
        </div>
      </div>

      {/* Today's 6 schedule slots (with adhan toggle & prayer check) */}
      <div className="card mt-3 overflow-hidden">
        {PRAYER_ORDER.map(p => {
          const tm = times[p];
          const isNext = p === np.name;
          const passed = tm <= nowMin && !isNext;
          const fard = p !== 'sunrise';
          const bellOn = !!settings.prayerOn[p];
          const done = prayedToday.has(p);
          return (
            <div key={p} className={cn('flex items-center gap-3 px-4 py-3 border-b hairline last:border-0 transition-colors', isNext && 'bg-[var(--accent-soft)]')}>
              <span className={cn('w-2 h-8 rounded-full transition-colors', done ? 'bg-[var(--ok)]' : isNext ? 'bg-[var(--accent)]' : passed ? 'bg-[var(--border-strong)]' : 'bg-[var(--surface-3)]')} />
              <div className="flex-1 min-w-0">
                <p className={cn('font-extrabold', isNext && 'accent')}>{pname(p)}</p>
                {isNext && <p className="text-[0.6rem] font-bold accent">{lang === 'ar' ? 'الصلاة الجاية' : 'Up next'}</p>}
                {done && !isNext && <p className="text-[0.58rem] font-bold text-[var(--ok)]">{lang === 'ar' ? 'اتصلّت ✓' : 'Prayed ✓'}</p>}
              </div>
              <span className="num text-[1.05rem] font-extrabold" dir="ltr">{fmtHM(tm, hour12)}</span>
              <button
                className="icon-btn !w-9 !h-9"
                onClick={() => { haptic('light'); saveSettings({ prayerOn: { ...settings.prayerOn, [p]: !bellOn } }); }}
                aria-label={`منبه ${pname(p)}`}
                aria-pressed={bellOn}
              >
                {bellOn ? <BellRing className="w-4 h-4 accent" /> : <BellOff className="w-4 h-4 text-3" />}
              </button>
              {fard ? (
                <button
                  onClick={() => togglePrayed(p)}
                  className={cn('w-9 h-9 rounded-xl grid place-items-center border-2 transition-all', done ? 'bg-[var(--ok)] border-transparent text-white scale-105 shadow-sm' : 'border-[var(--border-strong)] text-3')}
                  aria-pressed={done} aria-label={`سجّل ${pname(p)}`}
                >
                  <Check className="w-5 h-5" strokeWidth={2.6} />
                </button>
              ) : <span className="w-9" />}
            </div>
          );
        })}
      </div>

      {/* Real prayer statistics: 7-day bar, streak, 30-day total & per-prayer breakdown */}
      <div className="grid grid-cols-3 gap-2 mt-3">
        <div className="card p-3 col-span-2">
          <div className="flex items-center justify-between">
            <p className="text-[0.62rem] font-bold text-2">{lang === 'ar' ? 'آخر 7 أيام' : 'Last 7 days'}</p>
            <p className="num text-sm font-extrabold">{weekTotal}<span className="text-[0.65rem] text-2"> / 35</span></p>
          </div>
          <BarChart data={week} height={54} formatY={v => `${v}/5`} />
        </div>
        <div className="card p-3 flex flex-col justify-center items-center text-center">
          <Flame className="w-6 h-6 text-[var(--warn)]" />
          <p className="num text-2xl font-extrabold leading-tight">{streak}</p>
          <p className="text-[0.58rem] font-bold text-2">{lang === 'ar' ? 'يوم كامل ورا بعض' : 'Full-day streak'}</p>
        </div>
      </div>

      <div className="card p-3.5 mt-2">
        <div className="flex items-center justify-between mb-2">
          <p className="text-[0.7rem] font-extrabold flex items-center gap-1.5"><Award className="w-4 h-4 text-[var(--ok)]" />{lang === 'ar' ? 'التزامك آخر 30 يوم' : '30-day consistency'}</p>
          <span className="num text-xs font-extrabold text-[var(--ok)]">{month30.total}/150 ({month30.rate}%)</span>
        </div>
        <div className="space-y-1.5">
          {month30.byPrayer.map(({ p, count }) => (
            <div key={p} className="flex items-center gap-2">
              <span className="text-[0.65rem] font-bold w-12">{pname(p)}</span>
              <LinearProgress value={(count / 30) * 100} className="flex-1" tone="var(--ok)" />
              <span className="num text-[0.62rem] font-bold text-2 w-10 text-end">{count}/30</span>
            </div>
          ))}
        </div>
      </div>

      {/* Offline Qibla card */}
      <div className="card p-3.5 mt-2 flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl grid place-items-center bg-[var(--accent-soft)] shrink-0">
          <img src="/decor/compass.png" alt="" className="w-8 h-8" style={{ transform: `rotate(${qibla}deg)` }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-extrabold flex items-center gap-1.5">
            {lang === 'ar' ? `اتجاه القبلة من ${g.ar}` : `Qibla from ${g.en}`}
            <HelpTip title="اتجاه القبلة">الزاوية <b>{qibla}°</b> من الشمال الحقيقي باتجاه عقارب الساعة (يعني تقريباً نحو الجنوب الشرقي من مصر ناحية الكعبة المشرفة). محسوبة فلكياً أوفلاين من غير نت ولا GPS.</HelpTip>
          </p>
          <p className="text-[0.65rem] text-2 num mt-0.5">{qibla}° {lang === 'ar' ? 'من الشمال (جنوب شرق ناحية مكة)' : 'CW from true North'}</p>
        </div>
      </div>

      {/* Adhan & notification settings */}
      <div className="card px-4 mt-3">
        <SettingRow label="منبه الأذان" hint="تنبيه حقيقي وإحصائياتك تظهر في الإشعار والويدجيت"
          help={<p>لما يبقى شغال، أندرويد هيجدول كل صلاة انت فاتح جرسها 🔔 تلقائيًا كل يوم حتى لو التطبيق مقفول أو الموبايل اتعمل له ريستارت. هيظهرلك مع كل أذان «صلّيت النهارده X من 5» وزرار <b>صلّيت ✓</b> يسجّل صلاتك بضغطة واحدة.</p>}>
          <Toggle on={settings.prayerEnabled} onChange={v => saveSettings({ prayerEnabled: v })} />
        </SettingRow>
        <SettingRow label="تنبيه قبل الصلاة بـ" hint="دقايق للاستعداد والوضوء (0 = بدون)">
          <select className="input !py-1.5 !w-20 num" value={settings.prayerPreMin} onChange={e => saveSettings({ prayerPreMin: Number(e.target.value) })}>
            {[0, 5, 10, 15, 20, 30].map(n => <option key={n} value={n}>{n === 0 ? 'لأ' : `${n} د`}</option>)}
          </select>
        </SettingRow>
        <SettingRow label="صوت الأذان" hint={settings.prayerSound === 'custom' && settings.prayerToneName ? `🎵 ${settings.prayerToneName}` : settings.prayerSound === 'alarm' ? 'نغمة المنبه' : 'صوت الإشعار العادي'}
          help={<p>تقدر تحط أي ملف أذان محفوظ على موبايلك (مثلاً الشيخ عبد الباسط أو المنشاوي) من «صوت من الموسيقى» أو تختار من نغمات الموبايل — أوفلاين بالكامل.</p>}>
          <select className="input !py-1.5 !w-28" value={settings.prayerSound} onChange={e => saveSettings({ prayerSound: e.target.value as any })}>
            <option value="alarm">نغمة المنبه</option>
            <option value="default">إشعار هادي</option>
            <option value="custom" disabled={!settings.prayerToneUri}>أذان مختار</option>
          </select>
        </SettingRow>
        <div className="flex gap-2 py-2.5 border-b hairline">
          <button className="btn btn-ghost btn-sm flex-1 justify-center" onClick={() => pickTone('system')}><Smartphone className="w-4 h-4" />نغمات الموبايل</button>
          <button className="btn btn-soft btn-sm flex-1 justify-center" onClick={() => pickTone('music')}><Music2 className="w-4 h-4" />أذان من الموسيقى</button>
        </div>
        <SettingRow label="ينطق اسم الصلاة قبل الأذان" help={<p>بيقول «حان دلوقتي موعد صلاة الظهر» بصوت عالي باستخدام محرك النطق في جهازك.</p>}>
          <Toggle on={settings.prayerSpeak} onChange={v => saveSettings({ prayerSpeak: v })} />
        </SettingRow>
      </div>

      {/* Manual adjustment */}
      <p className="text-[0.74rem] font-extrabold text-2 mt-4 mb-1.5 flex items-center gap-1.5">
        {lang === 'ar' ? 'تصحيح يدوي (± دقايق)' : 'Manual offsets (± min)'}
        <HelpTip title="التصحيح اليدوي للمواقيت">لو المسجد اللي جنبك بيأذن بدقيقة بدري أو متأخر عن الحساب الفلكي، زوّد (+1) أو نقص (-1) هنا. هيتطبق فوراً على التطبيق، الإشعارات، والويدجيت.</HelpTip>
      </p>
      <div className="card p-3 grid grid-cols-3 gap-2">
        {PRAYER_ORDER.map(p => (
          <label key={p} className="text-center">
            <span className="text-[0.62rem] font-bold text-2 block mb-0.5">{pname(p)}</span>
            <input type="number" min={-15} max={15} className="input !py-1.5 text-center num"
              value={settings.prayerAdjust[p] ?? 0}
              onChange={e => saveSettings({ prayerAdjust: { ...settings.prayerAdjust, [p]: Math.max(-15, Math.min(15, Number(e.target.value) || 0)) } })} />
          </label>
        ))}
      </div>
    </div>
  );
}
