/* DAYFLOW — Goals (with milestones) · Notes (searchable, taggable, offline) */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Target, Plus, Check, Trash2, Search, Star, StickyNote, NotebookPen, Users, BookOpen, Pin,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, newId } from '@/lib/db';
import { Sheet, EmptyState, Field, LinearProgress, Segmented, HelpTip } from '@/components/ui';
import type { Goal, GoalMilestone, NoteItem } from '@/lib/types';
import { cn } from '@/utils/cn';

type GNTab = 'goals' | 'notes';
const NOTE_KINDS: Array<{ id: NoteItem['kind']; ar: string; en: string; icon: any }> = [
  { id: 'note', ar: 'ملاحظة', en: 'Note', icon: StickyNote },
  { id: 'study', ar: 'دراسية', en: 'Study', icon: BookOpen },
  { id: 'meeting', ar: 'اجتماع', en: 'Meeting', icon: Users },
  { id: 'journal', ar: 'يوميات', en: 'Journal', icon: NotebookPen },
];

export default function GoalsNotesModule({ params }: { params?: { tab?: GNTab } }) {
  const { t, lang } = useApp();
  const [tab, setTab] = useState<GNTab>(params?.tab ?? 'goals');
  return (
    <div className="pb-6 px-4 pt-14">
      <h1 className="skin-title font-extrabold flex items-center gap-2">{lang === 'ar' ? 'أهدافي وملاحظاتي' : 'Goals & notes'}<HelpTip title="الأهداف والملاحظات"><p>أي هدف كبير قسّمه لخطوات (معالم) عشان النسبة تزيد مع شغلك الحقيقي. وملاحظاتك كلها أوفلاين على موبايلك وتقدر تثبّت المهم وتدوّر بالوسوم.</p></HelpTip></h1>
      <div className="mt-2"><Segmented value={tab} onChange={v => setTab(v as GNTab)} options={[{ value: 'goals', label: t('goals') }, { value: 'notes', label: t('notes') }]} /></div>
      {tab === 'goals' ? <GoalsTab /> : <NotesTab />}
    </div>
  );
}

function GoalsTab() {
  const { lang, tick } = useApp();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [milestones, setMilestones] = useState<GoalMilestone[]>([]);
  const [addOpen, setAddOpen] = useState(false);
  const [openGoal, setOpenGoal] = useState<Goal | null>(null);
  const reload = useCallback(async () => { const [g, m] = await Promise.all([db.all<Goal>('goals'), db.all<GoalMilestone>('goal_milestones')]); setGoals(g); setMilestones(m); }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const progressOf = (g: Goal) => {
    const ms = milestones.filter(m => m.goalId === g.id);
    if (!ms.length) return g.progress;
    return Math.round((ms.filter(m => m.done).length / ms.length) * 100);
  };
  const horizonLabel = (h: Goal['horizon']) => h === 'short' ? (lang === 'ar' ? 'قصيرة المدى' : 'Short-term') : h === 'monthly' ? (lang === 'ar' ? 'شهري' : 'Monthly') : (lang === 'ar' ? 'طويلة المدى' : 'Long-term');
  const active = goals.filter(g => g.status !== 'done');

  return (
    <div className="mt-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-bold text-2">{goals.filter(g => g.status === 'active').length} {lang === 'ar' ? 'هدف نشط' : 'active goals'}</p>
        <button className="btn btn-soft btn-sm" onClick={() => setAddOpen(true)}><Plus className="w-4 h-4" />{lang === 'ar' ? 'هدف' : 'Goal'}</button>
      </div>
      <div className="space-y-2 mt-2">
        {active.map(g => {
          const pct = progressOf(g);
          const daysLeft = g.targetDate ? Math.ceil((new Date(g.targetDate + 'T12:00:00').getTime() - Date.now()) / 86400000) : null;
          return (
            <button key={g.id} className="card w-full p-3 text-start" onClick={() => setOpenGoal(g)}>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl grid place-items-center shrink-0" style={{ background: `color-mix(in srgb, ${g.color} 18%, transparent)`, color: g.color }}><Target className="w-6 h-6" /></div>
                <div className="flex-1 min-w-0">
                  <p className="font-extrabold leading-snug">{g.title}</p>
                  <p className="text-[0.6rem] text-2 font-semibold">{horizonLabel(g.horizon)}{g.targetDate ? <> · <span dir="ltr" className="num">{g.targetDate}</span>{daysLeft !== null && daysLeft >= 0 ? ` · ${daysLeft} ${lang === 'ar' ? 'يوم' : 'd'}` : ''}</> : null}</p>
                  <LinearProgress value={pct} tone={g.color} className="mt-1.5" />
                </div>
                <span className="num text-sm font-extrabold">{pct}%</span>
              </div>
            </button>
          );
        })}
        {active.length === 0 && <EmptyState icon={<Target className="w-7 h-7" />} title={lang === 'ar' ? 'لسه محددتش أهداف' : 'No goals yet'} hint={lang === 'ar' ? 'حدد هدفك الأول وقسّمـه إلى معالم — كل معلم مهمة قابلة للإنجاز' : 'Set your first goal and split it into milestones — each is a finishable task'} action={<button className="btn btn-primary" onClick={() => setAddOpen(true)}><Plus className="w-4 h-4" />{lang === 'ar' ? 'هدف جديد' : 'New goal'}</button>} />}
      </div>

      {/* goal detail + milestones */}
      <Sheet open={!!openGoal} onClose={() => setOpenGoal(null)} title={openGoal?.title}>
        {openGoal && <GoalDetail goal={openGoal} milestones={milestones.filter(m => m.goalId === openGoal.id)} onChanged={reload} />}
      </Sheet>

      {/* goal creator */}
      <Sheet open={addOpen} onClose={() => setAddOpen(false)} title={lang === 'ar' ? 'هدف جديد' : 'New goal'}>
        <GoalCreator onDone={() => { setAddOpen(false); reload(); }} />
      </Sheet>
    </div>
  );
}

function GoalCreator({ onDone }: { onDone: () => void }) {
  const { lang, t, toast } = useApp();
  const [title, setTitle] = useState(''); const [horizon, setHorizon] = useState<Goal['horizon']>('short'); const [targetDate, setTargetDate] = useState(''); const [color, setColor] = useState('#5856d6');
  const colors = ['#5856d6', '#0e8a94', '#e0356a', '#d97706', '#0da271', '#2f7de1'];
  const save = async () => {
    if (!title.trim()) { toast(lang === 'ar' ? 'أدخل عنوان الهدف' : 'Enter goal title'); return; }
    await db.put('goals', { id: newId(), title: title.trim(), description: '', horizon, targetDate: targetDate || null, progress: 0, color, icon: 'target', status: 'active', createdAt: Date.now() });
    onDone(); toast(t('saved'));
  };
  return (
    <>
      <Field label={lang === 'ar' ? 'العنوان' : 'Title'}><input autoFocus className="input" value={title} onChange={e => setTitle(e.target.value)} placeholder={lang === 'ar' ? 'أتقن أساسيات اللغة الإنجليزية…' : 'Master English fundamentals…'} /></Field>
      <Field label={lang === 'ar' ? 'الأفق الزمني' : 'Horizon'}><select className="input" value={horizon} onChange={e => setHorizon(e.target.value as any)}><option value="short">{lang === 'ar' ? 'قصيرة المدى' : 'Short-term'}</option><option value="monthly">{lang === 'ar' ? 'شهري' : 'Monthly'}</option><option value="long">{lang === 'ar' ? 'طويلة المدى' : 'Long-term'}</option></select></Field>
      <Field label={lang === 'ar' ? 'تاريخ الاستهداف' : 'Target date'}><input type="date" className="input num" value={targetDate} onChange={e => setTargetDate(e.target.value)} /></Field>
      <span className="label">{lang === 'ar' ? 'اللون' : 'Color'}</span>
      <div className="flex gap-2 mb-4">{colors.map(c => <button key={c} onClick={() => setColor(c)} className={cn('w-8 h-8 rounded-full', color === c && 'scale-125 ring-2 ring-offset-2 ring-[var(--accent)]')} style={{ background: c }} aria-label={c} />)}</div>
      <button className="btn btn-primary w-full justify-center !py-3" onClick={save}>{t('save')}</button>
    </>
  );
}

function GoalDetail({ goal, milestones, onChanged }: { goal: Goal; milestones: GoalMilestone[]; onChanged: () => void }) {
  const { lang, t, confirm, toast } = useApp();
  const [newMs, setNewMs] = useState('');
  const pct = milestones.length ? Math.round((milestones.filter(m => m.done).length / milestones.length) * 100) : goal.progress;
  const add = async () => { if (!newMs.trim()) return; await db.put('goal_milestones', { id: newId(), goalId: goal.id, title: newMs.trim(), done: false }); setNewMs(''); onChanged(); };
  return (
    <div>
      <LinearProgress value={pct} tone={goal.color} />
      <p className="num text-[0.7rem] text-2 mt-1.5 text-center">{pct}% · {milestones.filter(m => m.done).length}/{milestones.length} {lang === 'ar' ? 'معلماً' : 'milestones'}</p>
      <p className="text-[0.7rem] font-extrabold text-2 uppercase mt-4 mb-1.5">{lang === 'ar' ? 'المعالم' : 'Milestones'}</p>
      <div className="space-y-1">
        {milestones.map(m => (
          <div key={m.id} className="flex items-center gap-2 py-1.5 px-2 rounded-xl hover:bg-[var(--surface-2)]">
            <button className="icon-btn !w-8 !h-8" onClick={async () => { await db.put('goal_milestones', { ...m, done: !m.done }); onChanged(); }}><span className={cn('w-5 h-5 rounded-md border grid place-items-center', m.done ? 'bg-[var(--ok)] border-transparent text-white' : 'border-[var(--border-strong)]')}>{m.done && <Check className="w-3.5 h-3.5" />}</span></button>
            <span className={cn('flex-1 text-sm', m.done && 'line-through opacity-60')}>{m.title}</span>
            <button className="icon-btn !w-8 !h-8" onClick={async () => { await db.del('goal_milestones', m.id); onChanged(); }} aria-label="delete"><Trash2 className="w-4 h-4" /></button>
          </div>
        ))}
      </div>
      <div className="flex gap-2 mt-1.5"><input className="input flex-1 !py-2" value={newMs} onChange={e => setNewMs(e.target.value)} placeholder={lang === 'ar' ? 'معلم جديد…' : 'New milestone…'} onKeyDown={e => e.key === 'Enter' && add()} /><button className="btn btn-ghost btn-sm" onClick={add}><Plus className="w-4 h-4" /></button></div>
      <div className="flex gap-2 mt-4">
        <button className="btn btn-soft btn-sm flex-1 justify-center" onClick={async () => { await db.put('goals', { ...goal, status: 'done', progress: 100, updatedAt: Date.now() } as any); onChanged(); toast(lang === 'ar' ? 'أُنجز الهدف! 🎉' : 'Goal achieved!'); }}><Check className="w-4 h-4" />{lang === 'ar' ? 'إتمام الهدف' : 'Complete goal'}</button>
        <button className="btn btn-danger btn-sm" onClick={async () => { if (await confirm({ title: lang === 'ar' ? 'حذف الهدف ومعالمه؟' : 'Delete goal and its milestones?', danger: true, confirmLabel: t('delete') })) { for (const m of milestones) await db.del('goal_milestones', m.id); await db.del('goals', goal.id); onChanged(); toast(t('deleted')); } }}><Trash2 className="w-4 h-4" /></button>
      </div>
    </div>
  );
}

function NotesTab() {
  const { lang, tick, bump } = useApp();
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [q, setQ] = useState('');
  const [favOnly, setFavOnly] = useState(false);
  const [kind, setKind] = useState<'all' | NoteItem['kind']>('all');
  const [openNote, setOpenNote] = useState<NoteItem | null>(null);
  const reload = useCallback(async () => setNotes(await db.all<NoteItem>('notes')), []);
  useEffect(() => { reload(); }, [reload, tick]);

  const filtered = useMemo(() => notes
    .filter(n => (kind === 'all' || n.kind === kind) && (!favOnly || n.favorite) && (!q.trim() || (n.title + ' ' + n.body + ' ' + n.tags.join(' ')).toLowerCase().includes(q.trim().toLowerCase())))
    .sort((a, b) => Number(b.favorite) - Number(a.favorite) || b.updatedAt - a.updatedAt), [notes, q, favOnly, kind]);

  const create = async () => {
    const note: NoteItem = { id: newId(), title: '', body: '', tags: [], favorite: false, kind: kind === 'all' ? 'note' : kind, checklist: [], createdAt: Date.now(), updatedAt: Date.now() };
    await db.put('notes', note); bump(); setOpenNote(note);
  };

  return (
    <div className="mt-3">
      <div className="flex items-center gap-2">
        <div className="relative flex-1"><Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-3" /><input className="input ps-9" value={q} onChange={e => setQ(e.target.value)} placeholder={lang === 'ar' ? 'ابحث في ملاحظاتك…' : 'Search your notes…'} aria-label="search notes" /></div>
        <button className={cn('icon-btn border', favOnly ? 'border-[var(--warn)] text-[var(--warn)] bg-[var(--warn-soft)]' : 'hairline')} onClick={() => setFavOnly(v => !v)} aria-pressed={favOnly} aria-label="favorites"><Pin className="w-5 h-5" /></button>
        <button className="icon-btn bg-[var(--accent)] text-[var(--on-accent)]" onClick={create} aria-label="new note"><Plus className="w-5 h-5" /></button>
      </div>
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar mt-2 pb-1">
        <button className={cn('chip', kind === 'all' && 'chip-active')} onClick={() => setKind('all')}>{lang === 'ar' ? 'الكل' : 'All'}</button>
        {NOTE_KINDS.map(k => <button key={k.id} className={cn('chip', kind === k.id && 'chip-active')} onClick={() => setKind(k.id)}><k.icon className="w-3.5 h-3.5" />{lang === 'ar' ? k.ar : k.en}</button>)}
      </div>
      <div className="columns-2 gap-2 mt-2 [column-fill:_balance]">
        {filtered.map(n => {
          const KindIcon = NOTE_KINDS.find(k => k.id === n.kind)?.icon ?? StickyNote;
          return (
            <button key={n.id} onClick={() => setOpenNote(n)} className="card-flat w-full p-3 mb-2 text-start inline-block break-inside-avoid hover:shadow-md transition-shadow">
              <div className="flex items-center gap-1 text-3"><KindIcon className="w-3.5 h-3.5" />{n.favorite && <Star className="w-3.5 h-3.5 fill-[var(--warn)] text-[var(--warn)]" />}</div>
              <p className="font-extrabold text-[0.85rem] leading-snug mt-1 line-clamp-2">{n.title || (lang === 'ar' ? 'بدون عنوان' : 'Untitled')}</p>
              <p className="text-[0.68rem] text-2 mt-0.5 line-clamp-4 whitespace-pre-wrap">{n.body}</p>
              {n.tags.length > 0 && <div className="flex flex-wrap gap-1 mt-1.5">{n.tags.slice(0, 3).map(tg => <span key={tg} className="text-[0.52rem] font-bold text-3 bg-[var(--surface-2)] rounded-md px-1">#{tg}</span>)}</div>}
            </button>
          );
        })}
      </div>
      {filtered.length === 0 && <EmptyState icon={<StickyNote className="w-7 h-7" />} title={lang === 'ar' ? 'لسه مفيش ملاحظات' : 'No notes yet'} hint={lang === 'ar' ? 'مساحتك الخاصة — يوميات، اجتماعات، أفكار' : 'Your private space — journals, meetings, ideas'} action={<button className="btn btn-primary" onClick={create}><Plus className="w-4 h-4" />{lang === 'ar' ? 'أول ملاحظة' : 'First note'}</button>} />}

      {/* note editor */}
      <Sheet open={!!openNote} onClose={() => { setOpenNote(null); reload(); }} title={lang === 'ar' ? 'تحرير الملاحظة' : 'Edit note'}>
        {openNote && <NoteEditor note={openNote} onSaved={reload} onDeleted={() => { setOpenNote(null); reload(); }} />}
      </Sheet>
    </div>
  );
}

function NoteEditor({ note, onSaved, onDeleted }: { note: NoteItem; onSaved: () => void; onDeleted: () => void }) {
  const { lang, t, confirm, toast } = useApp();
  const [title, setTitle] = useState(note.title); const [body, setBody] = useState(note.body); const [tags, setTags] = useState(note.tags.join(', ')); const [favorite, setFavorite] = useState(note.favorite); const [kind, setKind] = useState(note.kind);
  const save = async () => {
    await db.put('notes', { ...note, title: title.trim(), body, tags: tags.split(',').map(s => s.trim()).filter(Boolean), favorite, kind, updatedAt: Date.now() });
    onSaved(); toast(t('saved'));
  };
  return (
    <>
      <div className="flex items-center gap-2 mb-2">
        <input autoFocus className="input flex-1 font-bold" value={title} onChange={e => setTitle(e.target.value)} placeholder={lang === 'ar' ? 'العنوان…' : 'Title…'} />
        <button className={cn('icon-btn border', favorite ? 'border-[var(--warn)] text-[var(--warn)]' : 'hairline text-2')} onClick={() => setFavorite(v => !v)} aria-pressed={favorite}><Star className={cn('w-5 h-5', favorite && 'fill-[var(--warn)]')} /></button>
      </div>
      <select className="input mb-2" value={kind} onChange={e => setKind(e.target.value as any)} aria-label="kind">{NOTE_KINDS.map(k => <option key={k.id} value={k.id}>{lang === 'ar' ? k.ar : k.en}</option>)}</select>
      <textarea className="input min-h-[180px] leading-relaxed" value={body} onChange={e => setBody(e.target.value)} placeholder={lang === 'ar' ? 'اكتب بحرية — كل شيء يبقى على جهازك…' : 'Write freely — everything stays on-device…'} />
      <Field label={lang === 'ar' ? 'الوسوم (مفصولة بفواصل)' : 'Tags (comma separated)'}><input className="input" value={tags} onChange={e => setTags(e.target.value)} placeholder="work, ideas, study" /></Field>
      <div className="flex gap-2">
        <button className="btn btn-primary flex-1 justify-center" onClick={save}>{t('save')}</button>
        <button className="btn btn-danger" onClick={async () => { if (await confirm({ title: lang === 'ar' ? 'حذف الملاحظة؟' : 'Delete note?', danger: true, confirmLabel: t('delete') })) { await db.del('notes', note.id); toast(t('deleted')); onDeleted(); } }} aria-label={t('delete')}><Trash2 className="w-5 h-5" /></button>
      </div>
    </>
  );
}
