/* DAYFLOW — Workouts: weekly plan · guided execution with persistent rest timer · logs · library */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Dumbbell, Play, Plus, Trash2, Check, X, CalendarClock, ArrowRightLeft, Pause,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, newId } from '@/lib/db';
import { Sheet, EmptyState, Field, Segmented, LinearProgress, HelpTip } from '@/components/ui';
import { haptic, playChime } from '@/lib/platform';
import type { WorkoutPlan, WorkoutLog, Exercise } from '@/lib/types';
import { cn } from '@/utils/cn';

type WTab = 'plan' | 'execute' | 'library';

export default function WorkoutsModule() {
  const { t, lang, locale, tick, toast, confirm, bump, settings } = useApp();
  const [tab, setTab] = useState<WTab>('plan');
  const [plans, setPlans] = useState<WorkoutPlan[]>([]);
  const [logs, setLogs] = useState<WorkoutLog[]>([]);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [editDay, setEditDay] = useState<number | null>(null);

  const reload = useCallback(async () => {
    const [p, l, e] = await Promise.all([db.all<WorkoutPlan>('workout_plans'), db.all<WorkoutLog>('workout_logs'), db.all<Exercise>('exercises')]);
    setPlans(p); setLogs(l); setExercises(e);
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const weekOrder = useMemo(() => Array.from({ length: 7 }, (_, i) => (settings.weekStart + i) % 7), [settings.weekStart]);
  const todayWeekday = new Date().getDay();
  const todayPlan = plans.find(p => p.weekday === todayWeekday) ?? null;
  const exMap = useMemo(() => Object.fromEntries(exercises.map(e => [e.id, e])), [exercises]);
  const weekdayName = (w: number) => new Intl.DateTimeFormat(locale, { weekday: 'long' }).format(new Date(2024, 5, 2 + w)); // 2024-06-02 = Sunday
  const weekMin = logs.filter(l => l.date >= todayKey().slice(0, 8) + '01').reduce((s, l) => s + l.durationMin, 0); // month-to-date minutes
  const weekSessions = logs.filter(l => l.date >= todayKey().slice(0, 8) + '01').length;

  const moveTodayToTomorrow = async () => {
    if (!todayPlan) return;
    const ok = await confirm({ title: lang === 'ar' ? 'انقل تمرين اليوم للغد؟' : "Move today's workout to tomorrow?", body: lang === 'ar' ? `«${todayPlan.sessionName}» ستنتقل لليوم التالي في خطتك.` : `"${todayPlan.sessionName}" moves to the next day in your plan.` });
    if (!ok) return;
    const tomorrowWeekday = (todayWeekday + 1) % 7;
    const tomorrowPlan = plans.find(p => p.weekday === tomorrowWeekday);
    await db.put('workout_plans', { ...todayPlan, id: tomorrowPlan?.id ?? newId(), weekday: tomorrowWeekday, updatedAt: Date.now() });
    await db.del('workout_plans', todayPlan.id);
    toast(lang === 'ar' ? 'تم النقل — راجع خطتك' : 'Moved — check your plan');
    bump();
  };

  return (
    <div className="pb-6 px-4 pt-14">
      <div className="flex items-center justify-between">
        <h1 className="skin-title font-extrabold flex items-center gap-2">{t('workouts')}<HelpTip title="خطة التمارين"><p>حط تمرين كل يوم في الأسبوع بالمجموعات والعدات والوزن ووقت الراحة. وقت التنفيذ هيشتغل مؤقت راحة تلقائي بين كل مجموعة بصوت تنبيه، ولو فاتك تمرين النهارده تقدر تنقله لبكرة بضغطة.</p></HelpTip></h1>
        <div className="flex items-center gap-2 text-[0.68rem] font-bold text-2"><span className="chip num">{weekSessions} {lang === 'ar' ? 'جلسة' : 'sessions'}</span><span className="chip num">{weekMin} {lang === 'ar' ? 'د' : 'min'}</span></div>
      </div>
      <div className="mt-2"><Segmented value={tab} onChange={v => setTab(v as WTab)} options={[{ value: 'plan', label: lang === 'ar' ? 'الخطة الأسبوعية' : 'Weekly plan' }, { value: 'execute', label: lang === 'ar' ? 'تنفيذ اليوم' : 'Today' }, { value: 'library', label: lang === 'ar' ? 'المكتبة' : 'Library' }]} /></div>

      {tab === 'plan' && (
        <div className="space-y-1.5 mt-3">
          {weekOrder.map(w => {
            const p = plans.find(x => x.weekday === w);
            const isToday = w === todayWeekday;
            return (
              <div key={w} className={cn('card-flat p-2.5 flex items-center gap-2.5 border', isToday ? 'border-[var(--accent)] bg-[var(--accent-soft)]' : 'border-transparent')}>
                <div className="w-12 text-center">
                  <p className="text-[0.6rem] font-bold text-2">{weekdayName(w)}</p>
                  {isToday && <span className="text-[0.52rem] font-extrabold accent">{lang === 'ar' ? 'اليوم' : 'TODAY'}</span>}
                </div>
                <button className="flex-1 min-w-0 text-start" onClick={() => setEditDay(w)}>
                  {p ? (<>
                    <p className="font-bold text-sm truncate">{p.sessionName}</p>
                    <p className="num text-[0.6rem] text-2">{p.exercises.length} {lang === 'ar' ? 'تمرين' : 'exercises'} · {p.exercises.reduce((s, e) => s + e.sets, 0)} {lang === 'ar' ? 'مجموعة' : 'sets'}</p>
                  </>) : <p className="text-sm text-3 py-1">{lang === 'ar' ? '+ ضيف تمرين اليوم' : '+ Add session'}</p>}
                </button>
                {p && isToday && <button className="icon-btn" onClick={moveTodayToTomorrow} title={lang === 'ar' ? 'انقل للغد' : 'Move to tomorrow'} aria-label="move"><ArrowRightLeft className="w-4 h-4" /></button>}
              </div>
            );
          })}
          <p className="text-[0.62rem] text-3 pt-1 px-1">{lang === 'ar' ? 'اضغط أي يوم لتعديل الجلسة والتمارين — تُحفظ الخطة على جهازك.' : 'Tap any day to edit the session — the plan persists on-device.'}</p>
        </div>
      )}

      {tab === 'execute' && <WorkoutExecutor plan={todayPlan} exMap={exMap} logs={logs} onChanged={reload} />}
      {tab === 'library' && <ExerciseLibrary exercises={exercises} onChanged={reload} />}

      <DayEditor open={editDay !== null} day={editDay} plans={plans} exercises={exercises} onClose={() => setEditDay(null)} onSaved={reload} />
    </div>
  );
}

/* ---------- Day editor ---------- */
function DayEditor({ open, day, plans, exercises, onClose, onSaved }: { open: boolean; day: number | null; plans: WorkoutPlan[]; exercises: Exercise[]; onClose: () => void; onSaved: () => void }) {
  const { lang, t, toast, bump, confirm } = useApp();
  const existing = plans.find(p => p.weekday === day);
  const [sessionName, setSessionName] = useState('');
  const [items, setItems] = useState<Array<{ exerciseId: string; sets: number; reps: number; restSec: number; loadKg: string }>>([]);
  useEffect(() => {
    if (!open) return;
    setSessionName(existing?.sessionName ?? (lang === 'ar' ? 'جلسة تمرين' : 'Workout'));
    setItems(existing?.exercises.map(e => ({ exerciseId: e.exerciseId, sets: e.sets, reps: e.reps, restSec: e.restSec, loadKg: e.loadKg != null ? String(e.loadKg) : '' })) ?? []);
  }, [open, existing, lang]);
  if (day === null) return null;
  const dayName = new Intl.DateTimeFormat(lang === 'ar' ? 'ar' : 'en-GB', { weekday: 'long' }).format(new Date(2024, 5, 2 + day));
  const save = async () => {
    if (!sessionName.trim()) { toast(lang === 'ar' ? 'أدخل اسم الجلسة' : 'Enter session name'); return; }
    await db.put('workout_plans', { id: existing?.id ?? newId(), weekday: day, sessionName: sessionName.trim(), exercises: items.filter(i => i.exerciseId).map(i => ({ exerciseId: i.exerciseId, sets: i.sets, reps: i.reps, restSec: i.restSec, loadKg: i.loadKg === '' ? null : Number(i.loadKg) })), notes: existing?.notes ?? '', updatedAt: Date.now() } satisfies WorkoutPlan);
    onSaved(); onClose(); bump(); toast(t('saved'));
  };
  const removeDay = async () => { if (existing && await confirm({ title: lang === 'ar' ? 'مسح جلسة اليوم؟' : 'Clear this day?', danger: true, confirmLabel: t('delete') })) { await db.del('workout_plans', existing.id); onSaved(); onClose(); bump(); } };
  return (
    <Sheet open={open} onClose={onClose} title={`${dayName} — ${lang === 'ar' ? 'الجلسة' : 'Session'}`} actions={existing ? <button className="icon-btn text-[var(--danger)]" onClick={removeDay}><Trash2 className="w-5 h-5" /></button> : undefined}>
      <Field label={lang === 'ar' ? 'اسم الجلسة' : 'Session name'}><input className="input" value={sessionName} onChange={e => setSessionName(e.target.value)} placeholder={lang === 'ar' ? 'دفع / سحب / أرجل / مشي…' : 'Push / Pull / Legs / Walk…'} /></Field>
      <span className="label">{lang === 'ar' ? 'التمارين' : 'Exercises'}</span>
      <div className="space-y-2 max-h-72 overflow-y-auto">
        {items.map((item, i) => (
          <div key={i} className="card-flat p-2">
            <select className="input !py-1.5 text-sm" value={item.exerciseId} onChange={e => setItems(arr => arr.map((x, j) => j === i ? { ...x, exerciseId: e.target.value } : x))}>
              <option value="">{lang === 'ar' ? 'اختر تمريناً…' : 'Pick exercise…'}</option>
              {exercises.map(e => <option key={e.id} value={e.id}>{lang === 'ar' ? e.nameAr : e.nameEn}</option>)}
            </select>
            <div className="flex gap-1.5 mt-1.5">
              {[['sets', lang === 'ar' ? 'مجموعات' : 'Sets'], ['reps', lang === 'ar' ? 'عدات' : 'Reps'], ['restSec', lang === 'ar' ? 'راحة (ث)' : 'Rest (s)']].map(([key, label]) => (
                <label key={key} className="flex-1"><span className="text-[0.55rem] font-bold text-3">{label}</span><input type="number" min={0} className="input !py-1 num text-sm" value={(item as any)[key]} onChange={e => setItems(arr => arr.map((x, j) => j === i ? { ...x, [key]: Math.max(0, Number(e.target.value) || 0) } : x))} /></label>
              ))}
              <label className="w-16"><span className="text-[0.55rem] font-bold text-3">{lang === 'ar' ? 'وزن' : 'kg'}</span><input type="number" min={0} className="input !py-1 num text-sm" value={item.loadKg} onChange={e => setItems(arr => arr.map((x, j) => j === i ? { ...x, loadKg: e.target.value } : x))} placeholder="—" /></label>
              <button className="icon-btn self-end" onClick={() => setItems(arr => arr.filter((_, j) => j !== i))} aria-label="remove"><X className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>
      <button className="btn btn-ghost btn-sm mt-2" onClick={() => setItems(arr => [...arr, { exerciseId: exercises[0]?.id ?? '', sets: 3, reps: 10, restSec: 60, loadKg: '' }])}><Plus className="w-4 h-4" />{lang === 'ar' ? 'تمرين' : 'Exercise'}</button>
      <button className="btn btn-primary w-full justify-center !py-3 mt-2" onClick={save}>{t('save')}</button>
    </Sheet>
  );
}

/* ---------- Guided execution with persistent rest timer ---------- */
function WorkoutExecutor({ plan, exMap, logs, onChanged }: { plan: WorkoutPlan | null; exMap: Record<string, Exercise>; logs: WorkoutLog[]; onChanged: () => void }) {
  const { lang, toast, bump } = useApp();
  const [active, setActive] = useState(false);
  const [exIdx, setExIdx] = useState(0);
  const [setIdx, setSetIdx] = useState(0);
  const [restEnd, setRestEnd] = useState<number | null>(null);
  const [restLeft, setRestLeft] = useState(0);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  useEffect(() => { const id = setInterval(() => { if (restEnd) { const left = Math.max(0, Math.round((restEnd - Date.now()) / 1000)); setRestLeft(left); if (left === 0) { setRestEnd(null); playChime('break'); haptic('heavy'); } } }, 500); return () => clearInterval(id); }, [restEnd]);

  if (!plan) return <EmptyState icon={<CalendarClock className="w-7 h-7" />} title={lang === 'ar' ? 'النهارده يوم راحة أو لسه مفيش تمرين' : 'No session planned today'} hint={lang === 'ar' ? 'خطط جلسة لهذا اليوم من تبويب الخطة الأسبوعية' : 'Plan a session for today in the weekly plan tab'} />;
  if (!plan.exercises.length) return <EmptyState icon={<Dumbbell className="w-7 h-7" />} title={lang === 'ar' ? 'الجلسة فارغة' : 'Empty session'} hint={lang === 'ar' ? 'أضف تمارين لهذه الجلسة من تبويب الخطة' : 'Add exercises from the plan tab'} />;

  const current = plan.exercises[exIdx];
  const exercise = exMap[current.exerciseId];
  const doneSets = plan.exercises.slice(0, exIdx).reduce((s, e) => s + e.sets, 0) + setIdx;
  const totalSets = plan.exercises.reduce((s, e) => s + e.sets, 0);
  const lastSame = logs.filter(l => l.sessionName === plan.sessionName).at(-1);

  const finishSet = async () => {
    haptic('light');
    if (setIdx + 1 < current.sets) { setSetIdx(s => s + 1); setRestEnd(Date.now() + current.restSec * 1000); return; }
    if (exIdx + 1 < plan.exercises.length) { setExIdx(i => i + 1); setSetIdx(0); setRestEnd(Date.now() + current.restSec * 1000); return; }
    // session complete
    const dur = startedAt ? Math.max(1, Math.round((Date.now() - startedAt) / 60000)) : 0;
    await db.put('workout_logs', { id: newId(), date: todayKey(), sessionName: plan.sessionName, exerciseCount: plan.exercises.length, totalSets, durationMin: dur, notes: '', createdAt: Date.now() } satisfies WorkoutLog);
    setActive(false); setExIdx(0); setSetIdx(0); setRestEnd(null); setStartedAt(null);
    playChime('complete'); haptic('heavy');
    toast(lang === 'ar' ? 'عاش يا وحش! التمرين خلص واتسجّل في سجلك 💪' : 'Session done — logged to your history');
    onChanged(); bump();
  };

  if (!active) {
    return (
      <div className="mt-3 anim-fade">
        <div className="card p-4">
          <div className="flex items-center gap-3"><div className="w-12 h-12 rounded-2xl grid place-items-center bg-[var(--accent-soft)] accent"><Dumbbell className="w-6 h-6" /></div>
            <div className="min-w-0"><p className="font-extrabold">{plan.sessionName}</p><p className="num text-[0.68rem] text-2">{plan.exercises.length} {lang === 'ar' ? 'تمرين' : 'exercises'} · {totalSets} {lang === 'ar' ? 'مجموعة' : 'sets'}</p></div>
          </div>
          <div className="mt-3 space-y-1">{plan.exercises.map((e, i) => { const ex = exMap[e.exerciseId]; return (
            <div key={i} className="flex items-center gap-2 text-sm"><span className="num text-[0.65rem] text-3 w-5">{i + 1}.</span><span className="flex-1 font-semibold truncate">{ex ? (lang === 'ar' ? ex.nameAr : ex.nameEn) : e.exerciseId}</span><span className="num text-[0.65rem] text-2">{e.sets}×{e.reps}{e.loadKg ? ` @ ${e.loadKg}kg` : ''}</span></div>
          ); })}</div>
          {lastSame && <p className="text-[0.62rem] text-3 mt-2">{lang === 'ar' ? 'آخر مرة: ' : 'Last time: '}{lastSame.date} · {lastSame.totalSets} {lang === 'ar' ? 'مجموعة' : 'sets'} · {lastSame.durationMin}{lang === 'ar' ? ' دقيقة' : ' min'}</p>}
          <button className="btn btn-primary w-full justify-center !py-3 mt-3" onClick={() => { setActive(true); setStartedAt(Date.now()); }}><Play className="w-5 h-5" fill="currentColor" />{lang === 'ar' ? 'ابدأ التمرين' : 'Start workout'}</button>
        </div>
      </div>
    );
  }
  return (
    <div className="mt-3 card p-5 anim-pop">
      <LinearProgress value={(doneSets / totalSets) * 100} className="mb-4" />
      <p className="text-[0.62rem] font-extrabold text-3 uppercase tracking-widest text-center">{lang === 'ar' ? `التمرين ${exIdx + 1} من ${plan.exercises.length}` : `Exercise ${exIdx + 1} of ${plan.exercises.length}`}</p>
      <h2 className="text-2xl font-extrabold text-center mt-1">{exercise ? (lang === 'ar' ? exercise.nameAr : exercise.nameEn) : current.exerciseId}</h2>
      <p className="num text-center text-[0.8rem] text-2 mt-0.5">{current.sets}×{current.reps}{current.loadKg != null ? ` @ ${current.loadKg}kg` : ''} · {lang === 'ar' ? 'راحة' : 'rest'} {current.restSec}s{exercise ? ` · ${exercise.muscleGroup}` : ''}</p>
      <div className="flex items-center justify-center gap-2 my-5">
        {Array.from({ length: current.sets }, (_, i) => (
          <div key={i} className={cn('w-11 h-11 rounded-2xl grid place-items-center font-extrabold num border transition-all', i < setIdx ? 'bg-[var(--ok)] border-transparent text-white' : i === setIdx ? 'border-[var(--accent)] text-[var(--accent)] scale-110' : 'border-[var(--border)] text-3')}>{i < setIdx ? <Check className="w-5 h-5" /> : i + 1}</div>
        ))}
      </div>
      {restEnd ? (
        <div className="text-center py-2">
          <p className="text-[0.65rem] font-extrabold text-2 uppercase">{lang === 'ar' ? 'راحة' : 'Rest'}</p>
          <p className="num text-6xl font-extrabold accent">{restLeft}</p>
          <button className="btn btn-ghost btn-sm mt-2" onClick={() => setRestEnd(null)}>{lang === 'ar' ? 'تخطي الراحة' : 'Skip rest'}</button>
        </div>
      ) : (
        <button className="btn btn-primary w-full justify-center !py-4 text-base" onClick={finishSet}><Check className="w-6 h-6" />{lang === 'ar' ? `أنهيت المجموعة ${setIdx + 1}` : `Set ${setIdx + 1} done`}</button>
      )}
      <button className="btn btn-quiet btn-sm w-full justify-center mt-2" onClick={() => { setActive(false); }}><Pause className="w-4 h-4" />{lang === 'ar' ? 'إيقاف مؤقت والعودة' : 'Pause & exit'}</button>
    </div>
  );
}

/* ---------- Exercise library ---------- */
function ExerciseLibrary({ exercises, onChanged }: { exercises: Exercise[]; onChanged: () => void }) {
  const { lang, t, toast, confirm } = useApp();
  const [muscle, setMuscle] = useState<string>('all');
  const [addOpen, setAddOpen] = useState(false);
  const [nameAr, setNameAr] = useState(''); const [nameEn, setNameEn] = useState(''); const [group, setGroup] = useState(''); const [equipment, setEquipment] = useState('');
  const groups = useMemo(() => ['all', ...new Set(exercises.map(e => e.muscleGroup))], [exercises]);
  const filtered = muscle === 'all' ? exercises : exercises.filter(e => e.muscleGroup === muscle);
  return (
    <div className="mt-3">
      <div className="flex items-center justify-between gap-2">
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">{groups.map(g => <button key={g} className={cn('chip flex-none', muscle === g && 'chip-active')} onClick={() => setMuscle(g)}>{g === 'all' ? (lang === 'ar' ? 'الكل' : 'All') : g}</button>)}</div>
        <button className="btn btn-soft btn-sm flex-none" onClick={() => setAddOpen(true)}><Plus className="w-4 h-4" />{lang === 'ar' ? 'مخصص' : 'Custom'}</button>
      </div>
      <div className="grid grid-cols-1 gap-1.5 mt-2">
        {filtered.map(e => (
          <div key={e.id} className="card-flat p-2.5 flex items-center gap-2.5">
            <Dumbbell className="w-5 h-5 text-2 shrink-0" />
            <div className="flex-1 min-w-0"><p className="font-bold text-sm">{lang === 'ar' ? e.nameAr : e.nameEn}</p><p className="text-[0.58rem] text-2">{e.muscleGroup} · {e.equipment}{e.instructions ? ` · ${e.instructions}` : ''}</p></div>
            {!e.builtin && <button className="icon-btn" aria-label="delete" onClick={async () => { if (await confirm({ title: lang === 'ar' ? 'حذف التمرين؟' : 'Delete exercise?', danger: true, confirmLabel: t('delete') })) { await db.del('exercises', e.id); onChanged(); } }}><Trash2 className="w-4 h-4" /></button>}
          </div>
        ))}
      </div>
      <Sheet open={addOpen} onClose={() => setAddOpen(false)} title={lang === 'ar' ? 'تمرين مخصص' : 'Custom exercise'}>
        <Field label={lang === 'ar' ? 'الاسم بالعربية' : 'Arabic name'}><input autoFocus className="input" value={nameAr} onChange={e => setNameAr(e.target.value)} /></Field>
        <Field label={lang === 'ar' ? 'الاسم بالإنجليزية' : 'English name'}><input className="input" value={nameEn} onChange={e => setNameEn(e.target.value)} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={lang === 'ar' ? 'مجموعة العضلات' : 'Muscle group'}><input className="input" value={group} onChange={e => setGroup(e.target.value)} placeholder={lang === 'ar' ? 'صدر…' : 'Chest…'} /></Field>
          <Field label={lang === 'ar' ? 'المعدة' : 'Equipment'}><input className="input" value={equipment} onChange={e => setEquipment(e.target.value)} placeholder={lang === 'ar' ? 'دمبل…' : 'Dumbbells…'} /></Field>
        </div>
        <button className="btn btn-primary w-full justify-center" onClick={async () => { if (!nameAr.trim() && !nameEn.trim()) return; await db.put('exercises', { id: newId(), nameAr: nameAr.trim() || nameEn.trim(), nameEn: nameEn.trim() || nameAr.trim(), muscleGroup: group.trim() || (lang === 'ar' ? 'عام' : 'General'), equipment: equipment.trim() || (lang === 'ar' ? 'بدون' : 'None'), instructions: '', builtin: false }); setAddOpen(false); setNameAr(''); setNameEn(''); setGroup(''); setEquipment(''); onChanged(); toast(t('saved')); }}>{t('save')}</button>
      </Sheet>
    </div>
  );
}
