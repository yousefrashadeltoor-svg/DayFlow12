/* DAYFLOW — Study: subjects · lessons · flashcards (spaced repetition) · exams */
import { useCallback, useEffect, useState } from 'react';
import {
  Plus, GraduationCap, BookOpen, Layers, CalendarClock, Trash2, ChevronLeft, Check, Flame,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, addDays, newId } from '@/lib/db';
import { Sheet, EmptyState, Field, Segmented, LinearProgress, HelpTip } from '@/components/ui';
import type { StudySubject, StudyLesson, Exam, Flashcard, FlashcardDeck } from '@/lib/types';
import { cn } from '@/utils/cn';

type StudyTab = 'subjects' | 'cards' | 'exams';

export default function StudyModule() {
  const { t, lang, tick, confirm, bump } = useApp();
  const [tab, setTab] = useState<StudyTab>('subjects');
  const [subjects, setSubjects] = useState<StudySubject[]>([]);
  const [lessons, setLessons] = useState<StudyLesson[]>([]);
  const [decks, setDecks] = useState<FlashcardDeck[]>([]);
  const [cards, setCards] = useState<Flashcard[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [subjectOpen, setSubjectOpen] = useState(false);
  const [lessonFor, setLessonFor] = useState<StudySubject | null>(null);
  const [examOpen, setExamOpen] = useState(false);

  const reload = useCallback(async () => {
    const [s, l, d, c, e] = await Promise.all([db.all<StudySubject>('study_subjects'), db.all<StudyLesson>('study_lessons'), db.all<FlashcardDeck>('flashcard_decks'), db.all<Flashcard>('flashcards'), db.all<Exam>('exams')]);
    setSubjects(s); setLessons(l); setDecks(d); setCards(c); setExams(e);
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const today = todayKey();
  const dueCards = cards.filter(c => c.dueDate <= today);
  const subjectProgress = (id: string) => { const ls = lessons.filter(l => l.subjectId === id); const est = ls.reduce((s, l) => s + l.estimatedMin, 0); if (!ls.length) return { pct: 0, estMin: 0, done: 0, total: 0 }; const done = ls.filter(l => l.status === 'done').length; return { pct: Math.round((done / ls.length) * 100), estMin: est, done, total: ls.length }; };

  return (
    <div className="pb-6 px-4 pt-14">
      <div className="flex items-center justify-between">
        <h1 className="skin-title font-extrabold flex items-center gap-2">{t('study')}<HelpTip title="المذاكرة والبطاقات الذكية"><p>نظّم موادك ودروسك وامتحاناتك مع عدّاد للأيام اللي فاضلة واقتراح تذاكر كام درس في اليوم.</p><p><b>البطاقات (التكرار المتباعد):</b> بتسألك سؤال وتقلبها تشوف الإجابة — والسهلة بترجعلك بعد مدة أطول (1، 3، 7، 21 يوم) عشان تثبّت في دماغك من غير حفظ ممل!</p></HelpTip></h1>
        <button className="icon-btn" onClick={() => tab === 'subjects' ? setSubjectOpen(true) : tab === 'exams' ? setExamOpen(true) : null} aria-label="add">{tab !== 'cards' && <Plus className="w-6 h-6" />}</button>
      </div>
      <div className="mt-2"><Segmented value={tab} onChange={v => setTab(v as StudyTab)} options={[{ value: 'subjects', label: t('subjects') }, { value: 'cards', label: `${t('flashcards')}${dueCards.length ? ` (${dueCards.length})` : ''}` }, { value: 'exams', label: t('exams') }]} /></div>

      {tab === 'subjects' && (
        <div className="space-y-2 mt-3">
          {subjects.map(s => {
            const p = subjectProgress(s.id);
            return (
              <button key={s.id} className="card w-full p-3 flex items-center gap-3 text-start" onClick={() => setLessonFor(s)}>
                <div className="w-11 h-11 rounded-2xl grid place-items-center shrink-0" style={{ background: `color-mix(in srgb, ${s.color} 18%, transparent)`, color: s.color }}><BookOpen className="w-6 h-6" /></div>
                <div className="flex-1 min-w-0">
                  <p className="font-extrabold truncate">{s.title}</p>
                  <LinearProgress value={p.pct} tone={s.color} className="mt-1.5" />
                  <p className="num text-[0.6rem] text-2 mt-1">{p.pct}% · {p.done}/{p.total} {lang === 'ar' ? 'درس' : 'lessons'} · {Math.round((p.estMin) / 60 * 10) / 10}{lang === 'ar' ? ' س تقديرية' : 'h est.'}{s.dueDate ? ` · ⏰ ${s.dueDate}` : ''}</p>
                </div>
                <ChevronLeft className="w-4 h-4 text-3 rtl:rotate-180" />
              </button>
            );
          })}
          {subjects.length === 0 && <EmptyState icon={<GraduationCap className="w-7 h-7" />} title={lang === 'ar' ? 'لسه مضفتش مواد' : 'No subjects yet'} hint={lang === 'ar' ? 'ضيف أول مادة وقسّمها لدروس — وهنتابع نسبتك الحقيقية' : 'Add your first subject and estimate its hours — we track progress precisely'} action={<button className="btn btn-primary" onClick={() => setSubjectOpen(true)}><Plus className="w-4 h-4" />{t('newSubject')}</button>} />}
        </div>
      )}

      {tab === 'cards' && <Flashcards decks={decks} cards={cards} dueCards={dueCards} onChanged={reload} />}

      {tab === 'exams' && (
        <div className="space-y-2 mt-3">
          {exams.map(e => {
            const subject = subjects.find(s => s.id === e.subjectId);
            const daysLeft = Math.ceil((new Date(e.date + 'T12:00:00').getTime() - Date.now()) / 86400000);
            const remainingLessons = subject ? lessons.filter(l => l.subjectId === subject.id && l.status !== 'done').length : 0;
            const dailyTarget = daysLeft > 0 ? Math.ceil(remainingLessons / daysLeft) : remainingLessons;
            return (
              <div key={e.id} className="card p-3">
                <div className="flex items-start gap-3">
                  <div className="w-14 flex flex-col items-center rounded-2xl py-1.5 shrink-0" style={{ background: daysLeft <= 3 ? 'var(--danger-soft)' : 'var(--accent-soft)' }}>
                    <span className="num text-xl font-extrabold leading-none" style={{ color: daysLeft <= 3 ? 'var(--danger)' : 'var(--accent)' }}>{Math.max(0, daysLeft)}</span>
                    <span className="text-[0.55rem] font-bold text-2">{lang === 'ar' ? 'يوم' : 'days'}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-extrabold leading-snug">{e.title}</p>
                    <p className="text-[0.65rem] text-2 font-semibold">{subject?.title}{e.location ? ` · ${e.location}` : ''} · <span dir="ltr" className="num">{e.date}</span></p>
                    {subject && remainingLessons > 0 && <p className="text-[0.62rem] accent font-bold mt-1">{lang === 'ar' ? `يتبقى ${remainingLessons} درساً — خطة: ${dailyTarget} درس/يوم حتى الاختبار` : `${remainingLessons} lessons left — suggested: ${dailyTarget} lesson(s)/day until the exam`}</p>}
                    <button className="icon-btn !w-7 !h-7 text-[var(--danger)]" aria-label={t('delete')} onClick={async () => { if (await confirm({ title: lang === 'ar' ? 'حذف الاختبار؟' : 'Delete exam?', danger: true, confirmLabel: t('delete') })) { await db.del('exams', e.id); bump(); } }}><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              </div>
            );
          })}
          {exams.length === 0 && <EmptyState icon={<CalendarClock className="w-7 h-7" />} title={lang === 'ar' ? 'مفيش امتحانات متسجلة' : 'No exams yet'} hint={lang === 'ar' ? 'ضيف امتحانك وهنحسبلك فاضل كام يوم وتذاكر كام درس يومياً' : 'Add your exam and get a revision plan for the remaining days'} action={<button className="btn btn-primary" onClick={() => setExamOpen(true)}><Plus className="w-4 h-4" />{t('exams')}</button>} />}
        </div>
      )}

      {/* subject creator */}
      <SubjectSheet open={subjectOpen} onClose={() => setSubjectOpen(false)} />
      {/* lessons manager */}
      <Sheet open={!!lessonFor} onClose={() => setLessonFor(null)} title={lessonFor?.title}>
        {lessonFor && <LessonsManager subject={lessonFor} lessons={lessons.filter(l => l.subjectId === lessonFor.id)} onChanged={reload} />}
      </Sheet>
      {/* exam creator */}
      <ExamSheet open={examOpen} onClose={() => setExamOpen(false)} subjects={subjects} />
    </div>
  );
}

function SubjectSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { lang, t, toast, bump } = useApp();
  const [title, setTitle] = useState(''); const [hours, setHours] = useState(30); const [difficulty, setDifficulty] = useState<1|2|3|4|5>(3); const [color, setColor] = useState('#7c5cfc'); const [dueDate, setDueDate] = useState('');
  const colors = ['#7c5cfc', '#5856d6', '#0e8a94', '#e0356a', '#d97706', '#0da271', '#2f7de1'];
  const save = async () => {
    if (!title.trim()) { toast(lang === 'ar' ? 'أدخل اسم المادة' : 'Enter subject name'); return; }
    await db.put('study_subjects', { id: newId(), title: title.trim(), color, icon: 'book-open', estimatedHours: hours, difficulty, priority: Math.min(4, difficulty) as any, dueDate: dueDate || null, notes: '', createdAt: Date.now() });
    setTitle(''); onClose(); bump(); toast(t('saved'));
  };
  return (
    <Sheet open={open} onClose={onClose} title={lang === 'ar' ? 'مادة جديدة' : 'New subject'}>
      <Field label={lang === 'ar' ? 'الاسم' : 'Name'}><input autoFocus className="input" value={title} onChange={e => setTitle(e.target.value)} placeholder={lang === 'ar' ? 'رياضيات — تفاضل وتكامل…' : 'Mathematics — Calculus…'} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label={lang === 'ar' ? 'الساعات التقديرية' : 'Est. hours'}><input type="number" min={1} className="input num" value={hours} onChange={e => setHours(Math.max(1, Number(e.target.value) || 1))} /></Field>
        <Field label={lang === 'ar' ? 'تاريخ الإنجاز' : 'Target date'}><input type="date" className="input num" value={dueDate} onChange={e => setDueDate(e.target.value)} /></Field>
      </div>
      <Field label={lang === 'ar' ? 'الصعوبة' : 'Difficulty'}>
        <div className="flex gap-1.5">{[1, 2, 3, 4, 5].map(d => <button key={d} className={cn('chip num', difficulty === d && 'chip-active')} onClick={() => setDifficulty(d as any)}>{'★'.repeat(d)}</button>)}</div>
      </Field>
      <span className="label">{lang === 'ar' ? 'اللون' : 'Color'}</span>
      <div className="flex gap-2 mb-4">{colors.map(c => <button key={c} onClick={() => setColor(c)} className={cn('w-8 h-8 rounded-full', color === c && 'scale-125 ring-2 ring-offset-2 ring-[var(--accent)]')} style={{ background: c }} aria-label={c} />)}</div>
      <button className="btn btn-primary w-full justify-center !py-3" onClick={save}>{t('save')}</button>
    </Sheet>
  );
}

function LessonsManager({ subject, lessons, onChanged }: { subject: StudySubject; lessons: StudyLesson[]; onChanged: () => void }) {
  const { lang, t, bump, toast, confirm } = useApp();
  const [newLesson, setNewLesson] = useState(''); const [est, setEst] = useState(30);
  const add = async () => {
    if (!newLesson.trim()) return;
    await db.put('study_lessons', { id: newId(), subjectId: subject.id, title: newLesson.trim(), unit: '', estimatedMin: est, actualMin: 0, status: 'todo', order: lessons.length, difficulty: subject.difficulty });
    setNewLesson(''); onChanged(); bump();
  };
  const toggle = async (l: StudyLesson) => { await db.put('study_lessons', { ...l, status: l.status === 'done' ? 'todo' : 'done' }); onChanged(); bump(); };
  const logMinutes = async (l: StudyLesson, mins: number) => { await db.put('study_lessons', { ...l, actualMin: l.actualMin + mins }); onChanged(); toast(`+${mins} ${lang === 'ar' ? 'دقيقة فعلية' : 'actual min'}`); };
  return (
    <div>
      <div className="flex gap-2">
        <input className="input flex-1" autoFocus value={newLesson} onChange={e => setNewLesson(e.target.value)} placeholder={lang === 'ar' ? 'درس جديد…' : 'New lesson…'} onKeyDown={e => e.key === 'Enter' && add()} />
        <input type="number" className="input w-20 num" min={5} step={5} value={est} onChange={e => setEst(Math.max(5, Number(e.target.value) || 5))} title={lang === 'ar' ? 'التقدير بالدقائق' : 'Estimated minutes'} />
        <button className="btn btn-primary btn-sm" onClick={add}><Plus className="w-4 h-4" /></button>
      </div>
      <div className="mt-3 space-y-1.5 max-h-[52vh] overflow-y-auto">
        {lessons.map(l => (
          <div key={l.id} className="card-flat px-2.5 py-2 flex items-center gap-2">
            <button className="icon-btn !w-7 !h-7" onClick={() => toggle(l)} aria-label="toggle"><span className={cn('w-5 h-5 rounded-md border grid place-items-center', l.status === 'done' ? 'bg-[var(--ok)] border-transparent text-white' : 'border-[var(--border-strong)]')}>{l.status === 'done' && <Check className="w-3.5 h-3.5" />}</span></button>
            <div className="flex-1 min-w-0"><p className={cn('text-sm font-bold leading-snug', l.status === 'done' && 'line-through opacity-60')}>{l.title}</p><p className="num text-[0.58rem] text-3">~{l.estimatedMin}m · {lang === 'ar' ? 'الفعلي' : 'actual'} {l.actualMin}m</p></div>
            <button className="chip" onClick={() => logMinutes(l, 25)}>+25m</button>
            <button className="icon-btn !w-7 !h-7 text-[var(--danger)]" onClick={async () => { if (await confirm({ title: lang === 'ar' ? 'حذف الدرس؟' : 'Delete lesson?', danger: true, confirmLabel: t('delete') })) { await db.del('study_lessons', l.id); onChanged(); } }}><Trash2 className="w-4 h-4" /></button>
          </div>
        ))}
        {lessons.length === 0 && <p className="text-sm text-2 text-center py-6">{lang === 'ar' ? 'لا توجد دروس — أضف أول درس' : 'No lessons yet'}</p>}
      </div>
    </div>
  );
}

function ExamSheet({ open, onClose, subjects }: { open: boolean; onClose: () => void; subjects: StudySubject[] }) {
  const { lang, t, toast, bump } = useApp();
  const [title, setTitle] = useState(''); const [subjectId, setSubjectId] = useState(''); const [date, setDate] = useState(''); const [timeMin, setTimeMin] = useState(9 * 60); const [location, setLocation] = useState('');
  const save = async () => {
    if (!title.trim() || !date) { toast(lang === 'ar' ? 'أكمل الاسم والتاريخ' : 'Name and date required'); return; }
    await db.put('exams', { id: newId(), title: title.trim(), subjectId: subjectId || null, date, timeMin, location, topics: [], createdAt: Date.now() });
    setTitle(''); setDate(''); setLocation(''); onClose(); bump(); toast(t('saved'));
  };
  return (
    <Sheet open={open} onClose={onClose} title={lang === 'ar' ? 'اختبار جديد' : 'New exam'}>
      <Field label={lang === 'ar' ? 'الاسم' : 'Name'}><input autoFocus className="input" value={title} onChange={e => setTitle(e.target.value)} placeholder={lang === 'ar' ? 'اختبار الرياضيات نهاية الفصل…' : 'Midterm calculus…'} /></Field>
      <Field label={lang === 'ar' ? 'المادة' : 'Subject'}><select className="input" value={subjectId} onChange={e => setSubjectId(e.target.value)}><option value="">{lang === 'ar' ? '—' : '—'}</option>{subjects.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}</select></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label={lang === 'ar' ? 'التاريخ' : 'Date'}><input type="date" className="input num" value={date} onChange={e => setDate(e.target.value)} /></Field>
        <Field label={lang === 'ar' ? 'الوقت (دقيقة من منتصف الليل)' : 'Time (min from midnight)'}><input type="time" className="input num" value={`${String(Math.floor(timeMin / 60)).padStart(2, '0')}:${String(timeMin % 60).padStart(2, '0')}`} onChange={e => { const [h, m] = e.target.value.split(':').map(Number); setTimeMin(h * 60 + m); }} /></Field>
      </div>
      <Field label={lang === 'ar' ? 'المكان' : 'Location'}><input className="input" value={location} onChange={e => setLocation(e.target.value)} placeholder={lang === 'ar' ? 'قاعة ب-٢١…' : 'Hall B-21…'} /></Field>
      <button className="btn btn-primary w-full justify-center !py-3" onClick={save}>{t('save')}</button>
    </Sheet>
  );
}

function Flashcards({ decks, cards, dueCards, onChanged }: { decks: FlashcardDeck[]; cards: Flashcard[]; dueCards: Flashcard[]; onChanged: () => void }) {
  const { lang, t, toast, confirm, settings } = useApp();
  const [deckOpen, setDeckOpen] = useState(false);
  const [reviewDeck, setReviewDeck] = useState<FlashcardDeck | null>(null);
  const [flipped, setFlipped] = useState(false);
  const [front, setFront] = useState(''); const [back, setBack] = useState(''); const [newDeckName, setNewDeckName] = useState('');
  const intervals: number[] = settings.flashcardIntervals ?? [1, 3, 7, 21];

  const activeDeck = reviewDeck ?? decks[0] ?? null;
  const deckCards = activeDeck ? cards.filter(c => c.deckId === activeDeck.id) : [];
  const deckDue = deckCards.filter(c => c.dueDate <= todayKey());
  const current = deckDue[0] ?? null;

  const rate = async (quality: 'again' | 'hard' | 'good' | 'easy') => {
    if (!current) return;
    const step = { again: 0, hard: 1, good: 2, easy: 3 }[quality];
    const interval = quality === 'again' ? 1 : intervals[Math.min(step, intervals.length - 1)];
    const ease = Math.max(1.3, Math.min(2.8, current.ease + ({ again: -0.2, hard: -0.05, good: 0.05, easy: 0.15 }[quality])));
    await db.put('flashcards', { ...current, intervalDays: interval, ease, reps: current.reps + 1, dueDate: addDays(todayKey(), interval) });
    setFlipped(false); onChanged();
  };

  return (
    <div className="mt-3">
      {reviewDeck ? (
        <div className="anim-fade">
          <button className="btn btn-quiet btn-sm mb-2" onClick={() => { setReviewDeck(null); setFlipped(false); }}><ChevronLeft className="w-4 h-4 rtl:rotate-180" />{lang === 'ar' ? 'كل البطاقات' : 'All decks'}</button>
          {current ? (
            <>
              <p className="text-center text-[0.7rem] font-extrabold text-2">{reviewDeck.name} · <span className="accent">{deckDue.length} {lang === 'ar' ? 'مستحقة' : 'due'}</span></p>
              <button className="card w-full mt-2 p-8 min-h-56 flex flex-col items-center justify-center text-center" onClick={() => setFlipped(v => !v)} aria-pressed={flipped}>
                <span className="text-[0.6rem] font-extrabold text-3 uppercase tracking-widest">{flipped ? (lang === 'ar' ? 'الإجابة' : 'Answer') : (lang === 'ar' ? 'السؤال' : 'Question')} — {lang === 'ar' ? 'اضغط للقلب' : 'tap to flip'}</span>
                <p className="text-xl font-extrabold leading-snug mt-4">{flipped ? current.back : current.front}</p>
              </button>
              <div className="grid grid-cols-4 gap-2 mt-3">
                {[['again', lang === 'ar' ? 'مجدداً' : 'Again', 'var(--danger)'], ['hard', lang === 'ar' ? 'صعبة' : 'Hard', 'var(--warn)'], ['good', lang === 'ar' ? 'جيدة' : 'Good', 'var(--info)'], ['easy', lang === 'ar' ? 'سهلة' : 'Easy', 'var(--ok)']].map(([q, label, color]) =>
                  <button key={q as string} onClick={() => rate(q as any)} className="btn btn-ghost btn-sm justify-center" style={{ color: color as string }}>{label as string}</button>)}
              </div>
            </>
          ) : (
            <EmptyState icon={<Flame className="w-7 h-7" />} title={lang === 'ar' ? 'عاش! خلصت كل بطاقات النهارده 🎉' : 'No cards due today'} hint={lang === 'ar' ? 'ارجع بكرة — المخ بيثبّت المعلومات بين المراجعات' : 'Come back tomorrow — spaced repetition means memory is consolidating'} />
          )}
          {/* add card */}
          <div className="card p-3 mt-3">
            <p className="text-[0.7rem] font-extrabold text-2 mb-1.5">{lang === 'ar' ? 'بطاقة جديدة' : 'New card'}</p>
            <input className="input mb-1.5" placeholder={lang === 'ar' ? 'السؤال…' : 'Front…'} value={front} onChange={e => setFront(e.target.value)} />
            <input className="input mb-1.5" placeholder={lang === 'ar' ? 'الإجابة…' : 'Back…'} value={back} onChange={e => setBack(e.target.value)} />
            <button className="btn btn-primary btn-sm w-full justify-center" onClick={async () => { if (front.trim() && back.trim() && activeDeck) { await db.put('flashcards', { id: newId(), deckId: activeDeck.id, front: front.trim(), back: back.trim(), intervalDays: intervals[0], ease: 2.5, dueDate: todayKey(), reps: 0, createdAt: Date.now() }); setFront(''); setBack(''); onChanged(); toast(t('saved')); } }}><Plus className="w-4 h-4" />{lang === 'ar' ? 'أضف البطاقة' : 'Add card'}</button>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold text-2">{decks.length} {lang === 'ar' ? 'مجموعة' : 'decks'} · <span className="accent">{dueCards.length} {lang === 'ar' ? 'مستحقة الآن' : 'due now'}</span></p>
            <button className="btn btn-soft btn-sm" onClick={() => setDeckOpen(true)}><Plus className="w-4 h-4" />{lang === 'ar' ? 'مجموعة' : 'Deck'}</button>
          </div>
          <div className="space-y-2 mt-2">
            {decks.map(d => {
              const count = cards.filter(c => c.deckId === d.id).length;
              const due = cards.filter(c => c.deckId === d.id && c.dueDate <= todayKey()).length;
              return (
                <button key={d.id} className="card w-full p-3 flex items-center gap-3 text-start" onClick={() => setReviewDeck(d)}>
                  <div className="w-11 h-11 rounded-2xl grid place-items-center" style={{ background: `color-mix(in srgb, ${d.color} 18%, transparent)`, color: d.color }}><Layers className="w-6 h-6" /></div>
                  <div className="flex-1 min-w-0"><p className="font-extrabold truncate">{d.name}</p><p className="num text-[0.62rem] text-2">{count} {lang === 'ar' ? 'بطاقة' : 'cards'}{due ? ` · ${due} ${lang === 'ar' ? 'مستحقة' : 'due'}` : ''}</p></div>
                  {due > 0 && <span className="num text-[0.7rem] font-extrabold rounded-full bg-[var(--accent)] text-[var(--on-accent)] px-2 py-0.5">{due}</span>}
                  <button className="icon-btn text-[var(--danger)]" aria-label="delete" onClick={async e => { e.stopPropagation(); if (await confirm({ title: lang === 'ar' ? 'حذف المجموعة وبطاقاتها؟' : 'Delete deck and its cards?', danger: true, confirmLabel: t('delete') })) { for (const c of cards.filter(c => c.deckId === d.id)) await db.del('flashcards', c.id); await db.del('flashcard_decks', d.id); onChanged(); } }}><Trash2 className="w-4 h-4" /></button>
                </button>
              );
            })}
            {decks.length === 0 && <EmptyState icon={<Layers className="w-7 h-7" />} title={lang === 'ar' ? 'مفيش مجموعات بطاقات لسه' : 'No decks yet'} hint={lang === 'ar' ? 'أنشئ مجموعتك الأولى وراجع بفواصل 1 · 3 · 7 · 21 يوماً (قابلة للتعديل من الإعدادات)' : 'Create your first deck and review at 1 · 3 · 7 · 21-day intervals (editable in Settings)'} action={<button className="btn btn-primary" onClick={() => setDeckOpen(true)}><Plus className="w-4 h-4" />{lang === 'ar' ? 'مجموعة جديدة' : 'New deck'}</button>} />}
          </div>
        </>
      )}
      <Sheet open={deckOpen} onClose={() => setDeckOpen(false)} title={lang === 'ar' ? 'مجموعة جديدة' : 'New deck'}>
        <Field label={lang === 'ar' ? 'الاسم' : 'Name'}><input autoFocus className="input" value={newDeckName} onChange={e => setNewDeckName(e.target.value)} placeholder={lang === 'ar' ? 'مصطلحات الفصل الثالث…' : 'Chapter 3 terms…'} onKeyDown={async e => { if (e.key === 'Enter' && newDeckName.trim()) { await db.put('flashcard_decks', { id: newId(), name: newDeckName.trim(), subjectId: null, color: '#7c5cfc', createdAt: Date.now() }); setNewDeckName(''); setDeckOpen(false); onChanged(); } }} /></Field>
        <button className="btn btn-primary w-full justify-center" onClick={async () => { if (newDeckName.trim()) { await db.put('flashcard_decks', { id: newId(), name: newDeckName.trim(), subjectId: null, color: '#7c5cfc', createdAt: Date.now() }); setNewDeckName(''); setDeckOpen(false); onChanged(); } }}>{t('save')}</button>
      </Sheet>
    </div>
  );
}
