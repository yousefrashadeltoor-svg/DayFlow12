/* DAYFLOW — Tasks & Projects: inbox → done, schedule tasks into real blocks */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Plus, Star, Check, Trash2, CalendarClock, FolderPlus, Flag, CheckSquare, ListChecks, X,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, newId, nowMin } from '@/lib/db';
import { Sheet, EmptyState, Field, Segmented, LinearProgress, HelpTip } from '@/components/ui';
import { haptic } from '@/lib/platform';
import type { TaskItem, Project, ProjectMilestone } from '@/lib/types';
import { cn } from '@/utils/cn';

type Filter = 'inbox' | 'today' | 'overdue' | 'upcoming' | 'starred' | 'someday' | 'done';

export default function TasksModule({ params }: { params?: any }) {
  const { t, lang, tick, toast, bump, applyBlockMutation } = useApp();
  const [view, setView] = useState<'tasks' | 'projects'>('tasks');
  const [filter, setFilter] = useState<Filter>('inbox');
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [milestones, setMilestones] = useState<ProjectMilestone[]>([]);
  const [editorOpen, setEditorOpen] = useState(!!params?.create);
  const [editing, setEditing] = useState<TaskItem | null>(null);
  const [projectOpen, setProjectOpen] = useState(false);
  const [projectDetail, setProjectDetail] = useState<Project | null>(null);

  const reload = useCallback(async () => {
    const [t2, p, m] = await Promise.all([db.all<TaskItem>('tasks'), db.all<Project>('projects'), db.all<ProjectMilestone>('project_milestones')]);
    setTasks(t2); setProjects(p); setMilestones(m);
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const today = todayKey();
  const filtered = useMemo(() => {
    const open = tasks.filter(x => x.status !== 'cancelled');
    switch (filter) {
      case 'inbox': return open.filter(x => x.status === 'inbox' || x.status === 'todo');
      case 'today': return open.filter(x => x.status !== 'done' && x.dueDate === today);
      case 'overdue': return open.filter(x => x.status !== 'done' && x.dueDate && x.dueDate < today);
      case 'upcoming': return open.filter(x => x.status !== 'done' && x.dueDate && x.dueDate > today);
      case 'starred': return open.filter(x => x.starred && x.status !== 'done');
      case 'someday': return open.filter(x => x.status === 'someday');
      case 'done': return open.filter(x => x.status === 'done');
    }
  }, [tasks, filter, today]);
  const counts = useMemo(() => ({
    overdue: tasks.filter(x => x.status !== 'done' && x.dueDate && x.dueDate < today).length,
    today: tasks.filter(x => x.status !== 'done' && x.dueDate === today).length,
  }), [tasks, today]);

  const toggleDone = async (task: TaskItem) => {
    const done = task.status !== 'done';
    await db.put('tasks', { ...task, status: done ? 'done' : 'todo', updatedAt: Date.now() });
    haptic('light'); bump();
  };
  const toggleStar = async (task: TaskItem) => { await db.put('tasks', { ...task, starred: !task.starred, updatedAt: Date.now() }); bump(); };
  const scheduleTask = async (task: TaskItem) => {
    const s = Math.ceil(nowMin() / 15) * 15 + 15;
    await db.put('activity_blocks', {
      id: newId(), title: task.title, description: task.description ?? '', categoryId: task.categoryId || 'work',
      date: today, startMin: s, endMin: s + task.estimatedMin, fixed: false, priority: task.priority, energy: 'medium',
      difficulty: 3, status: 'planned', recurrence: 'none', reminderMin: 10, sound: 'default', repeatCount: 1,
      isCritical: false, splitAllowed: true, earliestStartMin: null, latestEndMin: null,
      linkedTaskId: task.id, linkedGoalId: task.goalId, linkedSubjectId: null, tags: task.tags, notes: '',
      actualStartMin: null, actualEndMin: null, createdAt: Date.now(), updatedAt: Date.now(),
    });
    toast(lang === 'ar' ? 'اتجدولت النهارده ✓ شوفها في صفحة النهارده' : 'Scheduled — check the Today tab');
    await applyBlockMutation();
  };
  const deleteTask = async (task: TaskItem) => {
    const stash = task; await db.del('tasks', task.id); bump();
    toast(t('deleted'), { actionLabel: t('undo'), onAction: async () => { await db.put('tasks', stash); bump(); } });
  };

  /* ---------- editor form state ---------- */
  const [title, setTitle] = useState(''); const [dueDate, setDueDate] = useState(''); const [priority, setPriority] = useState<1|2|3|4>(3);
  const [estimatedMin, setEstimatedMin] = useState(30); const [starred, setStarred] = useState(false); const [projectId, setProjectId] = useState<string>('');
  const [checklist, setChecklist] = useState<Array<{ id: string; text: string; done: boolean }>>([]);
  const [notes, setNotes] = useState(''); const [newCheck, setNewCheck] = useState('');
  const openEditor = (task: TaskItem | null) => {
    setEditing(task);
    setTitle(task?.title ?? ''); setDueDate(task?.dueDate ?? ''); setPriority(task?.priority ?? 3);
    setEstimatedMin(task?.estimatedMin ?? 30); setStarred(task?.starred ?? false); setProjectId(task?.projectId ?? '');
    setChecklist(task?.checklist ?? []); setNotes(task?.notes ?? ''); setNewCheck('');
    setEditorOpen(true);
  };
  const saveTask = async () => {
    if (!title.trim()) { toast(lang === 'ar' ? 'أدخل عنوان المهمة' : 'Enter a task title'); return; }
    const base = { title: title.trim(), dueDate: dueDate || null, priority, estimatedMin, starred, projectId: projectId || null, checklist, notes, updatedAt: Date.now() };
    if (editing) await db.put('tasks', { ...editing, ...base });
    else await db.put('tasks', { id: newId(), ...base, description: '', startDate: null, status: 'todo', trackedMin: 0, categoryId: 'work', tags: [], goalId: null, recurrence: 'none', reminderAt: null, createdAt: Date.now() } satisfies TaskItem);
    setEditorOpen(false); bump(); toast(t('saved'));
  };

  const priorityColor = (p: number) => p === 1 ? 'var(--danger)' : p === 2 ? 'var(--warn)' : p === 3 ? 'var(--info)' : 'var(--text-3)';

  const filters: Array<{ id: Filter; label: string; badge?: number }> = [
    { id: 'inbox', label: t('inbox') }, { id: 'today', label: t('today'), badge: counts.today },
    { id: 'overdue', label: t('overdue'), badge: counts.overdue }, { id: 'upcoming', label: t('upcoming') },
    { id: 'starred', label: t('starred') }, { id: 'someday', label: t('someday') }, { id: 'done', label: lang === 'ar' ? 'مكتملة' : 'Done' },
  ];

  return (
    <div className="pb-6 px-4 pt-14">
      <div className="flex items-center justify-between">
        <h1 className="skin-title font-extrabold flex items-center gap-2">{t('tasks')}<HelpTip title="المهام والمشاريع"><p>سجّل أي حاجة محتاج تعملها، ورتّبها بالأولوية أو اربطها بمشروع كبير له مراحل. وأي مهمة تقدر تدوس على أيقونة الساعة جنبها عشان تنزل في جدول النهارده وتجيلك في الإشعارات!</p></HelpTip></h1>
        <button className="icon-btn" onClick={() => view === 'tasks' ? openEditor(null) : setProjectOpen(true)} aria-label="add"><Plus className="w-6 h-6" /></button>
      </div>
      <div className="mt-2"><Segmented value={view} onChange={v => setView(v as any)} options={[{ value: 'tasks', label: t('allTasks') }, { value: 'projects', label: t('projects') }]} /></div>

      {view === 'tasks' && (<>
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar mt-3 pb-1">
          {filters.map(f => (
            <button key={f.id} className={cn('chip flex-none', filter === f.id && 'chip-active')} onClick={() => setFilter(f.id)}>
              {f.label}{f.badge ? <span className="num ms-1 rounded-full bg-[var(--danger)] text-white text-[0.6rem] px-1.5">{f.badge}</span> : null}
            </button>
          ))}
        </div>
        <div className="space-y-1.5 mt-2">
          {filtered.map(task => (
            <div key={task.id} className="card-flat p-2.5 flex items-start gap-2">
              <button onClick={() => toggleDone(task)} className={cn('w-6 h-6 rounded-full border-2 grid place-items-center shrink-0 mt-0.5 transition-colors', task.status === 'done' ? 'bg-[var(--ok)] border-transparent text-white' : 'border-[var(--border-strong)]')} aria-label="toggle">{task.status === 'done' && <Check className="w-4 h-4" />}</button>
              <button className="flex-1 min-w-0 text-start" onClick={() => openEditor(task)}>
                <span className={cn('block text-sm font-bold leading-snug', task.status === 'done' && 'line-through opacity-60')}>{task.title}</span>
                <span className="flex items-center gap-2 mt-1 flex-wrap">
                  <span className="w-2 h-2 rounded-full" style={{ background: priorityColor(task.priority) }} />
                  {task.dueDate && <span className={cn('num text-[0.62rem] font-bold', task.dueDate < today && task.status !== 'done' ? 'text-[var(--danger)]' : 'text-2')}>{task.dueDate}</span>}
                  <span className="num text-[0.62rem] text-3">~{task.estimatedMin}{lang === 'ar' ? 'د' : 'm'}</span>
                  {task.checklist.length > 0 && <span className="num text-[0.62rem] text-2 flex items-center gap-0.5"><CheckSquare className="w-3 h-3" />{task.checklist.filter(c => c.done).length}/{task.checklist.length}</span>}
                </span>
              </button>
              <button className="icon-btn" onClick={() => toggleStar(task)} aria-label="star" aria-pressed={task.starred}><Star className={cn('w-4 h-4', task.starred && 'fill-[var(--warn)] text-[var(--warn)]')} /></button>
              <button className="icon-btn" onClick={() => scheduleTask(task)} aria-label="schedule" title={lang === 'ar' ? 'جدولة لليوم' : 'Schedule today'}><CalendarClock className="w-4 h-4" /></button>
            </div>
          ))}
          {filtered.length === 0 && <EmptyState icon={<ListChecks className="w-7 h-7" />} title={lang === 'ar' ? 'مفيش مهام هنا دلوقتي' : 'Nothing here'} hint={lang === 'ar' ? 'ضيف أول مهمة — تقدر كمان تنقلها لجدول يومك بضغطة' : 'Add a task — everything persists on-device'} action={<button className="btn btn-primary" onClick={() => openEditor(null)}><Plus className="w-4 h-4" />{t('addTask')}</button>} />}
        </div>
      </>)}

      {view === 'projects' && (
        <div className="space-y-2 mt-3">
          {projects.map(p => {
            const pTasks = tasks.filter(x => x.projectId === p.id);
            const pDone = pTasks.filter(x => x.status === 'done').length;
            const pMilestones = milestones.filter(m => m.projectId === p.id);
            const mDone = pMilestones.filter(m => m.done).length;
            const pct = (pTasks.length + pMilestones.length) ? Math.round(((pDone + mDone) / (pTasks.length + pMilestones.length)) * 100) : 0;
            return (
              <button key={p.id} className="card w-full p-3 flex items-center gap-3 text-start" onClick={() => setProjectDetail(p)}>
                <div className="w-11 h-11 rounded-2xl grid place-items-center text-lg" style={{ background: `color-mix(in srgb, ${p.color} 18%, transparent)` }}>{p.icon || '📁'}</div>
                <div className="flex-1 min-w-0">
                  <p className="font-extrabold truncate">{p.title}</p>
                  <LinearProgress value={pct} className="mt-1.5" tone={p.color} />
                  <p className="num text-[0.58rem] text-3 mt-1">{pct}% · {pDone}/{pTasks.length} {lang === 'ar' ? 'مهمة' : 'tasks'}{p.deadline ? ` · ${p.deadline}` : ''}</p>
                </div>
              </button>
            );
          })}
          {projects.length === 0 && <EmptyState icon={<FolderPlus className="w-7 h-7" />} title={lang === 'ar' ? 'مفيش مشاريع لسه' : 'No projects yet'} hint={lang === 'ar' ? 'اعمل مشروع كبير وقسّمه لمراحل ومهام صغيرة' : 'Create a project and link your tasks'} action={<button className="btn btn-primary" onClick={() => setProjectOpen(true)}><Plus className="w-4 h-4" />{t('projects')}</button>} />}
        </div>
      )}

      {/* task editor */}
      <Sheet open={editorOpen} onClose={() => setEditorOpen(false)} title={editing ? (lang === 'ar' ? 'تعديل المهمة' : 'Edit task') : t('addTask')}
        actions={editing ? <button className="icon-btn text-[var(--danger)]" onClick={() => { deleteTask(editing); setEditorOpen(false); }}><Trash2 className="w-5 h-5" /></button> : undefined}>
        <Field label={lang === 'ar' ? 'العنوان' : 'Title'}><input autoFocus className="input" value={title} onChange={e => setTitle(e.target.value)} placeholder={lang === 'ar' ? 'عايز تخلص إيه؟' : 'What do you want to finish?'} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={lang === 'ar' ? 'تاريخ الاستحقاق' : 'Due date'}><input type="date" className="input num" value={dueDate} onChange={e => setDueDate(e.target.value)} /></Field>
          <Field label={lang === 'ar' ? 'التقدير (دقيقة)' : 'Estimate (min)'}><input type="number" min={5} step={5} className="input num" value={estimatedMin} onChange={e => setEstimatedMin(Math.max(5, Number(e.target.value) || 5))} /></Field>
        </div>
        <div className="grid grid-cols-2 gap-3 items-end">
          <Field label={lang === 'ar' ? 'الأولوية' : 'Priority'}>
            <select className="input" value={priority} onChange={e => setPriority(Number(e.target.value) as any)}>
              {[1, 2, 3, 4].map(p => <option key={p} value={p}>{lang === 'ar' ? ['١ قصوى', '٢ عالية', '٣ متوسطة', '٤ هادئة'][p - 1] : ['1 Critical', '2 High', '3 Medium', '4 Low'][p - 1]}</option>)}
            </select>
          </Field>
          <Field label={t('projects')}>
            <select className="input" value={projectId} onChange={e => setProjectId(e.target.value)}>
              <option value="">{lang === 'ar' ? 'بدون مشروع' : 'No project'}</option>
              {projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
            </select>
          </Field>
        </div>
        <button className={cn('chip mb-3', starred && 'chip-active')} onClick={() => setStarred(v => !v)}><Star className={cn('w-3.5 h-3.5', starred && 'fill-current')} />{t('starred')}</button>
        <span className="label">{lang === 'ar' ? 'قائمة التحقق' : 'Checklist'}</span>
        <div className="space-y-1 mb-2">
          {checklist.map(c => (
            <div key={c.id} className="flex items-center gap-2">
              <button className="icon-btn !w-7 !h-7" onClick={() => setChecklist(arr => arr.map(x => x.id === c.id ? { ...x, done: !x.done } : x))}><span className={cn('w-5 h-5 rounded-md border grid place-items-center', c.done ? 'bg-[var(--ok)] border-transparent text-white' : 'border-[var(--border-strong)]')}>{c.done && <Check className="w-3.5 h-3.5" />}</span></button>
              <span className={cn('flex-1 text-sm', c.done && 'line-through opacity-60')}>{c.text}</span>
              <button className="icon-btn !w-7 !h-7" onClick={() => setChecklist(arr => arr.filter(x => x.id !== c.id))}><X className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
        <div className="flex gap-2"><input className="input flex-1 !py-2" value={newCheck} onChange={e => setNewCheck(e.target.value)} placeholder={lang === 'ar' ? 'ضيف خطوة واضغط Enter…' : 'Add item, Enter…'} onKeyDown={e => { if (e.key === 'Enter' && newCheck.trim()) { setChecklist(arr => [...arr, { id: newId(), text: newCheck.trim(), done: false }]); setNewCheck(''); } }} /><button className="btn btn-ghost btn-sm" onClick={() => { if (newCheck.trim()) { setChecklist(arr => [...arr, { id: newId(), text: newCheck.trim(), done: false }]); setNewCheck(''); } }}><Plus className="w-4 h-4" /></button></div>
        <Field label={lang === 'ar' ? 'ملاحظات' : 'Notes'}><textarea className="input min-h-[56px]" value={notes} onChange={e => setNotes(e.target.value)} /></Field>
        <button className="btn btn-primary w-full justify-center !py-3" onClick={saveTask}>{t('save')}</button>
      </Sheet>

      {/* project creator */}
      <ProjectCreator open={projectOpen} onClose={() => setProjectOpen(false)} />

      {/* project detail */}
      <Sheet open={!!projectDetail} onClose={() => setProjectDetail(null)} title={projectDetail?.title}>
        {projectDetail && <ProjectDetail project={projectDetail} onDeleted={() => { setProjectDetail(null); bump(); }} />}
      </Sheet>
    </div>
  );
}

function ProjectCreator({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { lang, t, toast, bump } = useApp();
  const [title, setTitle] = useState(''); const [deadline, setDeadline] = useState(''); const [color, setColor] = useState('#5856d6'); const [icon, setIcon] = useState('📁');
  const save = async () => {
    if (!title.trim()) { toast(lang === 'ar' ? 'أدخل اسم المشروع' : 'Enter a project name'); return; }
    await db.put('projects', { id: newId(), title: title.trim(), description: '', objective: '', deadline: deadline || null, color, icon, status: 'active', createdAt: Date.now(), notes: '' });
    setTitle(''); setDeadline(''); onClose(); bump(); toast(t('saved'));
  };
  const colors = ['#5856d6', '#0e8a94', '#e0356a', '#d97706', '#0da271', '#2f7de1'];
  const icons = ['📁', '🚀', '🎓', '💼', '🏋️', '📚', '🌍', '💡'];
  return (
    <Sheet open={open} onClose={onClose} title={lang === 'ar' ? 'مشروع جديد' : 'New project'}>
      <Field label={lang === 'ar' ? 'الاسم' : 'Name'}><input autoFocus className="input" value={title} onChange={e => setTitle(e.target.value)} placeholder={lang === 'ar' ? 'مشروع بحث التخرج…' : 'Thesis research…'} /></Field>
      <Field label={lang === 'ar' ? 'الموعد النهائي' : 'Deadline'}><input type="date" className="input num" value={deadline} onChange={e => setDeadline(e.target.value)} /></Field>
      <span className="label">{lang === 'ar' ? 'اللون' : 'Color'}</span>
      <div className="flex gap-2 mb-3">{colors.map(c => <button key={c} onClick={() => setColor(c)} className={cn('w-8 h-8 rounded-full transition-transform', color === c && 'scale-125 ring-2 ring-offset-2 ring-[var(--accent)]')} style={{ background: c }} aria-label={c} />)}</div>
      <span className="label">{lang === 'ar' ? 'الأيقونة' : 'Icon'}</span>
      <div className="flex gap-1.5 mb-4 text-xl">{icons.map(i => <button key={i} onClick={() => setIcon(i)} className={cn('w-10 h-10 rounded-xl grid place-items-center', icon === i ? 'bg-[var(--accent-soft)] ring-1 ring-[var(--accent)]' : 'hover:bg-[var(--surface-2)]')}>{i}</button>)}</div>
      <button className="btn btn-primary w-full justify-center !py-3" onClick={save}>{t('save')}</button>
    </Sheet>
  );
}

function ProjectDetail({ project, onDeleted }: { project: Project; onDeleted: () => void }) {
  const { lang, t, confirm, toast } = useApp();
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [milestones, setMilestones] = useState<ProjectMilestone[]>([]);
  const [newMilestone, setNewMilestone] = useState('');
  const reload = useCallback(async () => {
    const [tk, ms] = await Promise.all([db.all<TaskItem>('tasks'), db.all<ProjectMilestone>('project_milestones')]);
    setTasks(tk.filter(x => x.projectId === project.id)); setMilestones(ms.filter(m => m.projectId === project.id).sort((a, b) => a.order - b.order));
  }, [project.id]);
  useEffect(() => { reload(); }, [reload]);
  const pDone = tasks.filter(x => x.status === 'done').length;
  const pct = (tasks.length + milestones.length) ? Math.round(((pDone + milestones.filter(m => m.done).length) / (tasks.length + milestones.length)) * 100) : 0;
  return (
    <div>
      <div className="flex items-center gap-3">
        <span className="text-3xl">{project.icon}</span>
        <div className="flex-1"><LinearProgress value={pct} tone={project.color} /><p className="num text-[0.65rem] text-2 mt-1">{pct}% · {pDone}/{tasks.length} {lang === 'ar' ? 'مهمة منجزة' : 'tasks done'}</p></div>
      </div>
      <p className="text-[0.7rem] font-extrabold text-2 uppercase mt-4 mb-1 flex items-center gap-1"><Flag className="w-4 h-4" />{lang === 'ar' ? 'المعالم' : 'Milestones'}</p>
      <div className="space-y-1">{milestones.map(m => (
        <button key={m.id} className="w-full flex items-center gap-2 py-1.5 px-2 rounded-xl hover:bg-[var(--surface-2)] text-start" onClick={async () => { await db.put('project_milestones', { ...m, done: !m.done }); reload(); }}>
          <span className={cn('w-5 h-5 rounded-md border grid place-items-center', m.done ? 'bg-[var(--ok)] border-transparent text-white' : 'border-[var(--border-strong)]')}>{m.done && <Check className="w-3.5 h-3.5" />}</span>
          <span className={cn('flex-1 text-sm', m.done && 'line-through opacity-60')}>{m.title}</span>
          <Trash2 className="w-4 h-4 text-3" onClick={async e => { e.stopPropagation(); await db.del('project_milestones', m.id); reload(); }} />
        </button>
      ))}</div>
      <div className="flex gap-2 mt-1.5"><input className="input flex-1 !py-2" value={newMilestone} onChange={e => setNewMilestone(e.target.value)} placeholder={lang === 'ar' ? 'معلم جديد…' : 'New milestone…'} onKeyDown={async e => { if (e.key === 'Enter' && newMilestone.trim()) { await db.put('project_milestones', { id: newId(), projectId: project.id, title: newMilestone.trim(), done: false, dueDate: null, order: milestones.length }); setNewMilestone(''); reload(); } }} /><button className="btn btn-ghost btn-sm" onClick={async () => { if (newMilestone.trim()) { await db.put('project_milestones', { id: newId(), projectId: project.id, title: newMilestone.trim(), done: false, dueDate: null, order: milestones.length }); setNewMilestone(''); reload(); } }}><Plus className="w-4 h-4" /></button></div>
      <p className="text-[0.7rem] font-extrabold text-2 uppercase mt-4 mb-1">{lang === 'ar' ? 'مهام المشروع' : 'Project tasks'}</p>
      {tasks.map(tk => <div key={tk.id} className="flex items-center gap-2 py-1 text-sm"><span className={cn('w-2 h-2 rounded-full', tk.status === 'done' ? 'bg-[var(--ok)]' : 'bg-[var(--border-strong)]')} /><span className={cn('flex-1', tk.status === 'done' && 'line-through opacity-60')}>{tk.title}</span></div>)}
      {tasks.length === 0 && <p className="text-xs text-3">{lang === 'ar' ? 'اربط مهاماً بهذا المشروع من محرر المهمة' : 'Link tasks to this project from the task editor'}</p>}
      <button className="btn btn-danger btn-sm w-full justify-center mt-4" onClick={async () => { if (await confirm({ title: lang === 'ar' ? 'حذف المشروع؟' : 'Delete project?', body: lang === 'ar' ? 'لن تُحذف مهامه.' : 'Its tasks will be kept.', danger: true, confirmLabel: t('delete') })) { await db.del('projects', project.id); toast(t('deleted')); onDeleted(); } }}><Trash2 className="w-4 h-4" />{lang === 'ar' ? 'حذف المشروع' : 'Delete project'}</button>
    </div>
  );
}
