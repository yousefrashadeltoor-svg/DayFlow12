/* DAYFLOW — Professional Native Alarm Studio
   · Full system integration: Default / Alarm tone / Phone ringtone / Music app picker (MediaStore Audio — NOT generic file explorer!)
   · Audio Trim Studio with REAL native PCM waveform decoded via MediaExtractor+MediaCodec (honest notice when fallback)
   · Label · exact time · weekdays & quick presets · snooze gap · max snoozes · repeat count · gradual volume · vibration · TTS spoken text */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Plus, Trash2, Music2, BellRing, Smartphone, PhoneCall, Play, Square, Scissors,
  Volume2, Vibrate, MessageSquareText, Clock3, Copy, Repeat,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, newId, isNative, minToTime } from '@/lib/db';
import { platform, haptic } from '@/lib/platform';
import { Sheet, Field, Toggle, HelpTip, SettingRow, EmptyState } from '@/components/ui';
import { cn } from '@/utils/cn';

export interface UserAlarm {
  id: string; hour: number; minute: number; label: string; days: number[]; enabled: boolean;
  snoozeMin: number; maxSnoozes: number; repeatCount: number;
  toneUri: string; toneName: string; toneKind: 'default' | 'alarm' | 'ringtone' | 'music';
  clipStartMs: number; clipEndMs: number; durationMs: number;
  peaks?: number[]; realWaveform?: boolean;
  volume: number; gradual: boolean; vibrate: boolean; speakLabel: boolean; createdAt: number;
}

const DAY_AR = ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];
const DAY_FULL = ['الأحد', 'الاتنين', 'التلات', 'الأربع', 'الخميس', 'الجمعة', 'السبت'];
const fmtMs = (ms: number) => {
  const s = Math.max(0, Math.round(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

function nextRing(a: UserAlarm, now = new Date()): Date | null {
  for (let d = 0; d < 8; d++) {
    const t = new Date(now);
    t.setDate(now.getDate() + d);
    t.setHours(a.hour, a.minute, 0, 0);
    if (t <= now) continue;
    if (!a.days.length || a.days.includes(t.getDay())) return t;
  }
  return null;
}

function untilLabel(t: Date | null, lang: 'ar' | 'en') {
  if (!t) return '';
  const total = Math.max(1, Math.round((t.getTime() - Date.now()) / 60000));
  const days = Math.floor(total / 1440);
  const h = Math.floor((total % 1440) / 60);
  const m = total % 60;
  if (lang === 'en') return `Rings in ${days ? `${days}d ` : ''}${h ? `${h}h ` : ''}${m}m`;
  const parts = [days ? `${days} يوم` : '', h ? `${h} ساعة` : '', m ? `${m} دقيقة` : ''].filter(Boolean);
  return `هيرن بعد ${parts.join(' و ')}`;
}

const blank = (): UserAlarm => ({
  id: newId(), hour: 7, minute: 0, label: '', days: [], enabled: true,
  snoozeMin: 10, maxSnoozes: 3, repeatCount: 10,
  toneUri: '', toneName: 'نغمة المنبه الافتراضية', toneKind: 'default',
  clipStartMs: 0, clipEndMs: 0, durationMs: 0,
  volume: 0.9, gradual: true, vibrate: true, speakLabel: false, createdAt: Date.now(),
});

export default function AlarmsModule() {
  const { lang, hour12, tick, bump, toast, confirm, settings } = useApp();
  const [alarms, setAlarms] = useState<UserAlarm[]>([]);
  const [edit, setEdit] = useState<UserAlarm | null>(null);
  const [trimOpen, setTrimOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [loadingWave, setLoadingWave] = useState(false);
  const [, setClock] = useState(0);

  useEffect(() => { const id = setInterval(() => setClock(x => x + 1), 30_000); return () => clearInterval(id); }, []);

  const reload = useCallback(async () => {
    const all = await db.all<UserAlarm>('user_alarms');
    setAlarms(all.map(a => ({ ...a, repeatCount: a.repeatCount ?? 10 })).sort((a, b) => a.hour * 60 + a.minute - (b.hour * 60 + b.minute)));
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const persist = async (a: UserAlarm, silent = false) => {
    await db.put('user_alarms', a);
    const res: any = await platform.setUserAlarm(a);
    bump();
    if (silent) return;
    if (res.unsupported) toast(lang === 'ar' ? 'المنبه اتحفظ ✓ — الرنين الحقيقي فوق شاشة القفل شغال في تطبيق الأندرويد' : 'Saved ✓ — real lock-screen ringing runs inside Android');
    else if (!res.ok) toast(lang === 'ar' ? `حصلت مشكلة في ضبط المنبه: ${res.error ?? ''}` : `Alarm failed: ${res.error ?? ''}`);
    else if (a.enabled) toast(`${untilLabel(nextRing(a), lang)}${res.exact === false ? ' ⚠️ فعّل المنبهات الدقيقة' : ' ✓'}`);
    else toast(lang === 'ar' ? 'المنبه اتقفل' : 'Alarm turned off');
  };

  const order = useMemo(() => Array.from({ length: 7 }, (_, i) => (settings.weekStart + i) % 7), [settings.weekStart]);

  const pickTone = async (kind: 'alarm' | 'ringtone' | 'music') => {
    if (!edit) return;
    if (!isNative()) {
      toast(lang === 'ar' ? 'اختيار نغمة أو أغنية من الموبايل شغال جوه تطبيق الأندرويد' : 'Tone picker works inside the Android app');
      return;
    }
    const res: any = kind === 'music'
      ? await platform.pickMusicTone()
      : await platform.pickSystemTone(kind, edit.toneUri);
    if (res.cancelled) return;
    if (!res.ok) { toast(lang === 'ar' ? `مقدرناش نفتح الصوت: ${res.error ?? ''}` : `Failed: ${res.error ?? ''}`); return; }
    const dur = Number(res.durationMs) || 0;
    const peaks = Array.isArray(res.peaks) && res.peaks.length ? res.peaks : undefined;
    const defaultEnd = kind === 'music' && dur > 0 ? Math.min(dur, 30_000) : 0;
    setEdit({
      ...edit, toneUri: res.uri,
      toneName: res.name || (kind === 'ringtone' ? 'نغمة الهاتف' : kind === 'alarm' ? 'نغمة المنبه' : 'أغنية مختارة'),
      toneKind: kind, durationMs: dur, clipStartMs: 0, clipEndMs: defaultEnd,
      peaks, realWaveform: !!res.realWaveform,
    });
    if (kind === 'music' && dur > 0) setTrimOpen(true);
  };

  const openTrim = async () => {
    if (!edit) return;
    setTrimOpen(true);
    if (isNative() && edit.toneUri && !edit.peaks?.length) {
      setLoadingWave(true);
      const r: any = await platform.extractWaveform(edit.toneUri, 64);
      setLoadingWave(false);
      if (r.ok && Array.isArray(r.peaks) && r.peaks.length) {
        setEdit(cur => cur ? { ...cur, peaks: r.peaks, realWaveform: !!r.realWaveform } : cur);
      }
    }
  };

  const preview = async () => {
    if (!edit) return;
    if (playing) { await platform.stopAlarmAudio(); setPlaying(false); return; }
    const res: any = await platform.previewClip(edit.toneUri || null, edit.clipStartMs, edit.clipEndMs, edit.volume);
    if (res.ok) {
      setPlaying(true);
      setTimeout(() => setPlaying(false), Math.min(45_000, Number(res.playingMs) || 15_000));
    } else {
      toast(res.unsupported ? 'معاينة النغمة شغالة جوه تطبيق الأندرويد' : `تعذّر تشغيل الصوت: ${res.error ?? ''}`);
    }
  };

  const setClipPreset = (seconds: number) => {
    if (!edit || !edit.durationMs) return;
    const ms = seconds * 1000;
    const s = Math.min(edit.clipStartMs, Math.max(0, edit.durationMs - 3000));
    setEdit({ ...edit, clipStartMs: s, clipEndMs: Math.min(edit.durationMs, s + ms) });
  };

  const nudge = (which: 's' | 'e', deltaMs: number) => {
    if (!edit || !edit.durationMs) return;
    const dur = edit.durationMs;
    const curE = edit.clipEndMs || dur;
    if (which === 's') {
      const s = Math.max(0, Math.min(edit.clipStartMs + deltaMs, curE - 3000));
      setEdit({ ...edit, clipStartMs: s, clipEndMs: curE });
    } else {
      const e = Math.min(dur, Math.max(curE + deltaMs, edit.clipStartMs + 3000));
      setEdit({ ...edit, clipEndMs: e });
    }
  };

  const nextActive = alarms.filter(a => a.enabled).map(a => ({ a, at: nextRing(a) })).filter(x => x.at).sort((x, y) => x.at!.getTime() - y.at!.getTime())[0];

  return (
    <div className="pb-6 px-4 pt-14">
      <div className="flex items-center justify-between gap-2">
        <h1 className="skin-title font-extrabold flex items-center gap-2">
          <img src="/decor/alarm.png" alt="" className="w-8 h-8 decor-float" />
          {lang === 'ar' ? 'المنبهات' : 'Alarms'}
          <HelpTip title="المنبه الاحترافي">
            <p>منبه حقيقي مربوط مباشرة بـ <b>AlarmManager</b> في أندرويد — بيرن في الدقيقة بالظبط حتى لو قفلت التطبيق أو شاشة الموبايل مطفية، ويظهرلك بشاشة كاملة فوق القفل.</p>
            <ul>
              <li>تقدر تختار نغمة المنبه أو نغمة رنين الموبايل أو أغنية من <b>تطبيق الموسيقى</b> بتاعك.</li>
              <li>بعد اختيار الأغنية بتفتحلك صفحة <b>قص الصوت</b> عشان تحدد المقطع اللي تحب تصحى عليه بالظبط.</li>
              <li>المنبه بيستمر يشتغل حتى بعد ريستارت الموبايل، وبيقف صوت أي موسيقى تانية شغالة لما يرن.</li>
            </ul>
          </HelpTip>
        </h1>
        <button className="btn btn-primary btn-sm" onClick={() => setEdit(blank())}>
          <Plus className="w-4 h-4" />{lang === 'ar' ? 'منبه جديد' : 'New'}
        </button>
      </div>

      {nextActive && (
        <div className="card p-3 mt-3 flex items-center gap-3" style={{ background: 'linear-gradient(135deg, var(--surface), var(--accent-soft))' }}>
          <img src="/decor/bell.png" alt="" className="w-9 h-9 decor-twinkle" />
          <div className="flex-1 min-w-0">
            <p className="text-[0.62rem] font-extrabold text-2">{lang === 'ar' ? 'المنبه الجاي' : 'Next alarm'}</p>
            <p className="font-extrabold text-sm truncate">{nextActive.a.label || 'منبه'} · <span className="num accent">{minToTime(nextActive.a.hour * 60 + nextActive.a.minute, hour12)}</span></p>
            <p className="text-[0.62rem] accent font-bold">{untilLabel(nextActive.at, lang)}</p>
          </div>
        </div>
      )}

      {!isNative() && (
        <p className="text-[0.65rem] text-2 mt-2.5 card-flat p-2.5">
          ℹ️ في المعاينة على المتصفح المنبهات بتتحفظ بس — الرنين الحقيقي فوق شاشة القفل واختيار الأغاني وقصّها شغال في تطبيق الأندرويد.
        </p>
      )}

      <div className="space-y-2.5 mt-3">
        {alarms.map(a => (
          <div key={a.id} className={cn('card p-4 flex items-center gap-3 transition-opacity', !a.enabled && 'opacity-55')}>
            <button className="flex-1 text-start min-w-0" onClick={() => setEdit({ ...a })}>
              <p className="num text-[2.2rem] font-extrabold tracking-tight leading-none" dir="ltr" style={{ textAlign: lang === 'ar' ? 'right' : 'left' }}>
                {minToTime(a.hour * 60 + a.minute, hour12)}
              </p>
              <p className="text-[0.78rem] font-bold mt-1.5 truncate">{a.label || (lang === 'ar' ? 'منبه' : 'Alarm')}</p>
              <p className="text-[0.62rem] text-2 mt-0.5 truncate">
                {a.days.length === 0 ? 'مرة واحدة' : a.days.length === 7 ? 'كل يوم' : order.filter(d => a.days.includes(d)).map(d => DAY_FULL[d]).join('، ')}
                {' · '}🎵 {a.toneName}
                {a.clipEndMs > a.clipStartMs ? ` (${fmtMs(a.clipStartMs)}–${fmtMs(a.clipEndMs)})` : ''}
              </p>
              {a.enabled && <p className="text-[0.62rem] accent font-bold mt-0.5">{untilLabel(nextRing(a), lang)}</p>}
            </button>
            <Toggle on={a.enabled} onChange={v => { haptic('light'); persist({ ...a, enabled: v }); }} label="toggle alarm" />
          </div>
        ))}
        {alarms.length === 0 && (
          <EmptyState
            icon={<BellRing className="w-7 h-7" />}
            title={lang === 'ar' ? 'مفيش منبهات لسه' : 'No alarms yet'}
            hint={lang === 'ar' ? 'اعمل منبه واصحى على أغنيتك أو المقطع اللي بتحبه 🎶' : 'Add an alarm and wake up to your favourite clip'}
            action={<button className="btn btn-primary" onClick={() => setEdit(blank())}><Plus className="w-4 h-4" />{lang === 'ar' ? 'منبه جديد' : 'New alarm'}</button>}
          />
        )}
      </div>

      {/* Alarm Editor Sheet */}
      <Sheet
        open={!!edit}
        onClose={() => { setEdit(null); platform.stopAlarmAudio(); setPlaying(false); }}
        title={alarms.some(a => a.id === edit?.id) ? (lang === 'ar' ? 'تعديل المنبه' : 'Edit alarm') : (lang === 'ar' ? 'منبه جديد' : 'New alarm')}
        actions={edit && alarms.some(a => a.id === edit.id) ? (
          <>
            <button className="icon-btn" aria-label="duplicate" title="نسخ المنبه" onClick={async () => { await persist({ ...edit, id: newId(), label: (edit.label || 'منبه') + ' (نسخة)', createdAt: Date.now() }); setEdit(null); }}><Copy className="w-4 h-4" /></button>
            <button className="icon-btn text-[var(--danger)]" aria-label="delete" onClick={async () => {
              if (await confirm({ title: 'تمسح المنبه ده؟', danger: true, confirmLabel: 'امسح' })) {
                await db.del('user_alarms', edit.id); await platform.deleteUserAlarm(edit.id); setEdit(null); bump();
              }
            }}><Trash2 className="w-5 h-5" /></button>
          </>
        ) : undefined}
      >
        {edit && (
          <div>
            <div className="flex justify-center py-2">
              <input
                type="time"
                className="num text-5xl font-extrabold bg-transparent text-center outline-none rounded-2xl px-5 py-2 border-2 border-[var(--accent)]"
                value={`${String(edit.hour).padStart(2, '0')}:${String(edit.minute).padStart(2, '0')}`}
                onChange={e => { const [h, m] = e.target.value.split(':').map(Number); setEdit({ ...edit, hour: h || 0, minute: m || 0 }); }}
              />
            </div>
            <p className="text-center text-[0.7rem] accent font-bold mb-2">{untilLabel(nextRing(edit), lang)}</p>

            <Field label="نص المنبه (بيظهر على الشاشة وقت الرنين)">
              <input className="input" value={edit.label} onChange={e => setEdit({ ...edit, label: e.target.value })} placeholder="اصحى يا بطل — ميعاد الشغل / الامتحان ☀️" />
            </Field>

            <span className="label flex items-center gap-1.5">
              أيام التنبيه
              <HelpTip title="أيام التنبيه">
                <p>اختار الأيام اللي المنبه يرن فيها كل أسبوع. لو سيبتهم كلهم فاضيين، هيرن <b>مرة واحدة بس</b> في أقرب ميعاد وبعدها يقفل لوحده.</p>
              </HelpTip>
            </span>
            <div className="flex gap-1.5 mb-1.5">
              {order.map(d => (
                <button
                  key={d}
                  onClick={() => setEdit({ ...edit, days: edit.days.includes(d) ? edit.days.filter(x => x !== d) : [...edit.days, d] })}
                  className={cn('flex-1 aspect-square rounded-full font-extrabold text-sm transition-all', edit.days.includes(d) ? 'bg-[var(--accent)] text-[var(--on-accent)] scale-105 shadow-sm' : 'bg-[var(--surface-2)] text-2')}
                  aria-pressed={edit.days.includes(d)}
                >{DAY_AR[d]}</button>
              ))}
            </div>
            <div className="flex flex-wrap gap-1.5 mb-3">
              <button className="chip" onClick={() => setEdit({ ...edit, days: [0, 1, 2, 3, 4, 5, 6] })}>كل يوم</button>
              <button className="chip" onClick={() => setEdit({ ...edit, days: [0, 1, 2, 3, 4] })}>أيام الشغل</button>
              <button className="chip" onClick={() => setEdit({ ...edit, days: [5, 6] })}>الجمعة والسبت</button>
              <button className="chip" onClick={() => setEdit({ ...edit, days: [] })}>مرة واحدة</button>
            </div>

            {/* Tone picker: all 4 authentic Android native sources */}
            <span className="label flex items-center gap-1.5">
              نغمة المنبه
              <HelpTip title="اختيار النغمة وقصها">
                <ul>
                  <li><b>الافتراضية:</b> نغمة المنبه الأساسية للموبايل.</li>
                  <li><b>نغمة المنبه:</b> تفتح قائمة نغمات المنبه المثبتة على جهازك.</li>
                  <li><b>نغمة الموبايل:</b> تفتح نغمات الرنين العادية لموبايلك.</li>
                  <li><b>من الموسيقى:</b> بتفتح <b>تطبيق اختيار الموسيقى</b> الافتراضي (مش مدير الملفات!) وتنسخ الأغنية بأمان جوه التطبيق وتفتحلك صفحة قص عشان تختار الجزء المفضل منها.</li>
                </ul>
              </HelpTip>
            </span>
            <div className="card-flat p-3 mb-2 flex items-center gap-2">
              <Music2 className="w-5 h-5 accent shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold truncate">{edit.toneName}</p>
                {edit.clipEndMs > edit.clipStartMs && (
                  <p className="num text-[0.62rem] accent font-bold">✂️ من {fmtMs(edit.clipStartMs)} لـ {fmtMs(edit.clipEndMs)} ({Math.round((edit.clipEndMs - edit.clipStartMs) / 1000)}ث)</p>
                )}
              </div>
              <button className="icon-btn" onClick={preview} aria-label="preview tone" title="اسمع">{playing ? <Square className="w-4 h-4 text-[var(--danger)]" /> : <Play className="w-4 h-4 accent" />}</button>
              {(edit.durationMs > 3000) && (
                <button className="icon-btn" onClick={openTrim} aria-label="trim audio" title="قص جزء من الصوت"><Scissors className="w-4 h-4" /></button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-1.5 mb-3">
              <button className={cn('btn btn-ghost btn-sm justify-center !text-[0.68rem]', edit.toneKind === 'default' && '!border-[var(--accent)] accent')}
                onClick={() => setEdit({ ...edit, toneUri: '', toneName: 'نغمة المنبه الافتراضية', toneKind: 'default', clipStartMs: 0, clipEndMs: 0, durationMs: 0, peaks: undefined })}>
                <BellRing className="w-3.5 h-3.5" />الافتراضية
              </button>
              <button className={cn('btn btn-ghost btn-sm justify-center !text-[0.68rem]', edit.toneKind === 'alarm' && '!border-[var(--accent)] accent')}
                onClick={() => pickTone('alarm')}>
                <Smartphone className="w-3.5 h-3.5" />نغمة المنبه
              </button>
              <button className={cn('btn btn-ghost btn-sm justify-center !text-[0.68rem]', edit.toneKind === 'ringtone' && '!border-[var(--accent)] accent')}
                onClick={() => pickTone('ringtone')}>
                <PhoneCall className="w-3.5 h-3.5" />نغمة الهاتف
              </button>
              <button className={cn('btn btn-soft btn-sm justify-center !text-[0.68rem]', edit.toneKind === 'music' && 'ring-1 ring-[var(--accent)]')}
                onClick={() => pickTone('music')}>
                <Music2 className="w-3.5 h-3.5" />من تطبيق الموسيقى
              </button>
            </div>

            <div className="card-flat px-3">
              <SettingRow label="الفرق بين الغفوات (دقيقة)" help={<p>لما تدوس <b>غفوة</b>، المنبه هيسكت ويرنلك تاني بعد المدة دي بالظبط.</p>}>
                <select className="input !py-1.5 !w-20 num" value={edit.snoozeMin} onChange={e => setEdit({ ...edit, snoozeMin: Number(e.target.value) })}>
                  {[1, 2, 3, 5, 10, 15, 20, 30].map(n => <option key={n} value={n}>{n} د</option>)}
                </select>
              </SettingRow>
              <SettingRow label="أقصى عدد غفوات" help={<p>عشان ما تفضلش تدوس غفوة وتنام 😅 بعد العدد ده زرار الغفوة بيتقفل ولازم توقف المنبه.</p>}>
                <select className="input !py-1.5 !w-20 num" value={edit.maxSnoozes} onChange={e => setEdit({ ...edit, maxSnoozes: Number(e.target.value) })}>
                  {[0, 1, 2, 3, 5, 10].map(n => <option key={n} value={n}>{n === 0 ? 'ممنوع' : `${n}×`}</option>)}
                </select>
              </SettingRow>
              <SettingRow label="تكرار النغمة" help={<p>كام مرة النغمة أو المقطع المقصوص يعيد نفسه في المرة الواحدة (بحد أقصى أمان 5 دقايق عشان البطارية).</p>}>
                <span className="flex items-center gap-1.5"><Repeat className="w-3.5 h-3.5 text-2" />
                  <select className="input !py-1.5 !w-20 num" value={edit.repeatCount} onChange={e => setEdit({ ...edit, repeatCount: Number(e.target.value) })}>
                    {[1, 2, 3, 5, 10, 20, 30].map(n => <option key={n} value={n}>{n}× </option>)}
                  </select>
                </span>
              </SettingRow>
              <SettingRow label="علو الصوت" hint={`${Math.round(edit.volume * 100)}%`}>
                <span className="flex items-center gap-2"><Volume2 className="w-4 h-4 text-2" />
                  <input type="range" min={0.1} max={1} step={0.05} value={edit.volume} onChange={e => setEdit({ ...edit, volume: Number(e.target.value) })} className="w-24 accent-[var(--accent)]" />
                </span>
              </SettingRow>
              <SettingRow label="صوت يعلى تدريجيًا" help={<p>المنبه يبدأ هادي ويعلى شوية بشوية خلال 18 ثانية — صحيان مريح من غير خضّة.</p>}>
                <Toggle on={edit.gradual} onChange={v => setEdit({ ...edit, gradual: v })} />
              </SettingRow>
              <SettingRow label="اهتزاز"><span className="flex items-center gap-2"><Vibrate className="w-4 h-4 text-2" /><Toggle on={edit.vibrate} onChange={v => setEdit({ ...edit, vibrate: v })} /></span></SettingRow>
              <SettingRow label="انطق نص المنبه بصوت" help={<p>الموبايل هيقرأ النص اللي كتبته بصوت عالي (بمحرك النطق TTS اللي على جهازك) قبل ما النغمة تبدأ.</p>}>
                <span className="flex items-center gap-2"><MessageSquareText className="w-4 h-4 text-2" /><Toggle on={edit.speakLabel} onChange={v => setEdit({ ...edit, speakLabel: v })} /></span>
              </SettingRow>
            </div>

            <button className="btn btn-primary w-full justify-center !py-3 mt-3" onClick={async () => {
              haptic('medium');
              await persist({ ...edit, enabled: true });
              setEdit(null);
              platform.stopAlarmAudio();
              setPlaying(false);
            }}>
              <Clock3 className="w-4 h-4" />{lang === 'ar' ? 'احفظ وشغّل المنبه' : 'Save & turn on'}
            </button>
          </div>
        )}
      </Sheet>

      {/* Audio Trim Studio (with genuine MediaCodec-decoded PCM waveform on Android) */}
      <Sheet open={trimOpen && !!edit} onClose={() => { setTrimOpen(false); platform.stopAlarmAudio(); setPlaying(false); }} title="✂️ قصّ مقطع النغمة">
        {edit && edit.durationMs > 0 && (() => {
          const dur = edit.durationMs;
          const s = edit.clipStartMs;
          const e = edit.clipEndMs > s ? edit.clipEndMs : dur;
          const bars: number[] = edit.peaks?.length
            ? edit.peaks
            : Array.from({ length: 64 }, (_, i) => 0.25 + Math.abs(Math.sin(i * 1.43) * 0.55));
          return (
            <div>
              <p className="text-sm font-extrabold truncate">{edit.toneName}</p>
              <div className="flex items-center justify-between text-[0.68rem] text-2 mt-0.5 num">
                <span>طول الملف: {fmtMs(dur)}</span>
                <span className="accent font-extrabold">المقطع: {fmtMs(s)} → {fmtMs(e)} ({Math.round((e - s) / 1000)}ث)</span>
              </div>

              {/* Quick selection length presets */}
              <div className="flex gap-1.5 mt-2.5">
                {[15, 30, 45, 60].filter(sec => sec * 1000 <= dur).map(sec => (
                  <button key={sec} className="chip num" onClick={() => setClipPreset(sec)}>{sec} ثانية</button>
                ))}
                <button className="chip" onClick={() => setEdit({ ...edit, clipStartMs: 0, clipEndMs: dur })}>كلها</button>
              </div>

              {/* Waveform */}
              <div className="relative h-24 mt-3 rounded-2xl overflow-hidden px-1 flex items-center gap-[1.5px]" style={{ background: 'var(--surface-2)' }} dir="ltr">
                {loadingWave && <div className="skeleton absolute inset-0" />}
                {bars.map((v, i) => {
                  const pos = ((i + 0.5) / bars.length) * dur;
                  const inside = pos >= s && pos <= e;
                  return (
                    <span
                      key={i}
                      className="flex-1 rounded-full transition-colors"
                      style={{
                        height: `${Math.round(Math.max(12, Math.min(92, v * 90)))}%`,
                        background: inside ? 'var(--accent)' : 'var(--border-strong)',
                        opacity: inside ? 1 : 0.45,
                      }}
                    />
                  );
                })}
                <span className="absolute inset-y-0 border-l-2 border-[var(--accent)] pointer-events-none" style={{ left: `${(s / dur) * 100}%` }} />
                <span className="absolute inset-y-0 border-l-2 border-[var(--accent)] pointer-events-none" style={{ left: `${(e / dur) * 100}%` }} />
              </div>
              <p className="text-[0.58rem] text-3 mt-1">
                {edit.realWaveform ? '✓ موجة الصوت الحقيقية مستخرجة مباشرة من الملف.' : 'شكل توضيحي للموضع — القصّ والتشغيل بالملّي ثانية حقيقي 100%.'}
              </p>

              {/* Sliders + fine ±5s nudge */}
              <div className="mt-3 space-y-2">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="label !mb-0 num">البداية: {fmtMs(s)}</span>
                    <div className="flex gap-1"><button className="chip !py-0.5 num" onClick={() => nudge('s', -5000)}>-5ث</button><button className="chip !py-0.5 num" onClick={() => nudge('s', 5000)}>+5ث</button></div>
                  </div>
                  <input type="range" min={0} max={dur} step={500} value={s} dir="ltr" className="w-full accent-[var(--accent)]"
                    onChange={ev => { const v = Math.min(Number(ev.target.value), e - 3000); setEdit({ ...edit, clipStartMs: Math.max(0, v), clipEndMs: e }); }} />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="label !mb-0 num">النهاية: {fmtMs(e)}</span>
                    <div className="flex gap-1"><button className="chip !py-0.5 num" onClick={() => nudge('e', -5000)}>-5ث</button><button className="chip !py-0.5 num" onClick={() => nudge('e', 5000)}>+5ث</button></div>
                  </div>
                  <input type="range" min={0} max={dur} step={500} value={e} dir="ltr" className="w-full accent-[var(--accent)]"
                    onChange={ev => { const v = Math.max(Number(ev.target.value), s + 3000); setEdit({ ...edit, clipEndMs: Math.min(dur, v) }); }} />
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                <button className="btn btn-soft flex-1 justify-center" onClick={preview}>
                  {playing ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  {playing ? 'وقّف' : 'اسمع المقطع'}
                </button>
                <button className="btn btn-primary flex-1 justify-center" onClick={() => { setTrimOpen(false); platform.stopAlarmAudio(); setPlaying(false); toast('اتحفظ المقطع ✓'); }}>
                  اعتماد المقطع ✓
                </button>
              </div>
            </div>
          );
        })()}
      </Sheet>
    </div>
  );
}
