/* DAYFLOW — Assistant settings: enable (opt-in), keys per provider (device-only), real key test + live model list,
   permissions and privacy controls. */
import { useEffect, useState } from 'react';
import { ShieldCheck, KeyRound, Loader2, CheckCircle2, XCircle, Eye, EyeOff, Trash2, Sparkles, Link2, RefreshCw } from 'lucide-react';
import { useApp } from '@/lib/store';
import { PROVIDERS, TIER_LABEL } from '@/lib/ai/providers';
import { getAIConfig, saveAIConfig, modelsFor, type AIConfig } from '@/lib/ai/config';
import { refreshCatalog, verifyModel, type CatalogEntry } from '@/lib/ai/liveCatalog';
import { markVerification } from '@/lib/ai/config';
import { BrandLogo } from '@/components/BrandLogo';
import { Toggle, SettingRow, HelpTip } from '@/components/ui';
import { cn } from '@/utils/cn';

export default function AssistantSettings() {
  const { lang, toast, bump } = useApp();
  const ar = lang === 'ar';
  const [cfg, setCfg] = useState<AIConfig | null>(null);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [show, setShow] = useState<Record<string, boolean>>({});
  const [testing, setTesting] = useState<string | null>(null);
  const [status, setStatus] = useState<Record<string, { ok: boolean; text: string }>>({});
  const [refreshing, setRefreshing] = useState<string | null>(null);

  useEffect(() => { getAIConfig().then(setCfg); }, []);
  if (!cfg) return <div className="text-sm text-2 py-6 text-center">…</div>;

  const set = async (patch: Partial<AIConfig>): Promise<AIConfig> => { const next = await saveAIConfig(patch); setCfg(next); bump(); return next; };

  const saveKey = async (pid: string) => {
    const key = (drafts[pid] ?? '').trim();
    const keys = { ...cfg.keys };
    if (key) keys[pid] = key; else delete keys[pid];
    await set({ keys });
    setDrafts(d => ({ ...d, [pid]: '' }));
    toast(key ? (ar ? 'المفتاح اتحفظ على جهازك ✓' : 'Key saved on device ✓') : (ar ? 'المفتاح اتمسح' : 'Key removed'));
  };

  const test = async (pid: string) => {
    const key = (drafts[pid] ?? cfg.keys[pid] ?? '').trim();
    if (!key) { toast(ar ? 'اكتب المفتاح الأول' : 'Enter a key first'); return; }
    setTesting(pid);
    try {
      await set({ keys: { ...cfg.keys, [pid]: key } });
      const state = await refreshCatalog((await getAIConfig()).catalog, pid, key);
      const updated = await set({ catalog: state }) as AIConfig;
      const list = updated.catalog.byProvider[pid] ?? [];
      const err = updated.catalog.errors[pid];
      if (err) {
        setStatus(s => ({ ...s, [pid]: { ok: false, text: ar ? `مقدرناش نجيب القائمة: ${err}` : `Catalog failed: ${err}` } }));
      } else {
        const free = list.filter((m: CatalogEntry) => m.tier === 'free').length;
        setStatus(s => ({ ...s, [pid]: { ok: true, text: ar ? `اتحدّثت القائمة الحية ✓ — ${list.length} موديل محادثة${free ? ` (${free} مجاني)` : ''} · دوس «اختبر» جنب أي موديل تتأكد إنه شغال` : `Live: ${list.length} chat models` } }));
      }
    } catch (e: any) {
      setStatus(s => ({ ...s, [pid]: { ok: false, text: String(e?.message ?? e) } }));
    } finally { setTesting(null); }
  };

  const refreshOne = async (pid: string) => {
    const key = cfg.keys[pid];
    if (!key) { toast(ar ? 'ضيف المفتاح الأول' : 'Add key first'); return; }
    setRefreshing(pid);
    const state = await refreshCatalog((await getAIConfig()).catalog, pid, key);
    await set({ catalog: state });
    setRefreshing(null);
    const list = state.byProvider[pid] ?? [];
    toast(state.errors[pid] ? `فشل التحديث: ${state.errors[pid]}` : (ar ? `اتحدّثت ${list.length} موديل حي ✓` : `${list.length} live models ✓`));
  };

  const verifyOne = async (pid: string, modelId: string) => {
    const key = cfg.keys[pid];
    if (!key) return;
    await set({ catalog: { ...cfg.catalog, byProvider: { ...cfg.catalog.byProvider, [pid]: (cfg.catalog.byProvider[pid] ?? []).map(m => m.id === modelId ? { ...m, verification: 'testing' as const } : m) } } });
    const r = await verifyModel(pid, modelId, key);
    await markVerification(pid, modelId, r.ok, r.error);
    setCfg(await getAIConfig());
    // If a hint model failed and no live catalogue exists, fabricate a live entry so it can be marked broken
    if (!cfg.catalog.byProvider[pid]?.length) {
      const cur = await getAIConfig();
      const p = PROVIDERS.find(x => x.id === pid)!;
      const hint = p.models.find(m => m.id === modelId);
      if (hint) {
        const entry: CatalogEntry = { ...hint, verification: r.ok ? 'working' : 'broken', error: r.error, checkedAt: Date.now(), source: 'live' };
        await set({ catalog: { ...cur.catalog, byProvider: { ...cur.catalog.byProvider, [pid]: [entry] } } });
      }
    } else await markVerification(pid, modelId, r.ok, r.error);
    toast(r.ok ? (ar ? 'الموديل شغال فعلاً ✓' : 'Model works ✓') : (ar ? `الموديل مش شغال: ${r.error}` : `Broken: ${r.error}`));
    setCfg(await getAIConfig());
  };

  const clearAllKeys = async () => { await set({ keys: {}, liveModels: {} }); toast(ar ? 'كل المفاتيح اتمسحت من الجهاز' : 'All keys cleared'); };

  return (
    <>
      <div className="card p-4 mb-3 relative overflow-hidden">
        <div aria-hidden className="absolute -top-8 -end-8 w-32 h-32 rounded-full" style={{ background: 'radial-gradient(circle, var(--accent-soft), transparent 70%)' }} />
        <div className="flex items-start gap-3 relative">
          <span className="w-11 h-11 rounded-2xl grid place-items-center bg-[var(--accent-soft)] accent shrink-0"><Sparkles className="w-5 h-5" /></span>
          <div className="flex-1 min-w-0">
            <p className="font-extrabold">{ar ? 'المساعد الذكي (ميزة اختيارية)' : 'AI assistant (opt-in)'}</p>
            <p className="text-[0.7rem] text-2 leading-relaxed mt-0.5">{ar ? 'المساعد بيفهم كلامك وينفّذه فعلاً في التطبيق. محتاج مفتاح من مزوّد عنده رصيد مجاني. بقية التطبيق بتفضل شغالة أوفلاين.' : 'The agent executes real app actions. Needs a provider key.'}</p>
          </div>
          <Toggle on={cfg.enabled} onChange={v => set({ enabled: v })} label="enable assistant" />
        </div>
      </div>

      <p className="label flex items-center gap-1.5">{ar ? 'المزوّدين ومفاتيحهم' : 'Providers & keys'}
        <HelpTip title="المفتاح بيتحفظ فين؟">
          <p>المفتاح بيتحفظ <b>على موبايلك بس</b>، وبيتبعت للمزوّد اللي اخترته بس وقت ما تكلّم المساعد. ومش بيدخل في النسخة الاحتياطية أبداً.</p>
          <p>المزوّدين اللي عندهم <b>رصيد مجاني</b> ظاهرين فوق. اختبار المفتاح بيجيب قايمة الموديلات الحية ويصنّفها.</p>
        </HelpTip>
      </p>

      <div className="space-y-2.5 mb-4">
        {PROVIDERS.map(p => {
          const hasKey = !!cfg.keys[p.id];
          const st = status[p.id];
          const models = modelsFor(p.id, cfg);
          const freeN = models.filter(m => m.tier === 'free').length;
          const active = cfg.providerId === p.id;
          return (
            <div key={p.id} className={cn('card p-3.5 transition-shadow', active && 'ring-2 ring-[var(--accent)]')}>
              <div className="flex items-center gap-2.5">
                <BrandLogo icon={p.icon} mono={p.mono} color={p.color} size={40} rounded="lg" />
                <div className="flex-1 min-w-0">
                  <p className="font-extrabold text-[0.9rem] flex items-center gap-1.5 flex-wrap">{p.name}
                    <span className="text-[0.55rem] font-extrabold rounded-full px-1.5 py-0.5" style={{ color: TIER_LABEL[p.tier].color, background: `color-mix(in srgb, ${TIER_LABEL[p.tier].color} 14%, transparent)` }}>{ar ? TIER_LABEL[p.tier].ar : TIER_LABEL[p.tier].en}</span>
                    {active && <span className="text-[0.55rem] font-extrabold accent">● {ar ? 'المختار' : 'Selected'}</span>}
                  </p>
                  <p className="text-[0.64rem] text-2 leading-snug mt-0.5">{p.freeSummary}</p>
                  <p className="text-[0.58rem] text-3 mt-1 num flex items-center gap-1" dir="ltr"><Link2 className="w-3 h-3" />{p.keyUrl}</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 mt-2.5">
                <div className="relative flex-1">
                  <KeyRound className="absolute start-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-3" />
                  <input
                    type={show[p.id] ? 'text' : 'password'}
                    className="input ps-8 !py-2 text-xs num"
                    dir="ltr"
                    placeholder={hasKey ? '••••••••••• (محفوظ)' : (ar ? 'ألصق المفتاح هنا' : 'Paste key')}
                    value={drafts[p.id] ?? ''}
                    onChange={e => setDrafts(d => ({ ...d, [p.id]: e.target.value }))}
                    autoComplete="off" spellCheck={false}
                    aria-label={`${p.name} API key`}
                  />
                </div>
                <button className="icon-btn !w-9 !h-9" onClick={() => setShow(s => ({ ...s, [p.id]: !s[p.id] }))} aria-label="show">{show[p.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                <button className="btn btn-primary btn-sm" onClick={() => saveKey(p.id)} disabled={!(drafts[p.id] ?? '').trim()}>{ar ? 'احفظ' : 'Save'}</button>
                <button className="btn btn-soft btn-sm" onClick={() => test(p.id)} disabled={testing === p.id}>
                  {testing === p.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}{ar ? 'اختبر المفتاح' : 'Test key'}
                </button>
                {hasKey && <button className="btn btn-ghost btn-sm" onClick={async () => { await set({ keys: Object.fromEntries(Object.entries(cfg.keys).filter(([k]) => k !== p.id)) }); }}><Trash2 className="w-4 h-4" />{ar ? 'امسح' : 'Remove'}</button>}
                {hasKey && !active && <button className="btn btn-ghost btn-sm" onClick={() => set({ providerId: p.id, model: models[0]?.id ?? p.models[0].id })}>{ar ? 'اختار المزوّد ده' : 'Use provider'}</button>}
              </div>
              {hasKey && <p className="text-[0.6rem] text-2 mt-1.5">{ar ? `${models.length} موديل · ${freeN} مجاني` : `${models.length} models · ${freeN} free`}</p>}
              {st?.text && (
                <p className={cn('text-[0.66rem] font-bold mt-2 flex items-start gap-1.5 leading-snug', st.ok ? 'text-[var(--ok)]' : 'text-[var(--danger)]')}>
                  {st.ok ? <CheckCircle2 className="w-3.5 h-3.5 shrink-0 mt-0.5" /> : <XCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />}{st.text}
                </p>
              )}
              {(() => {
                const live = cfg.catalog.byProvider[p.id] ?? [];
                if (!live.length) return null;
                const shown = live.slice(0, 10);
                return (
                  <div className="mt-2.5 rounded-xl p-2" style={{ background: 'var(--surface-2)' }}>
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="text-[0.64rem] font-extrabold flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-[var(--ok)]" />{ar ? `القائمة الحية (${live.length} موديل)` : `Live catalogue (${live.length})`}</p>
                      <button className="chip !py-0 !text-[0.55rem]" onClick={() => refreshOne(p.id)} disabled={refreshing === p.id}>
                        {refreshing === p.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}{ar ? 'تحديث' : 'Refresh'}
                      </button>
                    </div>
                    <div className="space-y-1 max-h-40 overflow-y-auto no-scrollbar">
                      {shown.map(m => (
                        <div key={m.id} className="flex items-center gap-1.5 rounded-lg px-1.5 py-1" style={{ background: 'var(--surface)' }}>
                          <span className="num text-[0.6rem] flex-1 min-w-0 truncate" dir="ltr">{m.id}</span>
                          <span className="chip !py-0 !text-[0.5rem]" style={{ color: m.tier === 'free' ? 'var(--ok)' : m.tier === 'credit' ? 'var(--info)' : 'var(--danger)' }}>{ar ? (m.tier === 'free' ? 'مجاني' : m.tier === 'credit' ? 'رصيد' : 'مدفوع') : m.tier}</span>
                          {m.verification === 'working' && <CheckCircle2 className="w-3.5 h-3.5 text-[var(--ok)]" />}
                          {m.verification === 'broken' && <span title={m.error}><XCircle className="w-3.5 h-3.5 text-[var(--danger)]" /></span>}
                          {m.verification === 'testing' && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                          <button className="chip !py-0 !text-[0.5rem]" onClick={() => verifyOne(p.id, m.id)} disabled={m.verification === 'testing'}>{ar ? 'اختبر' : 'Test'}</button>
                        </div>
                      ))}
                    </div>
                    {live.length > shown.length && <p className="text-[0.55rem] text-3 mt-1 text-center">+{live.length - shown.length} {ar ? 'موديل تاني في منتقي الموديلات' : 'more in model picker'}</p>}
                  </div>
                );
              })()}
            </div>
          );
        })}
      </div>

      <p className="label">{ar ? 'الصلاحيات والخصوصية' : 'Permissions & privacy'}</p>
      <div className="card px-4 py-1 mb-3">
        <SettingRow label="المساعد يقدر يغيّر البيانات" help={<p>لما مفعّل، المساعد يقدر يضيف منبهات وأنشطة ومهام ويكتب يومياتك ويغيّر الإعدادات. لو مقفول يبقى قراءة بس.</p>}>
          <Toggle on={cfg.allowActions} onChange={v => set({ allowActions: v })} />
        </SettingRow>
        <SettingRow label="الحذف بيحتاج تأكيد في الشات" help={<p>أي حذف بيوقف عند بطاقة تأكيد، وانت اللي تضغط «أكيد امسح». الخيار ده ثابت لأمانك.</p>}>
          <Toggle on={cfg.confirmDeletes} onChange={v => set({ confirmDeletes: v })} />
        </SettingRow>
        <SettingRow label="أرسل ملخص يومك للمساعد" help={<p>لما مفعّل، المساعد بيعرف ملخص يومك (أنشطة ومهام) عشان يرد بدقة. لو قفلته، المساعد بيعرف بس الكلام اللي انت بتكتبه.</p>}>
          <Toggle on={cfg.shareContext} onChange={v => set({ shareContext: v })} />
        </SettingRow>
      </div>

      <div className="card-flat p-3 text-[0.66rem] text-2 leading-relaxed mb-3 flex items-start gap-2">
        <ShieldCheck className="w-4 h-4 text-[var(--ok)] shrink-0 mt-0.5" />
        <p>{ar ? 'بنبعت للمزوّد: كلامك في المحادثة + نتايج الأدوات اللي بتنفذها. ومفيش حاجة تانية بتطلع من جهازك إلا لو فعّلت ملخص اليوم. كل ده بيتم من غير أي حساب عندنا.' : 'Sent to provider: your messages and tool results only.'}</p>
      </div>

      <button className="btn btn-danger btn-sm w-full justify-center" onClick={clearAllKeys}><Trash2 className="w-4 h-4" />{ar ? 'امسح كل المفاتيح من الجهاز' : 'Clear all keys'}</button>
      <p className="text-[0.55rem] text-3 mt-3 text-center">{ar ? 'Groq وOpenRouter وGemini وغيرهم — كلهم بيستخدموا نفس بروتوكول OpenAI، فالتبديل بينهم فوري.' : 'All providers share the OpenAI-compatible protocol.'}</p>
    </>
  );
}
