/* DAYFLOW — Cleanly separated Settings pages (Egyptian colloquial + green "?" HelpTip on every single option!) */
import { useEffect, useState, type ReactNode } from 'react';
import {
  Palette, Sparkles, Globe, BellRing, AlarmClock, MoonStar, SlidersHorizontal,
  Database, ShieldCheck, Info, ChevronLeft, CheckCircle2, XCircle, AlertCircle,
  Loader2, Zap, BatteryWarning, FlaskConical, RotateCcw, Bell, Clock,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, isNative } from '@/lib/db';
import { platform } from '@/lib/platform';
import { syncNative } from '@/lib/sync';
import { Toggle, SettingRow, HelpTip, Segmented } from '@/components/ui';
import ThemePreview, { SKINS } from '@/components/ThemePreview';
import SettingsBackup from '@/components/SettingsBackup';
import AssistantSettings from '@/modules/AssistantSettings';
import { SCENES } from '@/components/Seasonal';
import type { ScheduleRule } from '@/lib/types';
import { cn } from '@/utils/cn';

type Page = 'hub' | 'appearance' | 'decor' | 'general' | 'notifications' | 'rules' | 'data' | 'reliability' | 'about' | 'assistant';

const ACCENTS = [
  { id: 'indigo', label: 'نيلي', c: '#5856d6' },
  { id: 'teal', label: 'تركواز', c: '#0e8a94' },
  { id: 'rose', label: 'وردي', c: '#e0356a' },
  { id: 'amber', label: 'دهبي', c: '#d97706' },
  { id: 'emerald', label: 'زمردي', c: '#0da271' },
  { id: 'violet', label: 'بنفسجي', c: '#7c3aed' },
] as const;

const toHM = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
const fromHM = (s: string) => { const [h, m] = s.split(':').map(Number); return (h || 0) * 60 + (m || 0); };

export default function SettingsModule({ params }: { params?: { page?: Page } } = {}) {
  const { lang, navigate, settings } = useApp();
  const [page, setPage] = useState<Page>(params?.page ?? 'hub');
  const activeSkin = SKINS.find(s => s.id === settings.skin);

  const items: Array<{ id: Page | 'alarms' | 'prayer'; icon: any; ar: string; en: string; d: string; tone: string }> = [
    { id: 'appearance', icon: Palette, ar: 'الثيمات والمظهر', en: 'Themes & appearance', d: `الحالي: ${activeSkin?.ar ?? ''} · 12 ثيم بمعاينة حية`, tone: '#7c3aed' },
    { id: 'decor', icon: Sparkles, ar: 'الزينة والصور الموسمية', en: 'Seasonal decor', d: 'رمضان، العيد، رأس السنة، الخريف، الشتا، وصور متبدلة', tone: '#d97706' },
    { id: 'general', icon: Globe, ar: 'اللغة والوقت والتقويم', en: 'Language & calendar', d: 'اسمك، اللغة، 12/24 ساعة، الهجري، الفواصل', tone: '#2563eb' },
    { id: 'notifications', icon: BellRing, ar: 'الإشعارات وساعات الهدوء', en: 'Notifications & quiet hours', d: 'التأجيل، النطق الصوتي، ساعات النوم، المية', tone: '#e0356a' },
    { id: 'alarms', icon: AlarmClock, ar: 'المنبهات وقصّ النغمات', en: 'Alarms & sound trim', d: 'منبهات بأغانيك من تطبيق الموسيقى', tone: '#0e8a94' },
    { id: 'prayer', icon: MoonStar, ar: 'مواقيت الصلاة والأذان', en: 'Prayer times', d: 'كل محافظات مصر، القبلة، الأذان، التصحيح', tone: '#0da271' },
    { id: 'rules', icon: SlidersHorizontal, ar: 'قواعد التخطيط الذكي', en: 'Smart rules engine', d: 'الراحة، الفواصل، التحضير قبل التمرين', tone: '#64748b' },
    { id: 'data', icon: Database, ar: 'النسخ الاحتياطي والملفات', en: 'Backup, CSV & Excel', d: 'نسخة JSON مشفّرة، CSV، Excel، واستعادة', tone: '#0ea5e9' },
    { id: 'reliability', icon: ShieldCheck, ar: 'فحص الموثوقية والصلاحيات', en: 'Alarm reliability center', d: 'تأكد إن الإشعارات والمنبهات شغالة 100%', tone: '#16a34a' },
    { id: 'assistant', icon: Sparkles, ar: 'المساعد الذكي (AI)', en: 'AI assistant', d: 'مزوّدين ومفاتيح مجانية، وصلاحيات المساعد', tone: '#7c3aed' },
    { id: 'about', icon: Info, ar: 'عن مدير اليوم', en: 'About DAYFLOW', d: 'خصوصيتك، الأوفلاين، وإعادة الشرح الترحيبي', tone: '#a16207' },
  ];
  const current = items.find(i => i.id === page);

  return (
    <div className="pb-6 px-4 pt-14">
      {page === 'hub' ? (
        <>
          <h1 className="skin-title font-extrabold grad-text">{lang === 'ar' ? 'الإعدادات' : 'Settings'}</h1>
          <p className="text-[0.7rem] text-2 mt-0.5 mb-3">
            {lang === 'ar' ? 'كل قسم في صفحة لوحده — وأي علامة ' : 'Every section separated cleanly — tap '}
            <span className="help-dot !w-4 !h-4 !text-[9px] align-middle mx-0.5">?</span>
            {lang === 'ar' ? ' تشرحلك الميزة ببساطة.' : ' for a quick explanation.'}
          </p>
          <div className="card overflow-hidden">
            {items.map(it => (
              <button
                key={it.id}
                onClick={() => (it.id === 'alarms' || it.id === 'prayer') ? navigate(it.id) : setPage(it.id as Page)}
                className="w-full flex items-center gap-3 px-4 py-3.5 border-b hairline last:border-0 text-start hover:bg-[var(--surface-2)] transition-colors active:scale-[0.99]"
              >
                <span className="w-10 h-10 rounded-2xl grid place-items-center shrink-0 text-white shadow-sm" style={{ background: it.tone }}>
                  <it.icon className="w-5 h-5" />
                </span>
                <span className="flex-1 min-w-0">
                  <span className="block font-extrabold text-[0.9rem]">{lang === 'ar' ? it.ar : it.en}</span>
                  <span className="block text-[0.63rem] text-2 truncate mt-0.5">{it.d}</span>
                </span>
                <ChevronLeft className="w-4 h-4 text-3 ltr:rotate-180 shrink-0" />
              </button>
            ))}
          </div>
        </>
      ) : (
        <div className="anim-screen">
          <button className="text-[0.76rem] font-extrabold accent flex items-center gap-1 mb-2" onClick={() => setPage('hub')}>
            <ChevronLeft className="w-4 h-4 rtl:rotate-180" />{lang === 'ar' ? 'رجوع لكل الإعدادات' : 'All settings'}
          </button>
          <h1 className="skin-title font-extrabold mb-3">{current ? (lang === 'ar' ? current.ar : current.en) : ''}</h1>
          {page === 'appearance' && <AppearancePage />}
          {page === 'decor' && <DecorPage />}
          {page === 'general' && <GeneralPage />}
          {page === 'notifications' && <NotificationsPage />}
          {page === 'rules' && <RulesPage />}
          {page === 'data' && <SettingsBackup />}
          {page === 'reliability' && <ReliabilityCenter />}
          {page === 'about' && <AboutPage />}
          {page === 'assistant' && <AssistantSettings />}
        </div>
      )}
    </div>
  );
}

const Card = ({ children }: { children: ReactNode }) => <div className="card px-4 py-1 mb-3">{children}</div>;

function AppearancePage() {
  const { settings, saveSettings, lang, toast } = useApp();
  const mode = settings.theme === 'auto'
    ? (typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : settings.theme;

  return (
    <>
      <Card>
        <SettingRow label="الوضع (فاتح / داكن)" help={<p><b>فاتح</b> واضح ومشرق بالنهار، <b>داكن</b> مريح للعين بالليل وبيوفر بطارية، و<b>تلقائي</b> يمشي على نفس وضع موبايلك.</p>}>
          <Segmented size="sm" value={settings.theme} onChange={v => saveSettings({ theme: v as any })}
            options={[{ value: 'light', label: 'فاتح' }, { value: 'dark', label: 'داكن' }, { value: 'auto', label: 'تلقائي' }]} />
        </SettingRow>
        <SettingRow label="لون التمييز" help={<p>بيغيّر لون الزراير ودواير الإنجاز والتأكيد في ثيم iOS والصفحات الأساسية.</p>}>
          <div className="flex gap-1.5">
            {ACCENTS.map(a => (
              <button key={a.id} onClick={() => saveSettings({ accent: a.id })} title={a.label} aria-label={a.label}
                className={cn('w-7 h-7 rounded-full transition-transform', settings.accent === a.id && 'scale-125 ring-2 ring-offset-2 ring-offset-[var(--surface)]')}
                style={{ background: a.c, ['--tw-ring-color' as any]: a.c }} />
            ))}
          </div>
        </SettingRow>
        <SettingRow label="حجم الخط" hint={`${Math.round(settings.fontScale * 100)}%`} help={<p>كبّر الخط لو بتحب القراية أريح، أو صغّره عشان تشوف محتوى أكتر على الشاشة.</p>}>
          <input type="range" min={0.85} max={1.3} step={0.05} value={settings.fontScale} onChange={e => saveSettings({ fontScale: Number(e.target.value) })} className="w-28 accent-[var(--accent)]" />
        </SettingRow>
        <SettingRow label="كثافة الجدول" help={<p><b>مريحة:</b> مسافات أوسع وشكل هادي. <b>مضغوطة:</b> تعرض أنشطة أكتر في نفس الشاشة.</p>}>
          <Segmented size="sm" value={settings.timelineDensity} onChange={v => saveSettings({ timelineDensity: v as any })}
            options={[{ value: 'comfortable', label: 'مريحة' }, { value: 'compact', label: 'مضغوطة' }]} />
        </SettingRow>
      </Card>

      <p className="label flex items-center gap-1.5 mt-4 mb-2">
        اختار الثيم ({SKINS.length} تصميم مختلف — معاينة فاتح وداكن)
        <HelpTip title="نظام الثيمات">
          <p>كل ثيم هنا <b>تجربة تصميم كاملة مختلفة فعلاً</b> — مش مجرد تغيير لون!</p>
          <ul>
            <li>بيغيّر <b>الخط، شكل الكروت، الزجاج والشفافية، خلفية الشاشة، حجم العناوين، الزوايا، والظلال</b>.</li>
            <li>الصورة اللي قدامك هي معاينة حقيقية للشاشة الرئيسية بالوضع الفاتح والوضع الداكن.</li>
            <li>اضغط أي ثيم وهيتطبق فوراً بسلاسة على كل التطبيق!</li>
          </ul>
        </HelpTip>
      </p>

      <div className="grid grid-cols-2 gap-3 mb-2">
        {SKINS.map(s => {
          const active = settings.skin === s.id;
          return (
            <button
              key={s.id}
              onClick={() => { saveSettings({ skin: s.id }); toast(`تم تفعيل ثيم «${s.ar}» ✨`); }}
              className={cn('card p-2.5 text-start transition-all active:scale-[0.97]', active && 'ring-2 ring-[var(--accent)] shadow-md')}
              aria-pressed={active}
            >
              <div className="grid grid-cols-2 gap-1.5">
                <ThemePreview skin={s.id} theme="light" accent={settings.accent} selected={active && mode === 'light'} />
                <ThemePreview skin={s.id} theme="dark" accent={settings.accent} selected={active && mode === 'dark'} />
              </div>
              <div className="flex items-center justify-between gap-1 mt-2">
                <p className="font-extrabold text-[0.78rem] truncate">{lang === 'ar' ? s.ar : s.en}</p>
                {s.tag && <span className="text-[0.52rem] font-extrabold px-1.5 py-0.5 rounded-full bg-[var(--accent-soft)] accent shrink-0">{s.tag}</span>}
              </div>
              <p className="text-[0.58rem] text-2 leading-snug mt-0.5 line-clamp-2">{lang === 'ar' ? s.descAr : s.descEn}</p>
            </button>
          );
        })}
      </div>
    </>
  );
}

function DecorPage() {
  const { settings, saveSettings, toast, navigate, lang } = useApp();
  const speedOpts = [{ v: 'slow', l: 'بطيء ومريح' }, { v: 'normal', l: 'عادي' }, { v: 'fast', l: 'سريع' }] as const;
  const densityOpts = [{ v: 'light', l: 'خفيفة' }, { v: 'normal', l: 'متوازنة' }, { v: 'dense', l: 'كثيفة' }] as const;
  return (
    <>
      <Card>
        <SettingRow label="الزينة الموسمية والمناسبات"
          help={<p>التطبيق بيزيّن نفسه <b>لوحده أوتوماتيك</b> حسب الموسم والمناسبة الحالية — رسومات ثلاثية الأبعاد حقيقية من مكتبة Microsoft (مجانية) وصور التقطت لأماكن ومزية حقيقية، وكلها <b>محفوظة جوه التطبيق وبتشتغل بدون نت خالص</b>. رمضان، العيدين، الخريف، الشتا، الربيع، الصيف، رأس السنة، بداية الدراسة، موسم الامتحانات، وانتصار ٦ أكتوبر.</p>}>
          <Toggle on={settings.decorations} onChange={v => saveSettings({ decorations: v })} />
        </SettingRow>
        <SettingRow label="حركة العناصر المتساقطة"
          help={<p>أوراق الشجر، بلورات الثلج، النجوم، الورد، الكونفيتي... اللي بينزل على الشاشة بهدوء. لو عايز تركيز أكتر أو جهازك قديم، اقفل الحركة وسيب الزينة الثابتة شغالة.</p>}>
          <Toggle on={settings.particles} onChange={v => saveSettings({ particles: v })} />
        </SettingRow>
        <SettingRow label="موضع الزينة بالنسبة للمحتوى"
          help={<p><b>في الخلفية:</b> الزينة بتبقى ورا الكروت والكلام — أخف ومناسبة للي بيحب شكل هادي.<br/><b>فوق المحتوى:</b> الزينة بتطفو فوق كل حاجة (لكن من غير ما تمنع الضغط) — شكل احتفالي أكتر.</p>}>
          <Segmented size="sm" value={settings.decorLayer} onChange={v => saveSettings({ decorLayer: v as any })}
            options={[{ value: 'below', label: 'في الخلفية' }, { value: 'above', label: 'فوق المحتوى' }]} />
        </SettingRow>
        <SettingRow label="سرعة الحركة" help={<p>مدى سرعة نزول العناصر المتساقطة.</p>}>
          <Segmented size="sm" value={settings.decorSpeed} onChange={v => saveSettings({ decorSpeed: v as any })} options={speedOpts.map(o => ({ value: o.v, label: o.l }))} />
        </SettingRow>
        <SettingRow label="كثافة الزينة" help={<p>عدد العناصر اللي بتنزل: <b>خفيفة</b> لهدوء، <b>متوازنة</b> للشكل الطبيعي، <b>كثيفة</b> لاحتفال كامل في المناسبات الكبيرة.</p>}>
          <Segmented size="sm" value={settings.decorDensity} onChange={v => saveSettings({ decorDensity: v as any })} options={densityOpts.map(o => ({ value: o.v, label: o.l }))} />
        </SettingRow>
        <SettingRow label="شفافية الزينة المتساقطة" hint={`${Math.round((settings.decorOpacity ?? 0.9) * 100)}%`}
          help={<p>تقدر تخلّي العناصر أغمق أو أخف على حسب لون ثيمك والصورة اللي فوق.</p>}>
          <input type="range" min={0.15} max={1} step={0.05} value={settings.decorOpacity ?? 0.9}
            onChange={e => saveSettings({ decorOpacity: Number(e.target.value) })} className="w-28 accent-[var(--accent)]" dir="ltr" />
        </SettingRow>
        <SettingRow label="صور حقيقية بتتبدّل مع الوقت"
          help={<p>صورة الهيدر بتتبدّل لوحدها بين <b>الصبح والنهار والغروب والليل</b>، وفي المناسبات بتتحول لصورة نفس المناسبة.</p>}>
          <Toggle on={settings.headerPhotos} onChange={v => saveSettings({ headerPhotos: v })} />
        </SettingRow>
      </Card>

      <button className="btn btn-primary w-full justify-center mb-3" onClick={() => navigate('decorGallery')}>
        <Sparkles className="w-4 h-4" />{lang === 'ar' ? 'افتح معرض الزينة (معاينات حقيقية + دمج 3 زينة)' : 'Open decoration gallery'}
      </button>

      <p className="label flex items-center gap-1.5 mt-4 mb-2">
        عاين أي مشهد موسمي أو مناسبة — كلهم محفوظين أوفلاين
        <HelpTip title="معاينة الزخرفة">دوس على أي مشهد عشان تشوفه شغال فوراً على الشاشة الرئيسية (مع إعدادات السرعة والكثافة اللي فوق). المشاهد كلها موجودة أوفلاين داخل التطبيق حتى من غير نت. لما تخلص، اختار <b>«تلقائي»</b> عشان التطبيق يرجع يبدّل الزينة لوحده.</HelpTip>
      </p>

      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={() => { saveSettings({ decorOverride: 'auto' }); toast('رجع للتبديل التلقائي مع الموسم والمناسبة ✨'); }}
          className={cn('card p-2 text-center text-[0.72rem] font-extrabold h-[6.5rem] flex flex-col items-center justify-center gap-1', settings.decorOverride === 'auto' && 'ring-2 ring-[var(--accent)]')}
        >
          <img src="/decor/sparkles.png" alt="" className="w-9 h-9 decor-float" />
          <span>تلقائي (حسب التاريخ)</span>
        </button>
        {Object.values(SCENES).map(sc => (
          <button
            key={sc.id}
            onClick={() => { saveSettings({ decorOverride: sc.id }); toast(`مشهد «${sc.ar}» شغال — بص على الرئيسية 🎉`); }}
            className={cn('relative rounded-2xl overflow-hidden h-[6.5rem] text-white shadow-sm transition-transform active:scale-95', settings.decorOverride === sc.id && 'ring-2 ring-[var(--accent)]')}
            aria-pressed={settings.decorOverride === sc.id}
          >
            <img src={sc.photos[0]} alt="" className="absolute inset-0 w-full h-full object-cover" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/78 via-black/28 to-transparent" />
            {sc.corner && <img src={sc.corner} alt="" className="absolute top-1 end-1 w-8 h-8 drop-shadow" />}
            {sc.corner2 && <img src={sc.corner2} alt="" className="absolute top-4 end-9 w-5 h-5 opacity-90" />}
            <span className="absolute bottom-1.5 inset-x-1 text-[0.62rem] font-extrabold leading-tight drop-shadow text-start">{sc.ar}</span>
          </button>
        ))}
      </div>
      <p className="text-[0.6rem] text-3 mt-2 leading-relaxed">الزينة بتتبدّل أوتوماتيك مع الموسم والمناسبة والتاريخ والوقت — ومفيش ولا رسمة بتحتاج إنترنت.</p>
    </>
  );
}

function GeneralPage() {
  const { settings, saveSettings } = useApp();
  return (
    <Card>
      <SettingRow label="اسمك" hint="عشان نرحب بيك في الرئيسية والويدجيت">
        <input className="input !py-1.5 !w-36" value={settings.userName} onChange={e => saveSettings({ userName: e.target.value })} placeholder="مثلاً: أحمد" />
      </SettingRow>
      <SettingRow label="لغة التطبيق" help={<p>عربي (باللهجة المصرية وباتجاه من اليمين للشمال) أو إنجليزي (من الشمال لليمين). بيتطبق على التطبيق والإشعارات والويدجيت كمان.</p>}>
        <Segmented size="sm" value={settings.language} onChange={v => saveSettings({ language: v as any })} options={[{ value: 'ar', label: 'مصري' }, { value: 'en', label: 'English' }]} />
      </SettingRow>
      <SettingRow label="بداية الأسبوع" help={<p>أول يوم يظهر في التقويم وأسبوع الخطة والتمارين (في مصر غالباً السبت أو الأحد).</p>}>
        <select className="input !py-1.5 !w-28" value={settings.weekStart} onChange={e => saveSettings({ weekStart: Number(e.target.value) })}>
          {['الأحد', 'الاتنين', 'التلات', 'الأربع', 'الخميس', 'الجمعة', 'السبت'].map((d, i) => <option key={i} value={i}>{d}</option>)}
        </select>
      </SettingRow>
      <SettingRow label="نظام 12 ساعة (ص / م)" help={<p>بيعرض الأوقات بصيغة 3:30 م بدل 15:30 — في التطبيق والإشعارات والويدجيت وشاشة المنبه.</p>}>
        <Toggle on={settings.hour12} onChange={v => saveSettings({ hour12: v })} />
      </SettingRow>
      <SettingRow label="تصحيح التاريخ الهجري" hint={`${settings.hijriOffset > 0 ? '+' : ''}${settings.hijriOffset} يوم`}
        help={<p>التاريخ الهجري محسوب بتقويم أم القرى. لو دار الإفتاء المصرية أعلنت رؤية الهلال بفرق يوم، زوّد أو نقص يوم هنا — وكل مواعيد رمضان والعيد والزينة هتتظبط معاه فوراً.</p>}>
        <div className="flex items-center gap-1">
          {[-2, -1, 0, 1, 2].map(n => (
            <button key={n} onClick={() => saveSettings({ hijriOffset: n })} className={cn('w-7 h-7 rounded-lg num text-xs font-extrabold', settings.hijriOffset === n ? 'bg-[var(--accent)] text-[var(--on-accent)]' : 'bg-[var(--surface-2)]')}>
              {n > 0 ? `+${n}` : n}
            </button>
          ))}
        </div>
      </SettingRow>
      <SettingRow label="المدة الافتراضية للنشاط" hint="بالدقايق" help={<p>أول ما تفتح إضافة نشاط جديد، هتلاقي مدته مظبوطة بالرقم ده تلقائي — وتقدر تغيّرها لأي نشاط لوحده.</p>}>
        <input type="number" min={5} step={5} className="input !py-1.5 !w-20 num" value={settings.defaultBlockDuration} onChange={e => saveSettings({ defaultBlockDuration: Math.max(5, Number(e.target.value) || 45) })} />
      </SettingRow>
      <SettingRow label="الفاصل بين الأنشطة" hint="دقايق راحة انتقال" help={<p>الوقت البسيط بين نشاط واللي بعده (تشرب مية أو تغيّر قعدتك). محرك التخطيط والتعويض بيحسبه أوتوماتيك.</p>}>
        <input type="number" min={0} step={5} className="input !py-1.5 !w-20 num" value={settings.defaultBufferMin} onChange={e => saveSettings({ defaultBufferMin: Math.max(0, Number(e.target.value) || 0) })} />
      </SettingRow>
    </Card>
  );
}

function NotificationsPage() {
  const { settings, saveSettings } = useApp();
  return (
    <>
      <Card>
        <SettingRow label="تشغيل الإشعارات" help={<p>المفتاح العام لإشعارات الأنشطة والمهام والمناسبات والمية. المنبهات الشخصية والأذان لهم مفاتيح منفصلة عشان تتحكم براحتك.</p>}>
          <Toggle on={settings.notificationsEnabled} onChange={v => saveSettings({ notificationsEnabled: v })} />
        </SettingRow>
        <SettingRow label="اسألني لما النشاط يخلص" help={<p>لما وقت النشاط ينتهي يوصلك إشعار فيه زراير: <b>خلصت ✓ / خلصت جزء / أجّل</b>. تضغط من بره التطبيق وبيتحفظ في السجل والويدجيت والإحصائيات فوراً.</p>}>
          <Toggle on={settings.endOfBlockPrompt} onChange={v => saveSettings({ endOfBlockPrompt: v })} />
        </SettingRow>
        <SettingRow label="مدة التأجيل الافتراضية" help={<p>لما تضغط «أجّل» من أي إشعار، هيرجّع التنبيه بعد الدقايق دي.</p>}>
          <select className="input !py-1.5 !w-20 num" value={settings.snoozeDefaultMin} onChange={e => saveSettings({ snoozeDefaultMin: Number(e.target.value) })}>
            {[5, 10, 15, 20, 30].map(n => <option key={n} value={n}>{n} د</option>)}
          </select>
        </SettingRow>
        <SettingRow label="تكرار صوت التنبيه" help={<p>كام مرة يتكرر الصوت لو ما ردتش — محدود دايماً عشان مايزعجكش بلا نهاية.</p>}>
          <select className="input !py-1.5 !w-20 num" value={settings.soundRepeatCount} onChange={e => saveSettings({ soundRepeatCount: Number(e.target.value) })}>
            {[1, 2, 3, 5].map(n => <option key={n} value={n}>{n}×</option>)}
          </select>
        </SettingRow>
        <SettingRow label="النطق الصوتي (TTS)" help={<p><b>تحويل النص لصوت:</b> لو اخترت النطق أو مفيش نغمة، موبايلك بينطق اسم النشاط بصوت عالي بالعربي أو الإنجليزي (عن طريق محرك النطق الموجود على جهازك).</p>}>
          <Toggle on={settings.ttsFallback} onChange={v => saveSettings({ ttsFallback: v })} />
        </SettingRow>
        <SettingRow label="الاهتزاز"><Toggle on={settings.vibration} onChange={v => saveSettings({ vibration: v })} /></SettingRow>
        <SettingRow label="ساعة إشعار المناسبات والمهام" help={<p>المناسبات (الوطنية، الإسلامية، ومناسباتك اللي من غير ساعة محددة) والمهام اللي ميعادها النهارده بتبعتلك تنبيه في الساعة دي.</p>}>
          <select className="input !py-1.5 !w-24 num" value={settings.occasionNotifyHour} onChange={e => saveSettings({ occasionNotifyHour: Number(e.target.value) })}>
            {[6, 7, 8, 9, 10, 12].map(n => <option key={n} value={n}>{n}:00 ص</option>)}
          </select>
        </SettingRow>
      </Card>

      <p className="label mt-3">ساعات الهدوء (وقت النوم)</p>
      <Card>
        <SettingRow label="تفعيل ساعات الهدوء" help={<p>خلال الساعات دي أي إشعار عادي هيوصل <b>صامت تماماً من غير ما يصحيك</b>. المنبهات الشخصية والأذان والتنبيهات «الحرجة» بس هما اللي بيرنوا.</p>}>
          <Toggle on={settings.quietHoursEnabled} onChange={v => saveSettings({ quietHoursEnabled: v })} />
        </SettingRow>
        <SettingRow label="من الساعة"><input type="time" className="input !py-1.5 !w-28 num" value={toHM(settings.quietHoursStartMin)} onChange={e => saveSettings({ quietHoursStartMin: fromHM(e.target.value) })} /></SettingRow>
        <SettingRow label="لحد الساعة"><input type="time" className="input !py-1.5 !w-28 num" value={toHM(settings.quietHoursEndMin)} onChange={e => saveSettings({ quietHoursEndMin: fromHM(e.target.value) })} /></SettingRow>
      </Card>

      <p className="label mt-3">تذكير شرب المية</p>
      <Card>
        <SettingRow label="فكّرني أشرب مية" help={<p>بيبعتلك تذكير لطيف بين ميعاد صحيانك ونومك، وفيه شريط تقدم وزرار <b>«شربت كوباية 💧»</b> يسجل فوراً من بره التطبيق.</p>}>
          <Toggle on={settings.waterReminders} onChange={v => saveSettings({ waterReminders: v })} />
        </SettingRow>
        <SettingRow label="كل كام دقيقة"><select className="input !py-1.5 !w-20 num" value={settings.waterReminderMin} onChange={e => saveSettings({ waterReminderMin: Number(e.target.value) })}>{[45, 60, 90, 120, 180].map(n => <option key={n} value={n}>{n} د</option>)}</select></SettingRow>
        <SettingRow label="هدفك اليومي (مل)"><input type="number" step={250} className="input !py-1.5 !w-24 num" value={settings.waterTargetMl} onChange={e => saveSettings({ waterTargetMl: Math.max(500, Number(e.target.value) || 2500) })} /></SettingRow>
        <SettingRow label="حجم الكوباية (مل)"><input type="number" step={50} className="input !py-1.5 !w-24 num" value={settings.waterCupMl} onChange={e => saveSettings({ waterCupMl: Math.max(50, Number(e.target.value) || 250) })} /></SettingRow>
      </Card>
    </>
  );
}

function RulesPage() {
  const [rules, setRules] = useState<ScheduleRule[]>([]);
  useEffect(() => { db.all<ScheduleRule>('schedule_rules').then(r => setRules(r.sort((a, b) => a.priority - b.priority))); }, []);
  return (
    <>
      <p className="text-[0.72rem] text-2 mb-3 flex items-center gap-1.5 leading-relaxed">
        القواعد دي بتراجع خطتك وتنبهك لو نسيت راحة أو زحمت يومك
        <HelpTip title="محرك القواعد الذكية">
          <p>قواعد واضحة ومضمونة 100% — لو خططت ساعتين مذاكرة ورا بعض من غير راحة أو حطيت نشاط في وقت نومك، التطبيق هيحذرك في تبويب «الخطة».</p>
          <p><b>مستحيل يغيّر خطتك لوحده</b> — دايماً يقترحلك بس، وانت صاحب القرار النهائي.</p>
        </HelpTip>
      </p>
      <Card>
        {rules.map(r => (
          <SettingRow key={r.id} label={r.nameAr} hint={r.descriptionAr}>
            <Toggle on={r.enabled} onChange={async v => { await db.put('schedule_rules', { ...r, enabled: v }); setRules(rs => rs.map(x => x.id === r.id ? { ...x, enabled: v } : x)); }} />
          </SettingRow>
        ))}
      </Card>
    </>
  );
}

function AboutPage() {
  const { saveSettings } = useApp();
  return (
    <div className="card p-4 text-[0.82rem] leading-[1.9] space-y-2">
      <div className="flex items-center gap-3">
        <img src="/icons/icon-512.png" alt="DAYFLOW" className="w-16 h-16 rounded-2xl shadow" />
        <div>
          <p className="font-extrabold text-base">مدير اليوم · DAYFLOW</p>
          <p className="text-[0.68rem] text-2">الإصدار 2.0 · Android Native + Offline-first</p>
        </div>
      </div>
      <p className="text-2">نظام حياة متكامل على موبايلك: خطط يومك، نفّذ أولوياتك، راقب صلاتك ومناسباتك ومنبهاتك ويومياتك ودراستك وتمارينك. <b>شغّال بدون إنترنت 100%</b> — التطبيق أصلاً ماعندوش صلاحية إنترنت في الأندرويد. مفيش حساب، مفيش إعلانات، مفيش تتبع، كل بياناتك ملكك على جهازك بس.</p>
      <p className="text-[0.68rem] text-3">• الرسومات 3D: مكتبة Microsoft Fluent Emoji (رخصة MIT) — مدمجة داخل التطبيق.<br />• الصور والخلفيات: صور مرخصة من Pexels — مدمجة داخل التطبيق.<br />• الخطوط العربية: IBM Plex Sans Arabic و Cairo و Tajawal — مدمجة محلياً.</p>
      <button className="btn btn-soft btn-sm mt-2" onClick={() => saveSettings({ onboarded: false })}>
        <RotateCcw className="w-4 h-4" />شوف الجولة الترحيبية من الأول
      </button>
    </div>
  );
}

function ReliabilityCenter() {
  const { toast } = useApp();
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<Array<{ label: string; ok: boolean | null; detail?: string; fix?: () => void; help?: string }>>([]);

  const run = async () => {
    setLoading(true);
    const out: typeof rows = [];
    if (isNative()) {
      const [n, e, b, a, caps]: any[] = await Promise.all([
        platform.checkNotificationPermission(), platform.checkExactAlarm(),
        platform.batteryStatus(), platform.alarmStatus(), platform.capabilities(),
      ]);
      out.push({ label: 'صلاحية الإشعارات', ok: !!n.granted, detail: n.granted ? 'مسموح — الإشعارات هتوصل بشكل طبيعي' : 'مقفولة! من غيرها مش هيوصلك أي إشعار', fix: () => platform.requestNotificationPermission(), help: 'لازمة على أندرويد 13 فما فوق عشان أي إشعار يظهر على الشاشة.' });
      out.push({ label: 'المنبهات الدقيقة (Exact Alarm)', ok: !!e.granted, detail: e.granted ? 'مسموح — كل تنبيه ومنبه وأذان ييجي في الدقيقة بالظبط' : 'مقفولة — النظام ممكن يأخر التنبيهات دقايق أثناء الخمول', fix: () => platform.requestExactAlarm(), help: 'بتسمح للتطبيق يستخدم منبّه النظام الدقيق حتى لو الشاشة مقفولة (Doze Mode).' });
      out.push({ label: 'شاشة المنبه الكاملة فوق القفل', ok: caps.fullScreenIntent !== false, detail: caps.fullScreenIntent !== false ? 'مسموح — المنبه يفتحلك شاشة رنين كاملة' : 'محتاجة تفعيل على أندرويد 14+', fix: () => platform.requestFullScreen(), help: 'عشان لما المنبه يرن والشاشة مقفولة، يفتح شاشة الإيقاف والغفوة فوراً.' });
      out.push({ label: 'استثناء توفير البطارية', ok: !!b.ignoring, detail: b.ignoring ? 'غير مقيّد ✓ — ممتاز للثبات في الخلفية' : 'مقيّد — يفضّل تغييره لـ «غير مقيّد» عشان التنبيهات ماتتأخرش', fix: () => platform.openBatterySettings(), help: 'أغلب شركات أندرويد (شاومي/سامسونج/أوبو/ريلمي/هواوي) بتقفل التطبيقات لتوفير البطارية وده بيأخر الإشعارات.' });
      out.push({ label: `المواعيد المجدولة فعلياً: ${a.pendingCount ?? 0}`, ok: (a.pendingCount ?? 0) > 0 ? true : null, detail: a.nextTriggerAt ? `الجاي: ${a.nextTitle} — ${new Date(a.nextTriggerAt).toLocaleString('ar-EG')}` : 'مفيش مواعيد مستقبلية مجدولة دلوقتي' });
      out.push({ label: 'الاسترجاع بعد إعادة التشغيل', ok: true, detail: String(a.bootRecovery ?? '').startsWith('done') ? `اتنفذ بنجاح (${a.bootRecovery})` : 'مسجّل وجاهز — بيرجّع كل المنبهات بعد الريستارت وتغيير الساعة' });
      out.push({ label: 'بيانات الجهاز والوقت', ok: null, detail: `${caps.manufacturer ?? ''} ${caps.model ?? ''} · Android ${caps.release ?? ''} (SDK ${caps.sdk}) · ${caps.timeZone ?? ''}` });
    } else {
      const bp = typeof Notification !== 'undefined' ? Notification.permission : 'unsupported';
      out.push({ label: 'انت فاتح معاينة الويب (مش الأندرويد)', ok: null, detail: 'على المتصفح الإشعارات بتشتغل فقط والتطبيق مفتوح. على الأندرويد كل التنبيهات والمنبهات والويدجيت بتشتغل في الخلفية وبالموبايل مقفول.' });
      out.push({ label: `إشعارات المتصفح: ${bp === 'granted' ? 'مسموح' : bp === 'denied' ? 'مرفوض' : 'مش مفعّلة'}`, ok: bp === 'granted', fix: bp === 'default' ? () => { Notification.requestPermission().then(run); } : undefined });
    }
    setRows(out); setLoading(false);
  };

  useEffect(() => { run(); /* eslint-disable-next-line */ }, []);

  return (
    <>
      <div className="flex flex-wrap gap-2 mb-3">
        <button className="btn btn-soft btn-sm" onClick={run} disabled={loading}>
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}افحص دلوقتي
        </button>
        <button className="btn btn-ghost btn-sm" onClick={async () => {
          const r = await syncNative();
          toast(r.unsupported ? `في الويب: ${r.items} تنبيه جاهز للمزامنة على الأندرويد` : r.ok ? `تم ✓ اتجدول ${r.scheduled} (${r.exact} دقيق) واتمسح ${r.removed} قديم` : `فشل: ${r.error}`);
          run();
        }}><RotateCcw className="w-4 h-4" />زامن كل المواعيد</button>
        {isNative() && (
          <>
            <button className="btn btn-primary btn-sm" onClick={async () => {
              const r: any = await platform.triggerTestAlarm('notification', 10);
              toast(r.ok ? `🔔 تجربة إشعار بعد 10 ثواني (${r.delivery}) — اقفل الشاشة وجرّب!` : 'فشل الجدولة — راجع الصلاحيات');
              run();
            }}><Bell className="w-4 h-4" />جرّب إشعار (10ث)</button>
            <button className="btn btn-soft btn-sm" onClick={async () => {
              const r: any = await platform.triggerTestAlarm('alarm', 7);
              toast(r.ok ? '⏰ هيرن منبه حقيقي بعد 7 ثواني — اقفل الشاشة وشوفه!' : 'فشل الجدولة');
            }}><Clock className="w-4 h-4" />جرّب شاشة منبه (7ث)</button>
          </>
        )}
      </div>

      <div className="card px-4 py-1">
        {rows.map((r, i) => (
          <div key={i} className="flex items-start gap-2.5 py-3 border-b hairline last:border-0">
            {r.ok === true ? <CheckCircle2 className="w-5 h-5 text-[var(--ok)] shrink-0 mt-0.5" />
              : r.ok === false ? <XCircle className="w-5 h-5 text-[var(--danger)] shrink-0 mt-0.5" />
              : <AlertCircle className="w-5 h-5 text-[var(--info)] shrink-0 mt-0.5" />}
            <div className="flex-1 min-w-0">
              <p className="text-[0.84rem] font-bold flex items-center gap-1.5">
                {r.label}
                {r.help && <HelpTip title={r.label}><p>{r.help}</p></HelpTip>}
              </p>
              {r.detail && <p className="text-[0.65rem] text-2 mt-0.5 leading-snug">{r.detail}</p>}
            </div>
            {r.ok === false && r.fix && (
              <button className="btn btn-soft btn-sm shrink-0" onClick={() => { r.fix!(); setTimeout(run, 1500); }}>فعّلها</button>
            )}
          </div>
        ))}
      </div>

      <div className="card-flat p-3 mt-3 text-[0.65rem] text-2 leading-relaxed flex items-start gap-2">
        <BatteryWarning className="w-4 h-4 text-[var(--warn)] shrink-0 mt-0.5" />
        <p><b>نصيحة لموبايلات شاومي وأوبو وريلمي وهواوي وسامسونج:</b> لو لاحظت تأخير في الإشعارات بعد قفل الشاشة: افتح إعدادات الموبايل ← التطبيقات ← <b>مدير اليوم</b> ← البطارية ← <b>غير مقيّد</b>، وفعّل «التشغيل التلقائي (Autostart)» لو موجود.</p>
      </div>
      <span className="hidden"><FlaskConical /></span>
    </>
  );
}
