/* DAYFLOW — Notification Center (real AlarmManager upcoming + missed + real merged Android delivery/action log) */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Bell, BellRing, CheckCheck, XCircle, AlarmClock, Search, ListRestart, Trash2, Inbox, ShieldCheck,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, addDays, nowMin, minToTime, isNative } from '@/lib/db';
import { platform, haptic } from '@/lib/platform';
import { syncNative } from '@/lib/sync';
import { Segmented, EmptyState, HelpTip } from '@/components/ui';
import type { ActivityBlock } from '@/lib/types';
import { cn } from '@/utils/cn';

type NotifTab = 'upcoming' | 'missed' | 'log';
interface NotifLogRow { id: string; title: string; body: string; kind?: string; status: string; triggerAt: number }

const STATUS_AR: Record<string, string> = {
  sent: 'اتبعَت ✓', done: 'خلصت ✓', partial: 'خلصت جزء', start_now: 'بدأت دلوقتي',
  skip: 'تخطّي', snooze: 'اتأجّل', prayed: 'صلّيت ✓', log_water: 'شربت مية 💧',
  alarm_snooze: 'غفوة منبه', alarm_dismiss: 'إيقاف منبه', dismiss: 'اتقفل',
  stop_audio: 'وقف الصوت', blocked_no_permission: 'ممنوع (محتاج صلاحية!)', blocked_security: 'ممنوع من النظام',
};

export default function NotificationsModule() {
  const { lang, hour12, tick, toast, bump, navigate } = useApp();
  const [tab, setTab] = useState<NotifTab>('upcoming');
  const [q, setQ] = useState('');
  const [blocks, setBlocks] = useState<ActivityBlock[]>([]);
  const [logs, setLogs] = useState<NotifLogRow[]>([]);
  const [busy, setBusy] = useState(false);

  const reload = useCallback(async () => {
    const [b, dbLogs, nativeLog] = await Promise.all([
      db.all<ActivityBlock>('activity_blocks'),
      db.all<NotifLogRow>('notifications'),
      isNative() ? platform.notificationLog() : Promise.resolve({ ok: false, items: [] }),
    ]);
    const nat: NotifLogRow[] = Array.isArray((nativeLog as any)?.items) ? (nativeLog as any).items : [];
    const seen = new Set<string>();
    const merged = [...nat, ...dbLogs].filter(x => {
      if (!x?.id || seen.has(x.id)) return false;
      seen.add(x.id); return true;
    }).sort((a, b) => (b.triggerAt || 0) - (a.triggerAt || 0));
    setBlocks(b);
    setLogs(merged);
  }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const now = new Date();
  const today = todayKey();
  const horizonEnd = addDays(today, 3);
  const query = q.trim().toLowerCase();

  const upcoming = useMemo(() => blocks
    .filter(b => b.reminderMin >= 0 && b.status !== 'done' && b.status !== 'cancelled' && b.status !== 'skipped')
    .filter(b => b.date >= today && b.date <= horizonEnd)
    .filter(b => !query || b.title.toLowerCase().includes(query) || (b.notes ?? '').toLowerCase().includes(query))
    .sort((a, b) => (a.date === b.date ? a.startMin - b.startMin : a.date.localeCompare(b.date)))
    .slice(0, 60), [blocks, query, today, horizonEnd]);

  const missed = useMemo(() => blocks
    .filter(b => b.reminderMin >= 0 && (
      b.status === 'missed' || b.status === 'skipped' ||
      (b.date < today && b.status === 'planned') ||
      (b.date === today && b.endMin < now.getHours() * 60 + now.getMinutes() && b.status === 'planned')
    ))
    .filter(b => !query || b.title.toLowerCase().includes(query))
    .sort((a, b) => b.date.localeCompare(a.date)).slice(0, 60), [blocks, query, today, now]);

  const filteredLogs = logs.filter(l => !query || (l.title + ' ' + l.body).toLowerCase().includes(query)).slice(0, 100);

  const markDone = async (b: ActivityBlock) => {
    await db.put('activity_blocks', { ...b, status: 'done', actualEndMin: nowMin(), updatedAt: Date.now() });
    await platform.cancelAlarm(b.id);
    haptic('light'); bump();
    toast(lang === 'ar' ? 'تمام خلصت ✓ واتلغى تنبيهها' : 'Done — alarms cancelled');
  };

  const snooze = async (b: ActivityBlock, minutes: number) => {
    const res = await platform.scheduleBlockAlarm(
      { ...b, date: today, startMin: nowMin() + minutes, reminderMin: 0 },
      `${lang === 'ar' ? 'مؤجّل' : 'Snoozed'}: ${b.title}`
    );
    toast(res.ok ? `هيوصلك تاني بعد ${minutes} دقايق ✓` : res.unsupported ? 'التأجيل الحقيقي شغال في تطبيق الأندرويد' : 'تعذر التأجيل — راجع صلاحيات الإشعارات');
  };

  const cancelReminder = async (b: ActivityBlock) => {
    await db.put('activity_blocks', { ...b, reminderMin: -1, updatedAt: Date.now() });
    await platform.cancelAlarm(b.id);
    bump();
    toast(lang === 'ar' ? 'اتلغى التنبيه بتاعها' : 'Reminder removed');
  };

  const rescheduleAll = async () => {
    setBusy(true);
    const res = await syncNative();
    setBusy(false);
    reload();
    toast(
      res.unsupported ? `عندك ${res.items} تنبيه جاهز — بيتجدول فعلياً في تطبيق الأندرويد`
      : res.ok ? `اتجدول ${res.scheduled} تنبيه (${res.exact} دقيق) واتمسح ${res.removed} قديم ✓`
      : `فشل: ${res.error ?? ''}`
    );
  };

  const fmtDay = (key: string) => new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-GB', { weekday: 'short', day: 'numeric', month: 'short' }).format(new Date(key + 'T12:00:00'));

  const row = (b: ActivityBlock, tone: 'upcoming' | 'missed') => (
    <div key={b.id} className="card-flat p-2.5 flex items-center gap-2.5">
      <div className={cn('w-10 h-10 rounded-2xl grid place-items-center shrink-0', tone === 'missed' ? 'bg-[var(--danger-soft)] text-[var(--danger)]' : 'bg-[var(--accent-soft)] accent')}>
        {tone === 'missed' ? <XCircle className="w-5 h-5" /> : <BellRing className="w-5 h-5" />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold leading-snug truncate">{b.title}</p>
        <p className="num text-[0.6rem] text-2 mt-0.5">{fmtDay(b.date)} · {minToTime(b.startMin, hour12)}{b.reminderMin > 0 ? ` (قبلها بـ ${b.reminderMin}د)` : ''}</p>
        {b.notes && !b.notes.startsWith('tpl:') && <p className="text-[0.58rem] text-3 truncate">📝 {b.notes}</p>}
      </div>
      {tone === 'upcoming' ? (
        <div className="flex items-center gap-0.5 shrink-0">
          <button className="icon-btn !w-8 !h-8" onClick={() => snooze(b, 10)} title="أجّل 10 د"><AlarmClock className="w-4 h-4" /></button>
          <button className="icon-btn !w-8 !h-8 text-[var(--ok)]" onClick={() => markDone(b)} title="خلصت"><CheckCheck className="w-5 h-5" /></button>
          <button className="icon-btn !w-8 !h-8" onClick={() => cancelReminder(b)} title="الغي التنبيه"><Trash2 className="w-4 h-4" /></button>
        </div>
      ) : (
        <button className="btn btn-soft btn-sm shrink-0" onClick={() => markDone(b)}>خلصت ✓</button>
      )}
    </div>
  );

  return (
    <div className="pb-6 px-4 pt-14">
      <div className="flex items-center justify-between gap-2">
        <h1 className="skin-title font-extrabold flex items-center gap-1.5">
          <Bell className="w-6 h-6 accent" />{lang === 'ar' ? 'مركز الإشعارات' : 'Notifications'}
          <HelpTip title="مركز الإشعارات">
            <p>هنا بتشوف <b>الحالة الحقيقية</b> لكل إشعاراتك — مش أرقام وهمية:</p>
            <ul>
              <li><b>الجاية:</b> الأنشطة اللي متجدول لها تنبيه الأيام الجاية (أندرويد بيوصّلها حتى والتطبيق مقفول).</li>
              <li><b>اللي فاتوا:</b> الأنشطة اللي وقتها عدّى ولسه متسجلتش.</li>
              <li><b>السجل:</b> كل إشعار اتبعت فعلاً وكل زرار ضغطت عليه (خلصت / أجّل / صلّيت / شربت مية).</li>
              <li><b>ملحوظة:</b> المناسبات المسيحية واليهودية محذوفة تلقائياً من الإشعارات والويدجيت.</li>
            </ul>
          </HelpTip>
        </h1>
        <button className="btn btn-soft btn-sm" onClick={rescheduleAll} disabled={busy}>
          <ListRestart className="w-4 h-4" />{busy ? '…' : (lang === 'ar' ? 'جدوِل الكل' : 'Sync all')}
        </button>
      </div>

      <p className="text-[0.62rem] text-2 mt-1.5 flex items-center gap-1">
        <ShieldCheck className="w-3.5 h-3.5 text-[var(--ok)] shrink-0" />
        {lang === 'ar' ? 'المناسبات الإسلامية والوطنية ومناسباتك فقط — المناسبات المسيحية واليهودية مستبعدة تلقائياً.' : 'Christian & Jewish occasions are automatically excluded.'}
      </p>

      <div className="relative mt-2.5">
        <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-3" />
        <input className="input ps-9" value={q} onChange={e => setQ(e.target.value)} placeholder={lang === 'ar' ? 'دوّر في الإشعارات…' : 'Search notifications…'} />
      </div>

      <div className="mt-2.5">
        <Segmented value={tab} onChange={v => setTab(v as NotifTab)} options={[
          { value: 'upcoming', label: `${lang === 'ar' ? 'الجاية' : 'Upcoming'} (${upcoming.length})` },
          { value: 'missed', label: `${lang === 'ar' ? 'فاتت' : 'Missed'} (${missed.length})` },
          { value: 'log', label: `${lang === 'ar' ? 'السجل' : 'Log'} (${filteredLogs.length})` },
        ]} />
      </div>

      <div className="space-y-1.5 mt-3">
        {tab === 'upcoming' && (upcoming.length ? upcoming.map(b => row(b, 'upcoming')) : (
          <EmptyState icon={<Bell className="w-7 h-7" />} title="مفيش تنبيهات جاية دلوقتي" hint="ضيف أنشطة في خطتك وفعّل التنبيه ودوس «طبّق الخطة»" action={<button className="btn btn-primary" onClick={() => navigate('plan')}>افتح الخطة</button>} />
        ))}
        {tab === 'missed' && (missed.length ? missed.map(b => row(b, 'missed')) : (
          <EmptyState icon={<CheckCheck className="w-7 h-7" />} title="ممتاز! مفيش حاجة فاتتك" hint="يومك نضيف تماماً — كمّل كده 👏" />
        ))}
        {tab === 'log' && (filteredLogs.length ? filteredLogs.map(l => (
          <div key={l.id} className="card-flat px-3 py-2.5 flex items-start gap-2.5">
            <span className={cn('w-2 h-2 rounded-full mt-1.5 shrink-0',
              l.status === 'done' || l.status === 'prayed' || l.status === 'log_water' ? 'bg-[var(--ok)]'
              : l.status.startsWith('blocked') ? 'bg-[var(--danger)]'
              : l.status === 'sent' ? 'bg-[var(--info)]' : 'bg-[var(--warn)]')} />
            <div className="flex-1 min-w-0">
              <p className="text-[0.78rem] font-bold truncate">{l.title}</p>
              {l.body && <p className="text-[0.6rem] text-2 line-clamp-2 whitespace-pre-line">{l.body}</p>}
              <span className="inline-block mt-1 text-[0.58rem] font-extrabold text-2 bg-[var(--surface-2)] rounded-full px-2 py-0.5">
                {STATUS_AR[l.status] ?? l.status}
              </span>
            </div>
            <span className="num text-[0.58rem] text-3 shrink-0">
              {l.triggerAt ? new Date(l.triggerAt).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-GB', { day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''}
            </span>
          </div>
        )) : (
          <EmptyState icon={<Inbox className="w-7 h-7" />} title="السجل فاضي لسه" hint="هيتسجّل هنا كل إشعار وصلك وكل ضغطة عملتها (خلصت / أجّل / صلّيت / شربت مية)" />
        ))}
      </div>
    </div>
  );
}
