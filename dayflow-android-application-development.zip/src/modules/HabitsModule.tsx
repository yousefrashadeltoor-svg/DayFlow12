/* DAYFLOW — Habits · Water · Sleep · Meals (all real, all on-device) */
import { useCallback, useEffect, useState } from 'react';
import {
  Flame, Plus, Check, Trash2, Droplets, MoonStar, Sunrise, Utensils, BedDouble, Coffee, Salad, Apple,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, nowMin, newId } from '@/lib/db';
import { habitStreak, lastNDays, avgWater, fmtMinutes } from '@/lib/stats';
import { ProgressRing, Sheet, EmptyState, Field, Segmented, HelpTip } from '@/components/ui';
import { Heatmap } from '@/components/charts';
import { haptic } from '@/lib/platform';
import type { Habit, HabitLog, WaterLog, MealLog, SleepLog } from '@/lib/types';
import { cn } from '@/utils/cn';

type HabTab = 'habits' | 'water' | 'sleep' | 'meals';

export default function HabitsModule({ params }: { params?: { tab?: HabTab } }) {
  const { t, lang } = useApp();
  const [tab, setTab] = useState<HabTab>(params?.tab ?? 'habits');
  return (
    <div className="pb-6 px-4 pt-14">
      <h1 className="skin-title font-extrabold flex items-center gap-2">{lang === 'ar' ? 'العادات والمية والنوم' : 'Habits & wellness'}<HelpTip title="العادات والصحة اليومية"><p>تابع عاداتك (سلسلة الأيام 🔥 مبتتمسحش تاريخياً لو فوت يوم)، اشرب ميتك بالهدف اللي تختاره، خطط نومك، وسجّل وجباتك من غير أي أحكام ولا ضغط.</p></HelpTip></h1>
      <div className="mt-2"><Segmented value={tab} onChange={v => setTab(v as HabTab)} options={[{ value: 'habits', label: t('habits') }, { value: 'water', label: t('water') }, { value: 'sleep', label: t('sleep') }, { value: 'meals', label: t('meals') }]} /></div>
      {tab === 'habits' && <HabitsTab />}
      {tab === 'water' && <WaterTab />}
      {tab === 'sleep' && <SleepTab />}
      {tab === 'meals' && <MealsTab />}
    </div>
  );
}

/* ================= HABITS ================= */
function HabitsTab() {
  const { lang, tick, toast, bump } = useApp();
  const [habits, setHabits] = useState<Habit[]>([]);
  const [logs, setLogs] = useState<HabitLog[]>([]);
  const [addOpen, setAddOpen] = useState(false);
  const [detail, setDetail] = useState<Habit | null>(null);
  const reload = useCallback(async () => { const [h, l] = await Promise.all([db.all<Habit>('habits'), db.all<HabitLog>('habit_logs')]); setHabits(h); setLogs(l); }, []);
  useEffect(() => { reload(); }, [reload, tick]);

  const today = todayKey();
  const toggleToday = async (h: Habit) => {
    const todayLog = logs.find(l => l.habitId === h.id && l.date === today);
    if (todayLog && todayLog.count >= h.targetCount) { await db.del('habit_logs', todayLog.id); }
    else if (todayLog) await db.put('habit_logs', { ...todayLog, count: todayLog.count + 1 });
    else await db.put('habit_logs', { id: newId(), habitId: h.id, date: today, count: 1 });
    haptic('medium'); bump();
  };

  return (
    <div className="mt-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-bold text-2">{habits.length} {lang === 'ar' ? 'عادة نشطة' : 'active habits'}</p>
        <button className="btn btn-soft btn-sm" onClick={() => setAddOpen(true)}><Plus className="w-4 h-4" />{lang === 'ar' ? 'عادة' : 'Habit'}</button>
      </div>
      <div className="space-y-2 mt-2">
        {habits.map(h => {
          const todayLog = logs.find(l => l.habitId === h.id && l.date === today);
          const done = (todayLog?.count ?? 0) >= h.targetCount;
          const streak = habitStreak(logs.filter(l => l.habitId === h.id), h.targetCount);
          return (
            <div key={h.id} className={cn('card-flat p-3 flex items-center gap-3 border transition-colors', done ? 'border-[var(--ok)]' : 'border-transparent')}>
              <button onClick={() => toggleToday(h)} className={cn('w-12 h-12 rounded-2xl grid place-items-center shrink-0 transition-all', done ? 'bg-[var(--ok)] text-white' : 'bg-[var(--surface-2)]')} style={!done ? { color: h.color } : undefined} aria-pressed={done} aria-label={h.name}>
                {done ? <Check className="w-6 h-6" /> : <Flame className="w-6 h-6" />}
              </button>
              <button className="flex-1 min-w-0 text-start" onClick={() => setDetail(h)}>
                <p className="font-bold leading-snug">{h.name}{h.negative && <span className="text-[0.58rem] text-3 font-semibold"> · {lang === 'ar' ? 'تقليل' : 'reduce'}</span>}</p>
                <p className="num text-[0.62rem] text-2 mt-0.5"><span className="text-[var(--warn)] font-extrabold">{streak.current} 🔥</span> {lang === 'ar' ? `الحالية · الأفضل ${streak.best} · التزام ٣٠ يوم ${streak.rate30}%` : `current · best ${streak.best} · 30d ${streak.rate30}%`}</p>
              </button>
              <span className="num text-[0.68rem] font-bold text-2">{todayLog?.count ?? 0}/{h.targetCount}</span>
            </div>
          );
        })}
        {habits.length === 0 && <EmptyState icon={<Flame className="w-7 h-7" />} title={lang === 'ar' ? 'لسه مفيش عادات' : 'No habits yet'} hint={lang === 'ar' ? 'ابدأ بعادة واحدة بسيطة: قراية، مشي، أذكار، أو شرب مية' : 'Start with just one — reading, water, walking…'} action={<button className="btn btn-primary" onClick={() => setAddOpen(true)}><Plus className="w-4 h-4" />{lang === 'ar' ? 'عادة جديدة' : 'New habit'}</button>} />}
      </div>

      {/* habit detail heatmap */}
      <Sheet open={!!detail} onClose={() => setDetail(null)} title={detail?.name}>
        {detail && (() => {
          const l = logs.filter(x => x.habitId === detail.id);
          const days = lastNDays(84);
          const byDate = new Map(l.map(x => [x.date, x.count]));
          const weeks: Array<Array<{ date: string; level: 0|1|2|3|4 }>> = [];
          for (let i = 0; i < days.length; i += 7) weeks.push(days.slice(i, i + 7).map(date => { const c = byDate.get(date) ?? 0; return { date, level: (c <= 0 ? 0 : c >= detail.targetCount ? 4 : 2) as any }; }));
          const streak = habitStreak(l, detail.targetCount);
          return (
            <div>
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="card-inset p-2 text-center"><p className="num text-xl font-extrabold text-[var(--warn)]">{streak.current}</p><p className="text-[0.58rem] font-bold text-2">{lang === 'ar' ? 'السلسلة الحالية' : 'Current streak'}</p></div>
                <div className="card-inset p-2 text-center"><p className="num text-xl font-extrabold">{streak.best}</p><p className="text-[0.58rem] font-bold text-2">{lang === 'ar' ? 'الأفضل' : 'Best'}</p></div>
                <div className="card-inset p-2 text-center"><p className="num text-xl font-extrabold">{streak.rate30}%</p><p className="text-[0.58rem] font-bold text-2">{lang === 'ar' ? 'التزام ٣٠ يوم' : '30-day rate'}</p></div>
              </div>
              <Heatmap weeks={weeks} today={todayKey()} />
              <button className="btn btn-danger btn-sm w-full justify-center mt-4" onClick={async () => { const stash = detail; const stashLogs = l; await db.del('habits', stash.id); for (const x of stashLogs) await db.del('habit_logs', x.id); setDetail(null); bump(); toast(lang === 'ar' ? 'حُذفت العادة وسجلها' : 'Habit and its log deleted', { actionLabel: lang === 'ar' ? 'تراجع' : 'Undo', onAction: async () => { await db.put('habits', stash); await db.bulkPut('habit_logs', stashLogs); bump(); } }); }}><Trash2 className="w-4 h-4" />{lang === 'ar' ? 'حذف العادة' : 'Delete habit'}</button>
            </div>
          );
        })()}
      </Sheet>

      {/* add habit */}
      <HabitCreator open={addOpen} onClose={() => setAddOpen(false)} />
    </div>
  );
}

function HabitCreator({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { lang, t, toast, bump } = useApp();
  const [name, setName] = useState(''); const [frequency, setFrequency] = useState<'daily' | 'weekly' | 'custom'>('daily');
  const [targetPerWeek, setTargetPerWeek] = useState(5); const [targetCount, setTargetCount] = useState(1); const [negative, setNegative] = useState(false); const [color, setColor] = useState('#d97706');
  const colors = ['#d97706', '#0da271', '#5856d6', '#e0356a', '#0ea5e9', '#7c5cfc'];
  const save = async () => {
    if (!name.trim()) { toast(lang === 'ar' ? 'أدخل اسم العادة' : 'Enter habit name'); return; }
    await db.put('habits', { id: newId(), name: name.trim(), icon: 'flame', color, frequency, targetPerWeek, targetCount, unit: lang === 'ar' ? 'مرة' : 'times', reminderMin: null, category: 'personal', negative, createdAt: Date.now() });
    setName(''); onClose(); bump(); toast(t('saved'));
  };
  return (
    <Sheet open={open} onClose={onClose} title={lang === 'ar' ? 'عادة جديدة' : 'New habit'}>
      <Field label={lang === 'ar' ? 'الاسم' : 'Name'}><input autoFocus className="input" value={name} onChange={e => setName(e.target.value)} placeholder={lang === 'ar' ? 'أقرأ ٢٠ دقيقة قبل النوم…' : 'Read 20 minutes before bed…'} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label={lang === 'ar' ? 'التكرار' : 'Frequency'}><select className="input" value={frequency} onChange={e => setFrequency(e.target.value as any)}><option value="daily">{lang === 'ar' ? 'يومياً' : 'Daily'}</option><option value="weekly">{lang === 'ar' ? 'أسبوعياً' : 'Weekly'}</option><option value="custom">{lang === 'ar' ? 'مخصص' : 'Custom'}</option></select></Field>
        {frequency === 'weekly'
          ? <Field label={lang === 'ar' ? 'المرات/أسبوع' : 'Times/week'}><input type="number" min={1} max={7} className="input num" value={targetPerWeek} onChange={e => setTargetPerWeek(Math.max(1, Math.min(7, Number(e.target.value) || 1)))} /></Field>
          : <Field label={lang === 'ar' ? 'الهدف اليومي' : 'Daily target'}><input type="number" min={1} max={99} className="input num" value={targetCount} onChange={e => setTargetCount(Math.max(1, Number(e.target.value) || 1))} /></Field>}
      </div>
      <span className="label">{lang === 'ar' ? 'اللون' : 'Color'}</span>
      <div className="flex gap-2 mb-3">{colors.map(c => <button key={c} onClick={() => setColor(c)} className={cn('w-8 h-8 rounded-full', color === c && 'scale-125 ring-2 ring-offset-2 ring-[var(--accent)]')} style={{ background: c }} aria-label={c} />)}</div>
      <button className={cn('chip mb-3', negative && 'chip-active')} onClick={() => setNegative(v => !v)}>{lang === 'ar' ? 'عادة أريد تقليلها' : 'A habit to reduce'}</button>
      <button className="btn btn-primary w-full justify-center !py-3" onClick={save}>{t('save')}</button>
    </Sheet>
  );
}

/* ================= WATER ================= */
function WaterTab() {
  const { lang, tick, settings, saveSettings, bump } = useApp();
  const [logs, setLogs] = useState<WaterLog[]>([]);
  const [custom, setCustom] = useState(300);
  const reload = useCallback(async () => setLogs(await db.all<WaterLog>('water_logs')), []);
  useEffect(() => { reload(); }, [reload, tick]);
  const today = todayKey();
  const todayLogs = logs.filter(l => l.date === today).sort((a, b) => a.timeMin - b.timeMin);
  const todayMl = todayLogs.reduce((s, l) => s + l.amountMl, 0);
  const pct = Math.min(100, (todayMl / settings.waterTargetMl) * 100);
  const avg = avgWater(logs, 7);
  const add = async (ml: number) => { await db.put('water_logs', { id: newId(), date: today, timeMin: Math.round(nowMin()), amountMl: ml, createdAt: Date.now() }); haptic('medium'); bump(); };
  return (
    <div className="mt-3">
      <div className="card p-5 flex flex-col items-center">
        <ProgressRing size={150} stroke={13} progress={pct} track="var(--surface-2)">
          <div className="text-center"><p className="num text-3xl font-extrabold text-[var(--cat-water)]">{todayMl}</p><p className="text-[0.6rem] font-bold text-2">/ {settings.waterTargetMl} ml</p></div>
        </ProgressRing>
        <p className="text-[0.7rem] text-2 font-semibold mt-2">{lang === 'ar' ? `متوسط ٧ أيام: ${avg} مل/يوم` : `7-day average: ${avg} ml/day`}</p>
        <div className="flex flex-wrap gap-2 justify-center mt-3">
          {[settings.waterCupMl, 330, 500, 750].filter((v, i, a) => a.indexOf(v) === i).map(ml => <button key={ml} className="btn btn-soft btn-sm num" onClick={() => add(ml)}><Droplets className="w-4 h-4" />+{ml}</button>)}
        </div>
        <div className="flex items-center gap-2 mt-3">
          <input type="number" className="input w-24 num !py-2" min={50} step={50} value={custom} onChange={e => setCustom(Math.max(50, Number(e.target.value) || 50))} />
          <button className="btn btn-ghost btn-sm" onClick={() => add(custom)}>{lang === 'ar' ? 'مل مخصص' : 'ml custom'}</button>
        </div>
        <label className="flex items-center gap-2 mt-4 text-[0.68rem] font-bold text-2">{lang === 'ar' ? 'الهدف اليومي (مل):' : 'Daily target (ml):'}<input type="number" className="input w-24 num !py-1.5" value={settings.waterTargetMl} onChange={e => saveSettings({ waterTargetMl: Math.max(500, Number(e.target.value) || 2000) })} /></label>
      </div>
      <p className="text-[0.7rem] font-extrabold text-2 uppercase mt-4 mb-1">{lang === 'ar' ? 'سجل النهارده' : "Today's log"}</p>
      <div className="space-y-1">{todayLogs.map(l => (
        <div key={l.id} className="card-flat px-3 py-2 flex items-center gap-2"><Droplets className="w-4 h-4 text-[var(--cat-water)]" /><span className="num text-xs text-2 w-12">{String(Math.floor(l.timeMin / 60)).padStart(2, '0')}:{String(Math.floor(l.timeMin % 60)).padStart(2, '0')}</span><span className="num text-sm font-bold flex-1">{l.amountMl} ml</span><button className="icon-btn !w-8 !h-8" onClick={async () => { await db.del('water_logs', l.id); bump(); }} aria-label="delete"><Trash2 className="w-4 h-4" /></button></div>
      ))}{todayLogs.length === 0 && <p className="text-sm text-3 text-center py-4">{lang === 'ar' ? 'لسه مشربتش مية متسجلة النهارده 💧' : 'No water logged yet today'}</p>}</div>
    </div>
  );
}

/* ================= SLEEP ================= */
const minToInput = (min: number) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(Math.floor(min % 60)).padStart(2, '0')}`;
const inputToMin = (s: string) => { const [h, m] = s.split(':').map(Number); return h * 60 + (m || 0); };

function SleepTab() {
  const { t, lang, tick, settings, saveSettings, bump, toast } = useApp();
  const [logs, setLogs] = useState<SleepLog[]>([]);
  const [bedtime, setBedtime] = useState(settings.bedtimeMin); const [wake, setWake] = useState(settings.wakeMin);
  const [quality, setQuality] = useState<1|2|3|4|5>(4);
  const reload = useCallback(async () => setLogs(await db.all<SleepLog>('sleep_logs')), []);
  useEffect(() => { reload(); }, [reload, tick]);
  useEffect(() => { setBedtime(settings.bedtimeMin); setWake(settings.wakeMin); }, [settings.bedtimeMin, settings.wakeMin]);
  const today = todayKey();
  const todayLog = logs.find(l => l.date === today);
  const planDur = ((settings.wakeMin - settings.bedtimeMin + 1440) % 1440) || 480;
  const last7 = lastNDays(7).map(d => logs.find(l => l.date === d)).filter(Boolean) as SleepLog[];
  const consistency = last7.length ? Math.round((last7.filter(l => Math.abs(l.bedtimeMin - settings.bedtimeMin) <= 30).length / last7.length) * 100) : null;
  const saveLog = async () => {
    const dur = ((wake - bedtime + 1440) % 1440) || 480;
    await db.put('sleep_logs', { id: todayLog?.id ?? newId(), date: today, bedtimeMin: bedtime, wakeMin: wake, actualSleepMin: dur, quality, createdAt: todayLog?.createdAt ?? Date.now() });
    toast(t('saved')); bump();
  };
  return (
    <div className="mt-3">
      <div className="card p-4">
        <div className="flex items-center gap-3"><BedDouble className="w-6 h-6 text-[var(--cat-sleep)]" /><div><p className="font-extrabold">{lang === 'ar' ? 'خطة نومك' : 'Your sleep plan'}</p><p className="text-[0.65rem] text-2">{lang === 'ar' ? `المدة المخططة: ${fmtMinutes(planDur, lang)}` : `Planned duration: ${fmtMinutes(planDur, lang)}`}</p></div></div>
        <div className="grid grid-cols-2 gap-3 mt-3">
          <Field label={lang === 'ar' ? 'موعد النوم' : 'Bedtime'}><input type="time" className="input num" value={minToInput(bedtime)} onChange={e => { const v = inputToMin(e.target.value); setBedtime(v); saveSettings({ bedtimeMin: v }); }} /></Field>
          <Field label={lang === 'ar' ? 'الاستيقاظ' : 'Wake up'}><input type="time" className="input num" value={minToInput(wake)} onChange={e => { const v = inputToMin(e.target.value); setWake(v); saveSettings({ wakeMin: v }); }} /></Field>
        </div>
        <Field label={lang === 'ar' ? `تذكير ما قبل النوم — ${settings.preSleepReminderMin} دقيقة` : `Pre-sleep reminder — ${settings.preSleepReminderMin} min`}>
          <input type="range" min={15} max={120} step={5} className="w-full accent-[var(--accent)]" value={settings.preSleepReminderMin} onChange={e => saveSettings({ preSleepReminderMin: Number(e.target.value) })} />
        </Field>
        <Field label={lang === 'ar' ? 'جودة نومك الليلة' : "Tonight's sleep quality"}>
          <div className="flex gap-2">{([1, 2, 3, 4, 5] as const).map(q => <button key={q} className={cn('w-10 h-10 rounded-xl border num font-extrabold transition-all', quality === q ? 'bg-[var(--accent)] text-[var(--on-accent)] border-transparent scale-110' : 'border-[var(--border)]')} onClick={() => setQuality(q)}>{q}</button>)}</div>
        </Field>
        <button className="btn btn-primary w-full justify-center !py-3" onClick={saveLog}><MoonStar className="w-5 h-5" />{lang === 'ar' ? 'سجّل نوم الليلة' : "Log last night's sleep"}</button>
        <p className="text-[0.55rem] text-3 mt-2">{lang === 'ar' ? 'ملاحظة: هذا سجل ذاتي وليس قياساً طبياً لنومك.' : 'Note: this is a self-logged record, not a medical measurement.'}</p>
      </div>
      {consistency !== null && <div className="card-flat p-3 mt-3 flex items-center gap-3"><Sunrise className="w-5 h-5 text-[var(--warn)]" /><p className="text-sm font-bold flex-1">{lang === 'ar' ? 'انتظامك هذا الأسبوع' : 'Your consistency this week'}</p><p className="num text-xl font-extrabold accent">{consistency}%</p></div>}
      <p className="text-[0.7rem] font-extrabold text-2 uppercase mt-4 mb-1">{lang === 'ar' ? 'آخر الليالي' : 'Recent nights'}</p>
      <div className="space-y-1">{last7.slice().reverse().map(l => (
        <div key={l.id} className="card-flat px-3 py-2 flex items-center gap-2"><MoonStar className="w-4 h-4 text-[var(--cat-sleep)]" /><span className="num text-xs text-2 flex-1">{l.date}</span><span className="num text-xs font-bold">{minToInput(l.bedtimeMin)} → {minToInput(l.wakeMin)}</span>{l.quality && <span className="num text-xs text-2">★{l.quality}</span>}</div>
      ))}{last7.length === 0 && <p className="text-sm text-3 text-center py-4">{lang === 'ar' ? 'لا توجد سجلات بعد' : 'No nights logged yet'}</p>}</div>
    </div>
  );
}

/* ================= MEALS ================= */
function MealsTab() {
  const { lang, tick, bump, toast } = useApp();
  const [logs, setLogs] = useState<MealLog[]>([]);
  const [custom, setCustom] = useState(''); const [calories, setCalories] = useState('');
  const reload = useCallback(async () => setLogs(await db.all<MealLog>('meal_logs')), []);
  useEffect(() => { reload(); }, [reload, tick]);
  const today = todayKey();
  const todayLogs = logs.filter(l => l.date === today).sort((a, b) => a.timeMin - b.timeMin);
  const add = async (name: string) => { await db.put('meal_logs', { id: newId(), date: today, timeMin: Math.round(nowMin()), mealName: name, calories: calories ? Number(calories) : null, notes: '', createdAt: Date.now() }); setCustom(''); setCalories(''); haptic('light'); bump(); toast(lang === 'ar' ? 'سُجلت الوجبة' : 'Meal logged'); };
  const presets = [{ n: lang === 'ar' ? 'إفطار' : 'Breakfast', icon: Coffee }, { n: lang === 'ar' ? 'غداء' : 'Lunch', icon: Utensils }, { n: lang === 'ar' ? 'عشاء' : 'Dinner', icon: Salad }, { n: lang === 'ar' ? 'سناك' : 'Snack', icon: Apple }];
  return (
    <div className="mt-3">
      <p className="text-[0.62rem] text-3 px-1">{lang === 'ar' ? 'متابعة اختيارية وليست أحكاماً — الغرض التقويم والتذكير فقط.' : 'Optional and non-judgmental — this is for scheduling, not restriction.'}</p>
      <div className="grid grid-cols-4 gap-2 mt-2">{presets.map((p, i) => <button key={i} className="card-flat py-3 flex flex-col items-center gap-1.5" onClick={() => add(p.n)}><p.icon className="w-6 h-6 accent" /><span className="text-[0.65rem] font-bold">{p.n}</span></button>)}</div>
      <div className="flex gap-2 mt-3"><input className="input flex-1" value={custom} onChange={e => setCustom(e.target.value)} placeholder={lang === 'ar' ? 'وجبة مخصصة…' : 'Custom meal…'} onKeyDown={e => e.key === 'Enter' && custom.trim() && add(custom.trim())} /><input type="number" className="input w-24 num" placeholder="kcal" value={calories} onChange={e => setCalories(e.target.value)} /><button className="btn btn-primary btn-sm" onClick={() => custom.trim() && add(custom.trim())}><Plus className="w-4 h-4" /></button></div>
      <p className="text-[0.7rem] font-extrabold text-2 uppercase mt-4 mb-1">{lang === 'ar' ? 'وجبات اليوم' : "Today's meals"}</p>
      <div className="space-y-1">{todayLogs.map(l => (
        <div key={l.id} className="card-flat px-3 py-2 flex items-center gap-2"><Utensils className="w-4 h-4 text-[var(--cat-meal)]" /><span className="num text-xs text-2 w-12">{String(Math.floor(l.timeMin / 60)).padStart(2, '0')}:{String(Math.floor(l.timeMin % 60)).padStart(2, '0')}</span><span className="flex-1 text-sm font-bold">{l.mealName}</span>{l.calories ? <span className="num text-[0.68rem] text-2">{l.calories} kcal</span> : null}<button className="icon-btn !w-8 !h-8" onClick={async () => { await db.del('meal_logs', l.id); bump(); }} aria-label="delete"><Trash2 className="w-4 h-4" /></button></div>
      ))}{todayLogs.length === 0 && <p className="text-sm text-3 text-center py-4">{lang === 'ar' ? 'لسه مسجّلتش وجبات النهارده' : 'No meals logged yet today'}</p>}</div>
    </div>
  );
}
