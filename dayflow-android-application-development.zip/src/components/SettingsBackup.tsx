/* DAYFLOW — Data section: JSON backup (AES-GCM optional) · CSV · XLSX · restore */
import { useEffect, useRef, useState } from 'react';
import {
  FileJson, FileSpreadsheet, FileDown, FileUp, Trash2, AlertTriangle, ShieldCheck, Check, Database, History,
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey } from '@/lib/db';
import {
  createJsonBackup, previewJsonBackup, restoreJsonBackup, exportCsvDataset, exportXlsx,
  downloadTextFile, analyzeScheduleCsv, type BackupPreview, type CsvImportResult,
} from '@/lib/backup';
import { Sheet, Toggle, HelpTip } from '@/components/ui';
import type { BackupRecord } from '@/lib/types';
import { cn } from '@/utils/cn';

export default function SettingsBackup() {
  const { lang, t, toast, confirm, bump } = useApp();
  const [encrypt, setEncrypt] = useState(false);
  const [password, setPassword] = useState('');
  const [history, setHistory] = useState<BackupRecord[]>([]);
  const [restoreRaw, setRestoreRaw] = useState<any>(null);
  const [restorePreview, setRestorePreview] = useState<BackupPreview | null>(null);
  const [restorePassword, setRestorePassword] = useState('');
  const [restoreMode, setRestoreMode] = useState<'merge' | 'replace'>('merge');
  const [restoreOpen, setRestoreOpen] = useState(false);
  const [restoreError, setRestoreError] = useState('');
  const [csvResult, setCsvResult] = useState<CsvImportResult | null>(null);
  const [csvOpen, setCsvOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const csvRef = useRef<HTMLInputElement>(null);

  useEffect(() => { db.all<BackupRecord>('backup_history').then(h => setHistory(h.sort((a, b) => b.createdAt - a.createdAt).slice(0, 8))); }, [restoreOpen, csvOpen]);

  const doExportJson = async () => {
    if (encrypt && password.length < 6) { toast(lang === 'ar' ? 'كلمة المرور ٦ أحرف على الأقل' : 'Password must be at least 6 characters'); return; }
    const json = await createJsonBackup(encrypt ? password : undefined);
    downloadTextFile(`dayflow-backup-${todayKey()}.json`, json, 'application/json');
    toast(lang === 'ar' ? (encrypt ? 'نُسخت مشفّرة بنجاح' : 'تم إنشاء النسخة') : (encrypt ? 'Encrypted backup created' : 'Backup created'));
  };

  const onPickBackup = async (file: File) => {
    const text = await file.text();
    setRestoreError('');
    try {
      let preview, raw;
      try { ({ preview, raw } = await previewJsonBackup(text)); }
      catch (e: any) { if (e?.message === 'password-required') { setRestoreRaw({ encrypted: text }); setRestorePreview({ tables: {}, totalRows: -1, encrypted: true, settingsIncluded: false }); setRestoreOpen(true); return; } throw e; }
      setRestoreRaw(raw); setRestorePreview(preview); setRestoreOpen(true);
    } catch (e: any) {
      toast(lang === 'ar' ? `ملف غير صالح: ${e?.message ?? e}` : `Invalid backup file: ${e?.message ?? e}`);
    }
  };
  const doRestore = async () => {
    try {
      let raw = restoreRaw;
      if (restoreRaw?.encrypted) ({ raw } = await (async () => { const { previewJsonBackup: p } = await import('@/lib/backup'); return p(restoreRaw.encrypted, restorePassword); })());
      const summary = await restoreJsonBackup(raw, restoreMode);
      setRestoreOpen(false); setRestoreRaw(null); setRestorePreview(null); setRestorePassword('');
      bump();
      toast(lang === 'ar' ? 'تمت الاستعادة — أُعيد تحميل كل شيء' : 'Restored — everything reloaded');
      void summary;
    } catch (e: any) {
      setRestoreError(e?.message === 'invalid-backup-schema' ? (lang === 'ar' ? 'هذا ليس ملف نسخة DAYFLOW صالحاً' : 'This is not a valid DAYFLOW backup')
        : e?.message === 'unsupported-backup-version' ? (lang === 'ar' ? 'إصدار نسخة غير مدعوم' : 'Unsupported backup version')
        : lang === 'ar' ? 'كلمة المرور خاطئة أو الملف تالف' : 'Wrong password or corrupted file');
    }
  };

  const onPickCsv = async (file: File) => {
    const text = await file.text();
    const result = await analyzeScheduleCsv(text);
    setCsvResult(result); setCsvOpen(true);
  };
  const applyCsv = async () => {
    if (!csvResult) return;
    await db.bulkPut('activity_blocks', csvResult.rows);
    setCsvOpen(false); setCsvResult(null); bump();
    toast(lang === 'ar' ? `تم استيراد ${csvResult.rows.length} كتلة` : `Imported ${csvResult.rows.length} blocks`);
  };
  const doXlsx = async () => { await exportXlsx(); toast(lang === 'ar' ? 'تم تصدير Excel (كل الجداول)' : 'Excel exported (all tables)'); };
  const doCsv = async (kind: 'blocks' | 'tasks' | 'water' | 'habits') => {
    const csv = await exportCsvDataset(kind);
    downloadTextFile(`dayflow-${kind}-${todayKey()}.csv`, csv, 'text/csv;charset=utf-8');
  };
  const wipe = async () => {
    const ok1 = await confirm({ title: lang === 'ar' ? 'مسح كل بيانات DAYFLOW؟' : 'Erase ALL DAYFLOW data?', body: lang === 'ar' ? 'كل الكتل والمهام والملاحظات والسجلات ستُمحى نهائياً من هذا الجهاز.' : 'Every block, task, note and log will be permanently erased from this device.', danger: true, confirmLabel: lang === 'ar' ? 'امسح كل شيء' : 'Erase everything' });
    if (!ok1) return;
    const ok2 = await confirm({ title: lang === 'ar' ? 'تأكيد نهائي' : 'Final confirmation', body: lang === 'ar' ? 'لا يمكن التراجع. خذ نسخة JSON أولاً إن لم تفعل.' : 'This cannot be undone. Export a JSON backup first if you have not.', danger: true, confirmLabel: lang === 'ar' ? 'نعم، امسح' : 'Yes, erase' });
    if (!ok2) return;
    await db.wipeAll(); bump();
    toast(lang === 'ar' ? 'تم مسح كل البيانات' : 'All data erased');
  };

  return (
    <section className="card p-4">
      <h2 className="font-extrabold flex items-center gap-2"><Database className="w-5 h-5 accent" />{lang === 'ar' ? 'النسخ الاحتياطي والملفات' : 'Data & backup'}<HelpTip title="النسخ الاحتياطي والتشفير"><p><b>JSON:</b> ياخد نسخة كاملة من كل حاجة في التطبيق (خطتك، مهامك، يومياتك، منبهاتك، إعداداتك). وتقدر <b>تشفّرها بكلمة سر قوية (AES-256)</b> عشان محدش يقدر يفتحها غيرك.</p><p><b>دمج ولا استبدال:</b> عند الاستعادة بتشوف معاينة الأول وتختار تدمج مع اللي عندك أو تستبدله — عمرنا ما نمسح بياناتك فجأة.</p><p><b>CSV و Excel:</b> تصدّر جدولك أو تستورد خطة جاهزة من ملف Excel/CSV وتراجع الأخطاء قبل الحفظ.</p></HelpTip></h2>
      <p className="text-[0.65rem] text-2 mt-0.5">{lang === 'ar' ? 'كل شيء محلي على جهازك — النسخ الاحتياطية ملفات مستقلة تملكها أنت.' : 'Everything is local — backups are standalone files you own.'}</p>

      {/* encryption toggle */}
      <div className="flex items-center justify-between mt-3 gap-2">
        <div className="flex items-center gap-2 min-w-0"><ShieldCheck className="w-5 h-5 text-[var(--ok)] shrink-0" /><div><p className="text-sm font-bold">{lang === 'ar' ? 'تشفير النسخة بكلمة مرور' : 'Encrypt backup with password'}</p><p className="text-[0.58rem] text-2">AES-256-GCM · PBKDF2 (210k)</p></div></div>
        <Toggle on={encrypt} onChange={setEncrypt} label="encrypt" />
      </div>
      {encrypt && <input className="input mt-2" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder={lang === 'ar' ? 'كلمة مرور النسخة (٦+ أحرف)' : 'Backup password (6+ chars)'} autoComplete="new-password" />}

      <div className="grid grid-cols-2 gap-2 mt-3">
        <button className="btn btn-primary justify-center" onClick={doExportJson}><FileJson className="w-4 h-4" />{lang === 'ar' ? 'تصدير JSON' : 'Export JSON'}</button>
        <button className="btn btn-ghost justify-center" onClick={() => fileRef.current?.click()}><FileUp className="w-4 h-4" />{lang === 'ar' ? 'استعادة JSON' : 'Restore JSON'}</button>
        <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) onPickBackup(f); e.target.value = ''; }} />
        <button className="btn btn-ghost justify-center" onClick={doXlsx}><FileSpreadsheet className="w-4 h-4" />{lang === 'ar' ? 'تصدير Excel' : 'Export Excel'}</button>
        <button className="btn btn-ghost justify-center" onClick={() => csvRef.current?.click()}><FileUp className="w-4 h-4" />{lang === 'ar' ? 'استيراد CSV' : 'Import CSV'}</button>
        <input ref={csvRef} type="file" accept=".csv,text/csv" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) onPickCsv(f); e.target.value = ''; }} />
        <div className="col-span-2 flex flex-wrap gap-1.5 justify-center">
          {(['blocks', 'tasks', 'water', 'habits'] as const).map(k => <button key={k} className="chip" onClick={() => doCsv(k)}><FileDown className="w-3.5 h-3.5" />CSV · {k}</button>)}
        </div>
      </div>

      {/* backup history */}
      {history.length > 0 && (
        <div className="mt-3">
          <p className="text-[0.65rem] font-extrabold text-2 uppercase flex items-center gap-1"><History className="w-4 h-4" />{lang === 'ar' ? 'سجل النسخ' : 'Backup history'}</p>
          <div className="mt-1 space-y-1">{history.map(h => (
            <div key={h.id} className="flex items-center gap-2 text-[0.65rem] text-2"><span className="num flex-1">{new Date(h.createdAt).toLocaleString(lang === 'ar' ? 'ar' : 'en-GB')}</span><span className="chip !text-[0.55rem]">{h.kind.toUpperCase()}{h.encrypted ? ' 🔒' : ''}</span><span className="num">{Math.round(h.sizeBytes / 1024)}KB</span></div>
          ))}</div>
        </div>
      )}

      {/* danger zone */}
      <div className="mt-4 rounded-2xl border p-3" style={{ borderColor: 'var(--danger)', background: 'var(--danger-soft)' }}>
        <p className="text-[0.7rem] font-extrabold text-[var(--danger)] flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" />{lang === 'ar' ? 'منطقة الخطر' : 'Danger zone'}</p>
        <button className="btn btn-danger btn-sm mt-2" onClick={wipe}><Trash2 className="w-4 h-4" />{t('wipeData')}</button>
      </div>

      {/* restore sheet */}
      <Sheet open={restoreOpen} onClose={() => setRestoreOpen(false)} title={lang === 'ar' ? 'استعادة النسخة' : 'Restore backup'}>
        {restoreRaw?.encrypted ? (
          <>
            <p className="text-sm text-2">{lang === 'ar' ? 'هذه النسخة مشفّرة — أدخل كلمة المرور لفكها.' : 'This backup is encrypted — enter its password to unlock.'}</p>
            <input className="input mt-2" type="password" value={restorePassword} onChange={e => { setRestorePassword(e.target.value); setRestoreError(''); }} placeholder={lang === 'ar' ? 'كلمة مرور النسخة' : 'Backup password'} autoFocus />
            {restoreError && <p className="text-[0.7rem] text-[var(--danger)] font-bold mt-1.5">{restoreError}</p>}
          </>
        ) : restorePreview && (
          <>
            <p className="text-[0.72rem] text-2">{lang === 'ar' ? 'معاينة قبل الاستعادة — لن يُكتب شيء حتى تؤكد.' : 'Preview before restoring — nothing is written until you confirm.'}</p>
            <div className="grid grid-cols-3 gap-1.5 mt-2 max-h-48 overflow-y-auto">{Object.entries(restorePreview.tables).filter(([, n]) => n > 0).map(([table, n]) => <div key={table} className="card-inset p-1.5 text-center"><p className="num font-extrabold text-sm">{n}</p><p className="text-[0.52rem] text-2 truncate">{table}</p></div>)}</div>
            <p className="num text-[0.7rem] text-2 mt-2">{lang === 'ar' ? 'الإجمالي:' : 'Total rows:'} <b>{restorePreview.totalRows}</b>{restorePreview.exportedAt ? ` · ${new Date(restorePreview.exportedAt).toLocaleString()}` : ''}</p>
            <div className="flex gap-2 mt-2" role="radiogroup" aria-label="restore mode">
              {(['merge', 'replace'] as const).map(m => (
                <button key={m} role="radio" aria-checked={restoreMode === m} className={cn('chip', restoreMode === m && 'chip-active')} onClick={() => setRestoreMode(m)}>
                  {m === 'merge' ? (lang === 'ar' ? 'دمج مع الموجود' : 'Merge with existing') : (lang === 'ar' ? 'استبدال الكل' : 'Replace all')}
                </button>
              ))}
            </div>
            <p className="text-[0.6rem] text-3 mt-1.5">{restoreMode === 'merge' ? (lang === 'ar' ? 'تُحدَّث السجلات بنفس المعرف وتبقى البقية.' : 'Records with matching IDs update; the rest stay.') : (lang === 'ar' ? 'كل جدول يُمحى ثم يُملأ من النسخة.' : 'Each table is cleared, then filled from the backup.')}</p>
            {restoreError && <p className="text-[0.7rem] text-[var(--danger)] font-bold mt-1.5">{restoreError}</p>}
          </>
        )}
        <button className="btn btn-primary w-full justify-center mt-3" onClick={doRestore}><Check className="w-4 h-4" />{lang === 'ar' ? 'نفّذ الاستعادة' : 'Restore now'}</button>
      </Sheet>

      {/* CSV import preview */}
      <Sheet open={csvOpen} onClose={() => setCsvOpen(false)} title={lang === 'ar' ? 'معاينة الاستيراد' : 'Import preview'}>
        {csvResult && (
          <>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="card-inset p-2"><p className="num text-xl font-extrabold text-[var(--ok)]">{csvResult.rows.length}</p><p className="text-[0.55rem] font-bold text-2">{lang === 'ar' ? 'صف صالح' : 'Valid rows'}</p></div>
              <div className="card-inset p-2"><p className="num text-xl font-extrabold text-[var(--warn)]">{csvResult.duplicates}</p><p className="text-[0.55rem] font-bold text-2">{lang === 'ar' ? 'مكررة (تُتجاهل)' : 'Duplicates (skipped)'}</p></div>
              <div className="card-inset p-2"><p className="num text-xl font-extrabold text-[var(--info)]">{csvResult.overlaps}</p><p className="text-[0.55rem] font-bold text-2">{lang === 'ar' ? 'تتعارض مع جدولك' : 'Overlap existing'}</p></div>
            </div>
            {csvResult.errors.length > 0 && <div className="mt-2 max-h-32 overflow-y-auto rounded-xl p-2" style={{ background: 'var(--danger-soft)' }}>{csvResult.errors.slice(0, 20).map((e, i) => <p key={i} className="text-[0.65rem] font-semibold text-[var(--danger)] num">· {e}</p>)}</div>}
            {csvResult.errors.length === 0 && <p className="text-[0.72rem] text-[var(--ok)] font-bold mt-2 flex items-center gap-1"><Check className="w-4 h-4" />{lang === 'ar' ? 'لا توجد أخطاء — الملف نظيف' : 'No errors — file is clean'}</p>}
            <p className="text-[0.6rem] text-3 mt-2">{lang === 'ar' ? 'الأعمدة المطلوبة: title + date (YYYY-MM-DD) + start/end (HH:MM أو دقائق). القيم الزائدة تُتجاهل بأمان.' : 'Expected columns: title + date (YYYY-MM-DD) + start/end (HH:MM or minutes). Extra columns are safely ignored.'}</p>
            <button className="btn btn-primary w-full justify-center mt-3" disabled={!csvResult.rows.length} onClick={applyCsv}><Check className="w-4 h-4" />{lang === 'ar' ? `استيراد ${csvResult.rows.length} كتلة` : `Import ${csvResult.rows.length} blocks`}</button>
          </>
        )}
      </Sheet>
    </section>
  );
}
