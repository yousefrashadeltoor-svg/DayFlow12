/* DAYFLOW — global crash guard: shows a readable error instead of a white page */
import { Component, type ReactNode } from 'react';

export default class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error, info: any) { console.error('DAYFLOW crash:', error, info); }
  render() {
    if (this.state.error) {
      return (
        <div dir="rtl" className="h-full grid place-items-center p-6" style={{ background: 'var(--bg,#f5f4f1)', color: 'var(--text,#1b1b1f)' }}>
          <div className="max-w-sm text-center">
            <img src="/icons/icon-512.png" alt="" width="72" height="72" className="rounded-2xl mx-auto mb-3" />
            <h1 className="font-extrabold text-lg">حصلت مشكلة غير متوقعة</h1>
            <p className="text-sm opacity-70 mt-1">بياناتك بأمان. جرب تحديث الصفحة — لو المشكلة استمرت، كلمة للخطأ تحت هتساعدنا.</p>
            <pre className="text-[0.62rem] text-start whitespace-pre-wrap opacity-60 mt-3 p-2 rounded-xl" style={{ background: 'rgba(0,0,0,.06)' }}>{String(this.state.error?.message ?? this.state.error)}</pre>
            <button className="btn btn-primary mt-3" onClick={() => { this.setState({ error: null }); window.location.reload(); }}>حدّث الصفحة</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
