/* DAYFLOW — Genuine live Home-screen preview rendered inside each theme's real tokens, font, wallpaper, blur & layout */
import { Sun, CalendarDays, Plus, CalendarRange, LayoutGrid, Check } from 'lucide-react';

export interface SkinMeta {
  id: 'gemini' | 'oneui' | 'ios' | 'aurora' | 'frost' | 'midnight' | 'paper' | 'sand' | 'mint' | 'ocean' | 'rose' | 'sunset';
  ar: string; en: string; descAr: string; descEn: string; tag?: string;
}

export const SKINS: SkinMeta[] = [
  { id: 'gemini',   ar: 'Gemini المضيء',    en: 'Gemini Glow',     descAr: 'تدرجات ناعمة أزرق وبنفسجي ووردي مع خط Tajawal وحواف دايرية ناعمة', descEn: 'Luminous Gemini gradients, ultra-smooth 28px cards & Tajawal', tag: 'مميز' },
  { id: 'oneui',    ar: 'One UI زجاجي',     en: 'One UI Glass',    descAr: 'زجاج بلوري شفاف بحواف لامعة فوق خلفية حقيقية وعناوين كبيرة مريحة', descEn: 'Crystal frosted panes over wallpaper with tall One UI headers', tag: 'زجاجي' },
  { id: 'ios',      ar: 'iOS كلاسيك',       en: 'iOS Classic',     descAr: 'توازن وأناقة أبل الهادية، ألوان دافية وظلال خفيفة وخط IBM Plex', descEn: 'Clean warm surfaces, delicate layering & balanced precision' },
  { id: 'aurora',   ar: 'الشفق القطبي',     en: 'Aurora Glass',    descAr: 'ألوان الشفق المتدرجة بتتحرك بهدوء وكروت بلورية شفافة ناعمة', descEn: 'Living animated northern lights behind crystal frosted sheets', tag: 'متحرك' },
  { id: 'frost',    ar: 'جليد بلوري',       en: 'Nordic Frost',    descAr: 'زجاج سماوي نقي فوق خلفية بلور جليدي، صفاء وهدوء اسكندنافي', descEn: 'Crisp Scandinavian icy-blue frosted glass panes', tag: 'زجاجي' },
  { id: 'midnight', ar: 'أسود OLED',        en: 'Midnight OLED',   descAr: 'أسود حقيقي بيوفر البطارية مع حواف دقيقة وتوهج سماوي خفيف', descEn: 'True #000 OLED black with razor grid & crisp cyan halo' },
  { id: 'paper',    ar: 'دفتر ورق',         en: 'Paper Notebook',  descAr: 'دافي ومسطّر زي أجندة ورق حقيقية بظلال مطبوعة وحبر دافي', descEn: 'Warm ruled editorial paper with letterpress shadows' },
  { id: 'sand',     ar: 'رمال ودهب',        en: 'Egyptian Sand',   descAr: 'ذهبي مصري فخم مع أزرق لازوردي وخلفية دافية رايقة', descEn: 'Egyptian gold gradients with deep royal lapis accents' },
  { id: 'mint',     ar: 'نعناع هادي',       en: 'Mint Calm',       descAr: 'أخضر نعناعي مريح جداً للعين مع حواف دايرية كبيرة ومريحة', descEn: 'Soothing botanical sage, ultra-soft 30px cushions' },
  { id: 'ocean',    ar: 'أعماق البحر',      en: 'Deep Ocean',      descAr: 'تركواز البحر المتوسط وتدرجات زرقاء ناعمة منعشة للعين', descEn: 'Refreshing turquoise-to-navy gradients & calm glow' },
  { id: 'rose',     ar: 'مخملي وردي',       en: 'Rose Velvet',     descAr: 'وردي ناعم وأنيق مع تدرجات حريرية دافية ومظهر راقي', descEn: 'Satin blush & berry velvet gradients, refined warmth' },
  { id: 'sunset',   ar: 'غروب دافي',        en: 'Sunset Glow',     descAr: 'ألوان الغروب البرتقالي والعنبري الدافي — راحة قبل النوم', descEn: 'Warm golden-hour terracotta & soft amber horizon' },
];

export default function ThemePreview({ skin, theme, accent, selected }: {
  skin: string; theme: 'light' | 'dark'; accent: string; selected?: boolean;
}) {
  const isOneUi = skin === 'oneui';
  const isGlass = skin === 'oneui' || skin === 'aurora' || skin === 'frost';
  const isPaper = skin === 'paper';
  const isMidnight = skin === 'midnight';
  const r = isMidnight ? 5 : isPaper ? 4 : skin === 'mint' || skin === 'gemini' ? 12 : 9;

  return (
    <div
      data-skin={skin} data-theme={theme} data-accent={accent}
      className="app-surface relative rounded-[16px] overflow-hidden border hairline select-none"
      style={{ width: '100%', aspectRatio: '9 / 15.2', fontFamily: 'var(--font)', color: 'var(--text)' }}
    >
      {/* Top accent banner hinting seasonal photo header */}
      <div className="px-2 pt-2 pb-1.5 space-y-1.5" style={{ fontSize: 6.5 }}>
        <div
          className="font-extrabold grad-text leading-tight"
          style={{ fontSize: isOneUi ? 12 : skin === 'gemini' ? 10 : 9, paddingTop: isOneUi ? 10 : 1 }}
        >
          {isOneUi ? 'النهارده' : 'صباح الفل'}
        </div>
        {/* Progress card */}
        <div className="card p-1.5 flex items-center gap-1.5" style={{ borderRadius: r }}>
          <div className="w-7 h-7 rounded-full grid place-items-center font-black shrink-0" style={{ border: '2.5px solid var(--accent)', fontSize: 5.5 }}>74%</div>
          <div className="flex-1 space-y-1 min-w-0">
            <div className="h-1.5 rounded-full" style={{ background: 'var(--accent)', width: '78%', opacity: 0.85 }} />
            <div className="h-1 rounded-full" style={{ background: 'var(--surface-3)', width: '56%' }} />
          </div>
        </div>
        {/* Hero active card */}
        <div
          className="card p-1.5"
          style={{
            borderRadius: r,
            background: isGlass
              ? 'var(--surface)'
              : 'linear-gradient(155deg, var(--surface), var(--accent-soft))',
          }}
        >
          <div className="flex items-center justify-between">
            <span className="font-extrabold" style={{ color: 'var(--accent)', fontSize: 5.5 }}>● دلوقتي</span>
            <span className="opacity-65 font-bold" style={{ fontSize: 5 }}>09:30</span>
          </div>
          <div className="font-extrabold truncate" style={{ fontSize: 7.2 }}>مذاكرة + تركيز</div>
          <div className="mt-1 h-1 rounded-full overflow-hidden" style={{ background: 'var(--surface-2)' }}>
            <div className="h-full rounded-full" style={{ width: '62%', background: 'var(--accent)' }} />
          </div>
        </div>
        {/* Mini timeline cards */}
        {[
          { t: '11:00', w: '72%' },
          { t: '13:30', w: '54%' },
          { t: '17:00', w: '65%' },
        ].map((row, i) => (
          <div
            key={i}
            className="card-flat px-1.5 py-1 flex items-center gap-1"
            style={{ borderRadius: Math.max(3, r - 3), borderInlineStart: '2px solid var(--accent)' }}
          >
            <span className="font-bold opacity-75 num" style={{ fontSize: 5 }}>{row.t}</span>
            <span className="h-1 rounded-full" style={{ background: 'var(--text-3)', opacity: 0.45, width: row.w }} />
          </div>
        ))}
      </div>

      {/* Bottom glass navigation preview */}
      <div className="absolute bottom-0 inset-x-0 glass border-t hairline flex justify-around items-center py-1" style={{ color: 'var(--text-3)' }}>
        <Sun size={7.5} color="var(--accent)" />
        <CalendarDays size={7.5} />
        <span className="w-3.5 h-3.5 rounded-md grid place-items-center -mt-1.5 shadow" style={{ background: 'var(--accent)' }}>
          <Plus size={7.5} color="var(--on-accent)" />
        </span>
        <CalendarRange size={7.5} />
        <LayoutGrid size={7.5} />
      </div>

      {/* Mode tint corner tag */}
      <span
        className="absolute top-1 start-1 px-1 py-0.2 rounded text-[5px] font-extrabold opacity-75"
        style={{ background: 'var(--surface-2)', color: 'var(--text-2)' }}
      >
        {theme === 'dark' ? 'داكن' : 'فاتح'}
      </span>

      {selected && (
        <span className="absolute top-1 end-1 w-4.5 h-4.5 rounded-full grid place-items-center shadow-md" style={{ background: 'var(--accent)', color: 'var(--on-accent)' }}>
          <Check size={10} strokeWidth={3} />
        </span>
      )}
    </div>
  );
}
