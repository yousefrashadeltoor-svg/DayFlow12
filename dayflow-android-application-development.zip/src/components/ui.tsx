/* DAYFLOW — shared UI primitives (premium, accessible) */
import { useEffect, useState, type ReactNode } from 'react';
import {
  BookOpen, Briefcase, Dumbbell, Coffee, Utensils, BedDouble, Droplets, MoonStar,
  Sparkles, Users, HeartPulse, Shapes, Sun, GraduationCap, NotebookPen, Palmtree,
  Plane, Feather, X, type LucideIcon,
} from 'lucide-react';
import { cn } from '@/utils/cn';

export const CATEGORY_ICONS: Record<string, LucideIcon> = {
  'book-open': BookOpen, briefcase: Briefcase, dumbbell: Dumbbell, coffee: Coffee,
  utensils: Utensils, 'bed-double': BedDouble, droplets: Droplets, 'moon-star': MoonStar,
  sparkles: Sparkles, users: Users, 'heart-pulse': HeartPulse, shapes: Shapes, sun: Sun,
  'graduation-cap': GraduationCap, 'notebook-pen': NotebookPen, palmtree: Palmtree,
  plane: Plane, feather: Feather,
};
export const CategoryIcon = ({ icon, className }: { icon?: string; className?: string }) => {
  const C = (icon && CATEGORY_ICONS[icon]) || Sparkles;
  return <C className={className} strokeWidth={1.8} aria-hidden />;
};
export const ICON_OPTIONS = Object.keys(CATEGORY_ICONS);

export function ProgressRing({ size = 132, stroke = 11, progress, track, children }: {
  size?: number; stroke?: number; progress: number; track?: string; children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const p = Math.min(100, Math.max(0, progress));
  const [animated, setAnimated] = useState(0);
  useEffect(() => { const id = requestAnimationFrame(() => setAnimated(p)); return () => cancelAnimationFrame(id); }, [p]);
  return (
    <div className="relative inline-grid place-items-center" style={{ width: size, height: size }} role="img" aria-label={`${Math.round(p)}%`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke={track ?? 'var(--surface-2)'} strokeWidth={stroke} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--accent)" strokeWidth={stroke} fill="none"
          strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c - (animated / 100) * c}
          style={{ transition: 'stroke-dashoffset 1.1s cubic-bezier(0.22, 1, 0.36, 1)', filter: 'drop-shadow(0 0 6px color-mix(in srgb, var(--accent) 45%, transparent))' }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

export function LinearProgress({ value, className, tone = 'var(--accent)' }: { value: number; className?: string; tone?: string }) {
  return (
    <div className={cn('h-2 rounded-full overflow-hidden', className)} style={{ background: 'var(--surface-2)' }} role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-full rounded-full transition-[width] duration-700 ease-out" style={{ width: `${Math.min(100, Math.max(0, value))}%`, background: tone }} />
    </div>
  );
}

export function Sheet({ open, onClose, title, children, actions }: {
  open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode; actions?: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <>
      <div className="sheet-backdrop" onClick={onClose} aria-hidden />
      <div className="sheet-panel anim-sheet" role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : 'dialog'}>
        <div className="sheet-handle" />
        <div className="flex items-center justify-between px-5 pt-1 pb-2 sticky top-0 bg-[var(--surface)] z-10">
          <h2 className="font-bold text-lg">{title}</h2>
          <div className="flex items-center gap-2">{actions}<button className="icon-btn" onClick={onClose} aria-label="Close"><X className="w-5 h-5" /></button></div>
        </div>
        <div className="px-5 pb-5">{children}</div>
      </div>
    </>
  );
}

export function EmptyState({ icon, title, hint, action }: { icon: ReactNode; title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-10 px-6">
      <div className="w-16 h-16 rounded-2xl grid place-items-center mb-3" style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>{icon}</div>
      <p className="font-bold">{title}</p>
      {hint && <p className="text-sm text-2 mt-1 max-w-[26ch] leading-relaxed">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function StatTile({ label, value, unit, tone, icon }: { label: string; value: ReactNode; unit?: string; tone?: string; icon?: ReactNode }) {
  return (
    <div className="card-flat p-3 flex flex-col gap-0.5 min-w-0">
      <span className="text-[0.68rem] font-semibold text-2 flex items-center gap-1">{icon}{label}</span>
      <span className="num text-xl font-bold leading-tight truncate" style={{ color: tone }}>{value}{unit && <span className="text-[0.7rem] font-semibold text-2 ms-1">{unit}</span>}</span>
    </div>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-2 mt-5">
      <h3 className="text-[0.78rem] font-extrabold tracking-wide text-2 uppercase">{children}</h3>
      {action}
    </div>
  );
}

export function Segmented<T extends string>({ value, onChange, options, size = 'md' }: {
  value: T; onChange: (v: T) => void; options: Array<{ value: T; label: string }>; size?: 'sm' | 'md';
}) {
  return (
    <div className="inline-flex rounded-2xl p-1 gap-0.5" style={{ background: 'var(--surface-2)' }} role="tablist">
      {options.map(o => (
        <button key={o.value} role="tab" aria-selected={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn('rounded-xl font-semibold transition-all duration-200 whitespace-nowrap',
            size === 'sm' ? 'px-2.5 py-1.5 text-[0.72rem]' : 'px-3.5 py-2 text-[0.8rem]',
            value === o.value ? 'bg-[var(--surface)] shadow-sm text-[var(--accent)]' : 'text-2 hover:text-[var(--text)]')}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button type="button" className="switch" data-on={on} role="switch" aria-checked={on} aria-label={label}
      onClick={() => onChange(!on)} />
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block mb-3"><span className="label">{label}</span>{children}</label>;
}

/* ---------- HelpTip: green "?" → plain Egyptian-Arabic explanation ---------- */
export function HelpTip({ title, children }: { title: string; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className="help-dot" onClick={e => { e.stopPropagation(); setOpen(true); }} aria-label={`شرح: ${title}`}>?</button>
      <Sheet open={open} onClose={() => setOpen(false)} title={<span className="flex items-center gap-2"><span className="help-dot">?</span>{title}</span>}>
        <div className="text-[0.9rem] leading-[1.9] text-[var(--text)] space-y-2 [&_b]:text-[var(--accent)] [&_ul]:list-disc [&_ul]:ps-5">{children}</div>
        <button className="btn btn-primary w-full justify-center mt-4" onClick={() => setOpen(false)}>فهمت 👌</button>
      </Sheet>
    </>
  );
}

/** Row used across settings pages: label + optional help + control */
export function SettingRow({ label, hint, help, helpTitle, children }: { label: string; hint?: string; help?: ReactNode; helpTitle?: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5 border-b hairline last:border-0">
      <div className="min-w-0 flex-1">
        <p className="text-[0.85rem] font-bold flex items-center gap-1.5">{label}{help && <HelpTip title={helpTitle ?? label}>{help}</HelpTip>}</p>
        {hint && <p className="text-[0.65rem] text-2 mt-0.5 leading-snug">{hint}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}
