/* DAYFLOW — Activity block editor (sheet) — real persistence + alarm scheduling */
import { useEffect, useState } from 'react';
import { Trash2 } from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, newId, todayKey, nowMin } from '@/lib/db';
import { platform, haptic } from '@/lib/platform';
import { Sheet, Field, CategoryIcon, Toggle, HelpTip } from './ui';
import type { ActivityBlock, ActivityCategory, BlockStatus } from '@/lib/types';

const minToHHMM = (min: number) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(Math.floor(min % 60)).padStart(2, '0')}`;
const hhmmToMin = (s: string) => { const [h, m] = s.split(':').map(Number); return (h || 0) * 60 + (m || 0); };

export default function ActivityEditor({ open, onClose, initial, defaultDate, defaultStartMin }: {
  open: boolean; onClose: () => void; initial?: ActivityBlock | null; defaultDate?: string; defaultStartMin?: number | null;
}) {
  const { t, lang, toast, confirm, bump, settings } = useApp();
  const [cats, setCats] = useState<ActivityCategory[]>([]);
  const [title, setTitle] = useState('');
  const [categoryId, setCategoryId] = useState('personal');
  const [date, setDate] = useState(todayKey());
  const [start, setStart] = useState('09:00');
  const [end, setEnd] = useState('09:45');
  const [fixed, setFixed] = useState(false);
  const [priority, setPriority] = useState<1|2|3|4>(3);
  const [energy, setEnergy] = useState<'low'|'medium'|'high'>('medium');
  const [reminderMin, setReminderMin] = useState(10);
  const [sound, setSound] = useState('default');
  const [notes, setNotes] = useState('');
  const [recurrence, setRecurrence] = useState<ActivityBlock['recurrence']>('none');
  const [busy, setBusy] = useState(false);

  useEffect(() => { db.all<ActivityCategory>('activity_categories').then(setCats); }, [open]);
  useEffect(() => {
    if (!open) return;
    if (initial) {
      setTitle(initial.title); setCategoryId(initial.categoryId); setDate(initial.date);
      setStart(minToHHMM(initial.startMin)); setEnd(minToHHMM(initial.endMin));
      setFixed(initial.fixed); setPriority(initial.priority); setEnergy(initial.energy);
      setReminderMin(initial.reminderMin); setSound(initial.sound ?? 'default'); setNotes(initial.notes ?? '');
      setRecurrence(initial.recurrence);
    } else {
      setTitle(''); setCategoryId('personal'); setDate(defaultDate ?? todayKey());
      const s = defaultStartMin ?? (Math.ceil(nowMin() / 15) * 15 + 15);
      setStart(minToHHMM(s)); setEnd(minToHHMM(s + settings.defaultBlockDuration));
      setFixed(false); setPriority(3); setEnergy('medium'); setReminderMin(10); setSound('default'); setNotes(''); setRecurrence('none');
    }
  }, [open, initial, defaultDate, defaultStartMin, settings.defaultBlockDuration]);

  const save = async () => {
    const trimmed = title.trim();
    if (!trimmed) { toast(lang === 'ar' ? 'اكتب اسم النشاط الأول' : 'Please enter a title'); return; }
    const startMin = hhmmToMin(start), endMin = hhmmToMin(end);
    if (endMin <= startMin) { toast(lang === 'ar' ? 'وقت النهاية لازم يكون بعد البداية' : 'End must be after start'); return; }
    setBusy(true);
    const base = {
      title: trimmed, categoryId, date, startMin, endMin, fixed, priority, energy,
      reminderMin, sound, notes, recurrence, updatedAt: Date.now(),
    };
    let block: ActivityBlock;
    if (initial) {
      block = { ...initial, ...base };
    } else {
      block = {
        id: newId(), ...base, description: '', difficulty: 3, status: 'planned' as BlockStatus,
        repeatCount: settings.soundRepeatCount, isCritical: false, splitAllowed: true,
        earliestStartMin: null, latestEndMin: null, linkedTaskId: null, linkedGoalId: null, linkedSubjectId: null,
        tags: [], actualStartMin: null, actualEndMin: null, createdAt: Date.now(),
      };
    }
    await db.put('activity_blocks', block);
    // Schedule native exact alarm (authoritative result surfaced honestly)
    if (block.reminderMin >= 0 && block.status === 'planned') {
      const res = await platform.scheduleBlockAlarm(block, lang === 'ar' ? `يقترب موعد: ${block.title}` : `Upcoming: ${block.title}`);
      if (res.unsupported) toast(lang === 'ar' ? 'حُفظت الكتلة — الإشعارات الأصلية تعمل داخل تطبيق Android فقط' : 'Block saved — native alarms work inside the Android app');
      else if (!res.ok) toast(lang === 'ar' ? `حُفظت الكتلة لكن فشل الجدولة: ${res.error}` : `Saved, but scheduling failed: ${res.error}`);
    }
    haptic('light');
    setBusy(false);
    bump();
    toast(t('saved'));
    onClose();
  };

  const remove = async () => {
    if (!initial) return;
    const ok = await confirm({ title: lang === 'ar' ? 'حذف الكتلة؟' : 'Delete this block?', body: initial.title, danger: true, confirmLabel: t('delete') });
    if (!ok) return;
    const stash = initial;
    await db.del('activity_blocks', initial.id);
    await platform.cancelAlarm(initial.id);
    bump();
    onClose();
    toast(t('deleted'), { actionLabel: t('undo'), onAction: async () => { await db.put('activity_blocks', stash); bump(); } });
  };

  return (
    <Sheet open={open} onClose={onClose} title={initial ? (lang === 'ar' ? 'تعديل الكتلة' : 'Edit block') : t('addActivity')}
      actions={initial ? <button className="icon-btn text-[var(--danger)]" onClick={remove} aria-label={t('delete')}><Trash2 className="w-5 h-5" /></button> : undefined}>
      <Field label={lang === 'ar' ? 'العنوان' : 'Title'}>
        <input autoFocus className="input" value={title} onChange={e => setTitle(e.target.value)}
          placeholder={lang === 'ar' ? 'مثلاً: مذاكرة الفصل التالت…' : 'e.g. Study chapter 3…'} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label={lang === 'ar' ? 'التاريخ' : 'Date'}><input type="date" className="input num" value={date} onChange={e => setDate(e.target.value)} /></Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label={lang === 'ar' ? 'من' : 'From'}><input type="time" className="input num" value={start} onChange={e => setStart(e.target.value)} /></Field>
          <Field label={lang === 'ar' ? 'إلى' : 'To'}><input type="time" className="input num" value={end} onChange={e => setEnd(e.target.value)} /></Field>
        </div>
      </div>
      <Field label={lang === 'ar' ? 'التصنيف' : 'Category'}>
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {cats.map(c => (
            <button key={c.id} onClick={() => setCategoryId(c.id)}
              className={`chip flex-none ${categoryId === c.id ? 'chip-active' : ''}`} aria-pressed={categoryId === c.id}>
              <CategoryIcon icon={c.icon} className="w-4 h-4" />
              {lang === 'ar' ? c.nameAr : c.nameEn}
            </button>
          ))}
        </div>
      </Field>
      <div className="grid grid-cols-3 gap-3">
        <Field label={lang === 'ar' ? 'الأولوية' : 'Priority'}>
          <select className="input" value={priority} onChange={e => setPriority(Number(e.target.value) as any)}>
            {[1, 2, 3, 4].map(p => <option key={p} value={p}>{lang === 'ar' ? ['١ — قصوى', '٢ — عالية', '٣ — متوسطة', '٤ — هادئة'][p - 1] : ['1 — Critical', '2 — High', '3 — Medium', '4 — Low'][p - 1]}</option>)}
          </select>
        </Field>
        <Field label={lang === 'ar' ? 'الطاقة' : 'Energy'}>
          <select className="input" value={energy} onChange={e => setEnergy(e.target.value as any)}>
            <option value="low">{lang === 'ar' ? 'منخفضة' : 'Low'}</option>
            <option value="medium">{lang === 'ar' ? 'متوسطة' : 'Medium'}</option>
            <option value="high">{lang === 'ar' ? 'عالية' : 'High'}</option>
          </select>
        </Field>
        <Field label={lang === 'ar' ? 'التكرار' : 'Repeat'}>
          <select className="input" value={recurrence} onChange={e => setRecurrence(e.target.value as any)}>
            <option value="none">{lang === 'ar' ? 'بلا' : 'None'}</option>
            <option value="daily">{lang === 'ar' ? 'يومياً' : 'Daily'}</option>
            <option value="weekdays">{lang === 'ar' ? 'أيام الأسبوع' : 'Weekdays'}</option>
            <option value="weekly">{lang === 'ar' ? 'أسبوعياً' : 'Weekly'}</option>
          </select>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3 items-end">
        <Field label={lang === 'ar' ? 'تذكير قبل' : 'Remind before'}>
          <select className="input" value={reminderMin} onChange={e => setReminderMin(Number(e.target.value))}>
            <option value={-1}>{lang === 'ar' ? 'بدون تذكير' : 'No reminder'}</option>
            {[0, 5, 10, 15, 30, 60].map(m => <option key={m} value={m}>{m === 0 ? (lang === 'ar' ? 'عند البداية' : 'At start') : `${m} ${lang === 'ar' ? 'دقيقة' : 'min'}`}</option>)}
          </select>
        </Field>
        <Field label={lang === 'ar' ? 'الصوت' : 'Sound'}>
          <select className="input" value={sound} onChange={e => setSound(e.target.value)}>
            <option value="default">{lang === 'ar' ? 'الافتراضي' : 'Default'}</option>
            <option value="chime">{lang === 'ar' ? 'رنين هادئ' : 'Soft chime'}</option>
            <option value="alarm">{lang === 'ar' ? 'صوت منبه قوي' : 'Alarm'}</option>
            <option value="tts">{lang === 'ar' ? 'ينطق اسم النشاط' : 'Speak title (TTS)'}</option>
            <option value="none">{lang === 'ar' ? 'صامت' : 'Silent'}</option>
          </select>
        </Field>
      </div>
      <div className="flex items-center justify-between py-2.5 px-3 rounded-2xl" style={{ background: 'var(--surface-2)' }}>
        <div>
          <p className="text-sm font-bold flex items-center gap-1.5">{lang === 'ar' ? 'ميعاد ثابت 📌' : 'Fixed block'}<HelpTip title="ميعاد ثابت"><p>الأنشطة الثابتة زي ميعاد دكتور أو حصة أو شغل مهم — التطبيق عمره ما يحرّكها تلقائياً، ولو سحبتها بالغلط هيسألك تتأكد الأول.</p></HelpTip></p>
          <p className="text-[0.68rem] text-2">{lang === 'ar' ? 'ما بيتحركش لوحده — لازم تأكيدك' : 'Never auto-moved — requires your confirmation'}</p>
        </div>
        <Toggle on={fixed} onChange={setFixed} label="fixed" />
      </div>
      <Field label={lang === 'ar' ? 'ملاحظة (هتظهر على المربع وفي الإشعار)' : 'Note (shown on card & notification)'} >
        <textarea className="input min-h-[64px]" value={notes} onChange={e => setNotes(e.target.value)} placeholder={lang === 'ar' ? 'تفاصيل إضافية…' : 'Extra details…'} />
      </Field>
      <button className="btn btn-primary w-full justify-center !py-3 text-base" onClick={save} disabled={busy}>
        {busy ? '…' : (lang === 'ar' ? (initial ? 'حفظ التعديلات' : 'إضافة للجدول') : (initial ? 'Save changes' : 'Add to schedule'))}
      </button>
    </Sheet>
  );
}
