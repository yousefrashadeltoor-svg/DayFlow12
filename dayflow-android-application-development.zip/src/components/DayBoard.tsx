/* DAYFLOW — Interactive visual day board
   · Smooth pointer drag to move (5-min snap) + bottom handle to resize + live exact-time badge
   · Automatic separation for touching, adjacent, or overlapping blocks using visual extents:
     even tiny 10-min consecutive blocks sit cleanly side-by-side with clear gutters and ALWAYS
     display full title + exact start–end time + full note + pin/bell/done status!
   · Zoom modes (normal / zoomed / wide) · auto-scroll to now · tap empty space to add at exact time */
import { useEffect, useMemo, useRef, useState } from 'react';
import { Pin, Bell, StickyNote, Clock, Check, ZoomIn, Copy } from 'lucide-react';
import { useApp } from '@/lib/store';
import { db, todayKey, minToTime, newId } from '@/lib/db';
import { haptic } from '@/lib/platform';
import { CategoryIcon, Sheet, Field, HelpTip } from './ui';
import type { ActivityBlock, ActivityCategory } from '@/lib/types';
import { cn } from '@/utils/cn';

const START_H = 0, END_H = 24;
const ZOOM_PPM = { sm: 1.45, md: 2.0, lg: 2.75 } as const;
const SNAP = 5;
const COL_GAP = 6; // visible breathing space keeping adjacent blocks cleanly separated

export interface LaidBlock { b: ActivityBlock; col: number; cols: number; top: number; height: number; realH: number }

/** Visual-extent interval-graph layout: touching & short blocks separate side-by-side cleanly, zero clipping/overlap. */
export function layoutBlocks(blocks: ActivityBlock[], ppm = 1.45, minCardPx = 76): LaidBlock[] {
  const vis = blocks.map(b => {
    const cleanNote = b.notes && !b.notes.startsWith('tpl:') ? b.notes.trim() : '';
    const minH = cleanNote ? Math.max(minCardPx, 82) : Math.max(minCardPx - 8, 66);
    const realH = Math.max(8, (b.endMin - b.startMin) * ppm);
    const top = (b.startMin - START_H * 60) * ppm;
    const height = Math.max(minH, realH);
    return { b, top, bottom: top + height + 4, height, realH };
  }).sort((a, z) => a.top - z.top || z.height - a.height || a.b.id.localeCompare(z.b.id));

  const out: LaidBlock[] = [];
  let cluster: typeof vis = [];
  let clusterEnd = -Infinity;

  const flush = () => {
    const colsEnd: number[] = [];
    const assigned: Array<{ v: typeof vis[number]; col: number }> = [];
    for (const v of cluster) {
      let col = colsEnd.findIndex(e => e <= v.top + 0.5);
      if (col === -1) { col = colsEnd.length; colsEnd.push(v.bottom); }
      else colsEnd[col] = v.bottom;
      assigned.push({ v, col });
    }
    const totalCols = colsEnd.length;
    for (const a of assigned) {
      out.push({ b: a.v.b, col: a.col, cols: totalCols, top: a.v.top, height: a.v.height, realH: a.v.realH });
    }
    cluster = []; clusterEnd = -Infinity;
  };

  for (const v of vis) {
    if (cluster.length && v.top >= clusterEnd - 0.5) flush();
    cluster.push(v);
    clusterEnd = Math.max(clusterEnd, v.bottom);
  }
  if (cluster.length) flush();
  return out;
}

export default function DayBoard({ blocks, cats, date, onEdit, onCreateAt }: {
  blocks: ActivityBlock[]; cats: ActivityCategory[]; date: string;
  onEdit: (b: ActivityBlock) => void; onCreateAt: (startMin: number) => void;
}) {
  const { lang, hour12, confirm, bump, toast } = useApp();
  const catMap = useMemo(() => Object.fromEntries(cats.map(c => [c.id, c])), [cats]);
  const [zoom, setZoom] = useState<'sm' | 'md' | 'lg'>('sm');
  const [drag, setDrag] = useState<{
    id: string; mode: 'move' | 'resize'; startY: number;
    orig: { s: number; e: number }; s: number; e: number; moved: boolean;
  } | null>(null);
  const [copyOpen, setCopyOpen] = useState(false);
  const [copyDate, setCopyDate] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const scrolledDate = useRef('');

  const ppm = ZOOM_PPM[zoom];
  const active = useMemo(() => blocks.filter(b => b.status !== 'cancelled'), [blocks]);
  const visible = useMemo(
    () => active.map(b => (drag && b.id === drag.id ? { ...b, startMin: drag.s, endMin: drag.e } : b)),
    [active, drag]
  );
  const laid = useMemo(() => layoutBlocks(visible, ppm, zoom === 'lg' ? 92 : 78), [visible, ppm, zoom]);
  const totalH = (END_H - START_H) * 60 * ppm;
  const now = new Date();
  const nowM = now.getHours() * 60 + now.getMinutes();
  const isToday = date === todayKey();
  const f = (m: number) => minToTime(m, hour12);

  // Smooth smart scroll to current time (today) or earliest block (other day)
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || scrolledDate.current === date) return;
    scrolledDate.current = date;
    const anchorMin = isToday
      ? Math.max(0, nowM - 90)
      : active.length ? Math.max(0, Math.min(...active.map(b => b.startMin)) - 60) : 7 * 60;
    el.scrollTop = anchorMin * ppm;
  }, [date, isToday, active, nowM, ppm]);

  const onPointerDown = (e: React.PointerEvent, b: ActivityBlock, mode: 'move' | 'resize') => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setDrag({ id: b.id, mode, startY: e.clientY, orig: { s: b.startMin, e: b.endMin }, s: b.startMin, e: b.endMin, moved: false });
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag) return;
    const dy = e.clientY - drag.startY;
    const dMin = Math.round(dy / ppm / SNAP) * SNAP;
    const moved = drag.moved || Math.abs(dy) > 5;
    if (moved && !drag.moved) haptic('light');
    if (drag.mode === 'move') {
      const dur = drag.orig.e - drag.orig.s;
      const s = Math.min(Math.max(0, drag.orig.s + dMin), 1440 - dur);
      setDrag({ ...drag, s, e: s + dur, moved });
    } else {
      const eMin = Math.min(1440, Math.max(drag.orig.s + 10, drag.orig.e + dMin));
      setDrag({ ...drag, e: eMin, moved });
    }
  };

  const onPointerUp = async () => {
    if (!drag) return;
    const b = active.find(x => x.id === drag.id);
    const d = drag;
    setDrag(null);
    if (!b) return;
    if (!d.moved) { onEdit(b); return; }
    if (d.s === b.startMin && d.e === b.endMin) return;
    if (b.fixed) {
      const ok = await confirm({
        title: lang === 'ar' ? 'ده ميعاد ثابت 📌' : 'Fixed block 📌',
        body: lang === 'ar' ? `متأكد عايز تحرّك «${b.title}» إلى ${f(d.s)} – ${f(d.e)}؟` : `Move "${b.title}" to ${f(d.s)} – ${f(d.e)}?`,
        confirmLabel: lang === 'ar' ? 'حرّكه' : 'Move',
      });
      if (!ok) return;
    }
    await db.put('activity_blocks', { ...b, startMin: d.s, endMin: d.e, updatedAt: Date.now() });
    await db.put('schedule_changes', {
      id: newId(), blockId: b.id, date: b.date,
      reason: lang === 'ar' ? (d.mode === 'resize' ? 'تغيير مدة النشاط من اللوحة' : 'تحريك النشاط على اللوحة') : `Board ${d.mode}`,
      original: { startMin: b.startMin, endMin: b.endMin },
      proposed: { startMin: d.s, endMin: d.e }, applied: true, createdAt: Date.now(),
    });
    haptic('medium');
    bump();
    toast(
      lang === 'ar' ? `بقت ${f(d.s)} – ${f(d.e)} (${d.e - d.s} د)` : `Updated to ${f(d.s)} – ${f(d.e)}`,
      { actionLabel: lang === 'ar' ? 'رجّعها' : 'Undo', onAction: async () => { await db.put('activity_blocks', b); bump(); } }
    );
  };

  const toggleQuickDone = async (e: React.PointerEvent | React.MouseEvent, b: ActivityBlock) => {
    e.stopPropagation();
    const next = b.status === 'done' ? 'planned' : 'done';
    await db.put('activity_blocks', { ...b, status: next, actualEndMin: next === 'done' ? nowM : null, updatedAt: Date.now() });
    haptic('light');
    bump();
  };

  const copyDayTo = async () => {
    if (!copyDate || copyDate === date) { toast(lang === 'ar' ? 'اختار يوم مختلف' : 'Pick a different day'); return; }
    const copies = active.map(b => ({
      ...b, id: newId(), date: copyDate, status: 'planned' as const,
      actualStartMin: null, actualEndMin: null, createdAt: Date.now(), updatedAt: Date.now(),
    }));
    await db.bulkPut('activity_blocks', copies);
    setCopyOpen(false);
    bump();
    toast(lang === 'ar' ? `اتنسخ ${copies.length} نشاط ليوم ${copyDate} ✓` : `Copied ${copies.length} block(s) to ${copyDate}`);
  };

  const onBoardClick = (e: React.MouseEvent) => {
    if (drag || !boardRef.current) return;
    const rect = boardRef.current.getBoundingClientRect();
    const min = Math.max(0, Math.min(23 * 60 + 30, Math.floor(((e.clientY - rect.top) / ppm) / 15) * 15));
    onCreateAt(min);
  };

  const nextZoom = () => setZoom(z => (z === 'sm' ? 'md' : z === 'md' ? 'lg' : 'sm'));
  const zoomLabel = zoom === 'sm' ? '1×' : zoom === 'md' ? '1.4×' : '2×';

  return (
    <div className="card overflow-hidden">
      {/* Compact board toolbar */}
      <div className="flex items-center justify-between px-3 py-2 border-b hairline gap-2">
        <span className="text-[0.68rem] font-extrabold text-2 flex items-center gap-1.5">
          {lang === 'ar' ? `${active.length} نشاط` : `${active.length} blocks`}
          <HelpTip title="لوحة تخطيط اليوم">
            <p>اللوحة بتعرض اليوم ساعة بساعة وتقدر ترتّب فيها بسهولة:</p>
            <ul>
              <li><b>حرّك أي مربع:</b> اسحبه فوق أو تحت لتغيير ساعته (بيقفز كل 5 دقايق بدقة).</li>
              <li><b>غيّر المدة:</b> شد الخط الصغير اللي في آخر المربع.</li>
              <li><b>مربعات قريبة أو لازقة في بعض:</b> بتترتب تلقائياً جنب بعض بمسافة واضحة عشان تشوف الساعة والملاحظة كاملة في كل واحد من غير ما يتداخلو.</li>
              <li><b>ضيف نشاط سريع:</b> دوس على أي ساعة فاضية.</li>
              <li><b>تطبيق الخطة:</b> الزرار فوق بيجدول كل التنبيهات ويحدّث الويدجيت ويسجل في اليوميات.</li>
            </ul>
          </HelpTip>
        </span>
        <div className="flex items-center gap-1.5">
          {active.length > 0 && (
            <button className="chip" onClick={() => { setCopyDate(''); setCopyOpen(true); }} aria-label="copy day">
              <Copy className="w-3.5 h-3.5" />{lang === 'ar' ? 'نسخ ليوم تاني' : 'Copy day'}
            </button>
          )}
          <button className="chip num" onClick={nextZoom} aria-label="zoom">
            <ZoomIn className="w-3.5 h-3.5" />{zoomLabel}
          </button>
        </div>
      </div>

      {/* Scrollable 24-hour canvas */}
      <div
        ref={scrollRef}
        className="relative overflow-y-auto no-scrollbar"
        style={{ maxHeight: '62vh' }}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={() => setDrag(null)}
      >
        <div ref={boardRef} className="relative" style={{ height: totalH }} onClick={onBoardClick}>
          {Array.from({ length: END_H - START_H }, (_, i) => (
            <div key={i} className="absolute inset-x-0 border-t hairline" style={{ top: i * 60 * ppm }}>
              <span className="num absolute top-0.5 start-1 text-[0.58rem] font-bold text-3 bg-[var(--surface)]/90 px-1 rounded" dir="ltr">
                {minToTime(i * 60, hour12)}
              </span>
              <div className="absolute inset-x-0 border-t border-dashed opacity-35 hairline" style={{ top: 30 * ppm }} />
            </div>
          ))}

          {/* Real current-time hairline */}
          {isToday && (
            <div className="absolute inset-x-0 z-20 pointer-events-none flex items-center" style={{ top: nowM * ppm }}>
              <span className="w-2.5 h-2.5 rounded-full bg-[var(--danger)] ms-12 live-dot shadow" />
              <span className="flex-1 h-[2px] bg-[var(--danger)]" />
            </div>
          )}

          {/* Positioned activity blocks (never overlap visually; crisp gutter between siblings) */}
          <div className="absolute inset-y-0 start-[3.4rem] end-2">
            {laid.map(({ b, col, cols, top, height, realH }) => {
              const c = catMap[b.categoryId];
              const isDrag = drag?.id === b.id;
              const width = `calc(${100 / cols}% - ${COL_GAP}px)`;
              const startPos = `calc(${(100 / cols) * col}% + ${COL_GAP / 2}px)`;
              const note = b.notes && !b.notes.startsWith('tpl:') ? b.notes.trim() : '';
              const dur = b.endMin - b.startMin;
              const expanded = height > realH + 4;
              const done = b.status === 'done';
              const maxNoteLines = Math.max(1, Math.floor((height - 46) / 14));

              return (
                <div
                  key={b.id}
                  className={cn('board-block flex flex-col', isDrag && 'dragging', done && 'opacity-65')}
                  style={{
                    top: top + 2,
                    height: height - 4,
                    width,
                    insetInlineStart: startPos,
                    ['--blk' as any]: c?.color ?? 'var(--accent)',
                    zIndex: isDrag ? 35 : 5 + col,
                  }}
                  onPointerDown={e => onPointerDown(e, b, 'move')}
                  onClick={e => e.stopPropagation()}
                  role="button"
                  aria-label={`${b.title} ${f(b.startMin)} - ${f(b.endMin)}`}
                >
                  {/* Title + quick done button */}
                  <div className="flex items-center gap-1 min-w-0">
                    <CategoryIcon icon={c?.icon} className="w-3.5 h-3.5 shrink-0 opacity-85" />
                    <span className={cn('text-[0.75rem] font-extrabold truncate flex-1 leading-tight', done && 'line-through')}>
                      {b.title}
                    </span>
                    {b.fixed && <Pin className="w-3 h-3 shrink-0 opacity-75" />}
                    {b.reminderMin >= 0 && <Bell className="w-3 h-3 shrink-0 opacity-65" />}
                    <button
                      type="button"
                      onPointerDown={e => e.stopPropagation()}
                      onClick={e => toggleQuickDone(e, b)}
                      aria-label="done"
                      className={cn(
                        'w-4.5 h-4.5 rounded-full grid place-items-center shrink-0 border transition-colors',
                        done ? 'bg-[var(--ok)] border-transparent text-white' : 'border-[var(--border-strong)] bg-[var(--surface)]/70'
                      )}
                    >
                      {done && <Check className="w-3 h-3" strokeWidth={3} />}
                    </button>
                  </div>

                  {/* Exact time range & duration — ALWAYS visible regardless of block length */}
                  <div className="flex items-center justify-between gap-1 mt-0.5">
                    <span className="num text-[0.62rem] font-extrabold opacity-90 flex items-center gap-1 truncate" dir="ltr">
                      <Clock className="w-2.5 h-2.5 shrink-0" />
                      {f(b.startMin)} – {f(b.endMin)}
                    </span>
                    <span className="num text-[0.56rem] font-bold px-1.5 py-[1px] rounded-full bg-[var(--surface)]/75 shrink-0">
                      {dur}{lang === 'ar' ? ' د' : 'm'}
                    </span>
                  </div>

                  {/* Full note — always shown clearly whenever present */}
                  {note ? (
                    <p
                      className="text-[0.61rem] leading-[1.35] opacity-90 mt-1 flex items-start gap-1 min-w-0"
                      style={{
                        display: '-webkit-box', WebkitBoxOrient: 'vertical',
                        WebkitLineClamp: maxNoteLines, overflow: 'hidden',
                      }}
                    >
                      <StickyNote className="w-2.5 h-2.5 shrink-0 mt-0.5 inline me-0.5" />
                      {note}
                    </p>
                  ) : expanded ? (
                    <p className="text-[0.54rem] opacity-55 mt-0.5 truncate">
                      {lang === 'ar' ? (c?.nameAr ?? '') : (c?.nameEn ?? '')}
                    </p>
                  ) : null}

                  {/* Floating live drag badge */}
                  {isDrag && (
                    <span className="num absolute top-1 end-1 text-[0.62rem] font-black px-1.5 py-0.5 rounded-lg bg-[var(--accent)] text-[var(--on-accent)] shadow-md" dir="ltr">
                      {f(drag!.s)} – {f(drag!.e)}
                    </span>
                  )}

                  {/* Bottom smooth resize bar */}
                  <div
                    className="board-resize"
                    onPointerDown={e => onPointerDown(e, b, 'resize')}
                    aria-label="resize duration"
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <p className="text-[0.6rem] text-3 px-3 py-2 border-t hairline leading-relaxed">
        {lang === 'ar'
          ? '👆 اسحب أي مربع لتغيير وقته · شد آخره لتكبير أو تصغير مدته · دوس أي ساعة فاضية لإضافة نشاط'
          : 'Drag any block to move · drag its bottom edge to resize · tap empty time to create'}
      </p>

      {/* Duplicate day plan to another date */}
      <Sheet open={copyOpen} onClose={() => setCopyOpen(false)} title={lang === 'ar' ? 'انسخ خطة اليوم ليوم تاني' : 'Copy plan to another day'}>
        <p className="text-xs text-2 mb-3">{lang === 'ar' ? `هينسخ ${active.length} نشاط بكل مواعيدهم وملاحظاتهم لليوم اللي هتختاره.` : `Copies ${active.length} block(s) with times & notes to your chosen date.`}</p>
        <Field label={lang === 'ar' ? 'اليوم المستهدف' : 'Target date'}>
          <input type="date" className="input num" value={copyDate} onChange={e => setCopyDate(e.target.value)} />
        </Field>
        <button className="btn btn-primary w-full justify-center !py-3" onClick={copyDayTo}>
          <Copy className="w-4 h-4" />{lang === 'ar' ? 'انسخ الخطة' : 'Copy plan'}
        </button>
      </Sheet>
    </div>
  );
}
