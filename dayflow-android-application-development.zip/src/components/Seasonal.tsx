/* DAYFLOW — Rich seasonal & occasion decoration engine (100% offline)
   90+ Microsoft Fluent Emoji 3D PNGs + 38 distinct real photos · auto-rotates by
   season, occasion, date and time of day · user-tunable speed/density/opacity/layer. */
import { useMemo, type ReactNode } from 'react';
import BrandBlockArt from './BrandBlockArt';
import { useApp } from '@/lib/store';
import { hijriOf, hijriLabel, orthodoxEaster } from '@/lib/occasions';

export interface Scene {
  id: string; ar: string; en: string;
  photos: string[];
  particles: string[];
  hang: string[];
  garlandColor?: string;
  corner?: string; corner2?: string; corner3?: string;
  greetingAr: string; greetingEn: string;
  tint: string;
  particleCount?: number;
}

const D = (n: string) => `/decor/${n}.png`;

export const SCENES: Record<string, Scene> = {
  ramadan: {
    id: 'ramadan', ar: 'رمضان كريم', en: 'Ramadan',
    photos: ['/media/occ-ramadan3.jpg', '/media/occ-ramadan.jpg', '/media/occ-ramadan2.jpg'],
    particles: [D('star-glow'), D('sparkles'), D('crescent'), D('star'), D('mooncake'), D('lantern-gold')],
    hang: [D('lantern-gold'), D('star-glow'), D('crescent'), D('lantern-red'), D('star-glow'), D('crescent'), D('lantern-gold'), D('star')],
    garlandColor: 'rgba(253,224,130,.9)',
    corner: D('mosque'), corner2: D('prayer-beads'), corner3: D('full-moon'),
    greetingAr: 'رمضان كريم 🌙 ربنا يتقبل صيامنا وقيامنا',
    greetingEn: 'Ramadan Kareem 🌙', tint: 'rgba(24,14,58,.55)', particleCount: 16,
  },
  eidFitr: {
    id: 'eidFitr', ar: 'العيد الصغير', en: 'Eid al-Fitr',
    photos: ['/media/occ-eid-fitr.jpg', '/media/occ-ramadan3.jpg'],
    particles: [D('balloon'), D('confetti'), D('cupcake'), D('candy'), D('lollipop'), D('sparkles'), D('party')],
    hang: [D('ribbon'), D('star-glow'), D('crescent'), D('gift'), D('star-glow'), D('ribbon'), D('crescent'), D('star-glow')],
    garlandColor: 'rgba(255,215,150,.9)',
    corner: D('gift'), corner2: D('party'), corner3: D('cupcake'),
    greetingAr: 'عيد فطر سعيد 🎉 كحك وبسكوت وعيدية — كل سنة وانت طيب',
    greetingEn: 'Eid Mubarak 🎉', tint: 'rgba(74,16,58,.46)', particleCount: 17,
  },
  eidAdha: {
    id: 'eidAdha', ar: 'العيد الكبير', en: 'Eid al-Adha',
    photos: ['/media/occ-hajj.jpg', '/media/occ-islamic.jpg'],
    particles: [D('sparkles'), D('star-glow'), D('star'), D('sheep')],
    hang: [D('crescent'), D('lantern-gold'), D('kaaba'), D('lantern-gold'), D('crescent'), D('star-glow')],
    garlandColor: 'rgba(255,222,130,.85)',
    corner: D('kaaba'), corner2: D('mosque'), corner3: D('sheep'),
    greetingAr: 'عيد أضحى مبارك 🐑 تقبّل الله منّا ومنكم',
    greetingEn: 'Eid al-Adha Mubarak 🐑', tint: 'rgba(18,28,44,.48)', particleCount: 12,
  },
  islamic: {
    id: 'islamic', ar: 'مناسبة إسلامية', en: 'Islamic occasion',
    photos: ['/media/occ-mawlid.jpg', '/media/occ-islamic.jpg', '/media/occ-isra.jpg', '/media/occ-quran.jpg'],
    particles: [D('star-glow'), D('sparkles'), D('crescent'), D('star')],
    hang: [D('crescent'), D('star-glow'), D('lantern-gold'), D('star-glow'), D('crescent'), D('star')],
    garlandColor: 'rgba(253,224,140,.82)',
    corner: D('mosque'), corner2: D('prayer-beads'), corner3: D('full-moon'),
    greetingAr: 'يوم مبارك ✨ كل سنة وانت بخير',
    greetingEn: 'Blessed day ✨', tint: 'rgba(18,22,52,.48)', particleCount: 11,
  },
  newyear: {
    id: 'newyear', ar: 'زينة الشتا ورأس السنة', en: 'Festive Winter',
    photos: ['/media/occ-stockings.jpg', '/media/occ-christmas.jpg', '/media/occ-santa.jpg'],
    particles: [D('snowflake'), D('snowflake'), D('ice-cube'), D('gift'), D('candy'), D('lollipop')],
    hang: [D('socks'), D('bell'), D('pine-decor'), D('star-glow'), D('socks'), D('ribbon'), D('bell'), D('gift')],
    garlandColor: 'rgba(220,252,231,.85)',
    corner: D('xmas-tree'), corner2: D('santa'), corner3: D('gift'),
    greetingAr: 'سنة جديدة سعيدة 🎄 شجرة وحلوى وجوارب — أشوأ وقت للزينة!',
    greetingEn: 'Happy festive winter 🎄', tint: 'rgba(68,14,18,.46)', particleCount: 17,
  },
  nye: {
    id: 'nye', ar: 'ليلة رأس السنة', en: "New Year's Eve",
    photos: ['/media/occ-newyear.jpg', '/media/occ-santa.jpg'],
    particles: [D('sparkles'), D('fireworks'), D('confetti'), D('star-glow'), D('snowflake')],
    hang: [D('star-glow'), D('bell'), D('party'), D('socks'), D('bell'), D('star-glow'), D('confetti')],
    garlandColor: 'rgba(254,240,138,.88)',
    corner: D('fireworks'), corner2: D('xmas-tree'), corner3: D('santa'),
    greetingAr: 'سنة جديدة سعيدة 🎆 يا رب سنة كلها إنجاز وهنا',
    greetingEn: 'Happy New Year 🎆', tint: 'rgba(12,14,48,.46)', particleCount: 16,
  },
  winter: {
    id: 'winter', ar: 'الشتاء والثلج', en: 'Winter',
    photos: ['/media/bg-winter2.jpg', '/media/bg-winter.jpg'],
    particles: [D('snowflake'), D('snowflake'), D('snowflake'), D('ice-cube'), D('snow-cloud')],
    hang: [D('snowflake'), D('star'), D('snowflake'), D('star'), D('snowflake'), D('ice-cube')],
    garlandColor: 'rgba(224,242,254,.66)',
    corner: D('snowman'), corner2: D('tree-pine'), corner3: D('coffee-hot'),
    greetingAr: 'شتا دافي ورايق ❄️ كوباية سخنة ويوم مرتب',
    greetingEn: 'Cozy winter ❄️', tint: 'rgba(16,42,72,.4)', particleCount: 17,
  },
  autumn: {
    id: 'autumn', ar: 'الخريف والورق', en: 'Autumn',
    photos: ['/media/bg-autumn2.jpg', '/media/bg-autumn.jpg'],
    particles: [D('leaf-maple'), D('leaf-fallen'), D('leaf-flutter'), D('chestnut'), D('leaf-maple'), D('leaf-fallen')],
    hang: [D('leaf-maple'), D('leaf-fallen'), D('tree-autumn'), D('leaf-fallen'), D('leaf-maple'), D('chestnut')],
    garlandColor: 'rgba(254,215,170,.74)',
    corner: D('tree-autumn'), corner2: D('leaf-maple'), corner3: D('coffee-hot'),
    greetingAr: 'خريف هادئ وملفوف بأوراق الذهب 🍂',
    greetingEn: 'Golden autumn 🍂', tint: 'rgba(72,30,10,.4)', particleCount: 17,
  },
  spring: {
    id: 'spring', ar: 'الربيع والزهور', en: 'Spring',
    photos: ['/media/bg-spring2.jpg', '/media/bg-spring.jpg'],
    particles: [D('blossom'), D('tulip'), D('flower-gold'), D('hibiscus'), D('rose'), D('seedling')],
    hang: [D('blossom'), D('tulip'), D('bouquet'), D('tulip'), D('blossom'), D('hibiscus')],
    garlandColor: 'rgba(252,231,243,.8)',
    corner: D('bouquet'), corner2: D('sunflower'), corner3: D('clover'),
    greetingAr: 'ربيع مبهج 🌸 طاقة جديدة ويوم حلو',
    greetingEn: 'Blooming spring 🌸', tint: 'rgba(22,52,42,.32)', particleCount: 14,
  },
  sham: {
    id: 'sham', ar: 'شم النسيم', en: 'Sham El-Nessim',
    photos: ['/media/occ-sham.jpg', '/media/bg-spring2.jpg'],
    particles: [D('blossom'), D('egg'), D('tulip'), D('flower-gold'), D('hibiscus')],
    hang: [D('egg'), D('blossom'), D('tulip'), D('egg'), D('blossom')],
    garlandColor: 'rgba(254,243,199,.85)',
    corner: D('egg'), corner2: D('fish'), corner3: D('bouquet'),
    greetingAr: 'شم نسيم سعيد 🌸 خروجة عائلية وبهجة',
    greetingEn: 'Happy Sham El-Nessim 🌸', tint: 'rgba(26,56,88,.36)', particleCount: 12,
  },
  summer: {
    id: 'summer', ar: 'الصيف والبحر', en: 'Summer',
    photos: ['/media/bg-summer.jpg', '/media/bg-summer2.jpg'],
    particles: [D('sun'), D('droplet'), D('sparkles'), D('hibiscus'), D('wave'), D('sun-face')],
    hang: [D('sun'), D('droplet'), D('sun-face'), D('droplet'), D('sun')],
    garlandColor: 'rgba(254,249,195,.7)',
    corner: D('palm'), corner2: D('beach'), corner3: D('sun'),
    greetingAr: 'صيف منعش ☀️ روح البحر وخفّف الحمل — اشرب مية كتير',
    greetingEn: 'Fresh summer ☀️', tint: 'rgba(10,52,76,.34)', particleCount: 13,
  },
  national: {
    id: 'national', ar: 'مناسبة وطنية', en: 'National day',
    photos: ['/media/occ-national.jpg', '/media/occ-cairo.jpg', '/media/occ-sinai.jpg', '/media/occ-egypt.jpg'],
    particles: [D('sparkles'), D('confetti'), D('ribbon'), D('star-glow')],
    hang: [D('ribbon'), D('star-glow'), D('shield'), D('star-glow'), D('ribbon'), D('confetti')],
    garlandColor: 'rgba(254,226,226,.88)',
    corner: D('shield'), corner2: D('fireworks'), corner3: D('sparkles'),
    greetingAr: 'تحيا مصر 🇪🇬 كل سنة ومصر وشعبها بخير',
    greetingEn: 'Egypt Day 🇪🇬', tint: 'rgba(56,12,16,.42)', particleCount: 13,
  },
  october: {
    id: 'october', ar: 'نصر أكتوبر', en: '6 October Victory',
    photos: ['/media/occ-sinai.jpg', '/media/occ-egypt.jpg', '/media/occ-national.jpg'],
    particles: [D('sparkles'), D('confetti'), D('star-glow'), D('ribbon')],
    hang: [D('shield'), D('star-glow'), D('ribbon'), D('shield'), D('star-glow'), D('ribbon')],
    garlandColor: 'rgba(254,226,226,.9)',
    corner: D('shield'), corner2: D('fireworks'), corner3: D('trophy'),
    greetingAr: 'عيد قواتنا المسلحة 🎖️ نصر أكتوبر المجيدة 1973',
    greetingEn: 'Armed Forces Day · 6 October', tint: 'rgba(28,18,44,.48)', particleCount: 14,
  },
  exams: {
    id: 'exams', ar: 'موسم الامتحانات', en: 'Exam season',
    photos: ['/media/onb-1.jpg', '/media/onb-2.jpg'],
    particles: [D('book'), D('notebook'), D('star'), D('sparkles'), D('trophy')],
    hang: [D('book'), D('notebook'), D('star-glow'), D('book'), D('notebook'), D('star-glow')],
    garlandColor: 'rgba(226,232,255,.85)',
    corner: D('notebook'), corner2: D('book'), corner3: D('trophy'),
    greetingAr: 'موسم المذاكرة والتركيز 📚 التزم بالخطة هتوصل',
    greetingEn: 'Exam season 📚', tint: 'rgba(20,24,60,.45)', particleCount: 12,
  },
  school: {
    id: 'school', ar: 'بداية الدراسة', en: 'Back to school',
    photos: ['/media/onb-1.jpg', '/media/onb-2.jpg', '/media/bg-spring2.jpg'],
    particles: [D('notebook'), D('book'), D('blossom'), D('seedling'), D('sparkles')],
    hang: [D('notebook'), D('blossom'), D('book'), D('blossom'), D('notebook'), D('seedling')],
    garlandColor: 'rgba(219,234,254,.85)',
    corner: D('book'), corner2: D('notebook'), corner3: D('pencil'),
    greetingAr: 'سنة دراسية سعيدة 🎒 شدّة حيلك ونظّم خطتك',
    greetingEn: 'Back to school 🎒', tint: 'rgba(16,32,56,.38)', particleCount: 12,
  },
};

export function sceneFor(date: Date, hijriOffset = 0, override = 'auto'): Scene {
  if (override !== 'auto' && SCENES[override]) return SCENES[override];
  const h = hijriOf(date, hijriOffset);
  const m = date.getMonth() + 1, d = date.getDate(), y = date.getFullYear();
  if (h) {
    if (h.m === 9) return SCENES.ramadan;
    if (h.m === 10 && h.d <= 3) return SCENES.eidFitr;
    if (h.m === 12 && h.d >= 9 && h.d <= 13) return SCENES.eidAdha;
    if ((h.m === 1 && (h.d === 1 || h.d === 10)) || (h.m === 3 && h.d === 12) || (h.m === 7 && h.d === 27) || (h.m === 8 && h.d === 15)) return SCENES.islamic;
  }
  const md = m * 100 + d;
  if (md === 1006) return SCENES.october;
  if ([125, 425, 501, 630, 723].includes(md)) return SCENES.national;
  if (m === 6 && d >= 1 && d <= 20) return SCENES.exams;      // امتحانات آخر السنة
  if (md >= 915 && md <= 1010) return SCENES.school;          // بداية العام الدراسي
  const sham = orthodoxEaster(y); sham.setDate(sham.getDate() + 1);
  if (sham.getMonth() + 1 === m && sham.getDate() === d) return SCENES.sham;
  if (md === 1231 || md === 101) return SCENES.nye;
  if (md >= 1215 || md <= 107) return SCENES.newyear;
  if (m === 12 || m <= 2) return SCENES.winter;
  if (md >= 922) return SCENES.autumn;
  if (m >= 3 && m <= 5) return SCENES.spring;
  return SCENES.summer;
}


/** Resolves ALL active scenes: manual single override > user mix (≤3) > automatic by date.
    `auto` is recomputed on every render tick so a new season/occasion/date activates itself. */
export function activeScenes(settings: {
  decorOverride: string; decorMix?: string[]; hijriOffset: number;
}, date = new Date()): Scene[] {
  if (settings.decorOverride && settings.decorOverride !== 'auto' && SCENES[settings.decorOverride]) {
    return [SCENES[settings.decorOverride]];
  }
  const mix = (settings.decorMix ?? []).filter(id => !!SCENES[id]).slice(0, 3);
  if (mix.length) return mix.map(id => SCENES[id]);
  return [sceneFor(date, settings.hijriOffset, 'auto')];
}

/** Time-of-day aware seasonal/occasion photo with smooth rotation */
export function headerPhoto(scene: Scene, date: Date, forced = false): string {
  const hr = date.getHours();
  const seed = (date.getDate() + date.getMonth() * 31 + Math.floor(hr / 6)) % scene.photos.length;
  if (forced || !['winter', 'autumn', 'spring', 'summer'].includes(scene.id)) {
    return scene.photos[seed];
  }
  if (hr >= 5 && hr < 9) return '/media/bg-morning.jpg';
  if (hr >= 17 && hr < 19) return scene.id === 'summer' ? '/media/bg-summer2.jpg' : '/media/bg-sunset.jpg';
  if (hr >= 20 || hr < 5) return '/media/bg-night.jpg';
  return scene.photos[date.getDate() % scene.photos.length];
}

const SPEED_MULT = { slow: 1.55, normal: 1, fast: 0.55 } as const;
const DENSITY_MULT = { light: 0.55, normal: 1, dense: 1.65 } as const;

export function useScene() {
  const { settings } = useApp();
  const stamp = `${new Date().toDateString()}-${Math.floor(new Date().getHours() / 2)}`;
  return useMemo(() => sceneFor(new Date(), settings.hijriOffset, settings.decorOverride), [settings.hijriOffset, settings.decorOverride, stamp]);
}

/** Ambient falling/drifting 3D elements with user-tunable speed/density/opacity/layer */
export function SeasonalLayer() {
  const { settings } = useApp();
  const scenes = useMemo(
    () => activeScenes(settings, new Date()),
    [settings.decorOverride, JSON.stringify(settings.decorMix ?? []), settings.hijriOffset, new Date().toDateString()]
  );
  const primary = scenes[0];
  const density = settings.decorDensity ?? 'normal';
  const speed = settings.decorSpeed ?? 'normal';
  const opacity = Math.min(1, Math.max(0.15, settings.decorOpacity ?? 0.9));
  const above = settings.decorLayer === 'above';
  // A mixed scene divides its particle budget so 3 scenes never strain the CPU.
  const perScene = Math.max(3, Math.round(((primary.particleCount ?? 12) * (DENSITY_MULT[density] ?? 1)) / Math.max(1, scenes.length)));
  const items = useMemo(() => scenes.flatMap((scene, si) =>
    Array.from({ length: perScene }, (_, i) => {
      const r = (n: number) => { const x = Math.sin((i + si * 37 + 1) * 9301 + n * 49297) * 233280; return x - Math.floor(x); };
      return {
        src: scene.particles[i % scene.particles.length],
        left: 2 + r(1) * 94,
        size: 15 + r(2) * 19,
        dur: (11 + r(3) * 13) * (SPEED_MULT[speed] ?? 1),
        delay: -r(4) * 22,
        drift: (r(5) - 0.5) * 130,
        spin: (r(6) > 0.5 ? 1 : -1) * (140 + r(7) * 320),
      };
    })
  ), [scenes, perScene, speed]);

  // Static, unmoving ornaments: ALWAYS visible (even under prefers-reduced-motion),
  // and clearly visible behind content at a softer opacity. CSS handles opacity, not JS.
  const staticBits = useMemo(() => scenes.flatMap(sc => [sc.corner, sc.corner2, sc.corner3]).filter(Boolean).slice(0, 6) as string[], [scenes]);

  if (!settings.decorations) return null;
  const reduced = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

  return (
    <div
      aria-hidden
      className={`decor-root pointer-events-none absolute inset-0 overflow-hidden ${above ? 'z-[9]' : 'z-[4]'}`}
      style={{ opacity: above ? opacity : Math.max(0.55, opacity * 0.8) }}
    >
      {/* Permanent crisp garland: no animation, always readable */}
      <div className="decor-static-top absolute top-0 inset-x-0 flex justify-center gap-2 px-3 pt-1" style={{ opacity: above ? 0.9 : 0.7 }}>
        {scenes.flatMap(sc => sc.hang.slice(0, 2)).slice(0, 5).map((src, i) => (
          <img key={`s${i}`} src={src} alt="" className="w-5 h-5 object-contain decor-twinkle" style={{ animationDelay: `${i * 0.4}s` }} draggable={false} />
        ))}
      </div>

      {/* Gentle falling 3D particles (disabled on reduced motion) */}
      {settings.particles && !reduced && primary.particles.length > 0 && items.map((p, i) => (
        <img
          key={`${scenes.map(x => x.id).join('-')}-${density}-${speed}-${i}`}
          src={p.src} alt="" className="decor-particle" draggable={false}
          style={{
            left: `${p.left}%`, width: p.size, height: p.size,
            animationDuration: `${p.dur}s`, animationDelay: `${p.delay}s`,
            ['--drift' as any]: `${p.drift}px`, ['--spin' as any]: `${p.spin}deg`,
          }}
        />
      ))}

      {/* Fixed 3D sculptures anchored bottom-right — visible in BOTH layers, softer behind */}
      <div className="decor-static-corner absolute bottom-2 end-2 flex items-end gap-1" style={{ opacity: above ? 0.95 : 0.62 }}>
        {staticBits.slice(0, 3).map((src, i) => (
          <img key={i} src={src} alt="" className={i === 0 ? 'w-12 h-12 object-contain' : 'w-7 h-7 object-contain'} draggable={false} />
        ))}
      </div>
    </div>
  );
}

/** Festive photo header with arched garland, 3D ornaments and floating corner grace notes */
export function SeasonalHeader({ children }: { children: ReactNode }) {
  const { settings, lang } = useApp();
  const scenes = useMemo(() => activeScenes(settings, new Date()), [settings.decorOverride, JSON.stringify(settings.decorMix ?? []), settings.hijriOffset, new Date().toDateString()]);
  const scene = scenes[0];
  const now = new Date();
  if (!settings.decorations) return <div className="px-4 pt-5 pb-1">{children}</div>;

  const photo = settings.headerPhotos ? headerPhoto(scene, now, settings.decorOverride !== 'auto') : null;
  const cable = scene.garlandColor ?? 'rgba(255,240,200,.78)';

  return (
    <div
      className="relative mx-3 mt-3 rounded-[calc(var(--r-card,22px)+4px)] overflow-hidden shadow-md border hairline"
      style={{ minHeight: 188, background: 'linear-gradient(145deg, var(--accent-deep), var(--accent))' }}
    >
      {photo && (
        <img key={photo} src={photo} alt="" className="absolute inset-0 w-full h-full object-cover anim-fade" draggable={false} />
      )}
      <div
        className="absolute inset-0"
        style={{ background: `linear-gradient(180deg, ${scene.tint} 0%, rgba(0,0,0,.18) 44%, rgba(0,0,0,.72) 100%)` }}
      />

      {/* Exact wordmark: top-right of the hero card, RTL page but LTR glyphs preserved */}
      <div className="absolute top-1.5 end-3 z-[3] text-right pointer-events-none">
        <BrandBlockArt />
      </div>

      {/* Overhead arched string of twinkling 3D ornaments */}
      {(scenes.flatMap(x => x.hang).length > 0) && (
        <div aria-hidden className="absolute top-6 inset-x-0 flex justify-around px-2 pointer-events-none z-[1]">
          <svg className="absolute top-0 left-0 w-full h-7" viewBox="0 0 100 12" preserveAspectRatio="none">
            <path d="M0,1 Q16,10 33,2.5 T66,2.5 T100,1" stroke={cable} strokeWidth="0.5" fill="none" />
          </svg>
          {scenes.flatMap(x => x.hang).slice(0, 8).map((src, i) => {
            const edge = i === 0 || i === 7;
            const cord = edge ? 11 : 9 + (i % 3) * 7;
            const sz = 24 + (i % 2) * 7;
            return (
              <div key={i} className="decor-hang flex flex-col items-center" style={{ animationDelay: `${i * 0.3}s` }}>
                <span className="block w-[1.3px]" style={{ height: cord, background: cable }} />
                <img src={src} alt="" className="decor-twinkle object-contain" style={{ width: sz, height: sz, animationDelay: `${i * 0.38}s` }} draggable={false} />
              </div>
            );
          })}
        </div>
      )}

      {/* Layered 3D floating corners */}
      {scene.corner && <img aria-hidden src={scene.corner} alt="" className="decor-float absolute bottom-2 end-2 w-[4.3rem] h-[4.3rem] object-contain pointer-events-none z-[1]" draggable={false} />}
      {scene.corner2 && <img aria-hidden src={scene.corner2} alt="" className="decor-float absolute bottom-2.5 end-[4.6rem] w-11 h-11 object-contain pointer-events-none z-[1]" style={{ animationDelay: '1.3s' }} draggable={false} />}
      {scene.corner3 && <img aria-hidden src={scene.corner3} alt="" className="decor-twinkle absolute bottom-[4.4rem] end-3 w-7 h-7 object-contain pointer-events-none z-[1] opacity-95" style={{ animationDelay: '0.8s' }} draggable={false} />}

      <div className="relative z-[2] px-4 pt-14 pb-3.5 text-white [&_.text-2]:!text-white/85 [&_.text-3]:!text-white/75 [&_.icon-btn]:!text-white">
        {children}
        <p className="text-[0.68rem] font-bold text-white/92 mt-2 pe-24 leading-snug drop-shadow-sm">
          {lang === 'ar' ? scene.greetingAr : scene.greetingEn}
          <span className="block text-[0.6rem] text-white/80 font-semibold mt-0.5">{hijriLabel(now, lang, settings.hijriOffset)}</span>
        </p>
      </div>
    </div>
  );
}
