/* DAYFLOW — Exact wordmark. The strings below are preserved byte-for-byte:
   no letter substitution, no mirroring, no RTL reshaping, no trimming of internal spaces. */
export const BRAND_ART_LINE_1 = '█▀▄ ▄▀█ █▄█   █▀▀ █░░ █▀█ █░█░█';
export const BRAND_ART_LINE_2 = '█▄▀ █▀█ ░█░   █▀░ █▄▄ █▄█ ▀▄▀▄▀';

export default function BrandBlockArt({ className = '' }: { className?: string }) {
  return (
    <pre
      aria-label="Day Flow"
      dir="ltr"
      className={`brand-blockart ${className}`}
      style={{ margin: 0, padding: 0, border: 0, background: 'transparent' }}
    >{BRAND_ART_LINE_1}{'\n'}{BRAND_ART_LINE_2}</pre>
  );
}
