/* DAYFLOW — Brand logo renderer: official marks (bundled locally) or a brand-colored monogram. */
import { BRAND_ICONS, FAMILY_LOGO } from '@/lib/ai/providers';

export function BrandLogo({ icon, mono, color, size = 28, rounded = 'xl', label }: {
  icon?: string; mono: string; color: string; size?: number; rounded?: 'lg' | 'xl' | 'full'; label?: string;
}) {
  const r = rounded === 'full' ? 'rounded-full' : rounded === 'lg' ? 'rounded-lg' : 'rounded-xl';
  const brand = icon ? BRAND_ICONS[icon] : undefined;
  if (brand) {
    const fill = brand.hex === '000000' || brand.hex.toLowerCase() === 'ffffff' ? 'currentColor' : `#${brand.hex}`;
    return (
      <span
        className={`inline-grid place-items-center shrink-0 ${r}`}
        style={{ width: size, height: size, background: `color-mix(in srgb, ${fill === 'currentColor' ? 'var(--text)' : fill} 14%, var(--surface))`, color: 'var(--text)' }}
        role="img" aria-label={label ?? brand.title}
      >
        <svg viewBox="0 0 24 24" width={size * 0.6} height={size * 0.6} aria-hidden>
          <path d={brand.path} fill={fill} />
        </svg>
      </span>
    );
  }
  return (
    <span
      className={`inline-grid place-items-center shrink-0 font-black text-white ${r}`}
      style={{ width: size, height: size, background: `linear-gradient(145deg, ${color}, color-mix(in srgb, ${color} 70%, #000))`, fontSize: Math.max(8, size * 0.36), letterSpacing: '-0.02em' }}
      role="img" aria-label={label ?? mono}
    >
      {mono}
    </span>
  );
}

export function FamilyLogo({ family, size = 22 }: { family: string; size?: number }) {
  const f = FAMILY_LOGO[family] ?? FAMILY_LOGO.generic;
  return <BrandLogo icon={f.icon} mono={f.mono} color={f.color} size={size} rounded="lg" label={f.label} />;
}
