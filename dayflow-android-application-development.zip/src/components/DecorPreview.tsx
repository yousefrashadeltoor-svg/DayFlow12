/* DAYFLOW — A real miniature Home screen with the decoration ACTUALLY rendered inside it.
   Reused by the Decor Gallery (grid) and the single-scene full preview sheet. */
import { useMemo } from 'react';
import { Sun, CalendarDays, CalendarRange, LayoutGrid, Plus } from 'lucide-react';
import type { Scene } from './Seasonal';
import ThemePreview from './ThemePreview';
import BrandBlockArt from './BrandBlockArt';
import { cn } from '@/utils/cn';

interface Props {
  scene: Scene;
  selected?: boolean;
  active?: boolean;
  large?: boolean;
  intensity?: number;   // 0..1 — scales particle count & opacity
  speed?: 'slow' | 'normal' | 'fast';
  layer?: 'below' | 'above';
}

export default function DecorPreview({ scene, selected, active, large, intensity = 1, speed = 'normal', layer = 'above' }: Props) {
  const count = large ? Math.max(4, Math.round((scene.particleCount ?? 11) * 0.55 * intensity)) : Math.max(2, Math.round((scene.particleCount ?? 11) * 0.2 * intensity));
  const dur = speed === 'slow' ? 1.7 : speed === 'fast' ? 0.55 : 1;
  const particles = useMemo(() => Array.from({ length: Math.min(count, large ? 12 : 4) }, (_, i) => {
    const r = (n: number) => { const x = Math.sin((i + 1) * 9301 + n * 49297) * 233280; return x - Math.floor(x); };
    return { src: scene.particles[i % scene.particles.length], left: 3 + r(1) * 91, size: 8 + r(2) * 11, d: (7 + r(3) * 8) * dur, delay: -r(4) * 12, drift: (r(5) - 0.5) * 38 };
  }), [scene, count, dur]);
  const cable = scene.garlandColor ?? 'rgba(255,240,200,.78)';

  return (
    <div
      className={cn('relative overflow-hidden rounded-[18px] border hairline select-none', large ? 'w-full' : 'w-full')}
      style={{ aspectRatio: large ? '9 / 15.6' : '9 / 15.2', fontFamily: 'var(--font)', color: 'var(--text)', background: 'var(--surface)' }}
    >
      {/* Base Home screen underneath the decoration */}
      <div className={cn('absolute inset-0', layer === 'below' && 'opacity-95')}>
        <ThemePreview skin="ios" theme="light" accent="indigo" />
      </div>

      {/* Real photo header, visible in both layers */}
      <div className="absolute inset-x-1.5 top-1.5 h-[29%] rounded-t-[16px] overflow-hidden" style={{ zIndex: layer === 'above' ? 3 : 1 }}>
        <img src={scene.photos[0]} alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, ${scene.tint}, rgba(0,0,0,.72))` }} />
        <div className="absolute inset-x-0 top-0 flex justify-around px-1">
          {scene.hang.slice(0, large ? 7 : 3).map((h, i) => (
            <div key={i} className="decor-hang flex flex-col items-center" style={{ animationDelay: `${i * 0.3}s` }}>
              <span className="block w-px" style={{ height: 4 + (i % 2) * 4, background: cable }} />
              <img src={h} alt="" loading="lazy" decoding="async" className="decor-twinkle object-contain" style={{ width: 11 + (i % 2) * 4, height: 11 + (i % 2) * 4, animationDelay: `${i * 0.35}s` }} />
            </div>
          ))}
        </div>
        <div className="absolute top-0 end-1 z-[4] text-right pointer-events-none" style={{ transform: 'scale(.62)', transformOrigin: 'top right' }}>
          <BrandBlockArt />
        </div>
        <div className="absolute bottom-1 start-2 text-white">
          <p className="font-extrabold leading-none" style={{ fontSize: 6.5 }}>صباح الفل 👋</p>
          <p className="opacity-85" style={{ fontSize: 4.7 }}>{scene.ar}</p>
        </div>
        {scene.corner && <img src={scene.corner} alt="" loading="lazy" decoding="async" className="decor-float absolute bottom-0 end-1 w-7 h-7 object-contain" />}
        {scene.corner2 && <img src={scene.corner2} alt="" loading="lazy" decoding="async" className="decor-float absolute bottom-0.5 end-7 w-5 h-5 object-contain" style={{ animationDelay: '1s' }} />}
      </div>

      {/* Falling particles — visible in both layers; softer when behind */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden" style={{ zIndex: layer === 'above' ? 4 : 2, opacity: layer === 'above' ? 1 : 0.62 }}>
        {particles.map((p, i) => (
          <img key={i} src={p.src} alt="" loading="lazy" decoding="async" className="decor-particle"
            style={{ left: `${p.left}%`, width: p.size, height: p.size, animationDuration: `${Math.max(3, p.d)}s`, animationDelay: `${p.delay}s`, ['--drift' as any]: `${p.drift}px`, ['--spin' as any]: `${i % 2 ? 240 : -240}deg` }} />
        ))}
      </div>

      {/* Extra always-visible static 3D ornaments (even under reduced motion) */}
      <div className="absolute inset-x-0 bottom-[12%] pointer-events-none flex justify-between px-1.5" style={{ zIndex: layer === 'above' ? 5 : 2, opacity: layer === 'above' ? 0.95 : 0.55 }}>
        {scene.corner3 && <img src={scene.corner3} alt="" loading="lazy" className="w-5 h-5 object-contain" />}
        {scene.corner && <img src={scene.corner} alt="" loading="lazy" className="w-6 h-6 object-contain" />}
      </div>

      {/* Bottom nav stays readable in both modes */}
      <div className="absolute inset-x-0 bottom-0 glass border-t hairline flex justify-around items-center py-1" style={{ zIndex: 5, color: 'var(--text-3)' }}>
        <Sun size={7.5} color="var(--accent)" /><CalendarDays size={7.5} />
        <span className="w-3.5 h-3.5 rounded-md grid place-items-center -mt-1.5" style={{ background: 'var(--accent)' }}><Plus size={7.5} color="var(--on-accent)" /></span>
        <CalendarRange size={7.5} /><LayoutGrid size={7.5} />
      </div>

      {active && <span className="absolute top-1 start-1 z-10 text-[6px] font-black rounded-full px-1.5 py-0.5 text-white bg-[var(--accent)]">شغالة</span>}
      {selected && <span className="absolute top-1 end-1 z-10 w-4.5 h-4.5 rounded-full grid place-items-center text-white bg-[var(--accent)]" style={{ fontSize: 9 }}>✓</span>}
    </div>
  );
}
