/* DAYFLOW — lightweight dependency-free SVG charts (accessible) */
import { useId } from 'react';

const FEED = (v: number) => Math.round(v * 10) / 10;

export function LineChart({ data, height = 120, formatY = (v: number) => String(Math.round(v)) }: {
  data: Array<{ label: string; value: number }>; height?: number; formatY?: (v: number) => string;
}) {
  const id = useId();
  const w = 320, h = height, pad = 6;
  const max = Math.max(1, ...data.map(d => d.value));
  const step = (w - pad * 2) / Math.max(1, data.length - 1);
  const pts = data.map((d, i) => ({ x: pad + i * step, y: h - pad - (d.value / max) * (h - pad * 2), ...d }));
  const path = pts.map((p, i) => `${i ? 'L' : 'M'}${FEED(p.x)},${FEED(p.y)}`).join(' ');
  const area = `${path} L${FEED(pts[pts.length - 1]?.x ?? 0)},${h - pad} L${FEED(pts[0]?.x ?? 0)},${h - pad} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" role="img" aria-label={data.map(d => `${d.label}: ${formatY(d.value)}`).join(', ')} preserveAspectRatio="none">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.35" />
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0.02" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${id})`} />
      <path d={path} fill="none" stroke="var(--accent)" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" />
      {pts.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r="2.4" fill="var(--surface)" stroke="var(--accent)" strokeWidth="1.6"><title>{`${p.label}: ${formatY(p.value)}`}</title></circle>)}
    </svg>
  );
}

export function BarChart({ data, height = 110, formatY = (v: number) => String(Math.round(v)) }: {
  data: Array<{ label: string; value: number }>; height?: number; formatY?: (v: number) => string;
}) {
  const w = 320, h = height, pad = 4, gap = 3;
  const max = Math.max(0.5, ...data.map(d => d.value));
  const bw = (w - pad * 2 - gap * (data.length - 1)) / Math.max(1, data.length);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" role="img" aria-label={data.map(d => `${d.label}: ${formatY(d.value)}`).join(', ')} preserveAspectRatio="none">
      {data.map((d, i) => {
        const bh = Math.max(2, (d.value / max) * (h - 16));
        const x = pad + i * (bw + gap), y = h - bh;
        const today = i === data.length - 1;
        return <rect key={i} x={x} y={y} width={bw} height={bh} rx="2.5" fill={today ? 'var(--accent)' : 'color-mix(in srgb, var(--accent) 55%, var(--surface-3))'}><title>{`${d.label}: ${formatY(d.value)}`}</title></rect>;
      })}
    </svg>
  );
}

export function DonutChart({ segments, size = 148, stroke = 22, centerLabel, centerValue }: {
  segments: Array<{ label: string; value: number; color: string }>; size?: number; stroke?: number;
  centerLabel?: string; centerValue?: string;
}) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, total = Math.max(1, segments.reduce((s, x) => s + x.value, 0));
  let offset = 0;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} role="img"
      aria-label={segments.map(s => `${s.label}: ${Math.round((s.value / total) * 100)}%`).join(', ')}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-2)" strokeWidth={stroke} />
      {segments.map((s, i) => {
        const frac = s.value / total;
        const dash = frac * c;
        const el = (
          <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={s.color} strokeWidth={stroke}
            strokeDasharray={`${Math.max(0, dash - 2)} ${c - dash + 2}`} strokeDashoffset={-offset}
            strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`} style={{ transition: 'stroke-dasharray .8s ease' }}>
            <title>{`${s.label}: ${Math.round(frac * 100)}%`}</title>
          </circle>
        );
        offset += dash;
        return el;
      })}
      {centerValue && <text x="50%" y="47%" textAnchor="middle" fontSize="22" fontWeight="800" fill="var(--text)" className="num">{centerValue}</text>}
      {centerLabel && <text x="50%" y="62%" textAnchor="middle" fontSize="9" fontWeight="600" fill="var(--text-2)">{centerLabel}</text>}
    </svg>
  );
}

export function Heatmap({ weeks, today }: { weeks: Array<Array<{ date: string; level: 0 | 1 | 2 | 3 | 4 }>>; today?: string }) {
  const shades = ['var(--surface-2)', 'color-mix(in srgb, var(--accent) 25%, var(--surface-2))', 'color-mix(in srgb, var(--accent) 48%, var(--surface-2))', 'color-mix(in srgb, var(--accent) 72%, var(--surface-2))', 'var(--accent)'];
  return (
    <div className="flex gap-1 overflow-x-auto no-scrollbar py-1" role="img" aria-label="Activity heatmap of the last weeks">
      {weeks.map((week, i) => (
        <div key={i} className="flex flex-col gap-1">
          {week.map((d, j) => (
            <div key={j} title={d.date} className="w-[13px] h-[13px] rounded-[4px]" style={{ background: shades[d.level], outline: d.date === today ? '2px solid var(--accent)' : 'none' }} />
          ))}
        </div>
      ))}
    </div>
  );
}
