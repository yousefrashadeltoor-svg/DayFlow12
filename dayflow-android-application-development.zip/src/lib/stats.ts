/* DAYFLOW — Analytics computed from REAL stored rows only */
import type { ActivityBlock, HabitLog, FocusSession, WaterLog } from './types';
import { todayKey, addDays } from './db';
import { durationOf } from './scheduler';

export interface DaySummary {
  plannedMin: number; doneMin: number; partialMin: number; remainingMin: number;
  completed: number; pending: number; missed: number; inProgress: number;
  completionRate: number;      // done minutes / planned minutes
  blockRate: number;           // done count / planned count
  freeMinNow: number;          // from now until end of day, minus remaining planned
  elapsedMin: number;
}
export function summarizeDay(blocks: ActivityBlock[], now = new Date()): DaySummary {
  const active = blocks.filter(b => b.status !== 'cancelled');
  const isDone = (b: ActivityBlock) => b.status === 'done';
  const isMissed = (b: ActivityBlock) => b.status === 'missed' || b.status === 'skipped';
  const plannedMin = active.reduce((s, b) => s + durationOf(b), 0);
  const doneMin = active.filter(isDone).reduce((s, b) => s + durationOf(b), 0);
  const partialMin = active.filter(b => b.status === 'partial').reduce((s, b) => s + durationOf(b) * 0.5, 0);
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const isToday = active.some(b => b.date === todayKey(now)) || active.length === 0;
  const remainingMin = plannedMin - doneMin - partialMin;
  const freeMinNow = isToday
    ? Math.max(0, (1440 - nowMin) - active.filter(b => b.endMin > nowMin && !isDone(b) && b.status !== 'in_progress').reduce((s, b) => s + (b.endMin - Math.max(b.startMin, nowMin)), 0))
    : 0;
  return {
    plannedMin, doneMin: Math.round(doneMin + partialMin), partialMin: Math.round(partialMin), remainingMin,
    completed: active.filter(isDone).length,
    pending: active.filter(b => b.status === 'planned' || b.status === 'paused').length,
    missed: active.filter(isMissed).length,
    inProgress: active.filter(b => b.status === 'in_progress').length,
    completionRate: plannedMin > 0 ? Math.min(100, Math.round(((doneMin + partialMin) / plannedMin) * 100)) : 0,
    blockRate: active.length > 0 ? Math.round((active.filter(isDone).length / active.length) * 100) : 0,
    freeMinNow,
    elapsedMin: isToday ? nowMin : 1440,
  };
}

export function lastNDays(n: number, endKey = todayKey()): string[] {
  const out: string[] = [];
  for (let i = n - 1; i >= 0; i--) out.push(addDays(endKey, -i));
  return out;
}

export function completionSeries(blocks: ActivityBlock[], n = 7) {
  return lastNDays(n).map(date => {
    const day = blocks.filter(b => b.date === date && b.status !== 'cancelled');
    const planned = day.reduce((s, b) => s + durationOf(b), 0);
    const done = day.filter(b => b.status === 'done').reduce((s, b) => s + durationOf(b), 0) +
                 day.filter(b => b.status === 'partial').reduce((s, b) => s + durationOf(b) * 0.5, 0);
    return { date, planned, done: Math.round(done), rate: planned > 0 ? Math.min(100, Math.round((done / planned) * 100)) : 0 };
  });
}

export function categoryDistribution(blocks: ActivityBlock[], n = 30) {
  const cutoff = addDays(todayKey(), -n);
  const map = new Map<string, number>();
  for (const b of blocks) {
    if (b.date < cutoff || b.status !== 'done') continue;
    map.set(b.categoryId, (map.get(b.categoryId) ?? 0) + durationOf(b));
  }
  return [...map.entries()].map(([categoryId, minutes]) => ({ categoryId, minutes })).sort((a, b) => b.minutes - a.minutes);
}

export function workloadBars(blocks: ActivityBlock[], n = 14) {
  return lastNDays(n).map(date => {
    const planned = blocks.filter(b => b.date === date && b.status !== 'cancelled').reduce((s, b) => s + durationOf(b), 0);
    return { date, hours: Math.round((planned / 60) * 10) / 10 };
  });
}

export function focusMinutes(sessions: FocusSession[], n = 7) {
  const cutoff = addDays(todayKey(), -n + 1);
  return sessions.filter(s => s.date >= cutoff).reduce((s, x) => s + x.actualMin, 0);
}

export function habitStreak(logs: HabitLog[], minCount = 1): { current: number; best: number; rate30: number } {
  const days = new Map<string, number>();
  for (const l of logs) days.set(l.date, (days.get(l.date) ?? 0) + l.count);
  const doneOn = (d: string) => (days.get(d) ?? 0) >= minCount;
  let current = 0;
  let cursor = todayKey();
  if (!doneOn(cursor)) cursor = addDays(cursor, -1); // today pending doesn't break streak
  while (doneOn(cursor)) { current++; cursor = addDays(cursor, -1); }
  let best = 0, run = 0;
  for (const d of lastNDays(400)) { if (doneOn(d)) { run++; best = Math.max(best, run); } else run = 0; }
  const last30 = lastNDays(30);
  const rate30 = Math.round((last30.filter(doneOn).length / 30) * 100);
  return { current, best, rate30 };
}

export function avgWater(logs: WaterLog[], n = 7): number {
  const days = lastNDays(n);
  const per = days.map(d => logs.filter(l => l.date === d).reduce((s, l) => s + l.amountMl, 0));
  return Math.round(per.reduce((a, b) => a + b, 0) / n);
}

export interface WeeklyReportData {
  completed: number; missed: number; completionRate: number; focusMin: number;
  waterAvgMl: number; rescheduled: number; studyMin: number; exerciseMin: number;
  upcomingDeadlines: number; mostConsistentHabit: string | null;
}
export function weeklyReport(args: {
  blocks: ActivityBlock[]; sessions: FocusSession[]; water: WaterLog[];
  scheduleChanges: number; studyMin: number; exerciseMin: number;
  upcomingDeadlines: number; habitBest: string | null;
}): WeeklyReportData {
  const series = completionSeries(args.blocks, 7);
  const planned = series.reduce((s, d) => s + d.planned, 0);
  const done = series.reduce((s, d) => s + d.done, 0);
  const weekBlocks = args.blocks.filter(b => b.date >= addDays(todayKey(), -6));
  return {
    completed: weekBlocks.filter(b => b.status === 'done').length,
    missed: weekBlocks.filter(b => b.status === 'missed' || b.status === 'skipped').length,
    completionRate: planned > 0 ? Math.round((done / planned) * 100) : 0,
    focusMin: focusMinutes(args.sessions, 7),
    waterAvgMl: avgWater(args.water, 7),
    rescheduled: args.scheduleChanges,
    studyMin: args.studyMin,
    exerciseMin: args.exerciseMin,
    upcomingDeadlines: args.upcomingDeadlines,
    mostConsistentHabit: args.habitBest,
  };
}

export const fmtMinutes = (min: number, lang: 'ar' | 'en') => {
  const h = Math.floor(min / 60), m = Math.round(min % 60);
  if (lang === 'ar') return h ? `${h} س ${m ? `و ${m} د` : ''}`.trim() : `${m} د`;
  return h ? `${h}h ${m ? `${m}m` : ''}`.trim() : `${m}m`;
};
