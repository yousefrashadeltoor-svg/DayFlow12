/* DAYFLOW — App store: settings + navigation + toasts + confirm + native drain */
import { createContext, useContext, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { db, initDb, todayKey, nowMin, type AppSettings } from './db';
import { t as translate, type Lang, type DictKey, localeOf } from './i18n';
import { platform, startWebReminderEngine, haptic } from './platform';
import type { ActivityBlock } from './types';
import { syncNative } from './sync';

export type ScreenName =
  | 'today' | 'plan' | 'focus' | 'progress' | 'more'
  | 'tasks' | 'study' | 'workouts' | 'habits' | 'goals' | 'notes'
  | 'notifications' | 'settings' | 'search' | 'calendar' | 'journal' | 'alarms' | 'prayer' | 'assistant' | 'decorGallery';
export interface Screen { name: ScreenName; params?: any }

interface Toast { id: number; msg: string; actionLabel?: string; onAction?: () => void }
interface ConfirmState { title: string; body?: string; confirmLabel?: string; danger?: boolean; resolve: (v: boolean) => void }

interface AppContextValue {
  ready: boolean;
  settings: AppSettings;
  saveSettings: (patch: Partial<AppSettings>) => Promise<void>;
  lang: Lang;
  t: (key: DictKey) => string;
  locale: string;
  hour12: boolean;
  screen: Screen;
  navigate: (name: ScreenName, params?: any) => void;
  goTab: (name: ScreenName) => void;
  back: () => void;
  tick: number;
  bump: () => void;
  toast: (msg: string, opts?: { actionLabel?: string; onAction?: () => void }) => void;
  confirm: (opts: { title: string; body?: string; confirmLabel?: string; danger?: boolean }) => Promise<boolean>;
  syncWidget: () => Promise<void>;
  applyBlockMutation: () => Promise<void>;
}

const Ctx = createContext<AppContextValue | null>(null);
export const useApp = () => { const v = useContext(Ctx); if (!v) throw new Error('useApp outside provider'); return v; };

export function AppProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [settings, setSettingsState] = useState<AppSettings | null>(null);
  const [stack, setStack] = useState<Screen[]>([{ name: 'today' }]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [confirmState, setConfirmState] = useState<ConfirmState | null>(null);
  const [tick, setTick] = useState(0);
  const toastId = useRef(0);
  const draining = useRef(false);

  const bump = useCallback(() => setTick(x => x + 1), []);

  /* ---------- theme + lang application ---------- */
  const lang: Lang = settings?.language ?? 'ar';
  useEffect(() => {
    if (!settings) return;
    const root = document.documentElement;
    const resolved = settings.theme === 'auto'
      ? (window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : settings.theme;
    root.dataset.theme = resolved;
    root.dataset.accent = settings.accent;
    root.dataset.skin = settings.skin ?? 'ios';
    root.lang = settings.language;
    root.dir = settings.language === 'ar' ? 'rtl' : 'ltr';
    root.style.fontSize = `${16 * (settings.fontScale ?? 1)}px`;
  }, [settings]);

  /* ---------- init ---------- */
  useEffect(() => {
    (async () => {
      await initDb();
      const s = await db.getSettings();
      setSettingsState(s);
      setReady(true);
      // Native init + permission-aware plugin boot (fire and forget; failures surface in Reliability Center)
      platform.initialize().catch(() => undefined);
    })();
  }, []);

  /* ---------- toast + confirm ---------- */
  const toast = useCallback((msg: string, opts?: { actionLabel?: string; onAction?: () => void }) => {
    const id = ++toastId.current;
    setToasts(ts => [...ts.slice(-2), { id, msg, actionLabel: opts?.actionLabel, onAction: opts?.onAction }]);
    setTimeout(() => setToasts(ts => ts.filter(x => x.id !== id)), 4200);
  }, []);
  const confirm = useCallback((opts: { title: string; body?: string; confirmLabel?: string; danger?: boolean }) =>
    new Promise<boolean>(resolve => setConfirmState({ ...opts, resolve })), []);

  /* ---------- navigation ---------- */
  const navigate = useCallback((name: ScreenName, params?: any) => setStack(s => [...s, { name, params }]), []);
  const goTab = useCallback((name: ScreenName) => setStack([{ name }]), []);
  const back = useCallback(() => setStack(s => (s.length > 1 ? s.slice(0, -1) : s)), []);

  /* ---------- pending native action drain (notification buttons work offline) ---------- */
  const applyPendingActions = useCallback(async () => {
    if (draining.current) return;
    draining.current = true;
    try {
      const res = await platform.drainPendingActions();
      const actions: Array<{ action: string; blockId: string; at: number }> = (res as any)?.actions ?? [];
      if (!actions.length) return;
      const blocks = await db.all<ActivityBlock>('activity_blocks');
      let applied = 0;
      for (const a of actions) {
        const action = (a.action || '').toUpperCase();
        const extra: any = (a as any).extra ?? {};
        await db.put('notifications', { id: (a as any).id ?? `${a.blockId}:${action}:${a.at}`, title: extra.title ?? a.blockId, body: action, channel: extra.kind ?? 'block', status: action === 'DONE' ? 'done' : action === 'SNOOZE' ? 'snoozed' : action.toLowerCase(), triggerAt: a.at, actionLog: [{ action, at: a.at }], refId: a.blockId });
        if (action === 'PRAYED') {
          const date = extra.date || todayKey(); const prayer = extra.prayer;
          if (prayer) { await db.put('prayer_logs', { id: `${date}:${prayer}`, date, prayer, prayedAt: a.at, source: 'notification' }); applied++; }
          continue;
        }
        if (action === 'WATER') {
          await db.put('water_logs', { id: `w-${a.at}`, date: todayKey(new Date(a.at)), timeMin: new Date(a.at).getHours() * 60 + new Date(a.at).getMinutes(), amountMl: Number(extra.ml) || 250, createdAt: a.at });
          applied++; continue;
        }
        if (action === 'ALARM_OFF') {
          const al = await db.get<any>('user_alarms', a.blockId);
          if (al) { await db.put('user_alarms', { ...al, enabled: false }); applied++; }
          continue;
        }
        if (extra.kind === 'task' && action === 'DONE') {
          const tk = await db.get<any>('tasks', a.blockId);
          if (tk) { await db.put('tasks', { ...tk, status: 'done', updatedAt: Date.now() }); applied++; }
          continue;
        }
        const b = blocks.find(x => x.id === a.blockId);
        if (!b) continue;
        if (action === 'DONE') { b.status = 'done'; b.actualEndMin = nowMin(); }
        else if (action === 'PARTIAL') { b.status = 'partial'; b.actualEndMin = nowMin(); }
        else if (action === 'SKIP') { b.status = 'skipped'; }
        else if (action === 'START_NOW') { b.status = 'in_progress'; b.actualStartMin = b.actualStartMin ?? nowMin(); }
        else continue;
        b.updatedAt = Date.now();
        await db.put('activity_blocks', b);
        applied++;
      }
      if (applied) {
        bump();
        toast(lang === 'ar' ? `اتسجّل ${applied} إجراء عملته من الإشعارات أو الويدجيت ✓` : `Applied ${applied} action(s) from notifications/widgets`);
      }
    } finally {
      draining.current = false;
    }
  }, [bump, toast, lang]);

  useEffect(() => {
    if (!ready) return;
    applyPendingActions();
    const onVis = () => { if (document.visibilityState === 'visible') applyPendingActions(); };
    document.addEventListener('visibilitychange', onVis);
    // Native resume (Android) — drain actions made while app was backgrounded
    let remove: (() => void) | undefined;
    if (Capacitor.isNativePlatform()) {
      CapApp.addListener('appStateChange', (state: { isActive: boolean }) => { if (state.isActive) applyPendingActions(); }).then((h: any) => { remove = () => h.remove(); });
      CapApp.addListener('backButton', () => back());
    }
    return () => { document.removeEventListener('visibilitychange', onVis); remove?.(); };
  }, [ready, applyPendingActions, back]);

  /* ---------- web reminder engine (honest, documented) ---------- */
  useEffect(() => {
    if (!ready) return;
    startWebReminderEngine(async () => {
      const blocks = await db.all<ActivityBlock>('activity_blocks');
      const now = new Date();
      const today = todayKey(now);
      const cur = now.getHours() * 60 + now.getMinutes();
      return blocks
        .filter(b => b.date === today && b.reminderMin >= 0 && b.status !== 'done' && b.status !== 'skipped' && b.status !== 'cancelled')
        .filter(b => Math.abs((b.startMin - b.reminderMin) - cur) <= 1)
        .map(b => ({ id: b.id + ':' + today, title: b.title, body: `${lang === 'ar' ? 'يبدأ الآن ضمن دقائق' : 'Starts in a few minutes'} · ${Math.floor(b.startMin / 60)}:${String(Math.floor(b.startMin % 60)).padStart(2, '0')}` }));
    });
  }, [ready, lang]);

  /* ---------- widget sync ---------- */
  const syncWidget = useCallback(async () => { try { await syncNative(); } catch { /* surfaced in Reliability Center */ } }, []);

  /* Any DB change (tick) → debounced native sync: alarms + notifications + prayer + widgets */
  useEffect(() => {
    if (!ready) return;
    const id = setTimeout(() => { syncNative().catch(() => undefined); }, tick === 0 ? 300 : 1200);
    return () => clearTimeout(id);
  }, [ready, tick, settings]);

  const applyBlockMutation = useCallback(async () => { bump(); await syncWidget(); }, [bump, syncWidget]);

  const saveSettings = useCallback(async (patch: Partial<AppSettings>) => {
    await db.saveSettings(patch);
    const s = await db.getSettings();
    setSettingsState(s);
  }, []);

  const value = useMemo<AppContextValue | null>(() => settings && ({
    ready, settings, saveSettings, lang, t: (k: DictKey) => translate(lang, k), locale: localeOf(lang), hour12: settings.hour12,
    screen: stack[stack.length - 1], navigate, goTab, back, tick, bump, toast, confirm, syncWidget, applyBlockMutation,
  }), [ready, settings, saveSettings, lang, stack, navigate, goTab, back, tick, bump, toast, confirm, syncWidget, applyBlockMutation]);

  if (!settings || !value) {
    return (
      <div className="h-full grid place-items-center" style={{ background: 'var(--bg, #f5f4f1)', color: 'var(--text, #1b1b1f)' }}>
        <div className="flex flex-col items-center gap-4">
          <img src="/icons/icon-512.png" alt="DAYFLOW" width="96" height="96" className="rounded-3xl shadow-lg" draggable={false} />
          <div className="flex items-center gap-2 opacity-70">
            <div className="w-4 h-4 rounded-full border-2 border-current border-t-transparent animate-spin" />
            <span className="text-sm font-bold">يُجهّز يومك… · Preparing your day…</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Ctx.Provider value={value}>
      {children}
      {/* Toasts */}
      <div className="fixed bottom-24 inset-x-0 z-[70] flex flex-col items-center gap-2 pointer-events-none px-6">
        {toasts.map(t => (
          <div key={t.id} className="anim-toast pointer-events-auto glass border hairline shadow-lg rounded-2xl px-4 py-2.5 flex items-center gap-3 max-w-sm">
            <span className="text-sm font-medium">{t.msg}</span>
            {t.actionLabel && <button className="text-sm font-bold accent" onClick={() => { t.onAction?.(); setToasts(ts => ts.filter(x => x.id !== t.id)); }}>{t.actionLabel}</button>}
          </div>
        ))}
      </div>
      {/* Confirm dialog */}
      {confirmState && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-6" role="alertdialog" aria-modal="true">
          <div className="sheet-backdrop" onClick={() => { confirmState.resolve(false); setConfirmState(null); }} />
          <div className="anim-pop card relative w-full max-w-sm p-5">
            <h3 className="font-bold text-lg">{confirmState.title}</h3>
            {confirmState.body && <p className="text-sm text-2 mt-1.5 leading-relaxed">{confirmState.body}</p>}
            <div className="flex gap-2 mt-4 justify-end">
              <button className="btn btn-ghost btn-sm" onClick={() => { confirmState.resolve(false); setConfirmState(null); }}>{lang === 'ar' ? 'إلغاء' : 'Cancel'}</button>
              <button className={`btn btn-sm ${confirmState.danger ? 'btn-danger' : 'btn-primary'}`} onClick={() => { confirmState.resolve(true); setConfirmState(null); haptic('medium'); }}>{confirmState.confirmLabel ?? (lang === 'ar' ? 'تأكيد' : 'Confirm')}</button>
            </div>
          </div>
        </div>
      )}
    </Ctx.Provider>
  );
}
