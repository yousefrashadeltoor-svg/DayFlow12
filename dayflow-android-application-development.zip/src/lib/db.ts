/* ============================================================
   DAYFLOW — Unified persistence layer
   · Android (native): real SQLite via @capacitor-community/sqlite
     JSON1 json_extract indexes for hot paths + FK-ish integrity
     enforced at the domain boundary + schema_migrations table.
   · Web / PWA preview: IndexedDB with identical semantics.
   Same async API on both platforms; business logic never branches.
   ============================================================ */

import { Capacitor } from '@capacitor/core';

export const isNative = () => Capacitor.isNativePlatform();

export const TABLES = [
  'activity_blocks', 'activity_categories', 'day_templates', 'routines',
  'schedule_changes', 'schedule_rules', 'tasks', 'projects', 'project_milestones',
  'goals', 'goal_milestones', 'study_subjects', 'study_lessons', 'exams',
  'flashcard_decks', 'flashcards', 'exercises', 'workout_plans', 'workout_logs',
  'habits', 'habit_logs', 'water_logs', 'meal_logs', 'sleep_logs',
  'focus_sessions', 'distraction_logs', 'notes', 'notifications',
  'backup_history', 'body_metrics',
  'personal_occasions', 'journal_entries', 'user_alarms', 'prayer_logs', 'ai_chats',
] as const;

export type TableName = (typeof TABLES)[number];

interface Adapter {
  init(): Promise<void>;
  all<T = any>(table: string): Promise<T[]>;
  get<T = any>(table: string, id: string): Promise<T | undefined>;
  put(table: string, row: any): Promise<void>;
  bulkPut(table: string, rows: any[]): Promise<void>;
  del(table: string, id: string): Promise<void>;
  clear(table: string): Promise<void>;
  settingGet(key: string): Promise<any>;
  settingSet(key: string, value: any): Promise<void>;
  migrationVersion(): Promise<number>;
  setMigrationVersion(v: number): Promise<void>;
}

const uid = () => (crypto?.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36));
export const newId = uid;

/* ---------------- IndexedDB adapter ---------------- */
const IDB_NAME = 'dayflow';
const SETTINGS_STORE = 'settings';
const MIGRATION_STORE = 'schema_migrations';

class IdbAdapter implements Adapter {
  private db: IDBDatabase | null = null;

  async init() {
    this.db = await new Promise<IDBDatabase>((resolve, reject) => {
      const req = indexedDB.open(IDB_NAME, 3); // v3 adds ai_chats; existing stores & data are preserved
      req.onupgradeneeded = () => {
        const db = req.result;
        for (const t of TABLES) {
          if (!db.objectStoreNames.contains(t)) db.createObjectStore(t, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(SETTINGS_STORE)) db.createObjectStore(SETTINGS_STORE, { keyPath: 'key' });
        if (!db.objectStoreNames.contains(MIGRATION_STORE)) db.createObjectStore(MIGRATION_STORE, { keyPath: 'version' });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async all<T>(table: string): Promise<T[]> {
    return new Promise((resolve, reject) => {
      const r = this.db!.transaction(table, 'readonly').objectStore(table).getAll();
      r.onsuccess = () => resolve(r.result as T[]);
      r.onerror = () => reject(r.error);
    });
  }
  async get<T>(table: string, id: string): Promise<T | undefined> {
    return new Promise((resolve, reject) => {
      const r = this.db!.transaction(table, 'readonly').objectStore(table).get(id);
      r.onsuccess = () => resolve(r.result as T | undefined);
      r.onerror = () => reject(r.error);
    });
  }
  async put(table: string, row: any) {
    return new Promise<void>((resolve, reject) => {
      const r = this.db!.transaction(table, 'readwrite').objectStore(table).put(row);
      r.onsuccess = () => resolve(); r.onerror = () => reject(r.error);
    });
  }
  async bulkPut(table: string, rows: any[]) {
    return new Promise<void>((resolve, reject) => {
      const tx = this.db!.transaction(table, 'readwrite');
      const s = tx.objectStore(table);
      for (const r of rows) s.put(r);
      tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error);
    });
  }
  async del(table: string, id: string) {
    return new Promise<void>((resolve, reject) => {
      const r = this.db!.transaction(table, 'readwrite').objectStore(table).delete(id);
      r.onsuccess = () => resolve(); r.onerror = () => reject(r.error);
    });
  }
  async clear(table: string) {
    return new Promise<void>((resolve, reject) => {
      const r = this.db!.transaction(table, 'readwrite').objectStore(table).clear();
      r.onsuccess = () => resolve(); r.onerror = () => reject(r.error);
    });
  }
  async settingGet(key: string) {
    return new Promise<any>((resolve, reject) => {
      const r = this.db!.transaction(SETTINGS_STORE, 'readonly').objectStore(SETTINGS_STORE).get(key);
      r.onsuccess = () => resolve(r.result?.value); r.onerror = () => reject(r.error);
    });
  }
  async settingSet(key: string, value: any) {
    return new Promise<void>((resolve, reject) => {
      const r = this.db!.transaction(SETTINGS_STORE, 'readwrite').objectStore(SETTINGS_STORE).put({ key, value });
      r.onsuccess = () => resolve(); r.onerror = () => reject(r.error);
    });
  }
  async migrationVersion() {
    return new Promise<number>((resolve, reject) => {
      const r = this.db!.transaction(MIGRATION_STORE, 'readonly').objectStore(MIGRATION_STORE).getAllKeys();
      r.onsuccess = () => resolve(r.result.length ? Math.max(...(r.result as number[])) : 0);
      r.onerror = () => reject(r.error);
    });
  }
  async setMigrationVersion(v: number) {
    return new Promise<void>((resolve, reject) => {
      const r = this.db!.transaction(MIGRATION_STORE, 'readwrite').objectStore(MIGRATION_STORE).put({ version: v, applied_at: Date.now() });
      r.onsuccess = () => resolve(); r.onerror = () => reject(r.error);
    });
  }
}

/* ---------------- Native SQLite adapter ---------------- */
class SqliteAdapter implements Adapter {
  private con: any = null;

  async init() {
    const { CapacitorSQLite, SQLiteConnection } = await import('@capacitor-community/sqlite');
    const sqlite = new SQLiteConnection(CapacitorSQLite);
    const isConn = (await sqlite.isConnection('dayflow', false)).result;
    this.con = isConn ? await sqlite.retrieveConnection('dayflow', false)
      : await sqlite.createConnection('dayflow', false, 'no-encryption', 1, false);
    await this.con.open();
    // Relational envelope + JSON1 indexes for hot query paths.
    const ddl: string[] = [];
    for (const t of TABLES) {
      ddl.push(`CREATE TABLE IF NOT EXISTS ${t} (id TEXT PRIMARY KEY NOT NULL, updated_at INTEGER NOT NULL, data TEXT NOT NULL)`);
    }
    ddl.push(`CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)`);
    ddl.push(`CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY NOT NULL, applied_at INTEGER NOT NULL)`);
    // Hot-path indexes via SQLite JSON1 — real indexed queries, not full scans.
    const idx: Array<[string, string]> = [
      ['idx_blocks_date', `CREATE INDEX IF NOT EXISTS idx_blocks_date ON activity_blocks (json_extract(data,'$.date'))`],
      ['idx_blocks_status', `CREATE INDEX IF NOT EXISTS idx_blocks_status ON activity_blocks (json_extract(data,'$.status'))`],
      ['idx_blocks_updated', `CREATE INDEX IF NOT EXISTS idx_blocks_updated ON activity_blocks (updated_at)`],
      ['idx_tasks_due', `CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks (json_extract(data,'$.dueDate'))`],
      ['idx_tasks_status', `CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks (json_extract(data,'$.status'))`],
      ['idx_habitlog_habit_date', `CREATE INDEX IF NOT EXISTS idx_habitlog_habit_date ON habit_logs (json_extract(data,'$.habitId'), json_extract(data,'$.date'))`],
      ['idx_habitlog_date', `CREATE INDEX IF NOT EXISTS idx_habitlog_date ON habit_logs (json_extract(data,'$.date'))`],
      ['idx_waterlog_date', `CREATE INDEX IF NOT EXISTS idx_waterlog_date ON water_logs (json_extract(data,'$.date'))`],
      ['idx_meallog_date', `CREATE INDEX IF NOT EXISTS idx_meallog_date ON meal_logs (json_extract(data,'$.date'))`],
      ['idx_sleeplog_date', `CREATE INDEX IF NOT EXISTS idx_sleeplog_date ON sleep_logs (json_extract(data,'$.date'))`],
      ['idx_focus_date', `CREATE INDEX IF NOT EXISTS idx_focus_date ON focus_sessions (json_extract(data,'$.date'))`],
      ['idx_distraction_date', `CREATE INDEX IF NOT EXISTS idx_distraction_date ON distraction_logs (json_extract(data,'$.date'))`],
      ['idx_workoutlog_date', `CREATE INDEX IF NOT EXISTS idx_workoutlog_date ON workout_logs (json_extract(data,'$.date'))`],
      ['idx_notes_updated', `CREATE INDEX IF NOT EXISTS idx_notes_updated ON notes (updated_at)`],
    ];
    for (const [, stmt] of idx) ddl.push(stmt);
    await this.con.execute(ddl.join(';'));
  }
  async all<T>(table: string): Promise<T[]> {
    const res = await this.con.query(`SELECT data FROM ${table}`);
    return (res.values ?? []).map((r: any) => JSON.parse(r.data)) as T[];
  }
  async get<T>(table: string, id: string): Promise<T | undefined> {
    const res = await this.con.query(`SELECT data FROM ${table} WHERE id = ?`, [id]);
    const row = res.values?.[0];
    return row ? (JSON.parse(row.data) as T) : undefined;
  }
  async put(table: string, row: any) {
    const now = Date.now();
    await this.con.run(`INSERT OR REPLACE INTO ${table} (id, updated_at, data) VALUES (?,?,?)`,
      [row.id, row.updatedAt ?? row.updated_at ?? now, JSON.stringify(row)]);
  }
  async bulkPut(table: string, rows: any[]) {
    if (!rows.length) return;
    const now = Date.now();
    await this.con.execute('BEGIN');
    try {
      for (const row of rows) {
        await this.con.run(`INSERT OR REPLACE INTO ${table} (id, updated_at, data) VALUES (?,?,?)`,
          [row.id, row.updatedAt ?? now, JSON.stringify(row)]);
      }
      await this.con.execute('COMMIT');
    } catch (e) { await this.con.execute('ROLLBACK'); throw e; }
  }
  async del(table: string, id: string) {
    await this.con.run(`DELETE FROM ${table} WHERE id = ?`, [id]);
  }
  async clear(table: string) {
    await this.con.execute(`DELETE FROM ${table}`);
  }
  async settingGet(key: string) {
    const res = await this.con.query(`SELECT value FROM settings WHERE key = ?`, [key]);
    const row = res.values?.[0];
    return row ? JSON.parse(row.value) : undefined;
  }
  async settingSet(key: string, value: any) {
    await this.con.run(`INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)`, [key, JSON.stringify(value)]);
  }
  async migrationVersion() {
    try {
      const res = await this.con.query(`SELECT COALESCE(MAX(version), 0) AS v FROM schema_migrations`);
      return Number(res.values?.[0]?.v ?? 0);
    } catch { return 0; }
  }
  async setMigrationVersion(v: number) {
    await this.con.run(`INSERT OR REPLACE INTO schema_migrations (version, applied_at) VALUES (?,?)`, [v, Date.now()]);
  }
}

/* ---------------- Migrations + seeds ---------------- */
/* In-memory last-resort adapter: app must NEVER white-screen (private mode, disabled IDB, quota). */
class MemoryAdapter implements Adapter {
  private tables = new Map<string, Map<string, any>>();
  private settings = new Map<string, any>();
  private version = 0;
  async init() {}
  private t(n: string) { if (!this.tables.has(n)) this.tables.set(n, new Map()); return this.tables.get(n)!; }
  async all<T>(n: string): Promise<T[]> { return [...this.t(n).values()] as T[]; }
  async get<T>(n: string, id: string) { return this.t(n).get(id) as T | undefined; }
  async put(n: string, row: any) { this.t(n).set(row.id, row); }
  async bulkPut(n: string, rows: any[]) { rows.forEach(r => this.t(n).set(r.id, r)); }
  async del(n: string, id: string) { this.t(n).delete(id); }
  async clear(n: string) { this.t(n).clear(); }
  async settingGet(k: string) { return this.settings.get(k); }
  async settingSet(k: string, v: any) { this.settings.set(k, v); }
  async migrationVersion() { return this.version; }
  async setMigrationVersion(v: number) { this.version = v; }
}

let adapter: Adapter | null = null;

export const DEFAULT_SETTINGS = {
  language: 'ar' as 'ar' | 'en',
  theme: 'auto' as 'light' | 'dark' | 'auto',
  accent: 'indigo' as 'indigo' | 'teal' | 'rose' | 'amber' | 'emerald' | 'violet',
  weekStart: 6 as number,          // Saturday — common in Arab world; configurable
  hour12: false,
  fontScale: 1,
  timelineDensity: 'comfortable' as 'comfortable' | 'compact',
  firstDayLayout: 'overview' as 'overview' | 'timeline',
  defaultBlockDuration: 45,
  defaultBufferMin: 5,
  prepBufferMin: 10,
  bedtimeMin: 23 * 60,
  wakeMin: 6 * 60 + 30,
  preSleepReminderMin: 45,
  waterTargetMl: 2500,
  waterCupMl: 250,
  waterReminderMin: 90,
  quietHoursStartMin: 23 * 60,
  quietHoursEndMin: 6 * 60 + 30,
  quietHoursEnabled: true,
  criticalExceptions: true,
  notificationsEnabled: true,
  ttsFallback: true,
  snoozeDefaultMin: 10,
  soundRepeatCount: 2,
  vibration: true,
  haptics: true,
  defaultSound: 'default',
  flashcardIntervals: [1, 3, 7, 21],
  preferredHours: { start: 9 * 60, end: 12 * 60 },
  demoSeeded: false,
  version: 2,
  skin: 'gemini' as 'ios' | 'gemini' | 'oneui' | 'aurora' | 'frost' | 'midnight' | 'paper' | 'sand' | 'mint' | 'ocean' | 'rose' | 'sunset',
  onboarded: false,
  userName: '',
  governorate: 'cairo',
  prayerEnabled: true,
  prayerOn: { fajr: true, sunrise: false, dhuhr: true, asr: true, maghrib: true, isha: true } as Record<string, boolean>,
  prayerPreMin: 10,
  prayerAdjust: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 } as Record<string, number>,
  prayerSound: 'alarm' as 'alarm' | 'default' | 'custom',
  prayerToneUri: '',
  prayerToneName: '',
  prayerSpeak: false,
  hijriOffset: 0,
  decorations: true,
  particles: true,
  decorOverride: 'auto' as string,
  decorSpeed: 'normal' as 'slow' | 'normal' | 'fast',
  decorDensity: 'normal' as 'light' | 'normal' | 'dense',
  decorOpacity: 0.9,
  decorLayer: 'below' as 'below' | 'above',
  decorMix: [] as string[],
  decorFixed: true,   // always-visible static ornaments (works even with reduced motion)
  headerPhotos: true,
  occasionNotifyHour: 9,
  endOfBlockPrompt: true,
  waterReminders: false,
};
export type AppSettings = typeof DEFAULT_SETTINGS;

async function seedStructuralData(a: Adapter) {
  // Built-in categories (not user records)
  const cats = await a.all('activity_categories');
  if (!cats.length) {
    const c = (id: string, nameAr: string, nameEn: string, icon: string, color: string) => ({ id, nameAr, nameEn, icon, color, builtin: true });
    await a.bulkPut('activity_categories', [
      c('study', 'مذاكرة', 'Study', 'book-open', 'var(--cat-study)'),
      c('work', 'عمل', 'Work', 'briefcase', 'var(--cat-work)'),
      c('exercise', 'رياضة', 'Exercise', 'dumbbell', 'var(--cat-exercise)'),
      c('rest', 'راحة', 'Rest', 'coffee', 'var(--cat-rest)'),
      c('meal', 'وجبات', 'Meals', 'utensils', 'var(--cat-meal)'),
      c('sleep', 'نوم', 'Sleep', 'bed-double', 'var(--cat-sleep)'),
      c('water', 'ماء', 'Water', 'droplets', 'var(--cat-water)'),
      c('prayer', 'صلاة', 'Prayer', 'moon-star', 'var(--cat-prayer)'),
      c('personal', 'شخصي', 'Personal', 'sparkles', 'var(--cat-personal)'),
      c('social', 'اجتماعي', 'Social', 'users', 'var(--cat-social)'),
      c('health', 'صحة', 'Health', 'heart-pulse', 'var(--cat-health)'),
      c('other', 'أخرى', 'Other', 'shapes', 'var(--cat-other)'),
    ]);
  }
  // Built-in day templates
  const tpls = await a.all('day_templates');
  if (!tpls.length) {
    const t = (id: string, nameAr: string, nameEn: string, icon: string, items: any[]): any =>
      ({ id, nameAr, nameEn, icon, items, createdAt: Date.now() });
    const it = (title: string, categoryId: string, startMin: number, endMin: number, fixed = false) => ({ title, categoryId, startMin, endMin, fixed });
    await a.bulkPut('day_templates', [
      t('tpl_normal', 'يوم عادي', 'Normal day', 'sun', [it('الاستيقاظ والروتين', 'personal', 390, 450, true), it('العمل / المذاكرة الأساسي', 'work', 540, 720), it('غداء', 'meal', 780, 840, true), it('العمل / المذاكرة', 'work', 840, 1020), it('رياضة', 'exercise', 1080, 1140), it('عشاء عائلي', 'meal', 1140, 1200, true), it('روتين مسائي وقراءة', 'rest', 1290, 1380)]),
      t('tpl_school', 'يوم دراسي', 'School day', 'graduation-cap', [it('الاستيقاظ والفطور', 'meal', 360, 420, true), it('المدرسة / الجامعة', 'study', 450, 780, true), it('غداء', 'meal', 780, 840, true), it('مذاكرة يومية', 'study', 900, 1030), it('واجب ومراجعة', 'study', 1060, 1140)]),
      t('tpl_exam', 'استعداد للاختبار', 'Exam preparation', 'notebook-pen', [it('الاستيقاظ المبكر', 'personal', 360, 420, true), it('جلسة مذاكرة عميقة ١', 'study', 450, 660), it('راحة', 'rest', 660, 720), it('جلسة مذاكرة عميقة ٢', 'study', 720, 900), it('غداء', 'meal', 900, 960, true), it('حل نماذج واختبارات', 'study', 960, 1110), it('ملخص مراجعة سريعة', 'study', 1140, 1260), it('نوم وتجهيز', 'sleep', 1350, 1440, true)]),
      t('tpl_work', 'يوم عمل', 'Work day', 'briefcase', [it('روتين صباحي', 'personal', 390, 450, true), it('مراجعة خطة اليوم', 'work', 480, 510), it('عمل مركّز', 'work', 510, 750), it('غداء', 'meal', 750, 810, true), it('اجتماعات ومهام', 'work', 810, 1010), it('عمل مركّز', 'work', 1010, 1110)]),
      t('tpl_weekend', 'عطلة نهاية الأسبوع', 'Weekend', 'palmtree', [it('نوم هادئ', 'sleep', 420, 540, true), it('فطور عائلي', 'meal', 570, 660, true), it('رياضة / مشي', 'exercise', 690, 780), it('وقت حر وقراءة', 'personal', 840, 1020), it('زيارات اجتماعية', 'social', 1080, 1260)]),
      t('tpl_vacation', 'إجازة', 'Vacation', 'plane', [it('نوم', 'sleep', 480, 660, true), it('وجبة هادئة', 'meal', 700, 800, true), it('أنشطة واستكشاف', 'personal', 840, 1200)]),
      t('tpl_light', 'يوم خفيف', 'Light day', 'feather', [it('استيقاظ هادئ', 'personal', 450, 540, true), it('مراجعة خفيفة', 'rest', 600, 720), it('مشي وطبيعة', 'exercise', 780, 900), it('قراءة', 'rest', 1020, 1140)]),
      t('tpl_recovery', 'يوم تعافٍ', 'Recovery day', 'heart-pulse', [it('نوم كافٍ', 'sleep', 420, 600, true), it('فطور صحي', 'meal', 630, 720, true), it('تمددات خفيفة وتنفس', 'exercise', 780, 840), it('راحة واسترخاء', 'rest', 900, 1140)]),
    ]);
  }
  // Built-in exercises
  const ex = await a.all('exercises');
  if (!ex.length) {
    const e = (id: string, nameAr: string, nameEn: string, muscleGroup: string, equipment: string, instructions: string) =>
      ({ id, nameAr, nameEn, muscleGroup, equipment, instructions, builtin: true });
    await a.bulkPut('exercises', [
      e('ex_pushup', 'ضغط', 'Push-up', 'صدر', 'بدون معدات', 'الجسم مستقيم، انزل حتى يقترب الصدر من الأرض ثم ادفع.'),
      e('ex_squat', 'قرفصاء', 'Squat', 'أرجل', 'بدون معدات', 'الظهر مستقيم، انزل حتى موازاة الفخذ للأرض.'),
      e('ex_plank', 'بلانك', 'Plank', 'كور', 'بدون معدات', 'شد الجسم بالكامل وثبت من 30 لـ 60 ثانية.'),
      e('ex_lunge', 'لانج', 'Lunge', 'أرجل', 'بدون معدات', 'خطوة للأمام، انزل وادفع للأعلى بالتبادل.'),
      e('ex_burpee', 'بيربي', 'Burpee', 'كامل الجسم', 'بدون معدات', 'قرفصاء ثم قفز، ثم ضغط، ثم اقفز للأعلى.'),
      e('ex_row', 'تجديف', 'Dumbbell Row', 'ظهر', 'دمبل', 'انحنِ للأمام، شد الأوزان نحو الخصر.'),
      e('ex_press', 'ضغط كتف', 'Shoulder Press', 'كتف', 'دمبل', 'ارفع الأوزان للأعلى فوق الرأس ببطء.'),
      e('ex_curl', 'تبادل باي', 'Bicep Curl', 'ذراع', 'دمبل', 'اثنِ المرفق وارفع الأوزان للأعلى.'),
      e('ex_crunch', 'كرنش', 'Crunch', 'كور', 'بدون معدات', 'استلقِ، ارفع الكتف عن الأرض مع شد البطن.'),
      e('ex_walk', 'مشي سريع', 'Brisk Walk', 'كارديو', 'بدون معدات', '30 دقيقة مشي بوتيرة متوسطة إلى سريعة.'),
      e('ex_run', 'جري', 'Running', 'كارديو', 'بدون معدات', 'جري 20-30 دقيقة بوتيرة مريحة.'),
      e('ex_stretch', 'إطالات', 'Full-body Stretch', 'مرونة', 'حصيرة', 'إطالة كل عضلة 20-30 ثانية دون ارتداد.'),
    ]);
  }
  // Default rules
  const rules = await a.all('schedule_rules');
  if (!rules.length) {
    const r = (id: string, ruleType: string, enabled: boolean, priority: number, params: Record<string, any>, nameAr: string, nameEn: string, descriptionAr: string, descriptionEn: string): any =>
      ({ id, ruleType, enabled, priority, params, nameAr, nameEn, descriptionAr, descriptionEn });
    await a.bulkPut('schedule_rules', [
      r('rule_recovery', 'recovery_after_intense', true, 1, { afterMinutes: 90, breakMinutes: 10 }, 'راحة بعد المذاكرة المكثفة', 'Recovery after intense study', 'أضف فترة راحة 10 دقائق بعد كل 90 دقيقة من المذاكرة المكثفة', 'Insert a 10-minute recovery break after every 90 minutes of intense study'),
      r('rule_prep_workout', 'prep_before_workout', true, 2, { prepMinutes: 10 }, 'تحضير قبل التمرين', 'Preparation before workouts', 'أضف 10 دقائق تحضير قبل كل جلسة تمارين', 'Add 10 preparation minutes before each workout session'),
      r('rule_no_sleep_notif', 'quiet_during_sleep', true, 1, { }, 'صمت أثناء النوم', 'No interruptions during sleep', 'لا تصل إشعارات مرنة أثناء نافذة النوم المحددة', 'Never deliver flexible notifications inside your sleep window'),
      r('rule_hard_hours', 'deep_work_preference', true, 3, { }, 'المهام الصعبة في أوقات نشاطك', 'Difficult tasks in peak hours', 'جدول المهام عالية الصعوبة داخل أوقات نشاطك المفضلة', 'Place high-difficulty tasks inside your preferred energy hours'),
      r('rule_min_rest', 'minimum_rest', true, 2, { minBreakMin: 15, everyMinutes: 120 }, 'حد أدنى من الراحة', 'Minimum rest period', 'يجب ألا تتجاوز فترة العمل المتواصل 120 دقيقة دون راحة 15 دقيقة', 'Never work more than 120 continuous minutes without a 15-minute break'),
      r('rule_repeat_subject', 'max_repeat_subject', true, 4, { maxPerDay: 3 }, 'تنويع المواد', 'Limit same-subject repetition', 'لا تكرر مادة واحدة أكثر من 3 مرات في اليوم', 'Avoid scheduling the same subject more than 3 times per day'),
      r('rule_deadline_first', 'deadline_priority', true, 1, { daysAhead: 2 }, 'المواعيد النهائية أولاً', 'Deadlines come first', 'المهام ذات المواعيد النهائية خلال 48 ساعة لها أولوية الجدولة', 'Tasks due within 48 hours get scheduling priority'),
      r('rule_buffer', 'transition_buffer', true, 2, { bufferMin: 5 }, 'فاصل انتقالي', 'Transition buffers', 'حافظ على فاصل 5 دقائق بين الكتل المتتالية', 'Keep a 5-minute transition buffer between consecutive blocks'),
    ]);
  }
}

const MIGRATIONS: Array<{ version: number; name: string; up: (a: Adapter) => Promise<void> }> = [
  { version: 1, name: 'initial-schema', up: async (a) => { await seedStructuralData(a); } },
  // v2: new tables are created by the adapter DDL / IDB upgrade; nothing to rewrite — user rows untouched.
  { version: 2, name: 'calendar-journal-alarms-prayer', up: async () => { /* additive only */ } },
];

export let persistenceBackend: 'sqlite' | 'indexeddb' | 'memory' = 'indexeddb';
export async function initDb() {
  if (!adapter) {
    try {
      adapter = isNative() ? new SqliteAdapter() : new IdbAdapter();
      await adapter.init();
      persistenceBackend = isNative() ? 'sqlite' : 'indexeddb';
    } catch (e) {
      console.error('Persistence unavailable — falling back to memory (data will not persist)', e);
      adapter = new MemoryAdapter();
      await adapter.init();
      persistenceBackend = 'memory';
    }
  }
  const current = await adapter.migrationVersion();
  for (const m of MIGRATIONS) {
    if (m.version > current) {
      await m.up(adapter);
      await adapter.setMigrationVersion(m.version);
    }
  }
  return adapter;
}
const A = () => { if (!adapter) throw new Error('DB not initialized — call initDb() first'); return adapter; };

/* ---------------- Public API ---------------- */
export const db = {
  all: <T = any>(t: TableName | string) => A().all<T>(t),
  get: <T = any>(t: TableName | string, id: string) => A().get<T>(t, id),
  put: (t: TableName | string, row: any) => A().put(t, row),
  bulkPut: (t: TableName | string, rows: any[]) => A().bulkPut(t, rows),
  del: (t: TableName | string, id: string) => A().del(t, id),
  clear: (t: TableName | string) => A().clear(t),
  settingGet: <T = any>(key: string) => A().settingGet(key) as Promise<T | undefined>,
  settingSet: (key: string, value: any) => A().settingSet(key, value),
  async getSettings(): Promise<AppSettings> {
    const stored = (await A().settingGet('app')) ?? {};
    return { ...DEFAULT_SETTINGS, ...stored };
  },
  async saveSettings(patch: Partial<AppSettings>) {
    const cur = await db.getSettings();
    await A().settingSet('app', { ...cur, ...patch });
  },
  async storageInfo(): Promise<{ tables: number; rows: number; backend: string }> {
    let rows = 0;
    for (const t of TABLES) rows += (await A().all(t)).length;
    return { tables: TABLES.length, rows, backend: isNative() ? 'SQLite (Android native)' : 'IndexedDB (browser)' };
  },
  async wipeAll() {
    for (const t of TABLES) await A().clear(t);
    await A().settingSet('app', {}); // settings back to defaults on next load
    const a = A();
    await a.setMigrationVersion(0);
    // re-run structural seed
    for (const mig of MIGRATIONS) { await mig.up(a); await a.setMigrationVersion(mig.version); }
  },
};

/* ---------------- Convenience queries ---------------- */
export function todayKey(d = new Date()): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
export function addDays(key: string, delta: number): string {
  const d = new Date(key + 'T12:00:00'); // noon avoids DST edge shifts
  d.setDate(d.getDate() + delta);
  return todayKey(d);
}
export const minToTime = (min: number, hour12 = false) => {
  min = ((min % 1440) + 1440) % 1440;
  let h = Math.floor(min / 60), m = min % 60;
  if (hour12) { const ap = h >= 12 ? 'م' : 'ص'; h = h % 12 || 12; return `${h}:${String(m).padStart(2, '0')} ${ap}`; }
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
};
export const nowMin = () => { const d = new Date(); return d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60; };
