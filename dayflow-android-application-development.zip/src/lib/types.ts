/* DAYFLOW — domain model */
export type BlockStatus = 'planned' | 'in_progress' | 'paused' | 'done' | 'partial' | 'skipped' | 'missed' | 'cancelled';

export interface ActivityBlock {
  id: string;
  title: string;
  description?: string;
  categoryId: string;
  date: string;            // YYYY-MM-DD (local)
  startMin: number;        // minutes from midnight
  endMin: number;
  fixed: boolean;
  priority: 1 | 2 | 3 | 4; // 1 highest
  energy: 'low' | 'medium' | 'high';
  difficulty: 1 | 2 | 3 | 4 | 5;
  status: BlockStatus;
  recurrence: 'none' | 'daily' | 'weekdays' | 'weekly' | 'custom';
  reminderMin: number;     // minutes before start; -1 = none
  sound: string;           // 'default' | 'none' | custom uri/id
  repeatCount: number;
  isCritical: boolean;
  splitAllowed: boolean;
  earliestStartMin?: number | null;
  latestEndMin?: number | null;
  linkedTaskId?: string | null;
  linkedGoalId?: string | null;
  linkedSubjectId?: string | null;
  tags: string[];
  notes?: string;
  actualStartMin?: number | null;
  actualEndMin?: number | null;
  createdAt: number;
  updatedAt: number;
}

export interface ActivityCategory {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;   // lucide icon key
  color: string;  // css color or var
  builtin: boolean;
}

export interface DayTemplate {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  items: Array<{ title: string; categoryId: string; startMin: number; endMin: number; fixed: boolean }>;
  createdAt: number;
}

export interface Routine {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  timeOfDay: 'morning' | 'evening' | 'pre_study' | 'after_work' | 'workout' | 'pre_sleep';
  steps: Array<{ id: string; title: string; durationMin: number; done: boolean }>;
}

export interface TaskItem {
  id: string;
  title: string;
  description?: string;
  dueDate: string | null;
  startDate?: string | null;
  priority: 1 | 2 | 3 | 4;
  status: 'inbox' | 'todo' | 'done' | 'someday' | 'cancelled';
  estimatedMin: number;
  trackedMin: number;
  categoryId: string;
  tags: string[];
  checklist: Array<{ id: string; text: string; done: boolean }>;
  starred: boolean;
  projectId: string | null;
  goalId: string | null;
  recurrence: 'none' | 'daily' | 'weekly' | 'monthly';
  reminderAt: number | null;
  notes?: string;
  createdAt: number;
  updatedAt: number;
}

export interface Project {
  id: string;
  title: string;
  description?: string;
  objective?: string;
  deadline: string | null;
  color: string;
  icon: string;
  status: 'active' | 'done' | 'archived';
  createdAt: number;
  notes?: string;
}

export interface ProjectMilestone { id: string; projectId: string; title: string; done: boolean; dueDate: string | null; order: number; }

export interface Goal {
  id: string;
  title: string;
  description?: string;
  horizon: 'short' | 'monthly' | 'long';
  targetDate: string | null;
  progress: number; // 0-100 (also milestone-derived)
  color: string;
  icon: string;
  status: 'active' | 'done' | 'paused';
  createdAt: number;
}
export interface GoalMilestone { id: string; goalId: string; title: string; done: boolean; }

export interface StudySubject {
  id: string; title: string; color: string; icon: string;
  estimatedHours: number; difficulty: 1|2|3|4|5; priority: 1|2|3|4;
  dueDate: string | null; notes?: string; createdAt: number;
}
export interface StudyLesson {
  id: string; subjectId: string; title: string; unit?: string;
  estimatedMin: number; actualMin: number; status: 'todo' | 'done';
  order: number; difficulty: 1|2|3|4|5;
}
export interface Exam {
  id: string; title: string; subjectId: string | null;
  date: string; timeMin: number; location?: string; topics: string[];
  createdAt: number;
}
export interface FlashcardDeck { id: string; name: string; subjectId: string | null; color: string; createdAt: number; }
export interface Flashcard {
  id: string; deckId: string; front: string; back: string;
  intervalDays: number; ease: number; dueDate: string; reps: number; createdAt: number;
}

export interface Exercise {
  id: string; nameAr: string; nameEn: string; muscleGroup: string;
  equipment: string; instructions?: string; builtin: boolean;
}
export interface WorkoutPlan {
  id: string; weekday: number; // 0=Sunday
  sessionName: string;
  exercises: Array<{ exerciseId: string; sets: number; reps: number; restSec: number; loadKg?: number | null }>;
  notes?: string; updatedAt: number;
}
export interface WorkoutLog {
  id: string; date: string; sessionName: string; exerciseCount: number;
  totalSets: number; durationMin: number; notes?: string; createdAt: number;
}

export interface Habit {
  id: string; name: string; icon: string; color: string;
  frequency: 'daily' | 'weekly' | 'custom';
  targetPerWeek: number; targetCount: number; unit: string;
  reminderMin: number | null; category: string; negative: boolean; createdAt: number;
}
export interface HabitLog { id: string; habitId: string; date: string; count: number; note?: string; }

export interface WaterLog { id: string; date: string; timeMin: number; amountMl: number; createdAt: number; }
export interface MealLog { id: string; date: string; timeMin: number; mealName: string; calories?: number | null; notes?: string; createdAt: number; }
export interface SleepLog { id: string; date: string; bedtimeMin: number; wakeMin: number; actualSleepMin: number | null; quality: 1|2|3|4|5 | null; createdAt: number; }

export interface FocusSession {
  id: string; date: string; startedAt: number; endedAt: number | null;
  plannedMin: number; actualMin: number; mode: 'pomodoro' | 'extended' | 'deep' | 'open' | 'countdown';
  completed: boolean; taskTitle?: string; notes?: string;
}
export interface DistractionLog {
  id: string; date: string; timeMin: number; reason: string; minutesLost: number; note?: string; createdAt: number;
}

export interface NoteItem {
  id: string; title: string; body: string; tags: string[];
  favorite: boolean; kind: 'note' | 'study' | 'meeting' | 'journal' | 'checklist';
  checklist: Array<{ id: string; text: string; done: boolean }>;
  createdAt: number; updatedAt: number;
}

export interface ReminderRow {
  id: string; refId: string; refType: 'block' | 'task' | 'habit' | 'water' | 'meal' | 'sleep' | 'custom';
  title: string; triggerAt: number; status: 'scheduled' | 'sent' | 'done' | 'snoozed' | 'dismissed' | 'missed';
  createdAt: number; updatedAt: number;
}

export interface ScheduleChange {
  id: string; blockId: string; date: string;
  reason: string; original: { startMin: number; endMin: number };
  proposed: { startMin: number; endMin: number };
  applied: boolean; createdAt: number;
}

export interface ScheduleRule {
  id: string; nameAr: string; nameEn: string; descriptionAr: string; descriptionEn: string;
  ruleType: string; enabled: boolean; priority: number; params: Record<string, number | string | boolean>;
}

export interface AppNotification {
  id: string; title: string; body: string; channel: string; status: 'scheduled' | 'done' | 'snoozed' | 'dismissed' | 'missed';
  triggerAt: number; actionLog: Array<{ action: string; at: number }>; refId?: string | null;
}

export interface BackupRecord { id: string; createdAt: number; tableCounts: Record<string, number>; sizeBytes: number; encrypted: boolean; kind: 'json' | 'csv' | 'xlsx'; }
export interface BodyMetric { id: string; date: string; kind: string; value: number; unit: string; createdAt: number; }
