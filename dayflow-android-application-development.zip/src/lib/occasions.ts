/* DAYFLOW — Egyptian & Islamic occasions engine (100% offline, dynamically computed for every year)
   · Hijri via Intl islamic-umalqura (+ user moon-sighting offset ±2 days)
   · Coptic (Orthodox) Easter via Julian computus + Sham El-Nessim (next Monday)
   · Hebrew dates via Intl hebrew (informational only; explicitly flagged, NEVER notified or in widgets)
   · Every single occasion maps to its own curated real offline photograph and 3D Fluent badge. */
import { todayKey } from './db';

export type OccasionKind = 'islamic' | 'national' | 'egyptian' | 'christian' | 'jewish' | 'global' | 'personal';

export interface Occasion {
  id: string;
  date: string;
  nameAr: string;
  nameEn: string;
  kind: OccasionKind;
  religion?: 'مسيحية' | 'يهودية';
  official: boolean;
  officialNote?: string;
  image: string;
  decor?: string;
  detailsAr: string;
  detailsEn: string;
  /** Strictly FALSE for Christian & Jewish occasions — excluded from notifications AND home-screen widgets. */
  notify: boolean;
  color?: string;
  time?: number | null;
  personalId?: string;
}

const key = (d: Date) => todayKey(d);
const mk = (y: number, m: number, d: number) => new Date(y, m - 1, d, 12);

/* ---------- Hijri ---------- */
const hijriFmt = (() => {
  try { return new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric' }); }
  catch { return null; }
})();

export function hijriOf(date: Date, offsetDays = 0): { y: number; m: number; d: number } | null {
  if (!hijriFmt) return null;
  const dt = new Date(date); dt.setDate(dt.getDate() + offsetDays);
  const parts = hijriFmt.formatToParts(dt);
  const get = (t: string) => parseInt(parts.find(p => p.type === t)?.value ?? '0', 10);
  return { y: get('year'), m: get('month'), d: get('day') };
}

export const HIJRI_MONTHS_AR = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];
export const HIJRI_MONTHS_EN = ['Muharram', 'Safar', 'Rabi I', 'Rabi II', 'Jumada I', 'Jumada II', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhu al-Qa'dah", 'Dhu al-Hijjah'];

export function hijriLabel(date: Date, lang: 'ar' | 'en', offset = 0) {
  const h = hijriOf(date, offset);
  if (!h) return '';
  return lang === 'ar' ? `${h.d} ${HIJRI_MONTHS_AR[h.m - 1]} ${h.y} هـ` : `${h.d} ${HIJRI_MONTHS_EN[h.m - 1]} ${h.y} AH`;
}

/* ---------- Hebrew ---------- */
const hebFmt = (() => { try { return new Intl.DateTimeFormat('en-u-ca-hebrew', { day: 'numeric', month: 'long' }); } catch { return null; } })();

/* ---------- Coptic Orthodox Easter (Julian computus → Gregorian +13 days for 1900–2099) ---------- */
export function orthodoxEaster(y: number): Date {
  const a = y % 4, b = y % 7, c = y % 19;
  const d = (19 * c + 15) % 30;
  const e = (2 * a + 4 * b - d + 34) % 7;
  const month = Math.floor((d + e + 114) / 31);
  const day = ((d + e + 114) % 31) + 1;
  const dt = mk(y, month, day);
  dt.setDate(dt.getDate() + 13);
  return dt;
}

function firstFridayOfApril(y: number): Date {
  const d = mk(y, 4, 1);
  while (d.getDay() !== 5) d.setDate(d.getDate() + 1);
  return d;
}

const IMG = {
  ramadan: '/media/occ-ramadan3.jpg',
  ramadanLantern: '/media/occ-ramadan.jpg',
  qadr: '/media/occ-ramadan2.jpg',
  fitr: '/media/occ-eid-fitr.jpg',
  hajj: '/media/occ-hajj.jpg',
  islamic: '/media/occ-islamic.jpg',
  mawlid: '/media/occ-mawlid.jpg',
  isra: '/media/occ-isra.jpg',
  quran: '/media/occ-quran.jpg',
  national: '/media/occ-national.jpg',
  cairo: '/media/occ-cairo.jpg',
  sinai: '/media/occ-sinai.jpg',
  egypt: '/media/occ-egypt.jpg',
  labor: '/media/occ-labor.jpg',
  sham: '/media/occ-sham.jpg',
  spring: '/media/bg-spring2.jpg',
  christmas: '/media/occ-christmas.jpg',
  stockings: '/media/occ-stockings.jpg',
  church: '/media/occ-church.jpg',
  newyear: '/media/occ-newyear.jpg',
  jewish: '/media/occ-jewish.jpg',
  personal: '/media/onb-2.jpg',
};

interface HijriDef { m: number; d: number; days?: number; id: string; ar: string; en: string; official: boolean; officialNote?: string; img: string; decor: string; det: string; detEn: string; }

const HIJRI_DEFS: HijriDef[] = [
  { m: 1, d: 1, id: 'hijri-newyear', ar: 'رأس السنة الهجرية', en: 'Islamic New Year', official: true, officialNote: 'ممكن تتنقل للخميس', img: IMG.islamic, decor: 'crescent',
    det: 'أول يوم في السنة الهجرية الجديدة (1 محرم)، وبنفتكر فيه هجرة النبي ﷺ من مكة للمدينة وبداية التقويم الهجري. إجازة رسمية مدفوعة الأجر في مصر للحكومة والبنوك والقطاع الخاص، ومجلس الوزراء ساعات بيرحّلها ليوم الخميس.',
    detEn: 'First day of the Hijri calendar year commemorating the Prophet’s migration. Official public holiday in Egypt.' },
  { m: 1, d: 10, id: 'ashura', ar: 'يوم عاشوراء', en: 'Day of Ashura', official: false, img: IMG.quran, decor: 'prayer-beads',
    det: 'العاشر من شهر محرم — اليوم اللي نجّى فيه ربنا سيدنا موسى عليه السلام. يستحب صيامه مع يوم قبله (تاسوعاء) لأنه يكفّر ذنوب سنة فاتت، وفي مصر متعودين نعمل فيه طبق العاشوراء الحلو 🥣. اليوم ده مش إجازة رسمية.',
    detEn: '10th of Muharram — widely observed with recommended fasting and Egypt’s sweet Ashura dessert. Not an official holiday.' },
  { m: 3, d: 12, id: 'mawlid', ar: 'المولد النبوي الشريف', en: "Prophet's Birthday", official: true, img: IMG.mawlid, decor: 'star-glow',
    det: 'ذكرى ميلاد سيدنا محمد ﷺ في 12 ربيع الأول. في مصر أجواء خاصة: حلاوة المولد السمسمية والحمصية وعروسة المولد وحصان المولد، وإنشاد ديني في كل مكان. إجازة رسمية في مصر كلها.',
    detEn: 'Celebrates the birth of Prophet Muhammad (12 Rabi I) with traditional Egyptian Mawlid sweets. Official public holiday.' },
  { m: 7, d: 27, id: 'isra', ar: 'ليلة الإسراء والمعراج', en: "Isra and Mi'raj", official: false, img: IMG.isra, decor: 'mosque',
    det: 'ذكرى رحلة الإسراء من المسجد الحرام للمسجد الأقصى ثم المعراج للسماوات العلا، وفيها اتفرضت الصلوات الخمس. بنحييها بالدعاء والصلاة والذكر. مش إجازة رسمية في مصر.',
    detEn: 'Commemorates the Night Journey to Jerusalem and the Ascension, when the five daily prayers were instituted. Not a public holiday.' },
  { m: 8, d: 15, id: 'mid-shaban', ar: 'ليلة النصف من شعبان', en: "Mid-Sha'ban", official: false, img: IMG.ramadanLantern, decor: 'crescent',
    det: 'ليلة مباركة قبل رمضان بأسبوعين بالظبط — بنستعد فيها للشهر الكريم بالدعاء، الصيام، وتصفية النفوس. اليوم ده مش إجازة رسمية.',
    detEn: 'A blessed night two weeks before Ramadan, spent in prayer and spiritual preparation. Not a public holiday.' },
  { m: 9, d: 1, id: 'ramadan', ar: 'أول أيام شهر رمضان المبارك', en: 'First Day of Ramadan', official: false, officialNote: 'مواعيد شغل مخففة', img: IMG.ramadan, decor: 'lantern-gold',
    det: 'أهلاً رمضان 🌙 شهر الصيام والقرآن والفوانيس والزينة في الشوارع ولمّة الفطار والسحور! أول يوم مش إجازة رسمية، لكن ساعات الشغل والمدارس والبنوك بتتخفف طول الشهر. التطبيق كله بيتزين بالفوانيس والأهلة والنجوم طول رمضان أوتوماتيك.',
    detEn: 'Start of the holy month of Ramadan with reduced working hours across Egypt. The app automatically activates Ramadan lanterns and crescent decorations.' },
  { m: 9, d: 27, id: 'qadr', ar: 'ليلة القدر (المرجّحة)', en: 'Laylat al-Qadr (27th night)', official: false, img: IMG.qadr, decor: 'star-glow',
    det: 'أرجح ليالي القدر في العشر الأواخر من رمضان — خير من ألف شهر ✨ ليلة دعاء وتهجد وقرآن لحد الفجر. مش إجازة رسمية.',
    detEn: 'The most widely sought night of Laylat al-Qadr during the final ten nights of Ramadan. Not a public holiday.' },
  { m: 10, d: 1, days: 3, id: 'eid-fitr', ar: 'عيد الفطر المبارك', en: 'Eid al-Fitr', official: true, img: IMG.fitr, decor: 'party',
    det: 'كل سنة وانت طيب 🎉 العيد الصغير بعد صيام رمضان — صلاة العيد بعد الشروق بحوالي تلت ساعة، كحك وبسكوت وغريبة، عيدية، وزيارة الأهل. إجازة رسمية من 3 لـ 5 أيام حسب قرار مجلس الوزراء.',
    detEn: 'Joyful holiday ending Ramadan with morning Eid prayer, kahk sweets, and family gatherings. Official multi-day holiday.' },
  { m: 12, d: 9, id: 'arafat', ar: 'وقفة عرفات', en: 'Day of Arafah', official: true, img: IMG.hajj, decor: 'kaaba',
    det: 'أعظم أيام السنة — الحجاج واقفين على جبل عرفات بيلبّوا ويدعوا، وصيامه لغير الحاج بيكفّر سنة قبله وسنة بعده، وكل الناس بتستعد للعيد. إجازة رسمية في مصر.',
    detEn: 'Sacred peak day of Hajj on Mount Arafat; fasting is highly recommended. Official public holiday in Egypt.' },
  { m: 12, d: 10, days: 4, id: 'eid-adha', ar: 'عيد الأضحى المبارك', en: 'Eid al-Adha', official: true, img: IMG.hajj, decor: 'sheep',
    det: 'العيد الكبير 🐑 ذكرى فداء سيدنا إسماعيل — صلاة العيد والأضحية وتوزيعها على الأهل والفقراء ولمّة العيلة والفتة! إجازة رسمية عادةً 4 أيام متواصلة بعد الوقفة.',
    detEn: 'Feast of Sacrifice celebrating the spirit of devotion and sharing with family and the needy. Official 4-day holiday.' },
];

function hijriOccasionsForYear(y: number, offset: number): Occasion[] {
  const out: Occasion[] = [];
  const start = mk(y, 1, 1), end = mk(y, 12, 31);
  for (let dt = new Date(start); dt <= end; dt.setDate(dt.getDate() + 1)) {
    const h = hijriOf(dt, offset);
    if (!h) break;
    for (const def of HIJRI_DEFS) {
      const span = def.days ?? 1;
      if (h.m === def.m && h.d >= def.d && h.d < def.d + span) {
        const n = h.d - def.d + 1;
        out.push({
          id: `${def.id}-${key(dt)}`,
          date: key(dt),
          nameAr: span > 1 ? `${def.ar} — اليوم ${n}` : def.ar,
          nameEn: span > 1 ? `${def.en} (Day ${n})` : def.en,
          kind: 'islamic',
          official: def.official,
          officialNote: def.officialNote,
          image: def.img,
          decor: def.decor,
          detailsAr: def.det,
          detailsEn: def.detEn,
          notify: true,
        });
      }
    }
  }
  return out;
}

function fixedForYear(y: number): Occasion[] {
  const easter = orthodoxEaster(y);
  const sham = new Date(easter); sham.setDate(easter.getDate() + 1);
  const orphan = firstFridayOfApril(y);
  const f = (
    date: Date, id: string, ar: string, en: string, kind: OccasionKind, official: boolean,
    image: string, det: string, detEn: string, decor?: string, extra: Partial<Occasion> = {}
  ): Occasion => ({
    id: `${id}-${y}`, date: key(date), nameAr: ar, nameEn: en, kind, official, image,
    detailsAr: det, detailsEn: detEn, decor,
    // Strict invariant: Christian & Jewish occasions NEVER notify or appear in widgets
    notify: kind !== 'christian' && kind !== 'jewish',
    ...extra,
  });

  const list: Occasion[] = [
    f(mk(y, 1, 1), 'newyear', 'رأس السنة الميلادية', "New Year's Day", 'global', true, IMG.newyear,
      'أول يوم في السنة الميلادية الجديدة 🎆 بداية صفحة جديدة وأهداف جديدة! إجازة رسمية للبنوك وأغلب المصالح الحكومية حسب قرار مجلس الوزراء.',
      'First day of the Gregorian year — banks are officially off across Egypt.', 'fireworks', { officialNote: 'إجازة بنوك / قرار وزراء' }),
    f(mk(y, 1, 7), 'coptic-xmas', 'عيد الميلاد المجيد (القبطي)', 'Coptic Christmas', 'christian', true, IMG.stockings,
      'عيد ميلاد السيد المسيح وفق التقويم القبطي الأرثوذكسي. إجازة رسمية عامة في مصر، لكنه معروض هنا في التقويم للعلم بس ومش بيظهر في الإشعارات أو الويدجيت.',
      'Coptic Orthodox Christmas. Official Egyptian holiday. Shown for info only; excluded from notifications and widgets.', 'xmas-tree', { religion: 'مسيحية' }),
    f(mk(y, 1, 25), 'jan25', 'عيد الشرطة وثورة 25 يناير', 'Police Day & Jan 25', 'national', true, IMG.cairo,
      'ذكرى بطولات رجال الشرطة في معركة الإسماعيلية 1952 وذكرى ثورة 25 يناير 2011. إجازة رسمية مدفوعة الأجر (وغالبًا بتتنقل لأقرب يوم خميس).',
      'Honours Police Day (1952) and the 2011 revolution. Official national holiday.', 'shield', { officialNote: 'غالبًا تُرحَّل للخميس' }),
    f(mk(y, 3, 21), 'mothers-day', 'عيد الأم وبداية الربيع', "Mother's Day & Spring", 'egyptian', false, IMG.spring,
      'يوم تكريم ست الحبايب في مصر والعالم العربي 💐 وكمان أول يوم في فصل الربيع. متنساش تكلم ماما أو تجيبلها هدية حلوة! مش إجازة رسمية.',
      "Celebrates mothers across Egypt and the start of spring. Not an official public holiday.", 'bouquet'),
    f(orphan, 'orphan-day', 'يوم اليتيم في مصر', "Orphan's Day (Egypt)", 'egyptian', false, IMG.spring,
      'أول جمعة من شهر أبريل كل سنة — يوم مصري مخصص لإسعاد الأطفال الأيتام وتقديم الهدايا والزيارات. مش إجازة رسمية.',
      'First Friday of April, a dedicated community day supporting orphans across Egypt. Not an official holiday.', 'heart'),
    f(easter, 'coptic-easter', 'عيد القيامة المجيد (القبطي)', 'Coptic Easter', 'christian', false, IMG.church,
      'أحد الأعياد المسيحية الكبرى لدى الكنيسة القبطية الأرثوذكسية. مش إجازة رسمية عامة للدولة كلها، ومعروض في التقويم للعلم فقط ومش بيظهر في الإشعارات أو الويدجيت.',
      'Coptic Orthodox Easter. Not a general public holiday; hidden from notifications and widgets.', 'church', { religion: 'مسيحية' }),
    f(sham, 'sham', 'عيد شم النسيم', 'Sham El-Nessim', 'egyptian', true, IMG.sham,
      'أقدم عيد شعبي مصري من عهد الفراعنة 🌸 يوم الاتنين بعد عيد القيامة — الجناين والهوا الحلو والبيض الملون والفسيخ والرنجة والبصل الأخضر! إجازة رسمية في مصر كلها.',
      'Ancient Egyptian spring picnic holiday celebrating renewal (Monday after Coptic Easter). Official holiday.', 'egg'),
    f(mk(y, 4, 25), 'sinai', 'عيد تحرير سيناء', 'Sinai Liberation Day', 'national', true, IMG.sinai,
      'ذكرى استرداد آخر شبر من أرض سيناء الحبيبة ورفع علم مصر عليها يوم 25 أبريل 1982. إجازة رسمية في كل مصر.',
      'Marks the full return of Sinai in 1982. Official national holiday.', 'shield'),
    f(mk(y, 5, 1), 'labor', 'عيد العمال', 'Labour Day', 'national', true, IMG.labor,
      'تقدير لكل إيد شغالة بتبني البلد 🛠️ عمال المصانع والزراعة والمهن. إجازة رسمية مدفوعة الأجر للحكومة والقطاع الخاص.',
      'Honours working people across Egypt. Official public holiday.', 'tools'),
    f(mk(y, 6, 30), 'jun30', 'ذكرى ثورة 30 يونيو', 'June 30 Revolution', 'national', true, IMG.national,
      'ذكرى ثورة 30 يونيو 2013 في مصر. إجازة رسمية في المصالح الحكومية والبنوك والقطاع الخاص.',
      'Commemorates June 30, 2013. Official public holiday in Egypt.', 'shield'),
    f(mk(y, 7, 23), 'jul23', 'عيد ثورة 23 يوليو', 'July 23 Revolution', 'national', true, IMG.cairo,
      'العيد القومي لجمهورية مصر العربية — ذكرى ثورة 23 يوليو 1952 وإعلان الجمهورية. إجازة رسمية في كل أنحاء مصر.',
      "Egypt's National Revolution Day (1952). Official holiday.", 'shield'),
    f(mk(y, 9, 11), 'nayrouz', 'عيد النيروز (رأس السنة القبطية)', 'Coptic New Year', 'christian', false, IMG.church,
      'بداية السنة القبطية (1 توت) عند الإخوة الأقباط، ويشتهر بأكل البلح الأحمر والجوافة. مش إجازة رسمية، ومستبعد من الإشعارات والويدجيت.',
      'Start of the Coptic year (1 Tout). Not a public holiday; excluded from notifications and widgets.', 'church', { religion: 'مسيحية' }),
    f(mk(y, 10, 6), 'oct6', 'عيد القوات المسلحة (نصر أكتوبر)', 'Armed Forces Day (6 Oct)', 'national', true, IMG.egypt,
      'ذكرى انتصار حرب أكتوبر المجيدة سنة 1973 وعبور خط بارليف 🇪🇬 يوم فخر لكل مصري. إجازة رسمية في كل مصر.',
      'Commemorates Egypt’s October 1973 victory. Official national holiday.', 'shield'),
    f(mk(y, 12, 25), 'western-xmas', 'الكريسماس (عيد الميلاد الغربي)', 'Christmas (Western)', 'christian', false, IMG.christmas,
      'عيد الميلاد المجيد حسب التقويم الغربي. مش إجازة رسمية في مصر، ومستبعد من الإشعارات والويدجيت ومعروض للعلم فقط.',
      'Western Christian Christmas. Not an Egyptian public holiday; excluded from notifications and widgets.', 'xmas-tree', { religion: 'مسيحية' }),
  ];

  // Jewish holidays — strictly informational only, flagged red (!), NEVER notify or in widgets
  if (hebFmt) {
    const targets: Array<[string, number, string, string, string, string]> = [
      ['Tishri', 1, 'rosh', 'رأس السنة العبرية', 'Rosh Hashanah', 'بداية السنة العبرية في الديانة اليهودية.'],
      ['Tishri', 10, 'kippur', 'يوم الغفران (كيبور)', 'Yom Kippur', 'يوم صوم ديني في الديانة اليهودية.'],
      ['Nisan', 15, 'pesach', 'عيد الفصح اليهودي', 'Passover', 'أحد الأعياد الدينية في الديانة اليهودية.'],
      ['Kislev', 25, 'hanukkah', 'عيد الأنوار (حانوكا)', 'Hanukkah', 'عيد ديني يهودي يستمر 8 ليالٍ.'],
    ];
    for (let dt = mk(y, 1, 1); dt.getFullYear() === y; dt.setDate(dt.getDate() + 1)) {
      const parts = hebFmt.formatToParts(dt);
      const mo = parts.find(p => p.type === 'month')?.value ?? '';
      const da = parseInt(parts.find(p => p.type === 'day')?.value ?? '0', 10);
      for (const [mon, day, id, ar, en, note] of targets) {
        if (mo.startsWith(mon) && da === day) {
          list.push(f(
            new Date(dt), id, ar, en, 'jewish', false, IMG.jewish,
            `${note} مناسبة دينية يهودية — مش إجازة رسمية في مصر، ومحذوفة تمامًا من الإشعارات والويدجيت ومعروضة في التقويم للعلم فقط.`,
            'Jewish occasion — informational only; never shown in notifications or widgets.',
            'menorah', { religion: 'يهودية' }
          ));
        }
      }
    }
  }
  return list;
}

const cache = new Map<string, Occasion[]>();
export function occasionsForYear(y: number, hijriOffset = 0): Occasion[] {
  const k = `${y}:${hijriOffset}`;
  if (!cache.has(k)) {
    cache.set(k, [...fixedForYear(y), ...hijriOccasionsForYear(y, hijriOffset)].sort((a, b) => a.date.localeCompare(b.date)));
  }
  return cache.get(k)!;
}

export interface PersonalOccasion {
  id: string; title: string; date: string; yearly: boolean;
  timeMin: number | null; remindDaysBefore: number; color: string;
  note?: string; createdAt: number;
}

export function personalToOccasions(list: PersonalOccasion[], y: number): Occasion[] {
  return list.flatMap(p => {
    const date = p.yearly ? `${y}${p.date.slice(4)}` : p.date;
    if (!p.yearly && !p.date.startsWith(String(y))) return [];
    return [{
      id: `personal-${p.id}-${date}`, personalId: p.id, date,
      nameAr: p.title, nameEn: p.title, kind: 'personal' as const, official: false,
      image: IMG.personal, decor: 'ribbon',
      detailsAr: p.note || 'مناسبة خاصة إنت ضفتها — هتوصلك في الإشعارات والويدجيت في ميعادها.',
      detailsEn: p.note || 'Your personal occasion — delivered in notifications & widgets.',
      notify: true, color: p.color, time: p.timeMin,
    }];
  });
}

export function occasionsInRange(from: string, to: string, hijriOffset: number, personal: PersonalOccasion[] = []): Occasion[] {
  const y1 = +from.slice(0, 4), y2 = +to.slice(0, 4);
  const out: Occasion[] = [];
  for (let y = y1; y <= y2; y++) out.push(...occasionsForYear(y, hijriOffset), ...personalToOccasions(personal, y));
  return out.filter(o => o.date >= from && o.date <= to).sort((a, b) => a.date.localeCompare(b.date));
}

export const KIND_LABEL: Record<OccasionKind, { ar: string; en: string; color: string }> = {
  islamic: { ar: 'إسلامية', en: 'Islamic', color: '#0da271' },
  national: { ar: 'وطنية', en: 'National', color: '#dc2626' },
  egyptian: { ar: 'مصرية', en: 'Egyptian', color: '#d97706' },
  christian: { ar: 'مسيحية', en: 'Christian', color: '#dc2626' },
  jewish: { ar: 'يهودية', en: 'Jewish', color: '#dc2626' },
  global: { ar: 'عامة', en: 'Global', color: '#2563eb' },
  personal: { ar: 'شخصية', en: 'Personal', color: '#7c3aed' },
};
