/* DAYFLOW — Assistant agent tools. Every tool performs a REAL operation on the same database and
   native bridge the rest of the app uses (alarms are scheduled through AlarmManager, activities are
   synced to notifications & widgets, journal/tasks/occasions are persisted). Destructive operations
   return a pending confirmation that the user approves in the chat. */
import { db, newId, todayKey, addDays, minToTime, type AppSettings } from '@/lib/db';
import { platform } from '@/lib/platform';
import { syncNative } from '@/lib/sync';
import { occasionsInRange, type PersonalOccasion, type Occasion } from '@/lib/occasions';
import { computePrayerTimes, govById, PRAYER_AR, FARD, type PrayerName } from '@/lib/prayer';
import type { ActivityBlock, TaskItem, FocusSession } from '@/lib/types';
import {
  parseTimeMin, parseDays, parseDate, parseCategory, clampInt, minToHHMM, matchScore, todayIso,
} from './parse';
import type { ToolSpec } from './client';

/* ---------------- card model (rendered inside the chat as rich previews) ---------------- */
export type AssistantCard =
  | { type: 'occasions'; title: string; items: Array<{ name: string; date: string; official: boolean; kind: string; image: string; decor?: string; details: string; notify: boolean; religion?: string }> }
  | { type: 'schedule'; title: string; date: string; items: Array<{ title: string; start: string; end: string; status: string; note?: string; fixed?: boolean }> }
  | { type: 'prayer'; title: string; governorate: string; times: Array<{ name: PrayerName; label: string; time: string }> }
  | { type: 'alarms'; title: string; items: Array<{ label: string; time: string; days: string; enabled: boolean }> }
  | { type: 'tasks'; title: string; items: Array<{ title: string; due: string; priority: number; done: boolean; estimate: number }> }
  | { type: 'journal'; title: string; items: Array<{ date: string; title: string; body: string; mood: number | null }> }
  | { type: 'water'; ml: number; target: number }
  | { type: 'decor'; scene: string }
  | { type: 'summary'; title: string; lines: string[] };

export interface ActionLog { tool: string; ok: boolean; summary: string; pending?: PendingAction }
export interface PendingAction { id: string; kind: 'delete_alarm' | 'delete_activity' | 'delete_task' | 'delete_note' | 'delete_journal' | 'delete_occasion'; targetId: string; label: string }

export interface ToolContext {
  settings: AppSettings;
  allowActions: boolean;
  navigate: (name: string, params?: any) => void;
  bump: () => void;
}

export interface ToolOutcome {
  ok: boolean;
  summary: string;               // short Egyptian Arabic line shown to the user as an action chip
  data?: unknown;                // JSON returned to the model
  cards?: AssistantCard[];
  pending?: PendingAction;
}

const lang = (ctx: ToolContext) => ctx.settings.language;
const isAr = (ctx: ToolContext) => lang(ctx) === 'ar';

/* ---------------- tool specifications (OpenAI function-calling schema) ---------------- */
const str = (description: string) => ({ type: 'string', description });
const num = (description: string) => ({ type: 'number', description });
const bool = (description: string) => ({ type: 'boolean', description });
const arr = (description: string) => ({ type: 'array', items: { type: 'string' }, description });
const obj = (properties: Record<string, unknown>, required: string[] = []) => ({ type: 'object', properties, required });

export const TOOL_SPECS: ToolSpec[] = [
  { type: 'function', function: { name: 'create_alarm', description: 'ضبط منبه حقيقي (يرن بشاشة كاملة فوق القفل). استخدمه لأي طلب "صحّيني" أو "منبه".', parameters: obj({
    time: str('الساعة بصيغة HH:MM أو 7:30 أو 7 الصبح أو 9 بالليل'), label: str('نص المنبه يظهر وقت الرنين'),
    days: arr('الأيام: الأحد/الاتنين/... أو "كل يوم" أو "أيام الشغل" أو "الويك اند"؛ فاضي = مرة واحدة'),
    snooze_min: num('مدة الغفوة بالدقايق (افتراضي 10)'), max_snoozes: num('أقصى عدد غفوات (افتراضي 3)'),
    repeat_count: num('عدد مرات تكرار النغمة (افتراضي 10)') }, ['time']) } },
  { type: 'function', function: { name: 'list_alarms', description: 'اعرض كل المنبهات الحالية.', parameters: obj({}) } },
  { type: 'function', function: { name: 'set_alarm_enabled', description: 'اقفل أو افتح منبه بالاسم أو الساعة.', parameters: obj({ match: str('اسم المنبه أو الساعة'), enabled: bool('true يفتح، false يقفل') }, ['match', 'enabled']) } },
  { type: 'function', function: { name: 'delete_alarm', description: 'امسح منبه (يحتاج تأكيد المستخدم).', parameters: obj({ match: str('اسم المنبه أو الساعة') }, ['match']) } },
  { type: 'function', function: { name: 'create_activity', description: 'أضف نشاط/كتلة لجدول يوم محدد مع تذكير قبله بالإشعار. مثال: "ضيف مذاكرة كيمياء بكرة من 5 لـ 6 العصر".', parameters: obj({
    title: str('اسم النشاط'), date: str('اليوم: النهارده / بكرة / YYYY-MM-DD (افتراضي النهارده)'),
    start: str('وقت البداية HH:MM أو 5 العصر'), end: str('وقت النهاية (اختياري)'), duration_min: num('المدة بالدقايق لو مش معروف وقت النهاية'),
    category: str('مذاكرة / شغل / رياضة / راحة / وجبة / نوم / صلاة / شخصي / اجتماعي / صحة / أخرى'),
    note: str('ملاحظة تظهر على المربع وفي الإشعار'), reminder_min: num('التذكير قبل البداية بالدقايق (افتراضي 10، 0 = عند الميعاد، -1 = بدون)'),
    fixed: bool('هل ميعاده ثابت (ما يتحركش)') }, ['title', 'start']) } },
  { type: 'function', function: { name: 'update_activity', description: 'عدّل نشاط موجود (الاسم أو الوقت أو الملاحظة) بالبحث عنه بالاسم.', parameters: obj({
    match: str('اسم النشاط الحالي'), date: str('اليوم (افتراضي النهارده)'), new_title: str('الاسم الجديد'),
    start: str('الوقت الجديد للبداية'), end: str('الوقت الجديد للنهاية'), note: str('الملاحظة الجديدة') }, ['match']) } },
  { type: 'function', function: { name: 'complete_activity', description: 'علّم نشاط بأنه خلص / خلص جزء / اتخطّى.', parameters: obj({
    match: str('اسم النشاط'), date: str('اليوم (افتراضي النهارده)'), status: str('done أو partial أو skipped') }, ['match']) } },
  { type: 'function', function: { name: 'list_schedule', description: 'اعرض جدول يوم معين (أنشطة الصبح والنهارده).', parameters: obj({ date: str('اليوم') }) } },
  { type: 'function', function: { name: 'delete_activity', description: 'امسح نشاط (يحتاج تأكيد).', parameters: obj({ match: str('اسم النشاط'), date: str('اليوم') }, ['match']) } },
  { type: 'function', function: { name: 'create_task', description: 'أضف مهمة لتاريخ محدد (وتظهر في الإشعارات يوم استحقاقها).', parameters: obj({
    title: str('عنوان المهمة'), due_date: str('تاريخ الاستحقاق: النهارده / بكرة / YYYY-MM-DD'),
    priority: num('الأولوية 1 (أعلى) إلى 4'), estimate_min: num('التقدير بالدقايق'), note: str('ملاحظة') }, ['title']) } },
  { type: 'function', function: { name: 'complete_task', description: 'علّم مهمة بأنها خلصت.', parameters: obj({ match: str('اسم المهمة') }, ['match']) } },
  { type: 'function', function: { name: 'list_tasks', description: 'اعرض المهام: النهارده / المتأخرة / المفتوحة / الكل.', parameters: obj({ filter: str('today | overdue | open | all') }) } },
  { type: 'function', function: { name: 'create_journal_entry', description: 'اكتب تدوينة في يومياتي (مود، امتنان، وسوم، نص).', parameters: obj({
    title: str('عنوان التدوينة'), body: str('نص التدوينة'), mood: num('المود من 1 (زعلان) إلى 5 (مبسوط جداً)'),
    gratitude: arr('3 حاجات ممتن ليها'), tags: arr('وسوم'), date: str('اليوم (افتراضي النهارده)') }, ['body']) } },
  { type: 'function', function: { name: 'list_journal', description: 'اعرض آخر تدوينات اليوميات.', parameters: obj({ limit: num('عدد التدوينات (افتراضي 5)') }) } },
  { type: 'function', function: { name: 'create_occasion', description: 'ضيف مناسبة شخصية (عيد ميلاد، ذكرى…) تظهر في التقويم والإشعارات والويدجيت.', parameters: obj({
    title: str('اسم المناسبة'), date: str('التاريخ: YYYY-MM-DD أو بكرة…'), time: str('الساعة (اختياري)'),
    yearly: bool('تتكرر كل سنة'), remind_days_before: num('فكّرني قبلها بكام يوم (0 = في يومها)') }, ['title', 'date']) } },
  { type: 'function', function: { name: 'list_occasions', description: 'اعرض المناسبات (الوطنية والإسلامية ومناسباتي) لفترة.', parameters: obj({ from: str('من تاريخ'), to: str('لتاريخ'), only_official: bool('الإجازات الرسمية فقط') }) } },
  { type: 'function', function: { name: 'log_water', description: 'سجّل كوباية أو كمية مية.', parameters: obj({ ml: num('الكمية بالمليلتر (افتراضي حجم الكوباية)') }) } },
  { type: 'function', function: { name: 'create_habit', description: 'ضيف عادة يومية جديدة لتتابعها.', parameters: obj({ name: str('اسم العادة'), target_count: num('الهدف اليومي (افتراضي 1)') }, ['name']) } },
  { type: 'function', function: { name: 'log_habit', description: 'سجّل إن عادة اتعملت النهارده.', parameters: obj({ match: str('اسم العادة') }, ['match']) } },
  { type: 'function', function: { name: 'create_note', description: 'اكتب ملاحظة سريعة في الملاحظات.', parameters: obj({ title: str('العنوان'), body: str('النص'), tags: arr('وسوم') }, ['body']) } },
  { type: 'function', function: { name: 'start_focus', description: 'ابدأ جلسة تركيز (بومودورو أو عدّ تنازلي).', parameters: obj({ minutes: num('المدة بالدقايق'), task: str('هتركّز في إيه') }, ['minutes']) } },
  { type: 'function', function: { name: 'get_prayer_times', description: 'مواقيت الصلاة النهارده للمحافظة المختارة.', parameters: obj({}) } },
  { type: 'function', function: { name: 'set_setting', description: 'غيّر إعداد في التطبيق: theme (light/dark/auto) · skin (gemini/oneui/ios/aurora/frost/midnight/paper/sand/mint/ocean/rose/sunset) · accent · language (ar/en) · hour12 · decorations · particles · decorLayer (below/above) · decorSpeed (slow/normal/fast) · decorDensity (light/normal/dense) · decorOpacity (0.15-1) · decorOverride (auto أو اسم المشهد) · governorate · waterTargetMl · hijriOffset (-2..2) · userName', parameters: obj({ key: str('اسم الإعداد'), value: str('القيمة') }, ['key', 'value']) } },
  { type: 'function', function: { name: 'navigate', description: 'افتح شاشة في التطبيق للمستخدم: today, plan, calendar, more, focus, progress, tasks, study, workouts, habits, goals, notes, notifications, settings, journal, alarms, prayer, assistant', parameters: obj({ screen: str('اسم الشاشة') }, ['screen']) } },
  { type: 'function', function: { name: 'show_card', description: 'اعرض معاينة حية داخل المحادثة: occasions | schedule | prayer | alarms | tasks | journal | water | decor | summary. استخدمه لما المستخدم يقول "وريني" أو "اعرضلي".', parameters: obj({
    type: str('نوع المعاينة'), date: str('اليوم أو from'), to: str('لتاريخ (للمناسبات)'), filter: str('للمهام: today/overdue/open/all'), scene: str('للزخرفة: اسم المشهد أو auto') }, ['type']) } },
  { type: 'function', function: { name: 'get_app_summary', description: 'ملخص حقيقي لليوم: الأنشطة المنجزة والمتبقية، المهام، المية، الصلوات، الجلسات. استخدمه قبل ما تجاوب عن حالة اليوم.', parameters: obj({}) } },
];

const SCREENS = ['today', 'plan', 'calendar', 'more', 'focus', 'progress', 'tasks', 'study', 'workouts', 'habits', 'goals', 'notes', 'notifications', 'settings', 'journal', 'alarms', 'prayer', 'assistant'];

/* ---------------- helpers ---------------- */
const fmtTime = (min: number, ctx: ToolContext) => minToTime(min, ctx.settings.hour12);
const hmText = (min: number) => minToHHMM(min);
const weekdayName = (n: number, ar: boolean) => (ar ? ['الأحد', 'الاتنين', 'التلات', 'الأربع', 'الخميس', 'الجمعة', 'السبت'] : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'])[n];

function bestMatch<T>(items: T[], query: string, text: (t: T) => string): T | null {
  let best: T | null = null, score = 0;
  for (const it of items) { const s = matchScore(query, text(it)); if (s > score) { score = s; best = it; } }
  return score >= 40 ? best : null;
}

const GENERAL_OK = (ctx: ToolContext) => ctx.allowActions !== false;

/* ---------------- executor ---------------- */
export async function runTool(name: string, rawArgs: Record<string, any>, ctx: ToolContext): Promise<ToolOutcome> {
  const a = rawArgs ?? {};
  const ar = isAr(ctx);
  const today = todayKey();
  const s = ctx.settings;

  if (!GENERAL_OK(ctx) && !['list_alarms', 'list_schedule', 'list_tasks', 'list_journal', 'list_occasions', 'show_card', 'get_app_summary', 'get_prayer_times', 'navigate'].includes(name)) {
    return { ok: false, summary: ar ? 'التعديل بالمساعد متقفل من الإعدادات' : 'Assistant changes are disabled in settings' };
  }

  switch (name) {
    /* ---------- alarms ---------- */
    case 'create_alarm': {
      const min = parseTimeMin(a.time);
      if (min == null) return { ok: false, summary: ar ? 'محتاج ساعة واضحة للمنبه' : 'Need a clear time' };
      const days = parseDays(a.days);
      const alarm = {
        id: newId(), hour: Math.floor(min / 60), minute: min % 60, label: String(a.label ?? '').trim(),
        days, enabled: true, snoozeMin: clampInt(a.snooze_min, 1, 60, 10), maxSnoozes: clampInt(a.max_snoozes, 0, 10, 3),
        repeatCount: clampInt(a.repeat_count, 1, 30, 10), toneUri: '', toneName: ar ? 'نغمة المنبه الافتراضية' : 'Default alarm tone',
        toneKind: 'default', clipStartMs: 0, clipEndMs: 0, durationMs: 0, volume: 0.9, gradual: true, vibrate: true,
        speakLabel: false, createdAt: Date.now(),
      };
      await db.put('user_alarms', alarm);
      const native: any = await platform.setUserAlarm(alarm);
      ctx.bump();
      const when = days.length === 0 ? (ar ? 'مرة واحدة' : 'once') : days.length === 7 ? (ar ? 'كل يوم' : 'daily') : days.map(d => weekdayName(d, ar)).join('، ');
      const note = native.unsupported ? (ar ? ' — الرنين الحقيقي بيشتغل في تطبيق الأندرويد' : ' — real ringing runs on Android') : '';
      return { ok: true, summary: ar ? `اتضبط منبه ${fmtTime(min, ctx)}${alarm.label ? ` «${alarm.label}»` : ''} · ${when}${note}` : `Alarm set ${fmtTime(min, ctx)}${note}`, data: { id: alarm.id, time: hmText(min) } };
    }
    case 'list_alarms': {
      const list = await db.all<any>('user_alarms');
      const items = list.map(x => ({ label: x.label || (ar ? 'منبه' : 'Alarm'), time: hmText(x.hour * 60 + x.minute), days: x.days?.length ? x.days.map((d: number) => weekdayName(d, ar)).join(', ') : (ar ? 'مرة واحدة' : 'once'), enabled: !!x.enabled }));
      return { ok: true, summary: ar ? `عندك ${items.length} منبه` : `${items.length} alarms`, data: items, cards: [{ type: 'alarms', title: ar ? 'منبهاتك' : 'Your alarms', items }] };
    }
    case 'set_alarm_enabled': {
      const list = await db.all<any>('user_alarms');
      const hit = bestMatch(list, String(a.match ?? ''), x => `${x.label} ${hmText(x.hour * 60 + x.minute)}`) ?? list.find(x => { const want = parseTimeMin(a.match); return want != null && x.hour * 60 + x.minute === want; });
      if (!hit) return { ok: false, summary: ar ? 'مالقيتش المنبه ده' : 'Alarm not found' };
      const updated = { ...hit, enabled: !!a.enabled };
      await db.put('user_alarms', updated);
      await platform.setUserAlarm(updated);
      ctx.bump();
      return { ok: true, summary: ar ? `${updated.enabled ? 'اتفتح' : 'اتقفل'} منبه ${hmText(hit.hour * 60 + hit.minute)}` : `Alarm ${updated.enabled ? 'on' : 'off'}` };
    }
    case 'delete_alarm': {
      const list = await db.all<any>('user_alarms');
      const hit = bestMatch(list, String(a.match ?? ''), x => `${x.label} ${hmText(x.hour * 60 + x.minute)}`);
      if (!hit) return { ok: false, summary: ar ? 'مالقيتش المنبه ده' : 'Alarm not found' };
      const label = `${ar ? 'منبه' : 'Alarm'} ${hmText(hit.hour * 60 + hit.minute)}${hit.label ? ` «${hit.label}»` : ''}`;
      const pending: PendingAction = { id: newId(), kind: 'delete_alarm', targetId: hit.id, label };
      return { ok: true, summary: ar ? `محتاج تأكيدك عشان تمسح ${label}` : `Confirm deleting ${label}`, pending };
    }

    /* ---------- activities / schedule ---------- */
    case 'create_activity': {
      const date = parseDate(a.date) ?? today;
      const start = parseTimeMin(a.start);
      if (start == null) return { ok: false, summary: ar ? 'محتاج وقت بداية للنشاط' : 'Need a start time' };
      let end = parseTimeMin(a.end);
      if (end == null || end <= start) {
        const dur = clampInt(a.duration_min, 5, 1440, s.defaultBlockDuration || 45);
        end = Math.min(1439, start + dur);
      }
      const reminder = a.reminder_min == null ? 10 : clampInt(a.reminder_min, -1, 240, 10);
      const block: ActivityBlock = {
        id: newId(), title: String(a.title).trim(), description: '', categoryId: parseCategory(a.category),
        date, startMin: start, endMin: end, fixed: !!a.fixed, priority: 3, energy: 'medium', difficulty: 3,
        status: 'planned', recurrence: 'none', reminderMin: reminder, sound: 'default', repeatCount: s.soundRepeatCount || 1,
        isCritical: false, splitAllowed: true, earliestStartMin: null, latestEndMin: null, linkedTaskId: null,
        linkedGoalId: null, linkedSubjectId: null, tags: ['assistant'], notes: String(a.note ?? '').trim(),
        actualStartMin: null, actualEndMin: null, createdAt: Date.now(), updatedAt: Date.now(),
      };
      await db.put('activity_blocks', block);
      ctx.bump();
      const sync = await syncNative().catch(() => null);
      const dayLabel = date === today ? (ar ? 'النهارده' : 'today') : date;
      return {
        ok: true,
        summary: ar ? `اتضاف «${block.title}» ${dayLabel} ${hmText(start)}–${hmText(end)}${sync?.unsupported ? ' (التذكير بيشتغل في الأندرويد)' : ''}` : `Added "${block.title}" ${dayLabel}`,
        data: { id: block.id, date, start: hmText(start), end: hmText(end) },
        cards: [{ type: 'schedule', title: ar ? `جدول ${dayLabel}` : `Schedule ${dayLabel}`, date, items: [{ title: block.title, start: hmText(start), end: hmText(end), status: 'planned', note: block.notes, fixed: block.fixed }] }],
      };
    }
    case 'update_activity': {
      const date = parseDate(a.date) ?? today;
      const blocks = (await db.all<ActivityBlock>('activity_blocks')).filter(b => b.date === date);
      const hit = bestMatch(blocks, String(a.match ?? ''), b => b.title);
      if (!hit) return { ok: false, summary: ar ? 'مالقيتش النشاط ده في اليوم ده' : 'Activity not found' };
      const start = a.start != null ? parseTimeMin(a.start) : null;
      const end = a.end != null ? parseTimeMin(a.end) : null;
      const updated: ActivityBlock = {
        ...hit,
        title: a.new_title ? String(a.new_title) : hit.title,
        startMin: start ?? hit.startMin,
        endMin: end ?? hit.endMin,
        notes: a.note != null ? String(a.note) : hit.notes,
        updatedAt: Date.now(),
      };
      if (updated.endMin <= updated.startMin) return { ok: false, summary: ar ? 'وقت النهاية لازم يكون بعد البداية' : 'End must be after start' };
      await db.put('activity_blocks', updated);
      ctx.bump();
      await syncNative().catch(() => null);
      return { ok: true, summary: ar ? `اتعدّل «${updated.title}» (${hmText(updated.startMin)}–${hmText(updated.endMin)})` : `Updated "${updated.title}"` };
    }
    case 'complete_activity': {
      const date = parseDate(a.date) ?? today;
      const blocks = (await db.all<ActivityBlock>('activity_blocks')).filter(b => b.date === date);
      const hit = bestMatch(blocks, String(a.match ?? ''), b => b.title);
      if (!hit) return { ok: false, summary: ar ? 'مالقيتش النشاط ده' : 'Activity not found' };
      const status = ['done', 'partial', 'skipped'].includes(a.status) ? a.status : 'done';
      const now = new Date(); const nowMin = now.getHours() * 60 + now.getMinutes();
      await db.put('activity_blocks', { ...hit, status, actualEndMin: nowMin, updatedAt: Date.now() });
      await platform.cancelAlarm(hit.id);
      ctx.bump();
      const label = status === 'done' ? (ar ? 'خلصته ✓' : 'done ✓') : status === 'partial' ? (ar ? 'خلصت جزء منه' : 'partial') : (ar ? 'اتخطّاه' : 'skipped');
      return { ok: true, summary: ar ? `«${hit.title}» — ${label}` : `"${hit.title}" — ${label}` };
    }
    case 'delete_activity': {
      const date = parseDate(a.date) ?? today;
      const blocks = (await db.all<ActivityBlock>('activity_blocks')).filter(b => b.date === date);
      const hit = bestMatch(blocks, String(a.match ?? ''), b => b.title);
      if (!hit) return { ok: false, summary: ar ? 'مالقيتش النشاط ده' : 'Activity not found' };
      return { ok: true, summary: ar ? `محتاج تأكيدك عشان تمسح «${hit.title}»` : `Confirm deleting "${hit.title}"`, pending: { id: newId(), kind: 'delete_activity', targetId: hit.id, label: hit.title } };
    }
    case 'list_schedule': {
      const date = parseDate(a.date) ?? today;
      const blocks = (await db.all<ActivityBlock>('activity_blocks')).filter(b => b.date === date && b.status !== 'cancelled').sort((x, y) => x.startMin - y.startMin);
      const items = blocks.map(b => ({ title: b.title, start: hmText(b.startMin), end: hmText(b.endMin), status: b.status, note: b.notes, fixed: b.fixed }));
      return { ok: true, summary: ar ? `جدول ${date === today ? 'النهارده' : date}: ${items.length} نشاط` : `${items.length} blocks`, data: items, cards: [{ type: 'schedule', title: ar ? 'جدول اليوم' : 'Day schedule', date, items }] };
    }

    /* ---------- tasks ---------- */
    case 'create_task': {
      const due = parseDate(a.due_date) ?? null;
      const task: TaskItem = {
        id: newId(), title: String(a.title).trim(), description: '', dueDate: due, startDate: null,
        priority: clampInt(a.priority, 1, 4, 3) as any, status: 'todo', estimatedMin: clampInt(a.estimate_min, 5, 1440, 30),
        trackedMin: 0, categoryId: 'work', tags: ['assistant'], checklist: [], starred: false, projectId: null,
        goalId: null, recurrence: 'none', reminderAt: null, notes: String(a.note ?? ''), createdAt: Date.now(), updatedAt: Date.now(),
      };
      await db.put('tasks', task);
      ctx.bump();
      await syncNative().catch(() => null);
      return { ok: true, summary: ar ? `اتضافت المهمة «${task.title}»${due ? ` ليوم ${due === today ? 'النهارده' : due}` : ''}` : `Task added "${task.title}"`,
        cards: [{ type: 'tasks', title: ar ? 'المهمة الجديدة' : 'New task', items: [{ title: task.title, due: due ?? '—', priority: task.priority, done: false, estimate: task.estimatedMin }] }] };
    }
    case 'complete_task': {
      const tasks = await db.all<TaskItem>('tasks');
      const hit = bestMatch(tasks.filter(t => t.status !== 'done'), String(a.match ?? ''), t => t.title);
      if (!hit) return { ok: false, summary: ar ? 'مالقيتش المهمة دي' : 'Task not found' };
      await db.put('tasks', { ...hit, status: 'done', updatedAt: Date.now() });
      ctx.bump();
      return { ok: true, summary: ar ? `خلصت المهمة «${hit.title}» ✓` : `Task done "${hit.title}"` };
    }
    case 'list_tasks': {
      const filter = String(a.filter ?? 'open');
      const tasks = (await db.all<TaskItem>('tasks')).filter(t => t.status !== 'cancelled');
      const picked = tasks.filter(t => {
        if (filter === 'all') return true;
        if (filter === 'today') return t.dueDate === today && t.status !== 'done';
        if (filter === 'overdue') return !!t.dueDate && t.dueDate < today && t.status !== 'done';
        return t.status !== 'done';
      });
      const items = picked.slice(0, 30).map(t => ({ title: t.title, due: t.dueDate ?? '—', priority: t.priority, done: t.status === 'done', estimate: t.estimatedMin }));
      return { ok: true, summary: ar ? `${items.length} مهمة` : `${items.length} tasks`, data: items, cards: [{ type: 'tasks', title: ar ? 'مهامك' : 'Your tasks', items }] };
    }
    case 'delete_task': {
      const tasks = await db.all<TaskItem>('tasks');
      const hit = bestMatch(tasks, String(a.match ?? ''), t => t.title);
      if (!hit) return { ok: false, summary: ar ? 'مالقيتش المهمة دي' : 'Task not found' };
      return { ok: true, summary: ar ? `محتاج تأكيدك عشان تمسح المهمة «${hit.title}»` : 'Confirm', pending: { id: newId(), kind: 'delete_task', targetId: hit.id, label: hit.title } };
    }

    /* ---------- journal / notes / habits / water / occasions ---------- */
    case 'create_journal_entry': {
      const date = parseDate(a.date) ?? today;
      const mood = a.mood == null ? null : clampInt(a.mood, 1, 5, 3) as 1 | 2 | 3 | 4 | 5;
      const entry = {
        id: newId(), date, kind: 'entry' as const, title: String(a.title ?? '').trim() || (ar ? 'يومياتي' : 'Journal'),
        body: String(a.body ?? '').trim(), mood, gratitude: Array.isArray(a.gratitude) ? a.gratitude.map(String).filter(Boolean).slice(0, 3) : [],
        tags: Array.isArray(a.tags) ? a.tags.map(String).filter(Boolean) : [], createdAt: Date.now(), updatedAt: Date.now(),
      };
      await db.put('journal_entries', entry);
      ctx.bump();
      return { ok: true, summary: ar ? 'اتكتبت التدوينة في يومياتك ✍️' : 'Journal entry saved',
        cards: [{ type: 'journal', title: ar ? 'تدوينتك الجديدة' : 'New entry', items: [{ date, title: entry.title, body: entry.body, mood }] }] };
    }
    case 'list_journal': {
      const list = (await db.all<any>('journal_entries')).filter(e => e.kind === 'entry').sort((x, y) => y.createdAt - x.createdAt);
      const items = list.slice(0, clampInt(a.limit, 1, 20, 5)).map(e => ({ date: e.date, title: e.title, body: e.body, mood: e.mood ?? null }));
      return { ok: true, summary: ar ? `${items.length} تدوينة` : `${items.length} entries`, data: items, cards: [{ type: 'journal', title: ar ? 'آخر يومياتك' : 'Latest entries', items }] };
    }
    case 'create_occasion': {
      const date = parseDate(a.date);
      if (!date) return { ok: false, summary: ar ? 'محتاج تاريخ واضح للمناسبة' : 'Need a date' };
      const occ: PersonalOccasion = {
        id: newId(), title: String(a.title).trim(), date, yearly: !!a.yearly, timeMin: a.time ? parseTimeMin(a.time) : null,
        remindDaysBefore: clampInt(a.remind_days_before, 0, 30, 1), color: '#7c3aed', note: '', createdAt: Date.now(),
      };
      await db.put('personal_occasions', occ);
      ctx.bump();
      await syncNative().catch(() => null);
      return { ok: true, summary: ar ? `اتضافت مناسبة «${occ.title}» يوم ${date}${occ.yearly ? ' (كل سنة)' : ''}` : `Occasion added`,
        cards: [{ type: 'occasions', title: ar ? 'مناسبتك الجديدة' : 'New occasion', items: [{ name: occ.title, date, official: false, kind: 'personal', image: '/media/onb-2.jpg', decor: 'ribbon', details: ar ? 'مناسبة شخصية — هتوصلك في الإشعارات والويدجيت.' : 'Personal occasion', notify: true }] }] };
    }
    case 'list_occasions': {
      const from = parseDate(a.from) ?? today;
      const to = parseDate(a.to) ?? addDays(from, 30);
      const personal = await db.all<PersonalOccasion>('personal_occasions');
      let list = occasionsInRange(from, to, s.hijriOffset, personal);
      if (a.only_official) list = list.filter(o => o.official);
      const items = list.slice(0, 40).map(toCardOcc(ar));
      return { ok: true, summary: ar ? `${items.length} مناسبة في الفترة` : `${items.length} occasions`, data: items.map(i => ({ name: i.name, date: i.date, official: i.official })), cards: [{ type: 'occasions', title: ar ? 'المناسبات' : 'Occasions', items }] };
    }
    case 'log_water': {
      const ml = clampInt(a.ml, 50, 3000, s.waterCupMl || 250);
      const nowD = new Date();
      await db.put('water_logs', { id: newId(), date: today, timeMin: nowD.getHours() * 60 + nowD.getMinutes(), amountMl: ml, createdAt: Date.now() });
      const total = (await db.all<any>('water_logs')).filter(w => w.date === today).reduce((x, w) => x + w.amountMl, 0);
      ctx.bump();
      return { ok: true, summary: ar ? `اتسجّل ${ml} مل مية 💧 — إجمالي النهارده ${total} مل` : `+${ml} ml`, data: { total }, cards: [{ type: 'water', ml: total, target: s.waterTargetMl }] };
    }
    case 'create_habit': {
      const h = { id: newId(), name: String(a.name).trim(), icon: 'flame', color: '#d97706', frequency: 'daily', targetPerWeek: 7, targetCount: clampInt(a.target_count, 1, 99, 1), unit: ar ? 'مرة' : 'times', reminderMin: null, category: 'personal', negative: false, createdAt: Date.now() };
      await db.put('habits', h);
      ctx.bump();
      return { ok: true, summary: ar ? `اتضافت العادة «${h.name}» 🔥` : `Habit added` };
    }
    case 'log_habit': {
      const habits = await db.all<any>('habits');
      const hit = bestMatch(habits, String(a.match ?? ''), h => h.name);
      if (!hit) return { ok: false, summary: ar ? 'مالقيتش العادة دي' : 'Habit not found' };
      await db.put('habit_logs', { id: `${hit.id}:${today}`, habitId: hit.id, date: today, count: hit.targetCount ?? 1 });
      ctx.bump();
      return { ok: true, summary: ar ? `اتسجّلت عادة «${hit.name}» النهارده ✓` : `Logged "${hit.name}"` };
    }
    case 'create_note': {
      const note = { id: newId(), title: String(a.title ?? '').trim(), body: String(a.body).trim(), tags: Array.isArray(a.tags) ? a.tags.map(String) : [], favorite: false, kind: 'note', checklist: [], createdAt: Date.now(), updatedAt: Date.now() };
      await db.put('notes', note);
      ctx.bump();
      return { ok: true, summary: ar ? 'اتكتبت الملاحظة 📝' : 'Note saved' };
    }

    /* ---------- focus / prayer / settings / navigation ---------- */
    case 'start_focus': {
      const minutes = clampInt(a.minutes, 1, 240, 25);
      const timer = { mode: 'countdown', phase: 'work', running: true, startedAt: Math.floor(Date.now() / 1000), accumulatedSec: 0, cycles: 0, workMin: minutes, breakMin: 0, totalPlannedMin: 0, taskTitle: String(a.task ?? '') };
      await db.settingSet('focusTimer', timer);
      ctx.navigate('focus');
      ctx.bump();
      return { ok: true, summary: ar ? `بدأت جلسة تركيز ${minutes} دقيقة ⏱️` : `Focus ${minutes} min` };
    }
    case 'get_prayer_times': {
      const g = govById(s.governorate);
      const t = computePrayerTimes(new Date(), g.lat, g.lng, s.prayerAdjust as any);
      const times = FARD.concat(['sunrise' as PrayerName]).map(n => ({ name: n, label: PRAYER_AR[n], time: hmText(t[n]) }));
      const card = { type: 'prayer' as const, title: ar ? `مواقيت ${g.ar} النهارده` : `Prayer times ${g.en}`, governorate: ar ? g.ar : g.en, times };
      return { ok: true, summary: ar ? `مواقيت ${g.ar}: الفجر ${hmText(t.fajr)} · الظهر ${hmText(t.dhuhr)} · المغرب ${hmText(t.maghrib)}` : 'Prayer times', data: times, cards: [card] };
    }
    case 'set_setting': {
      const key = String(a.key ?? '');
      const value = a.value;
      const patch = coerceSetting(key, value, ctx);
      if (!patch) return { ok: false, summary: ar ? `الإعداد «${key}» مش متاح للتغيير من المساعد` : 'Setting not allowed' };
      await db.saveSettings(patch);
      ctx.bump();
      return { ok: true, summary: ar ? `اتغيّر الإعداد ${key} ✓` : `Setting ${key} updated` };
    }
    case 'navigate': {
      const screen = String(a.screen ?? '');
      if (!SCREENS.includes(screen)) return { ok: false, summary: ar ? 'الشاشة دي مش موجودة' : 'Unknown screen' };
      ctx.navigate(screen);
      return { ok: true, summary: ar ? `فتحت شاشة ${screen}` : `Opened ${screen}` };
    }
    case 'show_card': {
      const type = String(a.type ?? '');
      switch (type) {
        case 'occasions': {
          const from = parseDate(a.date) ?? today; const to = parseDate(a.to) ?? addDays(from, 31);
          const personal = await db.all<PersonalOccasion>('personal_occasions');
          const items = occasionsInRange(from, to, s.hijriOffset, personal).slice(0, 25).map(toCardOcc(ar));
          return { ok: true, summary: ar ? 'معاينة المناسبات' : 'Occasions', cards: [{ type: 'occasions', title: ar ? 'المناسبات' : 'Occasions', items }] };
        }
        case 'schedule': return runTool('list_schedule', { date: a.date }, ctx);
        case 'prayer': return runTool('get_prayer_times', {}, ctx);
        case 'alarms': return runTool('list_alarms', {}, ctx);
        case 'tasks': return runTool('list_tasks', { filter: a.filter ?? 'open' }, ctx);
        case 'journal': return runTool('list_journal', { limit: 5 }, ctx);
        case 'water': {
          const total = (await db.all<any>('water_logs')).filter(w => w.date === today).reduce((x, w) => x + w.amountMl, 0);
          return { ok: true, summary: ar ? 'معاينة المية' : 'Water', cards: [{ type: 'water', ml: total, target: s.waterTargetMl }] };
        }
        case 'decor': return { ok: true, summary: ar ? 'معاينة الزينة' : 'Decor', cards: [{ type: 'decor', scene: String(a.scene ?? 'auto') }] };
        case 'summary': return runTool('get_app_summary', {}, ctx);
        default: return { ok: false, summary: ar ? 'نوع المعاينة مش معروف' : 'Unknown card' };
      }
    }
    case 'get_app_summary': {
      const blocks = (await db.all<ActivityBlock>('activity_blocks')).filter(b => b.date === today && b.status !== 'cancelled');
      const done = blocks.filter(b => b.status === 'done').length;
      const pending = blocks.filter(b => b.status === 'planned' || b.status === 'in_progress').length;
      const tasks = (await db.all<TaskItem>('tasks')).filter(t => t.status !== 'done' && t.status !== 'cancelled');
      const dueToday = tasks.filter(t => t.dueDate === today).length;
      const overdue = tasks.filter(t => t.dueDate && t.dueDate < today).length;
      const water = (await db.all<any>('water_logs')).filter(w => w.date === today).reduce((x, w) => x + w.amountMl, 0);
      const prayed = (await db.all<any>('prayer_logs')).filter(p => p.date === today).length;
      const focus = (await db.all<FocusSession>('focus_sessions')).filter(f => f.date === today).reduce((x, f) => x + (f.actualMin || 0), 0);
      const lines = ar
        ? [`الأنشطة: ${done} خلصت · ${pending} لسه`, `المهام: ${dueToday} النهارده · ${overdue} متأخرة`, `المية: ${water} مل من ${s.waterTargetMl}`, `الصلاة: ${prayed} من 5`, `التركيز: ${focus} دقيقة`]
        : [`Blocks: ${done} done · ${pending} pending`, `Tasks: ${dueToday} due today · ${overdue} overdue`, `Water: ${water}/${s.waterTargetMl} ml`, `Prayers: ${prayed}/5`, `Focus: ${focus} min`];
      return { ok: true, summary: lines.join(' · '), data: { done, pending, dueToday, overdue, water, prayed, focus }, cards: [{ type: 'summary', title: ar ? 'ملخص يومك' : "Today's summary", lines }] };
    }
    default:
      return { ok: false, summary: ar ? `الأداة «${name}» مش معروفة` : `Unknown tool ${name}` };
  }
}

function toCardOcc(ar: boolean) {
  return (o: Occasion) => ({
    name: ar ? o.nameAr : o.nameEn, date: o.date, official: o.official, kind: o.kind, image: o.image, decor: o.decor,
    details: ar ? o.detailsAr : o.detailsEn, notify: o.notify && !o.religion && o.kind !== 'christian' && o.kind !== 'jewish', religion: o.religion,
  });
}

const SETTING_RULES: Record<string, (v: any) => any> = {
  theme: v => (['light', 'dark', 'auto'].includes(String(v)) ? String(v) : undefined),
  skin: v => (['gemini', 'oneui', 'ios', 'aurora', 'frost', 'midnight', 'paper', 'sand', 'mint', 'ocean', 'rose', 'sunset'].includes(String(v)) ? String(v) : undefined),
  accent: v => (['indigo', 'teal', 'rose', 'amber', 'emerald', 'violet'].includes(String(v)) ? String(v) : undefined),
  language: v => (['ar', 'en'].includes(String(v)) ? String(v) : undefined),
  hour12: v => v === true || v === 'true' || v === 'نعم' ? true : v === false || v === 'false' || v === 'لا' ? false : undefined,
  decorations: v => (v === true || v === 'true' || v === 'نعم' ? true : v === false || v === 'false' || v === 'لا' ? false : undefined),
  particles: v => (v === true || v === 'true' || v === 'نعم' ? true : v === false || v === 'false' || v === 'لا' ? false : undefined),
  decorLayer: v => (['below', 'above'].includes(String(v)) ? String(v) : undefined),
  decorSpeed: v => (['slow', 'normal', 'fast'].includes(String(v)) ? String(v) : undefined),
  decorDensity: v => (['light', 'normal', 'dense'].includes(String(v)) ? String(v) : undefined),
  decorOpacity: v => { const n = Number(v); return Number.isFinite(n) ? Math.max(0.15, Math.min(1, n)) : undefined; },
  decorOverride: v => String(v) || 'auto',
  governorate: v => (govById(String(v)).id === String(v) ? String(v) : undefined),
  waterTargetMl: v => clampInt(v, 500, 6000, 2500),
  hijriOffset: v => clampInt(v, -2, 2, 0),
  userName: v => String(v).slice(0, 40),
};

function coerceSetting(key: string, value: any, ctx: ToolContext): Record<string, any> | null {
  const rule = SETTING_RULES[key];
  if (!rule) return null;
  const v = rule(value);
  if (v === undefined) return null;
  void ctx;
  return { [key]: v };
}

/* ---------------- pending confirmations (user taps ✓ in chat) ---------------- */
export async function executePending(p: PendingAction, ctx: ToolContext): Promise<ToolOutcome> {
  const ar = isAr(ctx);
  switch (p.kind) {
    case 'delete_alarm': {
      await db.del('user_alarms', p.targetId);
      await platform.deleteUserAlarm(p.targetId);
      break;
    }
    case 'delete_activity': await db.del('activity_blocks', p.targetId); await platform.cancelAlarm(p.targetId); break;
    case 'delete_task': await db.del('tasks', p.targetId); break;
    case 'delete_note': await db.del('notes', p.targetId); break;
    case 'delete_journal': await db.del('journal_entries', p.targetId); break;
    case 'delete_occasion': await db.del('personal_occasions', p.targetId); break;
  }
  ctx.bump();
  return { ok: true, summary: ar ? `اتمسح ${p.label} ✓` : `Deleted ${p.label}` };
}

export const TODAY_ISO = todayIso;
