/* DAYFLOW — Assistant configuration & conversation storage (on-device only).
   · API keys live under the 'ai_config' setting, which is NOT part of JSON backups (keys never leave the device).
   · Conversations are stored in the 'ai_chats' table with a bounded size. */
import { db, newId } from '@/lib/db';
import type { Tier, ModelInfo } from './providers';
import { PROVIDERS, sortModels } from './providers';
import type { AssistantCard, ActionLog, PendingAction } from './tools';
import type { CatalogState, CatalogEntry, Verification } from './liveCatalog';

export interface AIConfig {
  enabled: boolean;                       // off by default — the assistant is opt-in
  providerId: string;
  model: string;
  keys: Record<string, string>;           // providerId → API key (device-only)
  supportsTools: Record<string, boolean>; // providerId → false if the provider rejected tools
  liveModels: Record<string, ModelInfo[]>; // legacy hints, kept for migration only
  catalog: CatalogState;                  // authoritative live catalogue + verification results
  allowActions: boolean;                  // the assistant may create/modify data
  confirmDeletes: boolean;                // deletions always need a tap in chat (default true)
  shareContext: boolean;                  // send a short summary of the user's day to the model
}

export const DEFAULT_AI: AIConfig = {
  enabled: false,
  providerId: 'groq',
  model: 'openai/gpt-oss-120b',
  keys: {},
  supportsTools: {},
  liveModels: {},
  catalog: { updatedAt: 0, byProvider: {}, errors: {} },
  allowActions: true,
  confirmDeletes: true,
  shareContext: true,
};

export async function getAIConfig(): Promise<AIConfig> {
  const stored = (await db.settingGet<Partial<AIConfig>>('ai_config')) ?? {};
  return { ...DEFAULT_AI, ...stored, keys: { ...(stored.keys ?? {}) }, supportsTools: { ...(stored.supportsTools ?? {}) }, liveModels: { ...(stored.liveModels ?? {}) }, catalog: { ...DEFAULT_AI.catalog, ...(stored.catalog ?? {}), byProvider: { ...(stored.catalog?.byProvider ?? {}) }, errors: { ...(stored.catalog?.errors ?? {}) } } };
}

export async function saveAIConfig(patch: Partial<AIConfig>): Promise<AIConfig> {
  const cur = await getAIConfig();
  const next = { ...cur, ...patch };
  await db.settingSet('ai_config', next);
  return next;
}

/** Models for a provider: live list (if fetched) else curated list; always sorted free → credit → paid. */
/** Live catalogue first (authoritative). Static list only as clearly-labelled hints. */
export function modelsFor(providerId: string, cfg: AIConfig): CatalogEntry[] {
  const p = PROVIDERS.find(x => x.id === providerId);
  if (!p) return [];
  const live = cfg.catalog?.byProvider?.[providerId];
  if (live && live.length) return sortModels(live.filter(m => m.verification !== 'broken')) as CatalogEntry[];
  const hints: CatalogEntry[] = p.models.map(m => ({ ...m, verification: 'untested', source: 'hint' }));
  return sortModels(hints) as CatalogEntry[];
}

export function catalogIsLive(providerId: string, cfg: AIConfig): boolean {
  return !!(cfg.catalog?.byProvider?.[providerId]?.length);
}

/** Hide models the real test proved broken, and keep verification metadata. */
export async function markVerification(providerId: string, modelId: string, ok: boolean, error?: string): Promise<AIConfig> {
  const cfg = await getAIConfig();
  const list = cfg.catalog.byProvider[providerId] ?? [];
  const next = list.map(m => m.id === modelId ? { ...m, verification: (ok ? 'working' : 'broken') as Verification, error, checkedAt: Date.now() } : m);
  return saveAIConfig({ catalog: { ...cfg.catalog, updatedAt: Date.now(), byProvider: { ...cfg.catalog.byProvider, [providerId]: next } } });
}

export function tierOf(providerId: string, model: string, cfg: AIConfig): Tier {
  return modelsFor(providerId, cfg).find(m => m.id === model)?.tier ?? (PROVIDERS.find(p => p.id === providerId)?.tier ?? 'paid');
}

/* ---------------- conversations ---------------- */
export interface ChatMessageRow {
  id: string;
  role: 'user' | 'assistant' | 'error';
  content: string;
  createdAt: number;
  providerId?: string;
  model?: string;
  actions?: ActionLog[];
  cards?: AssistantCard[];
  pending?: PendingAction[];
}
export interface ChatRow { id: string; title: string; createdAt: number; updatedAt: number; messages: ChatMessageRow[] }

const MAX_MSGS = 200;

export async function listChats(): Promise<ChatRow[]> {
  return (await db.all<ChatRow>('ai_chats')).sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function saveChat(chat: ChatRow): Promise<void> {
  const trimmed: ChatRow = { ...chat, messages: chat.messages.slice(-MAX_MSGS), updatedAt: Date.now() };
  await db.put('ai_chats', trimmed);
}

export async function deleteChat(id: string): Promise<void> {
  await db.del('ai_chats', id);
}

export function newChat(title = 'محادثة جديدة'): ChatRow {
  return { id: newId(), title, createdAt: Date.now(), updatedAt: Date.now(), messages: [] };
}

export function titleFrom(text: string): string {
  const t = text.trim().replace(/\s+/g, ' ');
  return t.length > 42 ? `${t.slice(0, 42)}…` : t || 'محادثة جديدة';
}

export const PROMPT_SUGGESTIONS_AR = [
  'صحّيني الساعة ٧ الصبح كل يوم من الأحد للخميس',
  'ضيف مذاكرة كيمياء بكرة من ٥ لـ ٦ العصر',
  'اكتب في يومياتي إن يومي كان حلو وممتن لأمي',
  'وريني المناسبات الجاية في مصر',
  'ضيف مهمة: أدفع فاتورة النت النهارده',
  'عاوز أشوف جدول النهارده',
  'غيّر الثيم لـ Aurora وفعّل الزينة فوق المحتوى',
  'مواقيت الصلاة النهارده في القاهرة',
  'سجّل كوباية مية',
  'ابدأ جلسة تركيز ٢٥ دقيقة',
];
export const PROMPT_SUGGESTIONS_EN = [
  'Wake me at 7 every weekday',
  'Add study chemistry tomorrow 5 to 6 pm',
  'Write a journal entry about a good day',
  'Show me upcoming occasions in Egypt',
  'Add a task: pay internet bill today',
  "Show today's summary",
  'Switch theme to Aurora',
  'Prayer times today in Cairo',
  'Log a glass of water',
  'Start a 25 minute focus session',
];

export type { AssistantCard, ActionLog, PendingAction };
