/* DAYFLOW — Pure parsers for natural Arabic/English input used by the assistant's tools.
   No I/O, fully unit-tested. */

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
export function normalizeDigits(s: string): string {
  return s.replace(/[٠-٩]/g, d => String(AR_DIGITS.indexOf(d)));
}

/** "7", "7:30", "19:00", "٧ الصبح", "7 م", "7pm", "الساعة 9 بالليل", "12 الظهر" → minutes from midnight (or null). */
export function parseTimeMin(input: unknown): number | null {
  if (typeof input === 'number' && Number.isFinite(input)) return Math.max(0, Math.min(1439, Math.round(input)));
  if (typeof input !== 'string') return null;
  const s = normalizeDigits(input).trim().toLowerCase();
  const m = s.match(/(\d{1,2})(?:\s*[:٫.]\s*(\d{2}))?\s*(am|pm|ص|م|صباحا|صباحاً|مساء|مساءً|الصبح|الصباح|بالليل|الليل|الفجر|الظهر|العصر|بعد الظهر|المغرب|العشاء)?/);
  if (!m) return null;
  let h = parseInt(m[1], 10);
  const mm = m[2] ? parseInt(m[2], 10) : 0;
  const suffix = m[3] ?? '';
  if (mm > 59 || h > 24) return null;
  const pm = ['pm', 'م', 'مساء', 'مساءً', 'بالليل', 'الليل', 'بعد الظهر', 'المغرب', 'العشاء', 'الظهر', 'العصر'].includes(suffix);
  const am = ['am', 'ص', 'صباحا', 'صباحاً', 'الصبح', 'الصباح', 'الفجر'].includes(suffix);
  if (pm && h < 12) h += 12;
  if (am && h === 12) h = 0;
  if (!suffix && h >= 1 && h <= 6) {
    // Bare early hours like "7" in a daily-life context are usually PM-free; keep as given.
  }
  return (h % 24) * 60 + mm;
}

export function minToHHMM(min: number): string {
  const m = ((Math.round(min) % 1440) + 1440) % 1440;
  return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
}

const DAY_NAMES: Array<[string[], number]> = [
  [['الأحد', 'الاحد', 'sunday', 'sun'], 0],
  [['الاتنين', 'الإثنين', 'الاثنين', 'monday', 'mon'], 1],
  [['التلات', 'الثلاثاء', 'الثلاثا', 'tuesday', 'tue'], 2],
  [['الأربع', 'الاربع', 'الأربعاء', 'الاربعاء', 'wednesday', 'wed'], 3],
  [['الخميس', 'thursday', 'thu'], 4],
  [['الجمعة', 'الجمعه', 'friday', 'fri'], 5],
  [['السبت', 'saturday', 'sat'], 6],
];

/** Accepts [0..6], ["الاتنين","الجمعة"], "كل يوم", "أيام الشغل", "الويك اند" → sorted unique weekday numbers. */
export function parseDays(input: unknown): number[] {
  if (Array.isArray(input)) {
    const out = new Set<number>();
    for (const v of input) {
      if (typeof v === 'number' && v >= 0 && v <= 6) out.add(v);
      else if (typeof v === 'string') { const d = parseDays(v); d.forEach(x => out.add(x)); }
    }
    return [...out].sort((a, b) => a - b);
  }
  if (typeof input !== 'string') return [];
  const s = normalizeDigits(input).trim().toLowerCase();
  if (!s || s === 'مرة واحدة' || s === 'once' || s === 'none') return [];
  if (/كل يوم|يومي|كل الايام|كل الأيام|every ?day|daily/.test(s)) return [0, 1, 2, 3, 4, 5, 6];
  if (/أيام الشغل|ايام الشغل|weekdays?/.test(s)) return [0, 1, 2, 3, 4];
  if (/ويك ?اند|الويكند|weekend/.test(s)) return [5, 6];
  const out = new Set<number>();
  for (const [names, n] of DAY_NAMES) if (names.some(nm => s.includes(nm))) out.add(n);
  return [...out].sort((a, b) => a - b);
}

export function todayIso(now = new Date()): string {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

/** "اليوم/النهارده/today", "بكرة/غدًا/tomorrow", "بعد بكرة", "الأسبوع الجاي"(+7), YYYY-MM-DD, DD/MM(/YYYY) → ISO date. */
export function parseDate(input: unknown, now = new Date()): string | null {
  if (typeof input !== 'string' || !input.trim()) return null;
  const s = normalizeDigits(input).trim().toLowerCase();
  const addDaysIso = (n: number) => { const d = new Date(now); d.setDate(d.getDate() + n); return todayIso(d); };
  if (/^(اليوم|النهارده|النهاردة|today|now)$/.test(s)) return todayIso(now);
  if (/^(بكرة|بكره|بكرا|غدا|غداً|غدًا|tomorrow)$/.test(s)) return addDaysIso(1);
  if (/بعد بكرة|بعد بكره|after tomorrow/.test(s)) return addDaysIso(2);
  if (/الأسبوع الجاي|الاسبوع الجاي|next week/.test(s)) return addDaysIso(7);
  const iso = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (iso) return `${iso[1]}-${iso[2].padStart(2, '0')}-${iso[3].padStart(2, '0')}`;
  const dm = s.match(/^(\d{1,2})[\/.-](\d{1,2})(?:[\/.-](\d{2,4}))?$/);
  if (dm) {
    const y = dm[3] ? (dm[3].length === 2 ? `20${dm[3]}` : dm[3]) : String(now.getFullYear());
    return `${y}-${dm[2].padStart(2, '0')}-${dm[1].padStart(2, '0')}`;
  }
  return null;
}

const CATEGORY_MAP: Record<string, string> = {
  study: 'study', مذاكرة: 'study', دراسة: 'study', مذاكره: 'study',
  work: 'work', شغل: 'work', عمل: 'work', مشروع: 'work',
  exercise: 'exercise', رياضة: 'exercise', تمرين: 'exercise', جيم: 'exercise',
  rest: 'rest', راحة: 'rest', استراحة: 'rest',
  meal: 'meal', meals: 'meal', وجبة: 'meal', اكل: 'meal', أكل: 'meal', فطار: 'meal', غدا: 'meal', عشا: 'meal',
  sleep: 'sleep', نوم: 'sleep',
  water: 'water', ماء: 'water', مية: 'water',
  prayer: 'prayer', صلاة: 'prayer', صلاه: 'prayer',
  personal: 'personal', شخصي: 'personal',
  social: 'social', اجتماعي: 'social', زيارة: 'social', صحاب: 'social',
  health: 'health', صحة: 'health', دكتور: 'health',
  other: 'other', أخرى: 'other', اخرى: 'other',
};
export function parseCategory(input: unknown): string {
  if (typeof input !== 'string') return 'personal';
  const s = input.trim().toLowerCase();
  for (const [k, v] of Object.entries(CATEGORY_MAP)) if (s === k || s.includes(k)) return v;
  return 'personal';
}

export function clampInt(v: unknown, min: number, max: number, fallback: number): number {
  const n = typeof v === 'number' ? v : parseInt(String(v ?? ''), 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.round(n)));
}

/** Basic similarity used to resolve “the chemistry block” style references. */
export function matchScore(query: string, text: string): number {
  const q = query.trim().toLowerCase();
  const t = text.trim().toLowerCase();
  if (!q || !t) return 0;
  if (t === q) return 100;
  if (t.includes(q)) return 80;
  const qw = q.split(/\s+/).filter(w => w.length > 1);
  if (!qw.length) return 0;
  const hit = qw.filter(w => t.includes(w)).length;
  return Math.round((hit / qw.length) * 60);
}
