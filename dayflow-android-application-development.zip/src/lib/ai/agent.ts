/* DAYFLOW — Agent loop: the model reasons, calls real app tools, sees real results, and answers.
   · Native function calling when the provider supports it.
   · Text-protocol fallback (```tool {...}```) for models without tool support, so EVERY model can act.
   · Hard limits: max steps, max tool calls, no silent failures — errors are shown to the user. */
import type { ProviderInfo } from './providers';
import { chatCompletion, AIError, type ChatMessage } from './client';
import { TOOL_SPECS, runTool, type ActionLog, type AssistantCard, type PendingAction, type ToolContext } from './tools';
import { todayIso } from './parse';

export interface HistoryMsg { role: 'user' | 'assistant'; content: string }
export interface AgentResult { reply: string; actions: ActionLog[]; cards: AssistantCard[]; pending: PendingAction[] }

const MAX_STEPS = 6;

function buildSystemPrompt(ctx: ToolContext, shareContext: boolean): string {
  const ar = ctx.settings.language === 'ar';
  const now = new Date();
  const hh = String(now.getHours()).padStart(2, '0'), mm = String(now.getMinutes()).padStart(2, '0');
  const who = ctx.settings.userName ? (ar ? `اسمه ${ctx.settings.userName}` : `his/her name is ${ctx.settings.userName}`) : '';
  if (!ar) {
    return `You are "DAYFLOW Assistant", an agent inside the DAYFLOW personal-life app (Android). Today is ${todayIso(now)}, local time ${hh}:${mm} (Africa/Cairo). ${who}.
You MUST act through tools for every change the user asks for (alarms, activities, tasks, journal, occasions, water, notes, settings, navigation). Never claim an action happened unless a tool returned ok. Use show_card when the user asks to see something. Keep replies short, friendly and clear. Ask only when a required detail is missing. Never give medical advice. ${shareContext ? '' : 'Do not request personal data beyond what the user states.'}`;
  }
  return `أنت "مساعد مدير اليوم"، وكيل ذكي جوه تطبيق DAYFLOW على الأندرويد. اتكلم بالعامية المصرية المفهومة والودودة.
النهارده ${todayIso(now)} والساعة ${hh}:${mm} (توقيت القاهرة). ${who ? `المستخدم ${who}.` : ''}
القواعد الأساسية:
1) أي تغيير طلبه المستخدم (منبه، نشاط، مهمة، يومية، مناسبة، مية، ملاحظة، إعداد، فتح شاشة) لازم تنفذه بالأداة المناسبة — ما تقولش "اتعمل" غير لما الأداة ترجع ok.
2) لو المستخدم قال "وريني" أو "اعرضلي" استخدم show_card عشان يظهر له معاينة حية في الشات.
3) قبل ما تجاوب عن حالة يومه استخدم get_app_summary.
4) الحذف بيحتاج تأكيد المستخدم من الشات — قول له إنك جهزت الطلب واستنى ضغطة التأكيد.
5) لو معلومة ناقصة (ساعة، يوم) اسأل سؤال واحد واضح بدل ما تخمن.
6) الردود قصيرة ومرتبة. متقولش نصايح طبية. ومتخترعش بيانات.
7) الشاشات المتاحة: today, plan, calendar, more, focus, progress, tasks, study, workouts, habits, goals, notes, notifications, settings, journal, alarms, prayer, assistant.`;
}

/** Text protocol: ```tool\n{"name":"...","arguments":{...}}\n``` (or ```json). */
function parseTextToolCalls(content: string | null): Array<{ name: string; args: Record<string, any> }> {
  if (!content) return [];
  const out: Array<{ name: string; args: Record<string, any> }> = [];
  const re = /```(?:tool|json)?\s*([\s\S]*?)```/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(content))) {
    try {
      const j = JSON.parse(m[1].trim());
      if (j && typeof j.name === 'string') out.push({ name: j.name, args: j.arguments ?? j.args ?? {} });
    } catch { /* not a tool block */ }
  }
  return out.slice(0, 4);
}

function stripToolBlocks(content: string | null): string {
  return (content ?? '').replace(/```(?:tool|json)?\s*[\s\S]*?```/gi, '').trim();
}

function safeArgs(raw: unknown): Record<string, any> {
  if (raw && typeof raw === 'object') return raw as Record<string, any>;
  try { return JSON.parse(String(raw ?? '{}')); } catch { return {}; }
}

export async function runAgent(opts: {
  provider: ProviderInfo; apiKey: string; model: string; history: HistoryMsg[]; userText: string;
  ctx: ToolContext; shareContext: boolean; supportsTools: boolean;
}): Promise<AgentResult> {
  const { provider, apiKey, model, history, userText, ctx } = opts;
  const messages: ChatMessage[] = [
    { role: 'system', content: buildSystemPrompt(ctx, opts.shareContext) },
    ...history.slice(-14).map(h => ({ role: h.role, content: h.content }) as ChatMessage),
    { role: 'user', content: userText },
  ];
  const actions: ActionLog[] = [];
  const cards: AssistantCard[] = [];
  const pending: PendingAction[] = [];
  let useNativeTools = opts.supportsTools;
  let reply = '';

  for (let step = 0; step < MAX_STEPS; step++) {
    let msg: ChatMessage;
    try {
      msg = await chatCompletion({ provider, apiKey, model, messages, tools: useNativeTools ? TOOL_SPECS : undefined });
    } catch (e) {
      // Some providers reject the tools field → retry once with the text protocol.
      if (useNativeTools && e instanceof AIError && e.kind === 'bad_request') {
        useNativeTools = false;
        msg = await chatCompletion({ provider, apiKey, model, messages });
      } else throw e;
    }

    const nativeCalls = msg.tool_calls ?? [];
    if (nativeCalls.length) {
      messages.push({ role: 'assistant', content: msg.content ?? null, tool_calls: nativeCalls });
      for (const call of nativeCalls.slice(0, 6)) {
        const args = safeArgs(call.function?.arguments);
        const out = await runTool(call.function.name, args, ctx);
        actions.push({ tool: call.function.name, ok: out.ok, summary: out.summary, pending: out.pending });
        if (out.cards) cards.push(...out.cards);
        if (out.pending) pending.push(out.pending);
        messages.push({ role: 'tool', tool_call_id: call.id, name: call.function.name, content: JSON.stringify({ ok: out.ok, summary: out.summary, data: out.data ?? null, pending: !!out.pending }) });
      }
      continue;
    }

    const textCalls = parseTextToolCalls(msg.content);
    if (textCalls.length) {
      messages.push({ role: 'assistant', content: msg.content ?? '' });
      const results: string[] = [];
      for (const c of textCalls) {
        const out = await runTool(c.name, c.args, ctx);
        actions.push({ tool: c.name, ok: out.ok, summary: out.summary, pending: out.pending });
        if (out.cards) cards.push(...out.cards);
        if (out.pending) pending.push(out.pending);
        results.push(`${c.name}: ${JSON.stringify({ ok: out.ok, summary: out.summary, data: out.data ?? null })}`);
      }
      messages.push({ role: 'user', content: `نتيجة الأدوات:\n${results.join('\n')}\nكمّل بالرد النهائي للمستخدم بدون أي كود.` });
      continue;
    }

    reply = stripToolBlocks(msg.content) || (actions.length ? '' : 'تمام.');
    break;
  }

  if (!reply) {
    const ok = actions.filter(a => a.ok).length;
    reply = actions.length
      ? (ctx.settings.language === 'ar' ? `خلصت ${ok} من ${actions.length} إجراء. شوف التفاصيل تحت.` : `Done ${ok}/${actions.length} actions.`)
      : (ctx.settings.language === 'ar' ? 'معلش، ما قدرتش أكمّل الطلب ده. ممكن تقول تفاصيل أكتر؟' : 'Could not complete. Please add details.');
  }
  return { reply, actions, cards, pending };
}
