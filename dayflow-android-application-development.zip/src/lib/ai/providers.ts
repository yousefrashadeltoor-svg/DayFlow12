/* DAYFLOW — AI provider & model registry (OpenAI-compatible APIs)
   · Every provider exposes the same /chat/completions contract, so one client serves all of them.
   · Each model carries a REAL tier: 'free' (no payment ever), 'credit' (free trial/monthly credit), 'paid'.
   · Logos: official brand marks from simple-icons (bundled locally, works offline) with brand-color monograms as fallback.
   · OpenRouter's live catalogue is classified from its own pricing fields (prompt=0 & completion=0 ⇒ free). */
import {
  siOpenrouter, siGooglegemini, siMistralai, siNvidia, siHuggingface, siDeepseek,
  siMeta, siQwen, siAnthropic, siPerplexity,
} from 'simple-icons';

export type Tier = 'free' | 'credit' | 'paid';

export interface ModelInfo {
  id: string;
  name: string;
  family: string;      // used to pick the model's logo
  tier: Tier;
  context?: string;    // human readable context window
  tools?: boolean;     // supports native function calling
  note?: string;
}

export interface ProviderInfo {
  id: string;
  name: string;
  baseUrl: string;
  keyUrl: string;      // where the user gets a key (shown as text, no auto navigation)
  color: string;       // brand accent for monogram fallback
  mono: string;        // monogram letter(s)
  icon?: string;       // simple-icons key (see BRAND_ICONS)
  tier: Tier;          // best free offer of the provider
  freeSummary: string; // Egyptian Arabic summary of the free offer
  dynamic?: boolean;   // model list can be fetched live (/models)
  models: ModelInfo[];
}

export const TIER_LABEL: Record<Tier, { ar: string; en: string; color: string }> = {
  free: { ar: 'مجاني', en: 'Free', color: '#16a34a' },
  credit: { ar: 'رصيد مجاني', en: 'Free credit', color: '#0284c7' },
  paid: { ar: 'مدفوع', en: 'Paid', color: '#dc2626' },
};

export const PROVIDERS: ProviderInfo[] = [
  {
    id: 'groq', name: 'Groq', mono: 'G', color: '#f55036', tier: 'free',
    baseUrl: 'https://api.groq.com/openai/v1', keyUrl: 'console.groq.com/keys',
    freeSummary: 'مجاني بدون كارت — حد يومي لكل موديل (مثلاً gpt-oss-120b: ١٠٠٠ طلب في اليوم) وسرعة استجابة عالية جداً.',
    models: [
      { id: 'openai/gpt-oss-120b', name: 'GPT-OSS 120B', family: 'openai', tier: 'free', context: '131K', tools: true, note: 'أقوى موديل مجاني للأدوات والتفكير' },
      { id: 'openai/gpt-oss-20b', name: 'GPT-OSS 20B', family: 'openai', tier: 'free', context: '131K', tools: true, note: 'سريع جداً للمهام اليومية' },
      { id: 'qwen/qwen3.8-27b', name: 'Qwen 3.8 27B (Preview)', family: 'qwen', tier: 'free', context: '131K', tools: true, note: 'موديل معاينة مجاني' },
      { id: 'qwen/qwen3.6-27b', name: 'Qwen 3.6 27B', family: 'qwen', tier: 'free', context: '131K', tools: true },
      { id: 'groq/compound-mini', name: 'Groq Compound Mini', family: 'groq', tier: 'free', context: '128K', tools: false },
    ],
  },
  {
    id: 'openrouter', name: 'OpenRouter', mono: 'OR', color: '#6366f1', tier: 'free', icon: 'openrouter',
    baseUrl: 'https://openrouter.ai/api/v1', keyUrl: 'openrouter.ai/keys', dynamic: true,
    freeSummary: 'أكتر من ٢٠ موديل مجاني بالكامل (أي موديل ID بيخلص بـ :free). الكتالوج بيتحدّث، والزرار «اختبار» بيجيب القايمة الحية ويصنّفها.',
    models: [
      { id: 'openrouter/free', name: 'Free Models Router', family: 'openrouter', tier: 'free', context: '200K', tools: true, note: 'بيختار لوحده موديل مجاني مناسب' },
      { id: 'google/gemma-4-31b-it:free', name: 'Gemma 4 31B', family: 'google', tier: 'free', context: '262K', tools: true },
      { id: 'google/gemma-4-26b-a4b-it:free', name: 'Gemma 4 26B', family: 'google', tier: 'free', context: '262K', tools: true },
      { id: 'nvidia/nemotron-3-ultra-550b-a55b:free', name: 'Nemotron 3 Ultra 550B', family: 'nvidia', tier: 'free', context: '1M', tools: true },
      { id: 'nvidia/nemotron-3.5-lightning:free', name: 'Nemotron 3.5 Lightning', family: 'nvidia', tier: 'free', context: '1M', tools: true },
      { id: 'nvidia/nemotron-3.5-super-vl:free', name: 'Nemotron 3.5 Super VL', family: 'nvidia', tier: 'free', context: '1M', tools: true },
      { id: 'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free', name: 'Nemotron Nano Omni 30B', family: 'nvidia', tier: 'free', context: '256K', tools: true },
      { id: 'liquid/lfm-3-1.7b:free', name: 'LFM 3 1.7B', family: 'generic', tier: 'free', context: '262K', tools: true },
      { id: 'recursive/flint-v1.0:free', name: 'Flint 1.0', family: 'generic', tier: 'free', context: '262K', tools: true },
      { id: 'particle-ai/particle-1:free', name: 'Particle 1', family: 'generic', tier: 'free', context: '1M', tools: true },
      { id: 'inclusionai/ling-3.2-flash:free', name: 'Ling 3.2 Flash', family: 'generic', tier: 'free', context: '1M', tools: true },
      { id: 'baidu/ernie-5.5-flash-preview:free', name: 'ERNIE 5.5 Flash', family: 'generic', tier: 'free', context: '1M', tools: true },
    ],
  },
  {
    id: 'gemini', name: 'Google Gemini', mono: 'G', color: '#4285f4', tier: 'free', icon: 'google',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai', keyUrl: 'aistudio.google.com/apikey',
    freeSummary: 'طبقة مجانية في Google AI Studio بحدود يومية للطلبات والتوكنز — مفتاح من غير دفع.',
    models: [
      { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', family: 'google', tier: 'free', context: '1M', tools: true },
      { id: 'gemini-2.5-flash-lite', name: 'Gemini 2.5 Flash-Lite', family: 'google', tier: 'free', context: '1M', tools: true },
      { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro', family: 'google', tier: 'free', context: '1M', tools: true, note: 'الطبقة المجانية بتختلف حسب الحساب — اختبره' },
    ],
  },
  {
    id: 'cerebras', name: 'Cerebras', mono: 'CB', color: '#f97316', tier: 'credit',
    baseUrl: 'https://api.cerebras.ai/v1', keyUrl: 'cloud.cerebras.ai',
    freeSummary: 'رصيد تجريبي (حوالي ٥ دولار ينتهي خلال ٣٠ يوم) — مش طبقة مجانية دائمة. استخدم زر «تحديث القائمة» عشان تشوف الموديلات المتاحة فعلاً لحسابك.',
    models: [
      { id: 'gpt-oss-120b', name: 'GPT-OSS 120B', family: 'openai', tier: 'credit', context: '128K', tools: true },
      { id: 'qwen-3.8-27b', name: 'Qwen 3.8 27B', family: 'qwen', tier: 'credit', context: '128K', tools: true },
    ],
  },
  {
    id: 'mistral', name: 'Mistral AI', mono: 'M', color: '#fa520f', tier: 'free', icon: 'mistral',
    baseUrl: 'https://api.mistral.ai/v1', keyUrl: 'console.mistral.ai/api-keys',
    freeSummary: 'الخطة المجانية (Experiment) بتدي الموديلات المفتوحة بس: Nemo وMistral 7B وCodestral. موديلات Small/Medium/Large بترجع 429 على المفتاح المجاني.',
    models: [
      { id: 'open-mistral-nemo', name: 'Mistral Nemo', family: 'mistral', tier: 'free', context: '128K', tools: true },
      { id: 'open-mistral-7b', name: 'Mistral 7B', family: 'mistral', tier: 'free', context: '32K', tools: true },
      { id: 'codestral-latest', name: 'Codestral', family: 'mistral', tier: 'free', context: '32K', tools: true },
      { id: 'mistral-small-latest', name: 'Mistral Small (مدفوع)', family: 'mistral', tier: 'paid', context: '256K', tools: true },
    ],
  },
  {
    id: 'nvidia', name: 'NVIDIA Build', mono: 'NV', color: '#76b900', tier: 'credit', icon: 'nvidia',
    baseUrl: 'https://integrate.api.nvidia.com/v1', keyUrl: 'build.nvidia.com',
    freeSummary: 'رصيد تجريبي مجاني لكل حساب على NVIDIA Build لتجربة موديلات Llama وNemotron وDeepSeek.',
    models: [
      { id: 'meta/llama-3.1-8b-instruct', name: 'Llama 3.1 8B', family: 'meta', tier: 'credit', context: '128K', tools: true },
      { id: 'nvidia/llama-3.3-nemotron-super-49b-v1', name: 'Nemotron Super 49B', family: 'nvidia', tier: 'credit', context: '128K', tools: true },
      { id: 'deepseek-ai/deepseek-r1', name: 'DeepSeek R1', family: 'deepseek', tier: 'credit', context: '128K', tools: false },
    ],
  },
  {
    id: 'huggingface', name: 'Hugging Face', mono: 'HF', color: '#ffd21e', tier: 'credit', icon: 'huggingface',
    baseUrl: 'https://router.huggingface.co/v1', keyUrl: 'huggingface.co/settings/tokens',
    freeSummary: 'رصيد شهري مجاني لكل حساب عبر Inference Providers — بيغطي موديلات مفتوحة كتير.',
    models: [
      { id: 'meta-llama/Llama-3.1-8B-Instruct', name: 'Llama 3.1 8B', family: 'meta', tier: 'credit', context: '128K', tools: true },
      { id: 'Qwen/Qwen2.5-72B-Instruct', name: 'Qwen 2.5 72B', family: 'qwen', tier: 'credit', context: '32K', tools: true },
    ],
  },
  {
    id: 'together', name: 'Together AI', mono: 'TG', color: '#0f6fff', tier: 'credit',
    baseUrl: 'https://api.together.xyz/v1', keyUrl: 'api.together.ai/settings/api-keys',
    freeSummary: 'رصيد ترحيبي لحسابات جديدة لتجربة موديلات Llama وQwen وDeepSeek.',
    models: [
      { id: 'meta-llama/Llama-3.3-70B-Instruct-Turbo', name: 'Llama 3.3 70B Turbo', family: 'meta', tier: 'credit', context: '128K', tools: true },
    ],
  },
  {
    id: 'cohere', name: 'Cohere', mono: 'CO', color: '#39594d', tier: 'credit',
    baseUrl: 'https://api.cohere.ai/compatibility/v1', keyUrl: 'dashboard.cohere.com/api-keys',
    freeSummary: 'مفتاح Trial مجاني للتجربة بحدود دقيقة وشهرية.',
    models: [
      { id: 'command-a-03-2025', name: 'Command A', family: 'cohere', tier: 'credit', context: '256K', tools: true },
    ],
  },
  {
    id: 'deepseek', name: 'DeepSeek', mono: 'DS', color: '#5786fe', tier: 'paid', icon: 'deepseek',
    baseUrl: 'https://api.deepseek.com/v1', keyUrl: 'platform.deepseek.com/api_keys',
    freeSummary: 'مدفوع بسعر منخفض جداً لكل مليون توكن (مفيش طبقة مجانية دائمة).',
    models: [
      { id: 'deepseek-chat', name: 'DeepSeek V3', family: 'deepseek', tier: 'paid', context: '128K', tools: true },
      { id: 'deepseek-reasoner', name: 'DeepSeek R1 (reasoning)', family: 'deepseek', tier: 'paid', context: '128K', tools: false },
    ],
  },
  {
    id: 'openai', name: 'OpenAI', mono: 'AI', color: '#10a37f', tier: 'paid',
    baseUrl: 'https://api.openai.com/v1', keyUrl: 'platform.openai.com/api-keys',
    freeSummary: 'مدفوع. موديلات قوية ومستقرة جداً مع دعم كامل للأدوات.',
    models: [
      { id: 'gpt-4.1-mini', name: 'GPT-4.1 mini', family: 'openai', tier: 'paid', context: '1M', tools: true },
      { id: 'gpt-4o-mini', name: 'GPT-4o mini', family: 'openai', tier: 'paid', context: '128K', tools: true },
    ],
  },
];

/* Brand marks bundled locally (simple-icons). Keys match ProviderInfo.icon / family logos. */
export const BRAND_ICONS: Record<string, { path: string; hex: string; title: string }> = {
  openrouter: siOpenrouter,
  google: siGooglegemini,
  mistral: siMistralai,
  nvidia: siNvidia,
  huggingface: siHuggingface,
  deepseek: siDeepseek,
  meta: siMeta,
  qwen: siQwen,
  anthropic: siAnthropic,
  perplexity: siPerplexity,
};

/** Family → logo (brand icon when available, else monogram). */
export const FAMILY_LOGO: Record<string, { icon?: string; mono: string; color: string; label: string }> = {
  openai: { mono: 'AI', color: '#10a37f', label: 'OpenAI' },
  meta: { icon: 'meta', mono: 'LL', color: '#0467df', label: 'Meta Llama' },
  qwen: { icon: 'qwen', mono: 'Q', color: '#6950ef', label: 'Qwen' },
  google: { icon: 'google', mono: 'G', color: '#8e75b2', label: 'Google Gemma' },
  mistral: { icon: 'mistral', mono: 'M', color: '#fa520f', label: 'Mistral' },
  deepseek: { icon: 'deepseek', mono: 'DS', color: '#5786fe', label: 'DeepSeek' },
  nvidia: { icon: 'nvidia', mono: 'NV', color: '#76b900', label: 'NVIDIA' },
  cohere: { mono: 'CO', color: '#39594d', label: 'Cohere' },
  anthropic: { icon: 'anthropic', mono: 'AN', color: '#d97757', label: 'Anthropic' },
  openrouter: { icon: 'openrouter', mono: 'OR', color: '#6366f1', label: 'OpenRouter' },
  groq: { mono: 'G', color: '#f55036', label: 'Groq' },
  generic: { mono: 'AI', color: '#64748b', label: 'AI' },
};

export function familyOf(modelId: string): string {
  const m = modelId.toLowerCase();
  if (m.includes('gpt-oss') || m.includes('gpt-') || m.includes('openai')) return 'openai';
  if (m.includes('llama') || m.includes('meta')) return 'meta';
  if (m.includes('qwen')) return 'qwen';
  if (m.includes('gemma') || m.includes('gemini') || m.includes('google')) return 'google';
  if (m.includes('mistral') || m.includes('mixtral') || m.includes('nemo') || m.includes('magistral')) return 'mistral';
  if (m.includes('deepseek')) return 'deepseek';
  if (m.includes('nemotron') || m.includes('nvidia')) return 'nvidia';
  if (m.includes('command') || m.includes('cohere') || m.includes('north')) return 'cohere';
  if (m.includes('claude') || m.includes('anthropic')) return 'anthropic';
  if (m.includes('openrouter')) return 'openrouter';
  return 'generic';
}

export const providerById = (id: string) => PROVIDERS.find(p => p.id === id);

/** Real classification for OpenRouter's live /models payload. */
export interface LiveModel { id: string; name?: string; context_length?: number; pricing?: { prompt?: string; completion?: string }; supported_parameters?: string[]; architecture?: { output_modalities?: string[] }; output_modalities?: string[] }
export function classifyOpenRouter(list: LiveModel[]): ModelInfo[] {
  return list
    .filter(m => m && typeof m.id === 'string')
    .map(m => {
      const zero = String(m.pricing?.prompt ?? '1') === '0' && String(m.pricing?.completion ?? '1') === '0';
      const free = m.id.endsWith(':free') || zero;
      return {
        id: m.id,
        name: m.name || m.id,
        family: familyOf(m.id),
        tier: free ? 'free' : 'paid',
        context: m.context_length ? `${Math.round(m.context_length / 1000)}K` : undefined,
        tools: !!m.supported_parameters?.includes('tools'),
      } as ModelInfo;
    });
}

/** Free models first, then credit, then paid; alphabetical inside a group. */
export function sortModels(models: ModelInfo[]): ModelInfo[] {
  const rank: Record<Tier, number> = { free: 0, credit: 1, paid: 2 };
  return [...models].sort((a, b) => rank[a.tier] - rank[b.tier] || a.name.localeCompare(b.name));
}
