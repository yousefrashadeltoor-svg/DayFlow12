/* DAYFLOW — Network client for the optional AI assistant.
   · Native Android → Capacitor's native HTTP (no browser CORS restrictions).
   · Web preview → fetch. If the browser blocks a provider (CORS), the error says so honestly.
   · Only the assistant calls this file. The rest of the app never touches the network. */
import { Capacitor, CapacitorHttp } from '@capacitor/core';
import type { ProviderInfo, LiveModel, ModelInfo } from './providers';
import { classifyOpenRouter } from './providers';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | null;
  tool_calls?: Array<{ id: string; type: 'function'; function: { name: string; arguments: string } }>;
  tool_call_id?: string;
  name?: string;
}

export interface ToolSpec {
  type: 'function';
  function: { name: string; description: string; parameters: Record<string, unknown> };
}

export class AIError extends Error {
  constructor(public kind: 'auth' | 'quota' | 'model' | 'network' | 'cors' | 'server' | 'bad_request', message: string) { super(message); }
}

async function request(method: 'GET' | 'POST', url: string, headers: Record<string, string>, body?: unknown): Promise<{ status: number; data: any }> {
  const h = { Accept: 'application/json', ...headers, ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) };
  if (Capacitor.isNativePlatform()) {
    const r = await CapacitorHttp.request({ url, method, headers: h, data: body, connectTimeout: 30000, readTimeout: 120000 });
    return { status: r.status, data: r.data };
  }
  let res: Response;
  try {
    res = await fetch(url, { method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined });
  } catch {
    throw new AIError('cors', 'المتصفح منع الاتصال بالمزوّد (CORS) أو مفيش إنترنت. جرّب تطبيق الأندرويد — هناك الاتصال بيتم من غير قيود المتصفح.');
  }
  let data: any = null;
  try { data = await res.json(); } catch { data = null; }
  return { status: res.status, data };
}

function explain(status: number, data: any): AIError {
  const msg = (data?.error?.message ?? data?.message ?? data?.detail ?? '').toString();
  if (status === 401 || status === 403) return new AIError('auth', 'المفتاح غلط أو مش مفعّل عند المزوّد. راجع المفتاح من صفحة الإعدادات.');
  if (status === 429) return new AIError('quota', 'وصلت للحد المجاني للاستخدام دلوقتي. جرّب موديل تاني أو استنى شوية (الحدود بتتجدد).');
  if (status === 404) return new AIError('model', `الموديل ده مش متاح عند المزوّد ${msg ? `(${msg.slice(0, 120)})` : ''}. اختار موديل تاني.`);
  if (status >= 500) return new AIError('server', 'المزوّد عنده مشكلة مؤقتة. جرّب تاني بعد لحظات.');
  return new AIError('bad_request', msg ? `رفض المزوّد الطلب: ${msg.slice(0, 200)}` : `خطأ غير متوقع (${status}).`);
}

function authHeaders(provider: ProviderInfo, key: string): Record<string, string> {
  const h: Record<string, string> = { Authorization: `Bearer ${key}` };
  if (provider.id === 'openrouter') h['X-Title'] = 'DAYFLOW';
  return h;
}

export async function chatCompletion(opts: {
  provider: ProviderInfo; apiKey: string; model: string; messages: ChatMessage[]; tools?: ToolSpec[];
}): Promise<ChatMessage> {
  const body: Record<string, unknown> = { model: opts.model, messages: opts.messages, temperature: 0.4, max_tokens: 1400 };
  if (opts.tools && opts.tools.length) { body.tools = opts.tools; body.tool_choice = 'auto'; }
  const r = await request('POST', `${opts.provider.baseUrl}/chat/completions`, authHeaders(opts.provider, opts.apiKey), body);
  if (r.status >= 300) throw explain(r.status, r.data);
  const msg = r.data?.choices?.[0]?.message;
  if (!msg) throw new AIError('server', 'المزوّد رجّع رد فاضي. جرّب تاني.');
  return msg as ChatMessage;
}

/** Fetch live model list (validates the key too). OpenRouter is classified from its real pricing. */
export async function testAndListModels(provider: ProviderInfo, apiKey: string): Promise<{ count: number; free: number; models: ModelInfo[] }> {
  const r = await request('GET', `${provider.baseUrl}/models`, authHeaders(provider, apiKey));
  if (r.status >= 300) throw explain(r.status, r.data);
  const list: LiveModel[] = Array.isArray(r.data?.data) ? r.data.data : [];
  if (provider.id === 'openrouter') {
    const models = classifyOpenRouter(list).filter(m => m.tier === 'free' || m.id.startsWith('openai/') || m.id.startsWith('google/'));
    return { count: list.length, free: models.filter(m => m.tier === 'free').length, models: models.slice(0, 300) };
  }
  const models: ModelInfo[] = list.map(m => ({ id: m.id, name: m.id, family: 'generic', tier: provider.tier, tools: true }));
  return { count: list.length, free: provider.tier === 'free' ? list.length : 0, models: models.slice(0, 300) };
}
