/* DAYFLOW — Live model catalogue (the ONLY trustworthy source of model availability).
   Static lists are just hints; once a key exists we fetch the provider's own /models endpoint:
   · only chat/text models are kept (audio, TTS, embeddings, image, moderation are excluded)
   · OpenRouter: classified from its real pricing (0/0 or :free ⇒ free)
   · Groq/Mistral/Cerebras/Gemini/etc.: "free" list is a documented whitelist; everything else is
     marked 'unknown' (never falsely claimed free) until the user presses "اختبر" on that model.
   · a tiny real chat request per model marks it WORKING / BROKEN with the exact reason. */
import { Capacitor, CapacitorHttp } from '@capacitor/core';
import { PROVIDERS, type ModelInfo, type Tier, type LiveModel, classifyOpenRouter, familyOf } from './providers';

export type Verification = 'working' | 'broken' | 'untested' | 'testing';

export interface CatalogEntry extends ModelInfo {
  verification: Verification;
  error?: string;
  checkedAt?: number;
  source: 'live' | 'hint';
}

export interface CatalogState {
  updatedAt: number;
  byProvider: Record<string, CatalogEntry[]>;
  errors: Record<string, string>;
}

const NON_CHAT = /(whisper|tts|speech|audio|orpheus|embedding|embed|rerank|moderation|guard|image|vision-preview|lyria|music|video|transcribe|stable-diffusion|flux|dall[- ]?e|sora|imagen|veo)/i;
const isChatModel = (m: LiveModel) => {
  const id = String(m.id ?? '');
  if (NON_CHAT.test(id)) return false;
  const mods = m.architecture?.output_modalities ?? m.output_modalities;
  if (Array.isArray(mods) && mods.length && !mods.includes('text')) return false;
  return true;
};

/** Documented free chat models (used only until the live /models check runs). */
export const FREE_HINTS: Record<string, string[]> = {
  groq: ['openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'qwen/qwen3.8-27b', 'qwen/qwen3.6-27b', 'groq/compound-mini'],
  mistral: ['open-mistral-nemo', 'open-mistral-7b', 'codestral-latest'],
  gemini: ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.0-flash'],
  cerebras: [], // free trial credit, NOT a permanently free tier
  openrouter: [], // pricing classified live
  nvidia: [], huggingface: [], together: [], cohere: [], deepseek: [], openai: [],
};

function tierFor(providerId: string, m: LiveModel, pTier: Tier): Tier {
  if (providerId === 'openrouter') {
    const zero = Number(m.pricing?.prompt ?? 1) === 0 && Number(m.pricing?.completion ?? 1) === 0;
    return m.id.endsWith(':free') || zero ? 'free' : 'paid';
  }
  if (FREE_HINTS[providerId]?.some(f => m.id === f || m.id.startsWith(f))) return 'free';
  if (pTier === 'credit') return 'credit';
  return 'paid';
}

const extra = (m: LiveModel) => ({ context: m.context_length ? `${Math.round(m.context_length / 1000)}K` : undefined, tools: !!m.supported_parameters?.includes('tools') });

async function getJson(url: string, key: string): Promise<any> {
  const headers: Record<string, string> = { Authorization: `Bearer ${key}`, Accept: 'application/json' };
  if (Capacitor.isNativePlatform()) {
    const r = await CapacitorHttp.request({ url, method: 'GET', headers, connectTimeout: 20000, readTimeout: 60000 });
    if (r.status >= 300) throw new Error(`${r.status}: ${r.data?.error?.message ?? r.data?.detail ?? 'رفض المزوّد الطلب'}`);
    return r.data;
  }
  const res = await fetch(url, { headers });
  if (!res.ok) {
    let msg = '';
    try { msg = (await res.json())?.error?.message ?? ''; } catch { /* ignore */ }
    throw new Error(`${res.status}${msg ? `: ${msg.slice(0, 120)}` : ''}`);
  }
  return res.json();
}

/** Fetch live catalogue for one provider. Returns [] (and an error) on failure — never invents models. */
export async function fetchLiveModels(providerId: string, apiKey: string): Promise<{ list: CatalogEntry[]; total: number; error?: string }> {
  const p = PROVIDERS.find(x => x.id === providerId);
  if (!p || !apiKey) return { list: [], total: 0, error: 'مفيش مفتاح' };
  try {
    const data = await getJson(`${p.baseUrl}/models`, apiKey);
    const raw: LiveModel[] = Array.isArray(data?.data) ? data.data : Array.isArray(data?.models) ? data.models : [];
    if (!raw.length) return { list: [], total: 0, error: 'المزوّد مرجّعش موديلات' };
    const chat = raw.filter(isChatModel);
    if (p.id === 'openrouter') {
      const classified = classifyOpenRouter(chat);
      const list: CatalogEntry[] = classified
        .filter(m => m.tier === 'free' || /^(openai|google|meta-llama|anthropic|qwen|mistralai|deepseek)\//.test(m.id))
        .map(m => ({ ...m, verification: 'untested' as Verification, source: 'live' as const }));
      return { list, total: raw.length };
    }
    const list: CatalogEntry[] = chat.map(m => ({
      id: m.id, name: m.name || m.id, family: familyOf(m.id), tier: tierFor(p.id, m, p.tier),
      ...extra(m), verification: 'untested' as Verification, source: 'live' as const,
    }));
    return { list, total: raw.length };
  } catch (e: any) {
    let msg = String(e?.message ?? e);
    if (/Failed to fetch|NetworkError|Load failed/i.test(msg)) msg = 'المتصفح منع الاتصال (CORS) أو مفيش إنترنت — جرّب تطبيق الأندرويد';
    return { list: [], total: 0, error: msg };
  }
}

/** Update one catalogue in local settings (survives restarts). */
export async function refreshCatalog(state: CatalogState, providerId: string, apiKey: string): Promise<CatalogState> {
  const r = await fetchLiveModels(providerId, apiKey);
  const errors = { ...state.errors };
  if (r.error) errors[providerId] = r.error; else delete errors[providerId];
  return {
    updatedAt: Date.now(),
    byProvider: { ...state.byProvider, [providerId]: r.list },
    errors,
  };
}

/** A real minimal chat request; the result is definitive, not a guess. */
export async function verifyModel(providerId: string, modelId: string, apiKey: string): Promise<{ ok: boolean; error?: string }> {
  const p = PROVIDERS.find(x => x.id === providerId);
  if (!p || !apiKey) return { ok: false, error: 'مفيش مفتاح' };
  const url = `${p.baseUrl}/chat/completions`;
  const body = { model: modelId, messages: [{ role: 'user', content: 'قل: تمام' }], max_tokens: 8, temperature: 0 };
  try {
    const headers: Record<string, string> = { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', Accept: 'application/json' };
    let status = 200, data: any;
    if (Capacitor.isNativePlatform()) {
      const r = await CapacitorHttp.request({ url, method: 'POST', headers, data: body, connectTimeout: 20000, readTimeout: 60000 });
      status = r.status; data = r.data;
    } else {
      const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) });
      status = res.status;
      try { data = await res.json(); } catch { data = null; }
    }
    if (status >= 300) {
      const raw = String(data?.error?.message ?? data?.detail ?? data?.message ?? '');
      const friendly = status === 404 ? 'الموديل مش موجود عند المزوّد'
        : status === 429 ? 'وصلت للحد المجاني (429)'
        : status === 401 || status === 403 ? 'المفتاح مرفوض'
        : raw.slice(0, 140) || `خطأ ${status}`;
      return { ok: false, error: friendly };
    }
    if (!data?.choices?.[0]?.message) return { ok: false, error: 'المزوّد رجّع رد فاضي' };
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: /Failed to fetch|NetworkError/i.test(String(e?.message)) ? 'CORS / إنترنت' : String(e?.message ?? e).slice(0, 140) };
  }
}
