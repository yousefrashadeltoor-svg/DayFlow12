/* ============================================================
   DAYFLOW — Deterministic scheduling engine
   Pure functions only — no I/O — fully unit-testable.
   Rules: fixed blocks are sacred · suggestions never auto-apply ·
   every proposal carries before/after + human-readable reason.
   ============================================================ */

import type { ActivityBlock, ScheduleRule } from './types';

export interface Conflict { aId: string; bId: string; aTitle: string; bTitle: string; overlapMin: number; }

export const durationOf = (b: Pick<ActivityBlock, 'startMin' | 'endMin'>) => Math.max(0, b.endMin - b.startMin);
export const overlaps = (a: { startMin: number; endMin: number }, b: { startMin: number; endMin: number }) =>
  a.startMin < b.endMin && b.startMin < a.endMin;
export const overlapMinutes = (a: { startMin: number; endMin: number }, b: { startMin: number; endMin: number }) =>
  Math.max(0, Math.min(a.endMin, b.endMin) - Math.max(a.startMin, b.startMin));

export function detectConflicts(blocks: ActivityBlock[]): Conflict[] {
  const active = blocks.filter(b => b.status !== 'cancelled');
  const out: Conflict[] = [];
  const sorted = [...active].sort((a, b) => a.startMin - b.startMin);
  for (let i = 0; i < sorted.length; i++) {
    for (let j = i + 1; j < sorted.length; j++) {
      const a = sorted[i], b = sorted[j];
      if (b.startMin >= a.endMin) break;
      out.push({ aId: a.id, bId: b.id, aTitle: a.title, bTitle: b.title, overlapMin: overlapMinutes(a, b) });
    }
  }
  return out;
}

export interface FreeSlot { start: number; end: number; minutes: number; }
export function freeSlots(blocks: ActivityBlock[], dayStart = 0, dayEnd = 1440, ignoreId?: string): FreeSlot[] {
  const sorted = blocks
    .filter(b => b.status !== 'cancelled' && b.status !== 'done' && b.id !== ignoreId)
    .map(b => ({ s: b.startMin, e: b.endMin }))
    .sort((a, b) => a.s - b.s);
  const slots: FreeSlot[] = [];
  let cursor = dayStart;
  for (const b of sorted) {
    if (b.s > cursor) slots.push({ start: cursor, end: b.s, minutes: b.s - cursor });
    cursor = Math.max(cursor, b.e);
  }
  if (cursor < dayEnd) slots.push({ start: cursor, end: dayEnd, minutes: dayEnd - cursor });
  return slots;
}

export interface Proposal {
  id: string;
  kind: 'move' | 'split' | 'tomorrow' | 'advisory';
  titleAr: string; titleEn: string;
  reasonAr: string; reasonEn: string;
  blockId?: string;
  before?: { startMin: number; endMin: number } | null;
  after?: { startMin: number; endMin: number } | null;
  splitParts?: Array<{ startMin: number; endMin: number }>;
  expectedEffectAr: string; expectedEffectEn: string;
}

/** Deterministic catch-up plan: missed/overdue flexible work → concrete, reviewable proposals. */
export function buildCatchUpPlan(args: {
  missed: ActivityBlock[];
  fixed: ActivityBlock[];
  flexible: ActivityBlock[];
  remainingDayMin: number;       // minutes left in the day
  preferredHours: { start: number; end: number };
  bufferMin: number;
}): Proposal[] {
  const { missed, fixed, flexible, remainingDayMin, preferredHours, bufferMin } = args;
  const proposals: Proposal[] = [];
  const occupied = [...fixed, ...flexible];
  const slots = freeSlots(occupied, 0, 1440);
  let dayBudget = remainingDayMin;

  // Sort: higher priority first, then difficulties — deterministic.
  const sorted = [...missed].sort((a, b) => a.priority - b.priority || b.difficulty - a.difficulty || a.startMin - b.startMin);

  for (const m of sorted) {
    if (m.fixed) {
      proposals.push({
        id: `prop_fixed_${m.id}`, kind: 'advisory', blockId: m.id,
        titleAr: `«${m.title}» كتلة ثابتة فائتة`, titleEn: `"${m.title}" is a fixed commitment you missed`,
        reasonAr: 'الكتل الثابتة لا تُنقل تلقائياً — يلزم قرارك اليدوي', reasonEn: 'Fixed blocks are never moved automatically — your decision is required',
        before: { startMin: m.startMin, endMin: m.endMin }, after: null,
        expectedEffectAr: 'يراجع الوضع يدوياً وتُسجَّل المحاولة في السجل', expectedEffectEn: 'Handled manually; the attempt is logged for your review',
      });
      continue;
    }
    const dur = durationOf(m);
    // 1) Try to fit intact into the largest preferred-hours slot remaining today.
    const preferredSlots = slots.filter(s => s.end > preferredHours.start && s.start < preferredHours.end && s.minutes >= dur + bufferMin);
    const cand = (preferredSlots.length ? preferredSlots : slots.filter(s => s.minutes >= dur + bufferMin))
      .sort((a, b) => b.minutes - a.minutes)[0];
    if (cand && dayBudget >= dur) {
      const newStart = Math.max(cand.start, preferredHours.start);
      const newEnd = newStart + dur;
      const slot = slots.find(s => s === cand)!;
      slot.start = newEnd + bufferMin; slot.minutes = Math.max(0, slot.end - slot.start);
      dayBudget -= dur;
      proposals.push({
        id: `prop_move_${m.id}`, kind: 'move', blockId: m.id,
        titleAr: `انقل «${m.title}» إلى ${fmt(newStart)}`, titleEn: `Move "${m.title}" to ${fmt(newStart)}`,
        reasonAr: 'ساعات نشاط مفضلة وما زال لديك وقت حر كافٍ اليوم', reasonEn: 'Preferred energy window with enough free time left today',
        before: { startMin: m.startMin, endMin: m.endMin }, after: { startMin: newStart, endMin: newEnd },
        expectedEffectAr: `ستنجز ${dur} دقيقة من عملك دون المساس بأي كتلة ثابتة`, expectedEffectEn: `Recovers ${dur} minutes without touching any fixed block`,
      });
      continue;
    }
    // 2) Try splitting into two sessions if allowed and useful.
    if (m.splitAllowed && dur >= 40) {
      const half1 = Math.round(dur / 2), half2 = dur - half1;
      const smallSlots = slots.filter(s => s.minutes >= Math.min(half1, half2) + bufferMin && s.minutes < dur + bufferMin);
      if (smallSlots.length >= 2) {
        const p1 = smallSlots[0], p2 = smallSlots[1];
        const part1 = { startMin: p1.start, endMin: p1.start + half1 };
        const part2 = { startMin: p2.start, endMin: p2.start + half2 };
        dayBudget -= dur;
        proposals.push({
          id: `prop_split_${m.id}`, kind: 'split', blockId: m.id,
          titleAr: `قسّم «${m.title}» إلى جلستين`, titleEn: `Split "${m.title}" into two sessions`,
          reasonAr: 'لا توجد مساحة intact كافية اليوم — التقسيم أليق من الإلغاء', reasonEn: 'No single free slot fits it — splitting beats cancelling',
          before: { startMin: m.startMin, endMin: m.endMin }, after: null, splitParts: [part1, part2],
          expectedEffectAr: 'إنجاز كامل المدة على جلستين متوافقتين مع وقتك الحر', expectedEffectEn: 'Full duration covered across two slots that fit your day',
        });
        continue;
      }
    }
    // 3) Tomorrow — explicit proposal, never silent.
    proposals.push({
      id: `prop_tomorrow_${m.id}`, kind: 'tomorrow', blockId: m.id,
      titleAr: `أجّل «${m.title}» إلى الغد`, titleEn: `Move "${m.title}" to tomorrow`,
      reasonAr: 'الوقت الحر المتبقي اليوم لا يكفي — نقله غداً يحافظ على بقية يومك', reasonEn: 'Not enough free time left today — tomorrow keeps the rest of your day intact',
      before: { startMin: m.startMin, endMin: m.endMin }, after: null,
      expectedEffectAr: 'يُعرض الاقتراح للموافقة فقط؛ لا يتغيّر أي شيء دون إذنك', expectedEffectEn: 'Applied only with your approval — nothing changes silently',
    });
  }
  if (!proposals.length) {
    proposals.push({
      id: 'prop_none', kind: 'advisory',
      titleAr: 'يومك في وضع ممتاز', titleEn: 'Your day is on track',
      reasonAr: 'لا توجد عناصر فائتة تحتاج إعادة جدولة', reasonEn: 'Nothing missed needs rescheduling',
      expectedEffectAr: 'استمر كما أنت', expectedEffectEn: 'Keep going as you are',
    });
  }
  return proposals;
}
const fmt = (min: number) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(Math.floor(min % 60)).padStart(2, '0')}`;

/** What-if simulation: pure — returns simulated day + verdict. Never persists. */
export function simulateWhatIf(blocks: ActivityBlock[], change: { blockId: string; newStartMin?: number; newEndMin?: number; newDate?: string }):
  { blocks: ActivityBlock[]; feasible: boolean; conflicts: Conflict[]; warnings: string[] } {
  const warnings: string[] = [];
  const sim = blocks.map(b => ({ ...b }));
  const target = sim.find(b => b.id === change.blockId);
  if (!target) return { blocks: sim, feasible: false, conflicts: [], warnings: ['block-not-found'] };
  const dur = durationOf(target);
  if (change.newStartMin != null) {
    target.startMin = change.newStartMin;
    target.endMin = change.newEndMin ?? change.newStartMin + dur;
  } else if (change.newEndMin != null) {
    target.endMin = change.newEndMin;
  }
  if (change.newDate) target.date = change.newDate;
  // Window validation for flexible blocks
  if (!target.fixed) {
    if (target.earliestStartMin != null && target.startMin < target.earliestStartMin) warnings.push('before-window');
    if (target.latestEndMin != null && target.endMin > target.latestEndMin) warnings.push('after-window');
  }
  if (target.fixed && change.newStartMin != null) warnings.push('fixed-block-moved');
  const dayBlocks = sim.filter(b => b.date === target.date && b.id !== target.id);
  const conflicts = detectConflicts([target, ...dayBlocks]);
  // Feasibility: impossible hours / negative durations / total overflow
  if (target.endMin <= target.startMin) warnings.push('negative-duration');
  const totalPlanned = dayBlocks.filter(b => b.status !== 'done' && b.status !== 'cancelled').reduce((s, b) => s + durationOf(b), 0) + durationOf(target);
  if (totalPlanned > 16 * 60) warnings.push('overload-day');
  const feasible = conflicts.length === 0 && !warnings.includes('negative-duration') && !warnings.includes('overload-day');
  return { blocks: sim, feasible, conflicts, warnings };
}

/** Simple deterministic capacity check for a whole day. */
export function dayCapacity(blocks: ActivityBlock[]) {
  const active = blocks.filter(b => b.status !== 'cancelled');
  const plannedMin = active.reduce((s, b) => s + durationOf(b), 0);
  const overlapsFound = detectConflicts(active).length;
  return { plannedMin, overlaps: overlapsFound, impossible: plannedMin > 19 * 60 || overlapsFound > 0, overload: plannedMin > 14 * 60 };
}

/** Evaluate configurable rules against the current day. Returns human-readable findings. */
export function evaluateRules(rules: ScheduleRule[], ctx: {
  blocks: ActivityBlock[]; sleepWindow: { start: number; end: number };
}): Array<{ ruleId: string; severity: 'info' | 'warn'; messageAr: string; messageEn: string }> {
  const out: Array<{ ruleId: string; severity: 'info' | 'warn'; messageAr: string; messageEn: string }> = [];
  const { blocks, sleepWindow } = ctx;
  const active = blocks.filter(b => b.status !== 'cancelled').sort((a, b) => a.startMin - b.startMin);
  const L = (ar: string, en: string) => ({ messageAr: ar, messageEn: en });

  for (const r of rules.filter(r => r.enabled)) {
    switch (r.ruleType) {
      case 'recovery_after_intense': {
        const after = Number(r.params.afterMinutes ?? 90);
        const need = Number(r.params.breakMinutes ?? 10);
        let run = 0; let runStart = 0;
        for (const b of active) {
          const intense = b.difficulty >= 4 || b.energy === 'high';
          if (intense) { if (run === 0) runStart = b.startMin; run += durationOf(b); } else run = 0;
          if (run >= after) {
            const afterBlock = active.find(x => x.startMin >= b.endMin);
            const gap = afterBlock ? afterBlock.startMin - b.endMin : 1440 - b.endMin;
            if (gap < need) out.push({ ruleId: r.id, severity: 'warn', ...L(
              `بعد ${run} دقيقة من عمل مكثف (${fmt(runStart)}) لا توجد راحة ${need} دقائق كافية`,
              `After ${run} min of intense work from ${fmt(runStart)}, there is no ${need}-min recovery break`) });
            run = 0;
          }
        }
        break;
      }
      case 'prep_before_workout': {
        const prep = Number(r.params.prepMinutes ?? 10);
        for (const b of active) if (b.categoryId === 'exercise') {
          const idx = active.indexOf(b);
          const prev = idx > 0 ? active[idx - 1] : null;
          if (prev && prev.endMin > b.startMin - prep && prev.id !== b.id)
            out.push({ ruleId: r.id, severity: 'info', ...L(`«${b.title}» تبدأ بعد كتلة سابقة مباشرة — خطط ${prep} دقائق تجهيز`, `"${b.title}" starts right after another block — plan ${prep} min prep`) });
        }
        break;
      }
      case 'quiet_during_sleep': {
        for (const b of active) {
          if (b.isCritical) continue;
          const inSleep = overlaps(b, sleepWindow.start < sleepWindow.end ? { startMin: sleepWindow.start, endMin: sleepWindow.end } : { startMin: sleepWindow.start, endMin: 1440 }) ||
                          (sleepWindow.start > sleepWindow.end && b.startMin >= sleepWindow.start);
          if (inSleep) out.push({ ruleId: r.id, severity: 'warn', ...L(`«${b.title}» تقع داخل نافذة نومك — الأفضل نقلها`, `"${b.title}" falls inside your sleep window — consider moving it`) });
        }
        break;
      }
      case 'minimum_rest': {
        const maxWork = Number(r.params.everyMinutes ?? 120), need = Number(r.params.minBreakMin ?? 15);
        let run = 0;
        for (const b of active) {
          const worked = b.categoryId !== 'rest' && b.categoryId !== 'meal' && b.categoryId !== 'sleep';
          run = worked ? run + durationOf(b) : 0;
          if (run >= maxWork) {
            const idx = active.indexOf(b);
            const next = active[idx + 1];
            const gap = next ? next.startMin - b.endMin : 999;
            if (gap < need) out.push({ ruleId: r.id, severity: 'warn', ...L(`تجاوزت ${run} دقيقة عمل دون راحة ${need} دقائق`, `Over ${run} min of work without a ${need}-min break`) });
            run = 0;
          }
        }
        break;
      }
      case 'max_repeat_subject': {
        const max = Number(r.params.maxPerDay ?? 3);
        const count = active.filter(b => b.categoryId === 'study').length;
        if (count > max) out.push({ ruleId: r.id, severity: 'info', ...L(`لديك ${count} كتل دراسية اليوم — وزّعها أو بدّل بعضها`, `You have ${count} study blocks today — spread or vary them`) });
        break;
      }
      case 'deadline_priority': break; // enforced at scheduling time via sort order
      case 'transition_buffer': {
        const buffer = Number(r.params.bufferMin ?? 5);
        for (let i = 1; i < active.length; i++) {
          const gap = active[i].startMin - active[i - 1].endMin;
          if (gap >= 0 && gap < buffer) out.push({ ruleId: r.id, severity: 'info', ...L(`فاصل أقل من ${buffer} دقائق بين «${active[i - 1].title}» و«${active[i].title}»`, `Less than ${buffer} min between "${active[i - 1].title}" and "${active[i].title}"`) });
        }
        break;
      }
      default: break;
    }
  }
  return out;
}
