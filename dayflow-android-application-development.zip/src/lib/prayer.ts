/* DAYFLOW — Prayer times (Egyptian General Authority of Survey)
   Fajr 19.5° · Isha 17.5° · Asr Shafi'i · sunrise/sunset 0.833°.
   Identical math to android/.../Schedulers.kt → PrayerTimes. */

export type PrayerName = 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
export const PRAYER_ORDER: PrayerName[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];
export const FARD: PrayerName[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
export const PRAYER_AR: Record<PrayerName, string> = { fajr: 'الفجر', sunrise: 'الشروق', dhuhr: 'الظهر', asr: 'العصر', maghrib: 'المغرب', isha: 'العشاء' };
export const PRAYER_EN: Record<PrayerName, string> = { fajr: 'Fajr', sunrise: 'Sunrise', dhuhr: 'Dhuhr', asr: 'Asr', maghrib: 'Maghrib', isha: 'Isha' };

export interface Governorate { id: string; ar: string; en: string; city: string; lat: number; lng: number }
/** Coordinates of each governorate's capital (all 27 Egyptian governorates). */
export const GOVERNORATES: Governorate[] = [
  { id: 'cairo', ar: 'القاهرة', en: 'Cairo', city: 'القاهرة', lat: 30.0444, lng: 31.2357 },
  { id: 'giza', ar: 'الجيزة', en: 'Giza', city: 'الجيزة', lat: 30.0131, lng: 31.2089 },
  { id: 'alexandria', ar: 'الإسكندرية', en: 'Alexandria', city: 'الإسكندرية', lat: 31.2001, lng: 29.9187 },
  { id: 'qalyubia', ar: 'القليوبية', en: 'Qalyubia', city: 'بنها', lat: 30.4660, lng: 31.1848 },
  { id: 'sharqia', ar: 'الشرقية', en: 'Sharqia', city: 'الزقازيق', lat: 30.5877, lng: 31.5020 },
  { id: 'dakahlia', ar: 'الدقهلية', en: 'Dakahlia', city: 'المنصورة', lat: 31.0409, lng: 31.3785 },
  { id: 'gharbia', ar: 'الغربية', en: 'Gharbia', city: 'طنطا', lat: 30.7865, lng: 31.0004 },
  { id: 'monufia', ar: 'المنوفية', en: 'Monufia', city: 'شبين الكوم', lat: 30.5526, lng: 31.0090 },
  { id: 'kafrelsheikh', ar: 'كفر الشيخ', en: 'Kafr El Sheikh', city: 'كفر الشيخ', lat: 31.1107, lng: 30.9388 },
  { id: 'beheira', ar: 'البحيرة', en: 'Beheira', city: 'دمنهور', lat: 31.0341, lng: 30.4682 },
  { id: 'damietta', ar: 'دمياط', en: 'Damietta', city: 'دمياط', lat: 31.4165, lng: 31.8133 },
  { id: 'portsaid', ar: 'بورسعيد', en: 'Port Said', city: 'بورسعيد', lat: 31.2653, lng: 32.3019 },
  { id: 'ismailia', ar: 'الإسماعيلية', en: 'Ismailia', city: 'الإسماعيلية', lat: 30.5965, lng: 32.2715 },
  { id: 'suez', ar: 'السويس', en: 'Suez', city: 'السويس', lat: 29.9668, lng: 32.5498 },
  { id: 'fayoum', ar: 'الفيوم', en: 'Fayoum', city: 'الفيوم', lat: 29.3084, lng: 30.8428 },
  { id: 'benisuef', ar: 'بني سويف', en: 'Beni Suef', city: 'بني سويف', lat: 29.0661, lng: 31.0994 },
  { id: 'minya', ar: 'المنيا', en: 'Minya', city: 'المنيا', lat: 28.1099, lng: 30.7503 },
  { id: 'asyut', ar: 'أسيوط', en: 'Asyut', city: 'أسيوط', lat: 27.1783, lng: 31.1859 },
  { id: 'sohag', ar: 'سوهاج', en: 'Sohag', city: 'سوهاج', lat: 26.5591, lng: 31.6957 },
  { id: 'qena', ar: 'قنا', en: 'Qena', city: 'قنا', lat: 26.1551, lng: 32.7160 },
  { id: 'luxor', ar: 'الأقصر', en: 'Luxor', city: 'الأقصر', lat: 25.6872, lng: 32.6396 },
  { id: 'aswan', ar: 'أسوان', en: 'Aswan', city: 'أسوان', lat: 24.0889, lng: 32.8998 },
  { id: 'redsea', ar: 'البحر الأحمر', en: 'Red Sea', city: 'الغردقة', lat: 27.2579, lng: 33.8116 },
  { id: 'newvalley', ar: 'الوادي الجديد', en: 'New Valley', city: 'الخارجة', lat: 25.4390, lng: 30.5586 },
  { id: 'matrouh', ar: 'مطروح', en: 'Matrouh', city: 'مرسى مطروح', lat: 31.3543, lng: 27.2373 },
  { id: 'northsinai', ar: 'شمال سيناء', en: 'North Sinai', city: 'العريش', lat: 31.1316, lng: 33.7984 },
  { id: 'southsinai', ar: 'جنوب سيناء', en: 'South Sinai', city: 'الطور', lat: 28.2364, lng: 33.6254 },
];
export const govById = (id: string) => GOVERNORATES.find(g => g.id === id) ?? GOVERNORATES[0];

const dtr = (d: number) => (d * Math.PI) / 180;
const rtd = (r: number) => (r * 180) / Math.PI;
const fix = (a: number, b: number) => { const r = a - b * Math.floor(a / b); return r < 0 ? r + b : r; };

function julian(y: number, m: number, d: number) {
  if (m <= 2) { y -= 1; m += 12; }
  const A = Math.floor(y / 100), B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
}
function sun(jd: number) {
  const D = jd - 2451545.0;
  const g = fix(357.529 + 0.98560028 * D, 360), q = fix(280.459 + 0.98564736 * D, 360);
  const L = fix(q + 1.915 * Math.sin(dtr(g)) + 0.020 * Math.sin(dtr(2 * g)), 360);
  const e = 23.439 - 0.00000036 * D;
  const RA = fix(rtd(Math.atan2(Math.cos(dtr(e)) * Math.sin(dtr(L)), Math.cos(dtr(L)))) / 15, 24);
  return { decl: rtd(Math.asin(Math.sin(dtr(e)) * Math.sin(dtr(L)))), eqt: q / 15 - RA };
}

/** Minutes from local midnight for each prayer on `date`. */
export function computePrayerTimes(date: Date, lat: number, lng: number, adjust: Partial<Record<PrayerName, number>> = {}): Record<PrayerName, number> {
  const y = date.getFullYear(), m = date.getMonth() + 1, d = date.getDate();
  const tz = -new Date(y, m - 1, d, 12).getTimezoneOffset() / 60; // device zone incl. Egyptian DST
  const jd = julian(y, m, d) - lng / (15 * 24);
  const midDay = (t: number) => fix(12 - sun(jd + t).eqt, 24);
  const angleTime = (angle: number, t: number, ccw: boolean) => {
    const { decl } = sun(jd + t); const noon = midDay(t);
    const v = (-Math.sin(dtr(angle)) - Math.sin(dtr(decl)) * Math.sin(dtr(lat))) / (Math.cos(dtr(decl)) * Math.cos(dtr(lat)));
    const T = rtd(Math.acos(Math.min(1, Math.max(-1, v)))) / 15;
    return noon + (ccw ? -T : T);
  };
  const asr = (t: number) => { const { decl } = sun(jd + t); return angleTime(-rtd(Math.atan(1 / (1 + Math.tan(dtr(Math.abs(lat - decl)))))), t, false); };
  let times = [5, 6, 12, 13, 18, 18].map(x => x / 24);
  for (let i = 0; i < 2; i++) {
    times = [angleTime(19.5, times[0], true), angleTime(0.833, times[1], true), midDay(times[2]), asr(times[3]), angleTime(0.833, times[4], false), angleTime(17.5, times[5], false)].map(x => x / 24);
  }
  const out = {} as Record<PrayerName, number>;
  PRAYER_ORDER.forEach((n, i) => { const h = times[i] * 24 + tz - lng / 15; out[n] = Math.floor(fix(h, 24) * 60 + 0.5) + (adjust[n] ?? 0); });
  return out;
}

export interface NextPrayer { name: PrayerName; at: Date; prevAt: Date; progress: number; minutesLeft: number }
export function nextPrayer(lat: number, lng: number, adjust: Partial<Record<PrayerName, number>> = {}, now = new Date()): NextPrayer {
  const base = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  // Use yesterday's real Isha so the progress circle between Isha and Fajr is exact after midnight.
  const yest = new Date(base); yest.setDate(base.getDate() - 1);
  const yTimes = computePrayerTimes(yest, lat, lng, adjust);
  let prev = new Date(yest.getTime() + yTimes.isha * 60_000);
  for (let d = 0; d < 2; d++) {
    const day = new Date(base); day.setDate(base.getDate() + d);
    const t = computePrayerTimes(day, lat, lng, adjust);
    for (const n of FARD) {
      const at = new Date(day.getTime() + t[n] * 60_000);
      if (at > now) {
        const span = Math.max(1, at.getTime() - prev.getTime());
        return { name: n, at, prevAt: prev, progress: Math.min(100, ((now.getTime() - prev.getTime()) / span) * 100), minutesLeft: Math.ceil((at.getTime() - now.getTime()) / 60000) };
      }
      prev = at;
    }
  }
  return { name: 'fajr', at: now, prevAt: now, progress: 0, minutesLeft: 0 };
}
export const fmtHM = (min: number, hour12 = false) => {
  const h = Math.floor(min / 60) % 24, m = min % 60;
  if (!hour12) return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'م' : 'ص'}`;
};

/** True spherical bearing (degrees clockwise from North) toward the Kaaba (21.4225°N, 39.8262°E). */
export function qiblaAngle(lat: number, lng: number): number {
  const φ1 = dtr(lat), φ2 = dtr(21.4225), Δλ = dtr(39.8262 - lng);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return Math.round(((rtd(Math.atan2(y, x)) % 360) + 360) % 360);
}
