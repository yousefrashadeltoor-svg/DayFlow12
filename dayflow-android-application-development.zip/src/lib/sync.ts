/* DAYFLOW — single native sync pipeline (strictly idempotent, offline-only)
   DB → exact AlarmManager schedules + silent-channel custom sounds + prayer scheduler + all 4 widgets.
   Strictly excludes Christian & Jewish occasions from both notifications AND widgets. */
import { db, todayKey, addDays, isNative, minToTime, type AppSettings } from './db';
import { platform } from './platform';
import { occasionsInRange, hijriLabel, hijriOf, orthodoxEaster, type PersonalOccasion } from './occasions';
import { govById, nextPrayer, PRAYER_AR, PRAYER_EN } from './prayer';
import type { ActivityBlock, ActivityCategory, TaskItem, WaterLog } from './types';

const atMillis = (date: string, min: number) => new Date(`${date}T00:00:00`).getTime() + min * 60_000;

export interface SyncResult {
  ok: boolean; unsupported?: boolean; scheduled?: number; exact?: number; inexact?: number;
  removed?: number; error?: string; items: number;
}

/** Light helper duplicating active season id so widgets show the right 3D decor natively. */
export function activeSceneId(date: Date, hijriOffset: number, override: string): string {
  if (override && override !== 'auto') return override;
  const h = hijriOf(date, hijriOffset);
  if (h) {
    if (h.m === 9) return 'ramadan';
    if (h.m === 10 && h.d <= 3) return 'eidFitr';
    if (h.m === 12 && h.d >= 9 && h.d <= 13) return 'eidAdha';
    if ((h.m === 1 && (h.d === 1 || h.d === 10)) || (h.m === 3 && h.d === 12) || (h.m === 7 && h.d === 27) || (h.m === 8 && h.d === 15)) return 'islamic';
  }
  const m = date.getMonth() + 1, d = date.getDate(), md = m * 100 + d;
  if ([125, 425, 501, 630, 723, 1006].includes(md)) return 'national';
  const sham = orthodoxEaster(date.getFullYear()); sham.setDate(sham.getDate() + 1);
  if (sham.getMonth() + 1 === m && sham.getDate() === d) return 'sham';
  if (md === 1231 || md === 101) return 'nye';
  if (md >= 1215 || md <= 107) return 'newyear';
  if (m === 12 || m <= 2) return 'winter';
  if (md >= 922) return 'autumn';
  if (m >= 3 && m <= 5) return 'spring';
  return 'summer';
}

export async function buildScheduleItems(s: AppSettings) {
  if (!s.notificationsEnabled) return [];
  const lang = s.language;
  const today = todayKey();
  const until = addDays(today, 3); // rolling 4-day window ensures zero dropped alarms overnight
  const [blocks, cats, tasks, personal] = await Promise.all([
    db.all<ActivityBlock>('activity_blocks'),
    db.all<ActivityCategory>('activity_categories'),
    db.all<TaskItem>('tasks'),
    db.all<PersonalOccasion>('personal_occasions'),
  ]);
  const catName = (id: string) => {
    const c = cats.find(x => x.id === id);
    return c ? (lang === 'ar' ? c.nameAr : c.nameEn) : '';
  };
  const items: any[] = [];
  const now = Date.now();

  for (const b of blocks) {
    if (b.date < today || b.date > until) continue;
    if (!['planned', 'paused', 'in_progress'].includes(b.status)) continue;
    const dur = Math.max(0, b.endMin - b.startMin);
    const range = `${minToTime(b.startMin, s.hour12)} – ${minToTime(b.endMin, s.hour12)}`;
    const cleanNote = b.notes && !b.notes.startsWith('tpl:') ? b.notes.trim() : '';
    const noteLine = cleanNote ? `\n📝 ${cleanNote}` : '';
    const cat = catName(b.categoryId);

    if (b.reminderMin >= 0 && b.status === 'planned') {
      const at = atMillis(b.date, b.startMin - b.reminderMin);
      if (at > now) {
        const prefix = b.reminderMin > 0
          ? (lang === 'ar' ? `⏰ كمان ${b.reminderMin} د: ` : `⏰ In ${b.reminderMin}m: `)
          : '⏰ ';
        items.push({
          id: b.id, refId: b.id, kind: 'block', phase: 'start',
          triggerAtMillis: at, startAtMillis: atMillis(b.date, b.startMin),
          title: `${prefix}${b.title}`,
          body: `${range} · ${dur} ${lang === 'ar' ? 'دقيقة' : 'min'}${cat ? ` · ${cat}` : ''}${b.fixed ? (lang === 'ar' ? ' · ثابت 📌' : ' · fixed 📌') : ''}${noteLine}`,
          category: b.categoryId, sound: b.sound || 'default',
          repeatCount: b.repeatCount || s.soundRepeatCount || 1,
          isCritical: !!b.isCritical, vibrate: s.vibration,
          snoozeMin: s.snoozeDefaultMin, label: b.title,
        });
      }
    }
    if (s.endOfBlockPrompt) {
      const endAt = atMillis(b.date, b.endMin);
      if (endAt > now) {
        items.push({
          id: `${b.id}:end`, refId: b.id, kind: 'block', phase: 'end',
          triggerAtMillis: endAt, startAtMillis: endAt,
          title: lang === 'ar' ? `✅ وقت «${b.title}» خلص — خلصته؟` : `✅ "${b.title}" finished?`,
          body: `${range}${noteLine ? noteLine : ''}\n${lang === 'ar' ? 'سجّل حالته من الأزرار تحت عشان إحصائياتك تبقى مظبوطة' : 'Tap below to update your real stats'}`,
          sound: 'default', vibrate: s.vibration, snoozeMin: s.snoozeDefaultMin,
        });
      }
    }
  }

  for (const t of tasks) {
    if (t.status === 'done' || t.status === 'cancelled' || !t.dueDate) continue;
    if (t.dueDate < today || t.dueDate > addDays(today, 7)) continue;
    const at = atMillis(t.dueDate, s.occasionNotifyHour * 60);
    if (at > now) {
      items.push({
        id: `task:${t.id}`, refId: t.id, kind: 'task',
        triggerAtMillis: at, startAtMillis: at,
        title: (lang === 'ar' ? '📋 مهمة النهارده: ' : '📋 Due today: ') + t.title,
        body: `${lang === 'ar' ? 'تقدير الوقت' : 'Estimate'}: ~${t.estimatedMin} ${lang === 'ar' ? 'د' : 'min'}${t.notes ? `\n📝 ${t.notes}` : ''}`,
        sound: 'default', vibrate: s.vibration, snoozeMin: 60,
      });
    }
  }

  // Upcoming 45 days of occasions — strictly exclude Christian & Jewish dates (never notify!)
  const occ = occasionsInRange(today, addDays(today, 45), s.hijriOffset, personal);
  for (const o of occ) {
    if (!o.notify || o.kind === 'christian' || o.kind === 'jewish' || o.religion) continue;
    const name = lang === 'ar' ? o.nameAr : o.nameEn;
    const p = o.personalId ? personal.find(x => x.id === o.personalId) : null;
    const minute = o.time ?? s.occasionNotifyHour * 60;
    const at = atMillis(o.date, minute);
    if (at > now) {
      items.push({
        id: `occ:${o.id}`, refId: o.id, kind: o.kind === 'personal' ? 'event' : 'occasion',
        occasionKind: o.kind, notify: true, triggerAtMillis: at, startAtMillis: at,
        title: (o.kind === 'personal' ? '📌 ' : '✨ ') + name,
        body: (o.official ? (lang === 'ar' ? 'إجازة رسمية ✓ · ' : 'Official holiday ✓ · ') : '') + (lang === 'ar' ? o.detailsAr : o.detailsEn).slice(0, 180),
        sound: 'default', vibrate: s.vibration, snoozeMin: 60,
      });
    }
    if (p && p.remindDaysBefore > 0) {
      const pre = atMillis(addDays(o.date, -p.remindDaysBefore), s.occasionNotifyHour * 60);
      if (pre > now) {
        items.push({
          id: `occ:${o.id}:pre`, refId: o.id, kind: 'event', occasionKind: 'personal', notify: true,
          triggerAtMillis: pre, startAtMillis: pre,
          title: `📌 ${name}`,
          body: lang === 'ar' ? `فاضل ${p.remindDaysBefore} ${p.remindDaysBefore === 1 ? 'يوم' : 'أيام'} على المناسبة${p.note ? `\n📝 ${p.note}` : ''}` : `${p.remindDaysBefore} day(s) left`,
          sound: 'default', vibrate: s.vibration, snoozeMin: 60,
        });
      }
    }
  }

  if (s.waterReminders && s.waterReminderMin >= 30) {
    const start = Math.max(0, s.wakeMin + 60);
    const end = s.bedtimeMin > start ? s.bedtimeMin - 30 : 22 * 60;
    for (let m = start; m < end; m += s.waterReminderMin) {
      const at = atMillis(today, m);
      if (at > now) {
        items.push({
          id: `water:${today}:${m}`, refId: `water:${today}:${m}`, kind: 'water',
          triggerAtMillis: at, title: lang === 'ar' ? 'وقت كوباية مية 💧' : 'Drink some water 💧',
          body: '', sound: 'default', vibrate: s.vibration, snoozeMin: 20,
        });
      }
    }
  }
  return items;
}

export async function buildWidgetSnapshot(s: AppSettings) {
  const lang = s.language;
  const today = todayKey();
  const [blocks, water, personal] = await Promise.all([
    db.all<ActivityBlock>('activity_blocks'),
    db.all<WaterLog>('water_logs'),
    db.all<PersonalOccasion>('personal_occasions'),
  ]);
  const todays = blocks.filter(b => b.date === today && b.status !== 'cancelled').sort((a, b) => a.startMin - b.startMin);
  // Strictly never push Christian / Jewish occasions into native widgets
  const occ = occasionsInRange(today, today, s.hijriOffset, personal).find(o => o.notify && o.kind !== 'christian' && o.kind !== 'jewish' && !o.religion);
  const d = new Date();
  const scene = activeSceneId(d, s.hijriOffset, s.decorOverride);
  return {
    date: today, lang, hour12: s.hour12, scene,
    dateLabel: new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'long' }).format(d),
    hijriLabel: hijriLabel(d, lang, s.hijriOffset),
    greeting: lang === 'ar' ? (s.userName ? `يومك منظم يا ${s.userName} ✨` : 'يومك منظم ومتسجل ✨') : 'Your day, organised ✨',
    blocks: todays.map(b => ({
      id: b.id, title: b.title, startMin: b.startMin, endMin: b.endMin, status: b.status,
      note: b.notes?.startsWith('tpl:') ? '' : (b.notes ?? '').trim(), cat: b.categoryId,
    })),
    occasion: occ ? { name: lang === 'ar' ? occ.nameAr : occ.nameEn, official: occ.official, occasionKind: occ.kind, notify: true } : null,
    water: { ml: water.filter(w => w.date === today).reduce((a, w) => a + w.amountMl, 0), target: s.waterTargetMl },
  };
}

export function prayerConfig(s: AppSettings) {
  const g = govById(s.governorate);
  return {
    enabled: s.prayerEnabled, lat: g.lat, lng: g.lng,
    place: s.language === 'ar' ? g.ar : g.en,
    on: s.prayerOn, preMin: s.prayerPreMin, adjust: s.prayerAdjust,
    sound: s.prayerSound === 'custom' && s.prayerToneUri ? 'custom' : s.prayerSound,
    toneUri: s.prayerSound === 'custom' ? s.prayerToneUri : '',
    speak: s.prayerSpeak,
  };
}

let running: Promise<SyncResult> | null = null;
/** Idempotent master sync. Returns the REAL native status — never fakes success. */
export async function syncNative(): Promise<SyncResult> {
  if (running) return running;
  running = (async () => {
    const s = await db.getSettings();
    const items = await buildScheduleItems(s);
    if (!isNative()) return { ok: false, unsupported: true, items: items.length };
    const water = (await db.all<WaterLog>('water_logs')).filter(w => w.date === todayKey()).reduce((a, w) => a + w.amountMl, 0);
    await platform.initialize({
      lang: s.language, hour12: s.hour12,
      quietEnabled: s.quietHoursEnabled, quietStart: s.quietHoursStartMin, quietEnd: s.quietHoursEndMin,
      snoozeDefault: s.snoozeDefaultMin, ttsFallback: s.ttsFallback,
      waterCupMl: s.waterCupMl, waterTargetMl: s.waterTargetMl, waterTodayMl: water,
    });
    const res: any = await platform.syncSchedule(items, ['block', 'task', 'occasion', 'event', 'water']);
    await platform.configurePrayers(prayerConfig(s));
    await platform.updateWidget(await buildWidgetSnapshot(s));
    return {
      ok: !!res.ok, scheduled: res.scheduled, exact: res.exact,
      inexact: res.inexact, removed: res.removed, error: res.error, items: items.length,
    };
  })();
  try { return await running; } finally { running = null; }
}

export function prayerSummary(s: AppSettings) {
  const g = govById(s.governorate);
  const np = nextPrayer(g.lat, g.lng, s.prayerAdjust as any);
  return { ...np, label: s.language === 'ar' ? PRAYER_AR[np.name] : PRAYER_EN[np.name], gov: g };
}
