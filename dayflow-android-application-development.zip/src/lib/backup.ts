/* DAYFLOW — Backup & restore · JSON (optionally AES-GCM encrypted) · CSV · XLSX
   Every path validates before writing. Restore never silently overwrites —
   the caller chooses merge or replace explicitly. */
import * as XLSX from 'xlsx';
import { db, TABLES, todayKey } from './db';
import { newId } from './db';

export const BACKUP_SCHEMA = 'dayflow-backup';
export const BACKUP_SCHEMA_ENCRYPTED = 'dayflow-backup-encrypted';
export const BACKUP_VERSION = 1;

/* ---------- helpers ---------- */
const b64encode = (buf: ArrayBuffer | Uint8Array) => {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = ''; for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
};
const b64decode = (s: string) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const enc = new TextEncoder(), dec = new TextDecoder();

async function deriveKey(password: string, salt: Uint8Array) {
  const base = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: salt as BufferSource, iterations: 210_000, hash: 'SHA-256' }, base,
    { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

async function encryptPayload(plain: string, password: string) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(password, salt);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(plain));
  return JSON.stringify({ schema: BACKUP_SCHEMA_ENCRYPTED, version: BACKUP_VERSION, kdf: 'PBKDF2-SHA256-210k', cipher: 'AES-256-GCM',
    salt: b64encode(salt), iv: b64encode(iv), data: b64encode(ct) });
}
async function decryptPayload(text: string, password: string): Promise<string> {
  const obj = JSON.parse(text);
  if (obj.schema !== BACKUP_SCHEMA_ENCRYPTED) throw new Error('not-encrypted-dayflow-backup');
  const key = await deriveKey(password, b64decode(obj.salt));
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64decode(obj.iv) }, key, b64decode(obj.data));
  return dec.decode(plain);
}

export function downloadTextFile(filename: string, text: string, mime = 'application/octet-stream') {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* ---------- JSON backup ---------- */
export async function gatherBackup() {
  const tables: Record<string, any[]> = {};
  for (const t of TABLES) tables[t] = await db.all(t);
  const settings = await db.settingGet('app');
  return { schema: BACKUP_SCHEMA, version: BACKUP_VERSION, exportedAt: new Date().toISOString(), appVersion: '1.0.0', tables, settings };
}

export async function createJsonBackup(password?: string): Promise<string> {
  const backup = await gatherBackup();
  const plain = JSON.stringify(backup);
  const out = password ? await encryptPayload(plain, password) : plain;
  const counts = Object.fromEntries(Object.entries(backup.tables).map(([k, v]) => [k, v.length]));
  await db.put('backup_history', { id: newId(), createdAt: Date.now(), tableCounts: counts, sizeBytes: out.length, encrypted: !!password, kind: 'json' });
  return out;
}

export interface BackupPreview { tables: Record<string, number>; totalRows: number; exportedAt?: string; encrypted: boolean; settingsIncluded: boolean; }

export async function previewJsonBackup(text: string, password?: string): Promise<{ preview: BackupPreview; raw: any }> {
  let parsed: any;
  const head = (() => { try { return JSON.parse(text); } catch { return null; } })();
  if (head?.schema === BACKUP_SCHEMA_ENCRYPTED) {
    if (!password) throw new Error('password-required');
    parsed = JSON.parse(await decryptPayload(text, password));
  } else {
    parsed = head;
  }
  if (!parsed || parsed.schema !== BACKUP_SCHEMA) throw new Error('invalid-backup-schema');
  if (typeof parsed.version !== 'number' || parsed.version > BACKUP_VERSION) throw new Error('unsupported-backup-version');
  const tables: Record<string, number> = {};
  let total = 0;
  for (const t of TABLES) { const rows = Array.isArray(parsed.tables?.[t]) ? parsed.tables[t] : []; tables[t] = rows.length; total += rows.length; }
  return { preview: { tables, totalRows: total, exportedAt: parsed.exportedAt, encrypted: head?.schema === BACKUP_SCHEMA_ENCRYPTED, settingsIncluded: !!parsed.settings }, raw: parsed };
}

export async function restoreJsonBackup(raw: any, mode: 'merge' | 'replace'): Promise<Record<string, number>> {
  const summary: Record<string, number> = {};
  for (const t of TABLES) {
    const rows: any[] = Array.isArray(raw.tables?.[t]) ? raw.tables[t] : [];
    const valid = rows.filter(r => r && typeof r === 'object' && typeof r.id === 'string');
    if (mode === 'replace') await db.clear(t);
    if (valid.length) await db.bulkPut(t, valid);
    summary[t] = valid.length;
  }
  if (mode === 'replace' && raw.settings) await db.settingSet('app', raw.settings);
  return summary;
}

/* ---------- CSV ---------- */
const csvEscape = (v: any) => {
  const s = v == null ? '' : Array.isArray(v) ? v.join('; ') : typeof v === 'object' ? JSON.stringify(v) : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
export function toCsv(rows: any[], columns?: string[]): string {
  if (!rows.length) return (columns ?? []).join(',');
  const cols = columns ?? [...new Set(rows.flatMap(r => Object.keys(r)))];
  const lines = [cols.join(',')];
  for (const r of rows) lines.push(cols.map(c => csvEscape(r[c])).join(','));
  return lines.join('\n');
}
export function parseCsv(text: string): Array<Record<string, string>> {
  const rows: string[][] = [];
  let cur: string[] = [], field = '', inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (ch === '"') inQuotes = false;
      else field += ch;
    } else if (ch === '"') inQuotes = true;
    else if (ch === ',') { cur.push(field); field = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      cur.push(field); field = '';
      if (cur.length > 1 || cur[0] !== '') rows.push(cur);
      cur = [];
    } else field += ch;
  }
  cur.push(field);
  if (cur.length > 1 || cur[0] !== '') rows.push(cur);
  if (rows.length < 2) return [];
  const headers = rows[0].map(h => h.trim());
  return rows.slice(1).map(r => Object.fromEntries(headers.map((h, i) => [h, (r[i] ?? '').trim()])));
}

export async function exportCsvDataset(kind: 'blocks' | 'tasks' | 'water' | 'habits'): Promise<string> {
  if (kind === 'blocks') return toCsv(await db.all('activity_blocks'), ['date', 'title', 'categoryId', 'startMin', 'endMin', 'fixed', 'priority', 'status', 'notes']);
  if (kind === 'tasks') return toCsv(await db.all('tasks'), ['title', 'status', 'priority', 'dueDate', 'estimatedMin', 'trackedMin', 'categoryId', 'starred', 'notes']);
  if (kind === 'water') return toCsv(await db.all('water_logs'), ['date', 'timeMin', 'amountMl']);
  return toCsv(await db.all('habit_logs'), ['habitId', 'date', 'count', 'note']);
}

const HEADER_ALIASES: Record<string, string[]> = {
  date: ['date', 'التاريخ', 'day'],
  title: ['title', 'العنوان', 'name', 'النشاط', 'activity', 'task'],
  category: ['category', 'التصنيف', 'cat', 'type'],
  start: ['start', 'start_min', 'startmin', 'البداية', 'from'],
  end: ['end', 'end_min', 'endmin', 'النهاية', 'to'],
  fixed: ['fixed', 'ثابت', 'fixed?'],
  priority: ['priority', 'الأولوية', 'prio'],
  duration: ['duration', 'المدة', 'dur'],
};

export interface CsvImportResult {
  rows: any[]; errors: string[]; duplicates: number; overlaps: number; mappedHeaders: Record<string, string>;
}

/** Validate + map a schedule CSV. Nothing is written until the caller confirms. */
export async function analyzeScheduleCsv(text: string): Promise<CsvImportResult> {
  const raw = parseCsv(text);
  const errors: string[] = [];
  if (!raw.length) return { rows: [], errors: ['empty-or-unparseable-csv'], duplicates: 0, overlaps: 0, mappedHeaders: {} };
  const headers = Object.keys(raw[0]);
  const mapped: Record<string, string> = {};
  for (const [field, aliases] of Object.entries(HEADER_ALIASES)) {
    const hit = headers.find(h => aliases.includes(h.trim().toLowerCase()) || aliases.includes(h.trim()));
    if (hit) mapped[field] = hit;
  }
  if (!mapped.title) errors.push('missing-title-column');
  const parseMin = (v: string): number | null => {
    if (/^\d{1,2}:\d{2}$/.test(v)) { const [h, m] = v.split(':').map(Number); return h * 60 + m; }
    const n = Number(v); return Number.isFinite(n) && n >= 0 && n <= 1440 ? n : null;
  };
  const existing = await db.all<any>('activity_blocks');
  const seen = new Set<string>();
  const rows: any[] = [];
  let duplicates = 0, overlaps = 0;
  raw.forEach((r, i) => {
    const title = mapped.title ? r[mapped.title]?.trim() : '';
    if (!title) { errors.push(`row-${i + 2}: missing title`); return; }
    const date = mapped.date ? (r[mapped.date]?.trim() || todayKey()) : todayKey();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || isNaN(new Date(date + 'T12:00:00').getTime())) { errors.push(`row-${i + 2}: invalid date "${date}"`); return; }
    let start = mapped.start ? parseMin(String(r[mapped.start])) : null;
    let end = mapped.end ? parseMin(String(r[mapped.end])) : null;
    if (start == null) start = 9 * 60;
    if (end == null) {
      const dur = mapped.duration ? Number(r[mapped.duration]) : 45;
      end = start + (Number.isFinite(dur) && dur > 0 ? dur : 45);
    }
    if (end <= start) { errors.push(`row-${i + 2}: end before start (negative duration)`); return; }
    const key = `${date}|${title}|${start}`;
    if (seen.has(key)) { duplicates++; return; }
    seen.add(key);
    const dupe = existing.some(b => b.date === date && b.title === title && b.startMin === start);
    if (dupe) { duplicates++; return; }
    if (existing.some(b => b.date === date && start! < b.endMin && b.startMin < end!)) overlaps++;
    const fixedRaw = mapped.fixed ? String(r[mapped.fixed]).toLowerCase() : '';
    rows.push({
      id: newId(), title, description: '', categoryId: mapped.category ? (r[mapped.category]?.trim() || 'personal') : 'personal',
      date, startMin: start, endMin: end, fixed: ['true', '1', 'yes', 'نعم', 'ثابت'].includes(fixedRaw),
      priority: Math.min(4, Math.max(1, Number(mapped.priority ? r[mapped.priority] : 3) || 3)) as any,
      energy: 'medium', difficulty: 3, status: 'planned', recurrence: 'none', reminderMin: 10, sound: 'default',
      repeatCount: 1, isCritical: false, splitAllowed: true, earliestStartMin: null, latestEndMin: null,
      linkedTaskId: null, linkedGoalId: null, linkedSubjectId: null, tags: [], notes: '',
      actualStartMin: null, actualEndMin: null, createdAt: Date.now(), updatedAt: Date.now(),
    });
  });
  return { rows, errors, duplicates, overlaps, mappedHeaders: mapped };
}

/* ---------- XLSX ---------- */
export async function exportXlsx(): Promise<void> {
  const wb = XLSX.utils.book_new();
  const sheetDefs: Array<[string, string]> = [
    ['Blocks', 'activity_blocks'], ['Tasks', 'tasks'], ['Habits', 'habits'], ['Habit Logs', 'habit_logs'],
    ['Water', 'water_logs'], ['Focus', 'focus_sessions'], ['Goals', 'goals'], ['Notes', 'notes'],
  ];
  for (const [sheet, table] of sheetDefs) {
    const rows = await db.all(table);
    const flat = rows.map(r => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, Array.isArray(v) ? v.join('; ') : typeof v === 'object' && v !== null ? JSON.stringify(v) : v])));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(flat.length ? flat : [{ empty: true }]), sheet);
  }
  XLSX.writeFile(wb, `dayflow-export-${todayKey()}.xlsx`);
  await db.put('backup_history', { id: newId(), createdAt: Date.now(), tableCounts: {}, sizeBytes: 0, encrypted: false, kind: 'xlsx' });
}
