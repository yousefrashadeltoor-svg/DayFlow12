/* ============================================================
   DAYFLOW — Platform bridge (TypeScript ↔ Android native)
   Native: AlarmManager exact alarms · notification channels ·
   notification actions (DONE/SNOOZE/SKIP/START) · TTS ·
   home-screen widgets · boot recovery — via DayflowNativePlugin.
   Web preview: IndexedDB + honest capability reporting.
   Nothing here fakes success — native results are authoritative.
   ============================================================ */

import { registerPlugin } from '@capacitor/core';
import { isNative } from './db';
import type { ActivityBlock } from './types';

export interface NativeResult { ok: boolean; unsupported?: boolean; error?: string; [k: string]: any }

interface DayflowNativePluginInterface {
  initialize(): Promise<NativeResult>;
  getPlatformCapabilities(): Promise<NativeResult>;
  checkNotificationPermission(): Promise<NativeResult>;
  requestNotificationPermission(): Promise<NativeResult>;
  checkExactAlarmPermission(): Promise<NativeResult>;
  requestExactAlarmPermission(): Promise<NativeResult>;
  scheduleBlockAlarm(options: { id: string; title: string; body: string; triggerAtMillis: number; category: string; sound: string; repeatCount: number; isCritical: boolean; vibrate: boolean }): Promise<NativeResult>;
  cancelAlarm(options: { id: string }): Promise<NativeResult>;
  cancelBlockAlarms(): Promise<NativeResult>;
  rescheduleUpcomingAlarms(options: { blocks: any[] }): Promise<NativeResult>;
  getScheduledAlarmStatus(): Promise<NativeResult>;
  playCustomAlarmAudio(options: { uri: string | null; sound: string; repeatCount: number; volume: number; gradual: boolean }): Promise<NativeResult>;
  stopAlarmAudio(): Promise<NativeResult>;
  speakText(options: { text: string; lang: string }): Promise<NativeResult>;
  drainPendingActions(): Promise<NativeResult & { actions: Array<{ action: string; blockId: string; at: number }> }>;
  markPendingActionApplied(options: { id: string }): Promise<NativeResult>;
  importNativeFile(): Promise<NativeResult & { uri?: string; name?: string }>;
  updateWidget(options: { snapshot: string }): Promise<NativeResult>;
  getBatteryOptimizationStatus(): Promise<NativeResult>;
  requestBatterySettings(): Promise<NativeResult>;
  syncSchedule(options: { items: any[]; kinds: string[] }): Promise<NativeResult>;
  getNotificationLog(): Promise<NativeResult>;
  setUserAlarm(options: { alarm: any }): Promise<NativeResult>;
  deleteUserAlarm(options: { id: string }): Promise<NativeResult>;
  configurePrayers(options: { config: any }): Promise<NativeResult>;
  syncPrayed(options: { date: string; names: string[] }): Promise<NativeResult>;
  pickSystemTone(options: { type: 'alarm' | 'ringtone' | 'notification'; current?: string }): Promise<NativeResult>;
  pickMusicTone(): Promise<NativeResult>;
  getAudioInfo(options: { uri: string }): Promise<NativeResult>;
  requestFullScreenPermission(): Promise<NativeResult>;
  triggerTestAlarm(options: { mode: 'notification' | 'alarm'; delaySec?: number; toneUri?: string }): Promise<NativeResult>;
  extractWaveform(options: { uri: string; bars?: number }): Promise<NativeResult>;
  getDeviceTimeZone(): Promise<NativeResult>;
  initializeWith?(o: any): Promise<NativeResult>;
}

const DayflowNative = registerPlugin<DayflowNativePluginInterface>('DayflowNative');

const webOnly = <T extends object>(extra?: T): NativeResult & T =>
  ({ ok: false, unsupported: true, error: 'unsupported-on-web', ...(extra as T) });

async function native<T extends object>(fn: () => Promise<NativeResult & T>): Promise<NativeResult & T> {
  if (!isNative()) return webOnly<T>();
  try {
    const res = await fn();
    if (res && typeof res === 'object') return res;
    return { ok: false, error: 'empty-native-response' } as NativeResult & T;
  } catch (e: any) {
    return { ok: false, error: e?.message ?? String(e) } as NativeResult & T;
  }
}

export const platform = {
  isNative,
  backendLabel: () => (isNative() ? 'Android Native (SQLite + AlarmManager)' : 'Web Preview (IndexedDB — reminders fire only while open)'),

  initialize: (cfg: Record<string, any> = {}) => native(() => (DayflowNative.initialize as any)(cfg)),
  capabilities: () => native(() => DayflowNative.getPlatformCapabilities()),
  checkNotificationPermission: () => native(() => DayflowNative.checkNotificationPermission()),
  requestNotificationPermission: () => native(() => DayflowNative.requestNotificationPermission()),
  checkExactAlarm: () => native(() => DayflowNative.checkExactAlarmPermission()),
  requestExactAlarm: () => native(() => DayflowNative.requestExactAlarmPermission()),
  batteryStatus: () => native(() => DayflowNative.getBatteryOptimizationStatus()),
  openBatterySettings: () => native(() => DayflowNative.requestBatterySettings()),
  alarmStatus: () => native(() => DayflowNative.getScheduledAlarmStatus()),

  async scheduleBlockAlarm(block: ActivityBlock, body?: string) {
    const settings = { hour12: false }; // body text is pre-localized by caller
    void settings;
    const triggerAtMillis = new Date(`${block.date}T00:00:00`).getTime() + (block.startMin - (block.reminderMin >= 0 ? block.reminderMin : 0)) * 60_000;
    return native(() => DayflowNative.scheduleBlockAlarm({
      id: block.id,
      title: block.title,
      body: body ?? block.title,
      triggerAtMillis: Math.max(Date.now() + 5000, triggerAtMillis),
      category: block.categoryId,
      sound: block.sound ?? 'default',
      repeatCount: block.repeatCount ?? 1,
      isCritical: !!block.isCritical,
      vibrate: true,
    }));
  },
  cancelAlarm: (id: string) => native(() => DayflowNative.cancelAlarm({ id })),
  cancelAllAlarms: () => native(() => DayflowNative.cancelBlockAlarms()),
  rescheduleAll: (blocks: ActivityBlock[]) => native(() => DayflowNative.rescheduleUpcomingAlarms({
    blocks: blocks.map(b => ({
      id: b.id, title: b.title, date: b.date, startMin: b.startMin,
      reminderMin: b.reminderMin, category: b.categoryId, sound: b.sound,
      repeatCount: b.repeatCount, isCritical: b.isCritical,
    })),
  })),

  playAlarmAudio: (soundUri: string | null, repeatCount = 1, volume = 0.9) =>
    native(() => DayflowNative.playCustomAlarmAudio({ uri: soundUri, sound: soundUri ? 'custom' : 'default', repeatCount, volume, gradual: true })),
  stopAlarmAudio: () => native(() => DayflowNative.stopAlarmAudio()),
  speakText: (text: string, lang: 'ar' | 'en') => native(() => DayflowNative.speakText({ text, lang: lang === 'ar' ? 'ar' : 'en-US' })),

  drainPendingActions: () => native(() => DayflowNative.drainPendingActions()),
  markPendingActionApplied: (id: string) => native(() => DayflowNative.markPendingActionApplied({ id })),
  importAudioFile: () => native(() => DayflowNative.importNativeFile()),

  updateWidget: (snapshot: any) => native(() => DayflowNative.updateWidget({ snapshot: JSON.stringify(snapshot) })),
  syncSchedule: (items: any[], kinds: string[]) => native(() => DayflowNative.syncSchedule({ items, kinds })),
  notificationLog: () => native(() => DayflowNative.getNotificationLog()),
  setUserAlarm: (alarm: any) => native(() => DayflowNative.setUserAlarm({ alarm })),
  deleteUserAlarm: (id: string) => native(() => DayflowNative.deleteUserAlarm({ id })),
  configurePrayers: (config: any) => native(() => DayflowNative.configurePrayers({ config })),
  syncPrayed: (date: string, names: string[]) => native(() => DayflowNative.syncPrayed({ date, names })),
  pickSystemTone: (type: 'alarm' | 'ringtone' | 'notification', current?: string) => native(() => DayflowNative.pickSystemTone({ type, current })),
  pickMusicTone: () => native(() => DayflowNative.pickMusicTone()),
  audioInfo: (uri: string) => native(() => DayflowNative.getAudioInfo({ uri })),
  previewClip: (uri: string | null, startMs: number, endMs: number, volume = 1) => native(() => (DayflowNative.playCustomAlarmAudio as any)({ uri, startMs, endMs, volume })),
  requestFullScreen: () => native(() => DayflowNative.requestFullScreenPermission()),
  triggerTestAlarm: (mode: 'notification' | 'alarm', delaySec = 10, toneUri = '') => native(() => DayflowNative.triggerTestAlarm({ mode, delaySec, toneUri })),
  extractWaveform: (uri: string, bars = 64) => native(() => DayflowNative.extractWaveform({ uri, bars })),
  timeZone: () => native(() => DayflowNative.getDeviceTimeZone()),
};

/* ------- Haptics (real device vibration where available) ------- */
export function haptic(style: 'light' | 'medium' | 'heavy' = 'light') {
  try { navigator?.vibrate?.(style === 'light' ? 8 : style === 'medium' ? 18 : 35); } catch { /* unsupported */ }
}

/* ------- Web preview reminder engine — honest about its limits -------
   Browsers cannot fire notifications while the tab is closed. On web we
   check every 30s while the app is open and fire Notification API
   notifications (if permission granted). The Android build uses
   AlarmManager and works with the app killed. This is labelled in UI.  */
let webTimersStarted = false;
export function startWebReminderEngine(getDue: () => Promise<Array<{ id: string; title: string; body: string }>>) {
  if (isNative() || webTimersStarted || typeof window === 'undefined') return;
  webTimersStarted = true;
  const fired = new Set<string>();
  setInterval(async () => {
    try {
      const due = await getDue();
      for (const item of due) {
        if (fired.has(item.id)) continue;
        fired.add(item.id);
        if ('Notification' in window && Notification.permission === 'granted') {
          try { new Notification(item.title, { body: item.body, tag: item.id }); } catch { /* ignore */ }
        }
        window.dispatchEvent(new CustomEvent('dayflow:reminder-due', { detail: item }));
      }
    } catch { /* keep the loop alive */ }
  }, 30000);
}

/* ------- Audio cues for timers (Web Audio — real sound everywhere) ------- */
let audioCtx: AudioContext | null = null;
export function playChime(kind: 'complete' | 'break' | 'tick' = 'complete') {
  try {
    audioCtx = audioCtx ?? new (window.AudioContext || (window as any).webkitAudioContext)();
    const now = audioCtx.currentTime;
    const notes = kind === 'complete' ? [523.25, 659.25, 783.99] : kind === 'break' ? [659.25, 523.25] : [880];
    notes.forEach((freq, i) => {
      const o = audioCtx!.createOscillator();
      const g = audioCtx!.createGain();
      o.type = 'sine'; o.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, now + i * 0.18);
      g.gain.exponentialRampToValueAtTime(0.25, now + i * 0.18 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.18 + 0.34);
      o.connect(g).connect(audioCtx!.destination);
      o.start(now + i * 0.18); o.stop(now + i * 0.18 + 0.36);
    });
  } catch { /* audio unavailable — silent, no crash */ }
}
