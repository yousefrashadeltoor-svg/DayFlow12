/* DAYFLOW — Automated core engine & offline integrity test suite
   Run: node tests/core.test.mjs (bundles TS helpers with esbuild automatically) */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

const tmp = '/tmp/dayflow-tests';
fs.mkdirSync(tmp, { recursive: true });
const bundle = (entry, out) => {
  execSync(`npx esbuild ${entry} --bundle --platform=node --format=esm --external:@capacitor-community/sqlite --outfile=${tmp}/${out}`, { stdio: 'pipe' });
  return import(`${tmp}/${out}?t=${Date.now()}`);
};

let passed = 0;
function test(name, fn) {
  try { fn(); console.log(`  PASS  ${name}`); passed++; }
  catch (e) { console.error(`  FAIL  ${name}\n   → ${e.message}`); process.exitCode = 1; }
}

const sched = await bundle('src/lib/scheduler.ts', 'scheduler.mjs');
const prayer = await bundle('src/lib/prayer.ts', 'prayer.mjs');
const occ = await bundle('src/lib/occasions.ts', 'occasions.mjs');

const blk = (id, title, s, e, extra = {}) => ({
  id, title, categoryId: 'study', date: '2026-11-05', startMin: s, endMin: e,
  fixed: false, priority: 2, energy: 'medium', difficulty: 3, status: 'planned',
  recurrence: 'none', reminderMin: 10, sound: 'default', repeatCount: 1, isCritical: false,
  splitAllowed: true, tags: [], notes: '', createdAt: 0, updatedAt: 0, ...extra,
});

console.log('\n[1] Scheduling & Catch-Up Engine');
test('detects overlapping blocks accurately', () => {
  const c = sched.detectConflicts([blk('1', 'A', 540, 630), blk('2', 'B', 600, 690), blk('3', 'C', 700, 760)]);
  assert.equal(c.length, 1);
  assert.equal(c[0].overlapMin, 30);
});
test('cancelled blocks do not cause conflicts', () => {
  const c = sched.detectConflicts([blk('1', 'A', 540, 630), blk('2', 'B', 540, 630, { status: 'cancelled' })]);
  assert.equal(c.length, 0);
});
test('fixed missed blocks are NEVER auto-moved', () => {
  const props = sched.buildCatchUpPlan({
    missed: [blk('f1', 'دكتور', 540, 600, { fixed: true, status: 'missed' })],
    fixed: [], flexible: [], remainingDayMin: 600, preferredHours: { start: 600, end: 900 }, bufferMin: 5,
  });
  assert.equal(props[0].kind, 'advisory');
  assert.equal(props[0].after, null);
});
test('reschedules flexible missed block into free preferred slot without touching fixed', () => {
  const props = sched.buildCatchUpPlan({
    missed: [blk('m1', 'مذاكرة', 480, 540, { status: 'missed' })],
    fixed: [blk('f1', 'شغل', 540, 600, { fixed: true })],
    flexible: [], remainingDayMin: 500, preferredHours: { start: 600, end: 780 }, bufferMin: 10,
  });
  assert.equal(props[0].kind, 'move');
  assert.ok(props[0].after.startMin >= 600 && props[0].after.endMin === props[0].after.startMin + 60);
});
test('moves flexible block to tomorrow when insufficient remaining budget', () => {
  const props = sched.buildCatchUpPlan({
    missed: [blk('m1', 'مشروع طويل', 480, 660, { status: 'missed', splitAllowed: false })],
    fixed: [], flexible: [], remainingDayMin: 30, preferredHours: { start: 600, end: 720 }, bufferMin: 5,
  });
  assert.equal(props[0].kind, 'tomorrow');
});
test('what-if simulation detects conflict without mutating source blocks', () => {
  const src = [blk('1', 'A', 540, 600), blk('2', 'B', 630, 690)];
  const sim = sched.simulateWhatIf(src, { blockId: '1', newStartMin: 600 });
  assert.equal(sim.feasible, false);
  assert.equal(src[0].startMin, 540);
});
test('day capacity catches overload (>14h) and conflicts', () => {
  const cap = sched.dayCapacity([blk('1', 'A', 0, 900)]);
  assert.equal(cap.overload, true);
  assert.equal(cap.overlaps, 0);
});

console.log('\n[2] Visual DayBoard Layout Separation');
// Extract pure layoutBlocks check matching DayBoard.tsx
function layout(blocks, ppm = 1.45, minCardPx = 78) {
  const vis = blocks.map(b => {
    const cleanNote = b.notes ? b.notes.trim() : '';
    const minH = cleanNote ? Math.max(minCardPx, 82) : Math.max(minCardPx - 8, 66);
    const realH = Math.max(8, (b.endMin - b.startMin) * ppm);
    const top = b.startMin * ppm;
    const height = Math.max(minH, realH);
    return { b, top, bottom: top + height + 4, height };
  }).sort((a, z) => a.top - z.top || z.height - a.height);
  const out = []; let cluster = [], end = -Infinity;
  const flush = () => {
    const colsEnd = [], assigned = [];
    for (const v of vis.length ? cluster : []) {
      let col = colsEnd.findIndex(e => e <= v.top + 0.5);
      if (col === -1) { col = colsEnd.length; colsEnd.push(v.bottom); } else colsEnd[col] = v.bottom;
      assigned.push({ v, col });
    }
    for (const a of assigned) out.push({ id: a.v.b.id, col: a.col, cols: colsEnd.length, top: a.v.top, height: a.v.height });
    cluster = []; end = -Infinity;
  };
  for (const v of vis) { if (cluster.length && v.top >= end - 0.5) flush(); cluster.push(v); end = Math.max(end, v.bottom); }
  if (cluster.length) flush();
  return out;
}
test('back-to-back tiny 15-min touching blocks separate side-by-side cleanly with full note room', () => {
  const laid = layout([
    blk('a', 'مكالمة', 540, 555, { notes: 'مع العميل' }),
    blk('b', 'إيميل', 555, 570, { notes: 'بعت التقرير' }),
    blk('c', 'مراجعة', 570, 585, { notes: 'ملف 2' }),
  ]);
  assert.equal(laid.length, 3);
  assert.equal(new Set(laid.map(x => x.col)).size, 3); // all separated in distinct columns
  assert.ok(laid.every(x => x.cols === 3 && x.height >= 82));
});
test('non-overlapping distant blocks keep full 100% width (cols=1)', () => {
  const laid = layout([blk('a', 'صبح', 480, 540), blk('b', 'مساء', 1020, 1080)]);
  assert.ok(laid.every(x => x.cols === 1 && x.col === 0));
});

console.log('\n[3] Egyptian Prayer Times & Qibla (Offline Astronomy)');
test('all 27 Egyptian governorates present with valid Egypt lat/lng bounds', () => {
  assert.equal(prayer.GOVERNORATES.length, 27);
  for (const g of prayer.GOVERNORATES) {
    assert.ok(g.lat >= 22 && g.lat <= 32, `bad lat ${g.id}`);
    assert.ok(g.lng >= 25 && g.lng <= 35, `bad lng ${g.id}`);
  }
});
test('Cairo prayer order & accuracy on winter and summer DST dates', () => {
  const cairo = prayer.govById('cairo');
  const t = prayer.computePrayerTimes(new Date(2026, 10, 5), cairo.lat, cairo.lng);
  assert.ok(t.fajr < t.sunrise && t.sunrise < t.dhuhr && t.dhuhr < t.asr && t.asr < t.maghrib && t.maghrib < t.isha);
  // Expect Fajr around 04:43, Dhuhr around 11:39, Maghrib around 17:05 (in Africa/Cairo)
  if (process.env.TZ === 'Africa/Cairo') {
    assert.ok(Math.abs(t.fajr - (4 * 60 + 43)) <= 2, `fajr=${prayer.fmtHM(t.fajr)}`);
    assert.ok(Math.abs(t.dhuhr - (11 * 60 + 39)) <= 2, `dhuhr=${prayer.fmtHM(t.dhuhr)}`);
    assert.ok(Math.abs(t.maghrib - (17 * 60 + 5)) <= 2, `maghrib=${prayer.fmtHM(t.maghrib)}`);
  }
});
test('post-midnight nextPrayer uses yesterday Isha for real 0..100 progress', () => {
  const cairo = prayer.govById('cairo');
  const late = new Date(2026, 10, 5, 1, 30, 0); // 01:30 AM (past halfway between 18:24 Isha and 04:43 Fajr)
  const np = prayer.nextPrayer(cairo.lat, cairo.lng, {}, late);
  assert.equal(np.name, 'fajr');
  assert.ok(np.progress > 55 && np.progress < 80, `got progress=${np.progress}`);
});
test('Qibla direction from Cairo is ~136° SE (toward Mecca)', () => {
  const c = prayer.govById('cairo');
  const q = prayer.qiblaAngle(c.lat, c.lng);
  assert.ok(q >= 134 && q <= 138, `qibla=${q}`);
});

console.log('\n[4] Egyptian Occasions & Strict Notification Exclusion');
test('ALL Christian & Jewish occasions have notify=false & red religion label', () => {
  const list = occ.occasionsForYear(2026, 0);
  const chr = list.filter(o => o.kind === 'christian');
  const jew = list.filter(o => o.kind === 'jewish');
  assert.ok(chr.length >= 4, 'has Christian dates');
  assert.ok(jew.length >= 3, 'has Jewish dates');
  for (const o of [...chr, ...jew]) {
    assert.equal(o.notify, false, `must not notify: ${o.id}`);
    assert.ok(o.religion === 'مسيحية' || o.religion === 'يهودية', `missing religion on ${o.id}`);
  }
});
test('Islamic & Egyptian national holidays carry notify=true & existing real local photos', () => {
  const list = occ.occasionsForYear(2026, 0);
  const eid = list.filter(o => o.id.startsWith('eid-fitr'));
  const oct6 = list.find(o => o.id.startsWith('oct6'));
  const sham = list.find(o => o.id.startsWith('sham'));
  assert.ok(eid.length === 3 && eid.every(o => o.official && o.notify));
  assert.ok(oct6?.official && oct6.notify);
  assert.ok(sham?.official && sham.notify);
  for (const o of list) {
    assert.ok(fs.existsSync(path.join('public', o.image)), `missing image ${o.image} for ${o.id}`);
    if (o.decor) assert.ok(fs.existsSync(path.join('public/decor', `${o.decor}.png`)), `missing decor ${o.decor}.png`);
  }
});

console.log('\n[5] Offline Integrity & Android Manifest Audit');
test('AndroidManifest: INTERNET is requested ONLY for the opt-in AI assistant (justified), receivers stay private', () => {
  const m = fs.readFileSync('android/app/src/main/AndroidManifest.xml', 'utf8');
  assert.ok(m.includes('permission.INTERNET'), 'assistant needs INTERNET');
  assert.ok(/INTERNET is used ONLY by the optional AI assistant/.test(m), 'justification comment must be present');
  assert.equal((m.match(/permission\.INTERNET"/g) || []).length, 1, 'INTERNET declared exactly once');
  assert.ok(m.includes('WidgetTickReceiver') && m.includes('AlarmRingActivity') && m.includes('PrayerWidgetProvider'));
  for (const r of ['AlarmReceiver', 'NotificationActionReceiver', 'AlarmStopReceiver', 'WidgetActionReceiver', 'WidgetTickReceiver']) {
    assert.ok(m.includes(`android:name=".${r}" android:exported="false"`), `${r} must not be exported`);
  }
});
test('zero remote CDN image/font URLs outside the opt-in AI feature (src/ and index.html)', () => {
  const walk = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]);
  const aiOptIn = f => f.startsWith('src/lib/ai/') || f.endsWith('AssistantScreen.tsx') || f.endsWith('AssistantSettings.tsx');
  for (const f of [...walk('src'), 'index.html'].filter(f => !aiOptIn(f))) {
    const txt = fs.readFileSync(f, 'utf8');
    assert.ok(!/https?:\/\//.test(txt), `external URL found in ${f}`);
  }
});
test('every referenced /media/* and /decor/* asset exists locally on disk', () => {
  const walk = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]);
  const missing = [];
  for (const f of walk('src')) {
    const txt = fs.readFileSync(f, 'utf8');
    for (const m of txt.matchAll(/['"`](\/(media|decor|icons)\/[a-zA-Z0-9_.-]+\.(png|jpg|jpeg))['"`]/g)) {
      if (!fs.existsSync(path.join('public', m[1]))) missing.push(`${f}: ${m[1]}`);
    }
    for (const m of txt.matchAll(/D\('([a-z0-9-]+)'\)/g)) {
      if (!fs.existsSync(path.join('public/decor', `${m[1]}.png`))) missing.push(`${f}: /decor/${m[1]}.png`);
    }
  }
  assert.deepEqual(missing, []);
});

console.log(`\n✓ ${passed} tests passed.\n`);
