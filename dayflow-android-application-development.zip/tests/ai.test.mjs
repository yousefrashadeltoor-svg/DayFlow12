/* DAYFLOW — AI assistant test suite: natural-language parsing, real free-tier classification, sorting,
   logo coverage, and a guarantee that every advertised tool has a real executor. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { execSync } from 'node:child_process';

const tmp = '/tmp/dayflow-tests';
fs.mkdirSync(tmp, { recursive: true });
const bundle = (entry, out) => {
  execSync(`npx esbuild ${entry} --bundle --platform=node --format=esm --outfile=${tmp}/${out}`, { stdio: 'pipe' });
  return import(`${tmp}/${out}?t=${Date.now()}`);
};

const P = await bundle('src/lib/ai/parse.ts', 'ai-parse.mjs');
const V = await bundle('src/lib/ai/providers.ts', 'ai-providers.mjs');

let passed = 0;
const t = (name, fn) => { try { fn(); console.log(`  PASS  ${name}`); passed++; } catch (e) { console.error(`  FAIL  ${name}\n   → ${e.message}`); process.exitCode = 1; } };

console.log('\n[A] Natural language time/day/date parsing (Arabic & English)');
t('parses Egyptian time phrases', () => {
  assert.equal(P.parseTimeMin('٧ الصبح'), 7 * 60);
  assert.equal(P.parseTimeMin('7 م'), 19 * 60);
  assert.equal(P.parseTimeMin('9 بالليل'), 21 * 60);
  assert.equal(P.parseTimeMin('12 الصبح'), 0);
  assert.equal(P.parseTimeMin('7:30'), 7 * 60 + 30);
  assert.equal(P.parseTimeMin('19:05'), 19 * 60 + 5);
  assert.equal(P.parseTimeMin('5 العصر'), 17 * 60);
  assert.equal(P.parseTimeMin('7pm'), 19 * 60);
  assert.equal(P.parseTimeMin('nonsense'), null);
});
t('parses weekday names and presets', () => {
  assert.deepEqual(P.parseDays('كل يوم'), [0, 1, 2, 3, 4, 5, 6]);
  assert.deepEqual(P.parseDays('أيام الشغل'), [0, 1, 2, 3, 4]);
  assert.deepEqual(P.parseDays('الويك اند'), [5, 6]);
  assert.deepEqual(P.parseDays(['الاتنين', 'الأحد']), [0, 1]);
  assert.deepEqual(P.parseDays('مرة واحدة'), []);
});
t('parses dates: today, tomorrow, after tomorrow, ISO, dd/mm', () => {
  const now = new Date(2026, 10, 5, 10);
  assert.equal(P.parseDate('النهارده', now), '2026-11-05');
  assert.equal(P.parseDate('بكرة', now), '2026-11-06');
  assert.equal(P.parseDate('بعد بكرة', now), '2026-11-07');
  assert.equal(P.parseDate('2026-12-31', now), '2026-12-31');
  assert.equal(P.parseDate('25/12', now), '2026-12-25');
  assert.equal(P.parseDate('غير تاريخ', now), null);
});
t('maps Arabic categories to real category ids', () => {
  assert.equal(P.parseCategory('مذاكرة'), 'study');
  assert.equal(P.parseCategory('رياضة'), 'exercise');
  assert.equal(P.parseCategory('صلاة'), 'prayer');
  assert.equal(P.parseCategory('أي حاجة'), 'personal');
});
t('clampInt and matchScore are safe', () => {
  assert.equal(P.clampInt(999, 1, 30, 10), 30);
  assert.equal(P.clampInt('x', 1, 30, 10), 10);
  assert.ok(P.matchScore('كيمياء', 'مذاكرة كيمياء') >= 60);
  assert.equal(P.matchScore('', 'x'), 0);
});

console.log('\n[B] Real free-tier classification & sorting');
t('OpenRouter: :free suffix and zero pricing are classified as FREE; others PAID', () => {
  const list = V.classifyOpenRouter([
    { id: 'google/gemma-4-31b-it:free', pricing: { prompt: '0', completion: '0' }, context_length: 262144 },
    { id: 'stealth/zero-priced', pricing: { prompt: '0', completion: '0' } },
    { id: 'anthropic/claude-sonnet-4.5', pricing: { prompt: '0.000003', completion: '0.000015' } },
    { id: 'openai/gpt-oss-120b', pricing: { prompt: '0.00000015', completion: '0.0000006' }, supported_parameters: ['tools'] },
  ]);
  const byId = Object.fromEntries(list.map(m => [m.id, m]));
  assert.equal(byId['google/gemma-4-31b-it:free'].tier, 'free');
  assert.equal(byId['stealth/zero-priced'].tier, 'free');
  assert.equal(byId['anthropic/claude-sonnet-4.5'].tier, 'paid');
  assert.equal(byId['openai/gpt-oss-120b'].tier, 'paid');
  assert.equal(byId['openai/gpt-oss-120b'].tools, true);
  assert.equal(byId['google/gemma-4-31b-it:free'].context, '262K');
});
t('sortModels puts free first, then credit, then paid', () => {
  const sorted = V.sortModels([
    { id: 'a', name: 'Zeta', family: 'x', tier: 'paid' },
    { id: 'b', name: 'Alpha', family: 'x', tier: 'credit' },
    { id: 'c', name: 'Mid', family: 'x', tier: 'free' },
    { id: 'd', name: 'Beta', family: 'x', tier: 'free' },
  ]);
  assert.deepEqual(sorted.map(m => m.tier), ['free', 'free', 'credit', 'paid']);
  assert.equal(sorted[0].name, 'Beta');
});
t('every provider has a valid base URL, a tier, and at least one model', () => {
  assert.ok(V.PROVIDERS.length >= 10, 'at least 10 providers');
  for (const p of V.PROVIDERS) {
    assert.ok(/^https:\/\//.test(p.baseUrl), `${p.id} must use https`);
    assert.ok(['free', 'credit', 'paid'].includes(p.tier));
    assert.ok(p.models.length > 0, `${p.id} has models`);
    assert.ok(p.mono && p.color, `${p.id} has a fallback logo`);
  }
});
t('Groq is listed as free and includes gpt-oss models (current free catalogue)', () => {
  const g = V.PROVIDERS.find(p => p.id === 'groq');
  assert.equal(g.tier, 'free');
  assert.ok(g.models.some(m => m.id === 'openai/gpt-oss-120b' && m.tier === 'free'));
});
t('family detection maps model ids to logos', () => {
  assert.equal(V.familyOf('meta-llama/Llama-3.1-8B-Instruct'), 'meta');
  assert.equal(V.familyOf('openai/gpt-oss-120b'), 'openai');
  assert.equal(V.familyOf('qwen/qwen3.8-27b'), 'qwen');
  assert.equal(V.familyOf('google/gemma-4-31b-it:free'), 'google');
  assert.equal(V.familyOf('deepseek-chat'), 'deepseek');
  assert.equal(V.familyOf('unknown-model'), 'generic');
});
t('every brand logo referenced by a provider or family exists in the bundled icon set', () => {
  for (const p of V.PROVIDERS) if (p.icon) assert.ok(V.BRAND_ICONS[p.icon], `missing brand icon for ${p.id}`);
  for (const [fam, l] of Object.entries(V.FAMILY_LOGO)) if (l.icon) assert.ok(V.BRAND_ICONS[l.icon], `missing family icon ${fam}`);
});

console.log('\n[C] Agent tools are real (every advertised tool has an executor)');
t('TOOL_SPECS names are unique and each one is implemented in tools.ts', () => {
  const src = fs.readFileSync('src/lib/ai/tools.ts', 'utf8');
  const specNames = [...src.matchAll(/name: '([a-z_]+)', description/g)].map(m => m[1]);
  assert.equal(new Set(specNames).size, specNames.length, 'duplicate tool names');
  assert.ok(specNames.length >= 25, `expected ≥25 tools, got ${specNames.length}`);
  for (const n of specNames) assert.ok(src.includes(`case '${n}':`), `no executor for tool ${n}`);
});
t('destructive tools always return a pending confirmation (never delete directly)', () => {
  const src = fs.readFileSync('src/lib/ai/tools.ts', 'utf8');
  for (const n of ['delete_alarm', 'delete_activity', 'delete_task']) {
    const block = src.slice(src.indexOf(`case '${n}':`), src.indexOf(`case '`, src.indexOf(`case '${n}':`) + 10));
    assert.ok(/pending/.test(block), `${n} must return pending`);
    assert.ok(!/db\.del\(/.test(block), `${n} must not delete directly`);
  }
});
t('agent loop is bounded and has a text-protocol fallback for models without tools', () => {
  const src = fs.readFileSync('src/lib/ai/agent.ts', 'utf8');
  assert.ok(/MAX_STEPS\s*=\s*\d+/.test(src));
  assert.ok(src.includes('parseTextToolCalls'));
});
t('no assistant code path hardcodes an API key', () => {
  for (const f of ['src/lib/ai/providers.ts', 'src/lib/ai/client.ts', 'src/lib/ai/agent.ts', 'src/lib/ai/tools.ts', 'src/lib/ai/config.ts']) {
    const txt = fs.readFileSync(f, 'utf8');
    assert.ok(!/(gsk_|sk-[A-Za-z0-9]{16,}|nvapi-|hf_[A-Za-z0-9]{16,})/.test(txt), `hardcoded key pattern in ${f}`);
  }
});

console.log(`\n✓ ${passed} AI tests passed.\n`);
