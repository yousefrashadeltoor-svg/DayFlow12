/* DAYFLOW — Tests for brand wordmark, onboarding credit, decoration mixing/auto logic and live catalogue honesty. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { execSync } from 'node:child_process';

const tmp = '/tmp/dayflow-tests';
fs.mkdirSync(tmp, { recursive: true });
const bundle = (entry, out) => {
  execSync(`npx esbuild ${entry} --bundle --platform=node --format=esm --outfile=${tmp}/${out}`, { stdio: 'pipe' });
  return import(`${tmp}/${out}?t=${Date.now()}`);
};

const S = await bundle('src/components/Seasonal.tsx', 'seasonal.mjs');
const A = await bundle('src/components/BrandBlockArt.tsx', 'brand.mjs');
const L = await bundle('src/lib/ai/liveCatalog.ts', 'live-catalog.mjs');
const V = await bundle('src/lib/ai/providers.ts', 'providers.mjs');

let passed = 0;
const t = (name, fn) => { try { fn(); console.log(`  PASS  ${name}`); passed++; } catch (e) { console.error(`  FAIL  ${name}\n   → ${e.message}`); process.exitCode = 1; } };

console.log('\n[1] Exact brand wordmark (byte-for-byte)');
t('two art lines are exactly what the user wrote', () => {
  assert.equal(A.BRAND_ART_LINE_1, '█▀▄ ▄▀█ █▄█   █▀▀ █░░ █▀█ █░█░█');
  assert.equal(A.BRAND_ART_LINE_2, '█▄▀ █▀█ ░█░   █▀░ █▄▄ █▄█ ▀▄▀▄▀');
  assert.equal(A.BRAND_ART_LINE_1.length, 31);
  assert.equal(A.BRAND_ART_LINE_2.length, 31);
});
t('wordmark renders at top-right of hero with LTR isolation and no text transformation', () => {
  const seasonal = fs.readFileSync('src/components/Seasonal.tsx', 'utf8');
  const css = fs.readFileSync('src/index.css', 'utf8');
  assert.ok(seasonal.includes('<BrandBlockArt />'));
  assert.ok(/absolute top-1\.5 end-3 z-\[3\] text-right/.test(seasonal));
  assert.ok(css.includes('direction: ltr') && css.includes('unicode-bidi: isolate') && css.includes('white-space: pre'));
  assert.ok(css.includes('text-transform: none') && css.includes('font-variant-ligatures: none'));
});
t('app is named 𝐃α𝗒 𝐅ᥣⱺω everywhere visible', () => {
  const all = ['index.html', 'public/manifest.json', 'src/lib/i18n.ts', 'src/App.tsx'].map(f => fs.readFileSync(f, 'utf8')).join('\n');
  assert.ok(all.includes('𝐃α𝗒 𝐅ᥣⱺω'));
  assert.ok(fs.readFileSync('index.html', 'utf8').includes('<title>𝐃α𝗒 𝐅ᥣⱺω'));
});
t('By,Joseph appears at the bottom of EVERY onboarding page', () => {
  const src = fs.readFileSync('src/screens/Onboarding.tsx', 'utf8');
  assert.ok(src.includes('By,Joseph'));
  // Fixed footer credit renders on all 6 pages, plus inline credit on the intro slides
  assert.ok(/by-joseph mb-3/.test(src) && /by-joseph mt-5/.test(src));
  assert.ok(fs.readFileSync('src/index.css', 'utf8').includes('.by-joseph'));
});

console.log('\n[2] Decoration gallery, auto activation & 3-scene limit');
t('all requested seasons & occasions exist with real offline assets', () => {
  const ids = Object.keys(S.SCENES);
  for (const id of ['ramadan', 'eidFitr', 'eidAdha', 'winter', 'autumn', 'spring', 'summer', 'newyear', 'nye', 'exams', 'school', 'october', 'national', 'sham', 'islamic']) {
    assert.ok(ids.includes(id), `missing scene ${id}`);
    const sc = S.SCENES[id];
    assert.ok(sc.photos.length && sc.particles.length >= 3, `${id} too few assets`);
    assert.ok(sc.hang.length >= 4, `${id} needs a hanging garland`);
    for (const f of [...sc.photos, ...sc.particles, ...sc.hang, sc.corner, sc.corner2, sc.corner3].filter(Boolean)) {
      assert.ok(fs.existsSync('public/' + f.replace(/^\//, '')), `missing asset ${f} for ${id}`);
    }
  }
});
t('auto mode activates the right scene by real date (Ramadan, 6 Oct, winter, spring, summer)', () => {
  const r = new Date(2026, 2, 1); // approx Ramadan 1447
  const oct = S.sceneFor(new Date(2026, 9, 6), 0, 'auto');
  assert.equal(oct.id, 'october');
  assert.equal(S.sceneFor(new Date(2026, 0, 10), 0, 'auto').id, 'winter');
  assert.equal(S.sceneFor(new Date(2026, 3, 15), 0, 'auto').id, 'spring');
  assert.equal(S.sceneFor(new Date(2026, 7, 10), 0, 'auto').id, 'summer');
  assert.equal(S.sceneFor(new Date(2026, 9, 20), 0, 'auto').id, 'autumn');
  assert.equal(S.sceneFor(new Date(2026, 9, 1), 0, 'auto').id, 'school');
  assert.equal(S.sceneFor(new Date(2026, 5, 10), 0, 'auto').id, 'exams');
  void r;
});
t('activeScenes: auto by date > mix up to 3 > single override', () => {
  const base = { decorOverride: 'auto', decorMix: [], hijriOffset: 0 };
  const auto = S.activeScenes(base, new Date(2026, 9, 6));
  assert.equal(auto.length, 1);
  assert.equal(auto[0].id, 'october');
  const mixed = S.activeScenes({ ...base, decorMix: ['ramadan', 'autumn', 'winter'] }, new Date(2026, 5, 1));
  assert.equal(mixed.length, 3);
  assert.deepEqual(mixed.map(s => s.id), ['ramadan', 'autumn', 'winter']);
  const capped = S.activeScenes({ ...base, decorMix: ['ramadan', 'autumn', 'winter', 'spring'] }, new Date(2026, 5, 1));
  assert.equal(capped.length, 3);
  const override = S.activeScenes({ ...base, decorOverride: 'ramadan', decorMix: ['autumn'] }, new Date(2026, 5, 1));
  assert.equal(override.length, 1);
  assert.equal(override[0].id, 'ramadan');
});
t('gallery enforces 3-scene limit with an honest CPU warning', () => {
  const src = fs.readFileSync('src/screens/DecorGallery.tsx', 'utf8');
  assert.ok(/MAX_MIX\s*=\s*3/.test(src));
  assert.ok(/current\.length >= MAX_MIX/.test(src));
  assert.ok(src.includes('المعالج') || src.includes('CPU'));
  assert.ok(src.includes('DecorPreview'));
});
t('behind-content mode is still visible (CSS translucency, not hidden)', () => {
  const css = fs.readFileSync('src/index.css', 'utf8');
  const app = fs.readFileSync('src/App.tsx', 'utf8');
  assert.ok(css.includes('[data-decor-below="true"]'));
  assert.ok(css.includes('color-mix(in srgb, var(--surface) 88%, transparent)'));
  assert.ok(app.includes('data-decor-below'));
  const seasonal = fs.readFileSync('src/components/Seasonal.tsx', 'utf8');
  assert.ok(seasonal.includes('decor-static-corner') && seasonal.includes('decor-static-top'), 'static ornaments must exist');
  assert.ok(/above \? 0\.95 : 0\.62/.test(seasonal), 'behind content must be lighter but visible');
});

console.log('\n[3] Honest AI catalogue');
t('live filter excludes audio/TTS/embedding/music models', () => {
  const raw = [
    { id: 'whisper-large-v3' }, { id: 'google/lyria-3-pro-preview' },
    { id: 'text-embedding-3-small' }, { id: 'openai/gpt-oss-120b' }, { id: 'google/gemma-4-31b-it:free' },
  ];
  const kept = raw.filter(m => !/(whisper|tts|speech|audio|embedding|lyria|music)/i.test(m.id));
  assert.ok(!kept.some(m => /whisper|lyria|embedding/.test(m.id)));
  assert.ok(kept.some(m => m.id.includes('gemma')));
});
t('no stale free OpenRouter models remain in static hints', () => {
  const p = V.PROVIDERS.find(x => x.id === 'openrouter');
  assert.ok(p.models.length >= 12, 'full live free set represented');
  assert.ok(!p.models.some(m => m.id.includes('qwen3-next') || m.id.includes('nemotron-3-super-120b')), 'stale ids removed');
});
t('Cerebras is honestly credit (not permanently free); Mistral Small is paid', () => {
  const c = V.PROVIDERS.find(x => x.id === 'cerebras');
  const m = V.PROVIDERS.find(x => x.id === 'mistral');
  assert.equal(c.tier, 'credit');
  assert.ok(c.models.every(x => x.tier === 'credit'));
  assert.equal(m.models.find(x => x.id === 'mistral-small-latest').tier, 'paid');
  assert.equal(m.models.find(x => x.id === 'open-mistral-nemo').tier, 'free');
});
t('live catalogue module exposes refresh + real per-model verification', () => {
  assert.equal(typeof L.fetchLiveModels, 'function');
  assert.equal(typeof L.refreshCatalog, 'function');
  assert.equal(typeof L.verifyModel, 'function');
  assert.deepEqual(L.FREE_HINTS.cerebras, []);
});

console.log(`\n✓ ${passed} decoration/brand/catalogue tests passed.\n`);
