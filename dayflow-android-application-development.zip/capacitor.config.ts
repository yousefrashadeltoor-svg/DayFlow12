import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dayflow.app',
  appName: 'DAYFLOW',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    SplashScreen: { launchAutoHide: false },
    CapacitorHttp: { enabled: true },
  },
};

export default config;
